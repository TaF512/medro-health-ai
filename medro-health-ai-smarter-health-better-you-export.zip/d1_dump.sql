PRAGMA defer_foreign_keys=TRUE;
CREATE TABLE _mocha_migrations (
number     INTEGER UNIQUE,
up_sql     TEXT NOT NULL,
down_sql   TEXT NOT NULL,
applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);
INSERT INTO "_mocha_migrations" ("number","up_sql","down_sql","applied_at") VALUES(1,replace('\nCREATE TABLE users (\n  id INTEGER PRIMARY KEY AUTOINCREMENT,\n  mocha_user_id TEXT NOT NULL UNIQUE,\n  email TEXT NOT NULL,\n  name TEXT,\n  avatar_url TEXT,\n  role TEXT,\n  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);\n\nCREATE INDEX idx_users_mocha_user_id ON users(mocha_user_id);\nCREATE INDEX idx_users_role ON users(role);\n','\n',char(10)),replace('\nDROP INDEX idx_users_role;\nDROP INDEX idx_users_mocha_user_id;\nDROP TABLE users;\n','\n',char(10)),'2026-02-19 12:16:03');
INSERT INTO "_mocha_migrations" ("number","up_sql","down_sql","applied_at") VALUES(2,replace('\nCREATE TABLE patient_profiles (\n  id INTEGER PRIMARY KEY AUTOINCREMENT,\n  user_id INTEGER NOT NULL UNIQUE,\n  full_name TEXT,\n  date_of_birth DATE,\n  sex TEXT,\n  height_cm REAL,\n  weight_kg REAL,\n  blood_group TEXT,\n  conditions TEXT,\n  allergies TEXT,\n  current_medications TEXT,\n  emergency_contact_name TEXT,\n  emergency_contact_phone TEXT,\n  is_blood_donor INTEGER DEFAULT 0,\n  is_blood_group_public INTEGER DEFAULT 0,\n  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);\n\nCREATE INDEX idx_patient_profiles_user_id ON patient_profiles(user_id);\nCREATE INDEX idx_patient_profiles_blood_group ON patient_profiles(blood_group);\n','\n',char(10)),replace('\nDROP INDEX idx_patient_profiles_blood_group;\nDROP INDEX idx_patient_profiles_user_id;\nDROP TABLE patient_profiles;\n','\n',char(10)),'2026-02-19 12:16:03');
INSERT INTO "_mocha_migrations" ("number","up_sql","down_sql","applied_at") VALUES(3,replace('CREATE TABLE doctor_profiles (\n  id INTEGER PRIMARY KEY AUTOINCREMENT,\n  user_id INTEGER NOT NULL UNIQUE,\n  full_name TEXT,\n  photo_url TEXT,\n  specialty TEXT,\n  languages TEXT,\n  country_of_residence TEXT,\n  bio TEXT,\n  price_amount REAL,\n  price_currency TEXT DEFAULT ''GBP'',\n  availability TEXT,\n  scope TEXT DEFAULT ''guidance_only'',\n  licensed_countries TEXT,\n  license_details TEXT,\n  verification_status TEXT DEFAULT ''pending'',\n  rating REAL,\n  total_consultations INTEGER DEFAULT 0,\n  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);\n\nCREATE INDEX idx_doctor_profiles_user_id ON doctor_profiles(user_id);\nCREATE INDEX idx_doctor_profiles_specialty ON doctor_profiles(specialty);\nCREATE INDEX idx_doctor_profiles_verification_status ON doctor_profiles(verification_status);','\n',char(10)),replace('DROP INDEX idx_doctor_profiles_verification_status;\nDROP INDEX idx_doctor_profiles_specialty;\nDROP INDEX idx_doctor_profiles_user_id;\nDROP TABLE doctor_profiles;','\n',char(10)),'2026-02-25 17:29:45');
CREATE TABLE users (
id INTEGER PRIMARY KEY AUTOINCREMENT,
mocha_user_id TEXT NOT NULL UNIQUE,
email TEXT NOT NULL,
name TEXT,
avatar_url TEXT,
role TEXT,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "users" ("id","mocha_user_id","email","name","avatar_url","role","created_at","updated_at") VALUES(1,'019c75d5-8292-7536-a4ff-f3bd6b7fb1fc','tafsirulsalha213@gmail.com','ABCD XYZ','https://lh3.googleusercontent.com/a/ACg8ocIi_PG-mm4kVbsMloya75_twZIu4XRIXQWb3VLYf8yUZ8uOuA=s96-c','patient','2026-02-19 12:17:34','2026-02-19 12:17:37');
INSERT INTO "users" ("id","mocha_user_id","email","name","avatar_url","role","created_at","updated_at") VALUES(2,'019c75d9-b0a9-7758-b8a1-c914d0c24f0e','rafidanish252@gmail.com','Danish Rafi','https://lh3.googleusercontent.com/a/ACg8ocKyfPU3t5K8K_zIhSmLVxI94fEo9UAN8dq-OQ4ni_eJz9sj2g=s96-c','patient','2026-02-19 12:22:08','2026-02-19 12:22:10');
INSERT INTO "users" ("id","mocha_user_id","email","name","avatar_url","role","created_at","updated_at") VALUES(3,'019c7716-0b7f-720d-a93e-e9d32ffd8c3b','noman3056@gmail.com','Noman Mansuri','https://lh3.googleusercontent.com/a/ACg8ocJ1u_hvPGLO-g_mRUqMQbhFTsMbOFl41PwMgaS97MzkID0XJw=s96-c','patient','2026-02-19 18:07:41','2026-02-19 18:08:20');
INSERT INTO "users" ("id","mocha_user_id","email","name","avatar_url","role","created_at","updated_at") VALUES(4,'019c7824-c9a3-7c34-9e99-bf66a5975fcc','sixsinister783@gmail.com','Sinister Six','https://lh3.googleusercontent.com/a/ACg8ocK7VI5ahPO36hT8ZFdQW-VUtnXWcNN34C1QmIGuatibMuwzwA=s96-c','doctor','2026-02-19 23:03:24','2026-02-19 23:03:27');
INSERT INTO "users" ("id","mocha_user_id","email","name","avatar_url","role","created_at","updated_at") VALUES(5,'019c7a90-b28d-7897-ac14-17e9f0f1edc2','monaf_mo@yahoo.com','Mo Monaf','https://lh3.googleusercontent.com/a/ACg8ocIUvNF_dfgxlOBitwOqfM05kCPrnEkEyKquagoHBEl_x9D_2lk=s96-c','patient','2026-02-20 10:20:30','2026-02-20 10:20:44');
INSERT INTO "users" ("id","mocha_user_id","email","name","avatar_url","role","created_at","updated_at") VALUES(6,'019c7c55-217c-7afa-b830-a0e1e53862ad','tafsirulislam456@gmail.com','Tafsirul Islam','https://lh3.googleusercontent.com/a/ACg8ocKWozUJHIazwehSo2q2aQxXg9vCmD4R-OJ-rDui3qfxYlmmgA=s96-c','patient','2026-02-20 18:34:41','2026-02-20 18:34:52');
CREATE TABLE patient_profiles (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id INTEGER NOT NULL UNIQUE,
full_name TEXT,
date_of_birth DATE,
sex TEXT,
height_cm REAL,
weight_kg REAL,
blood_group TEXT,
conditions TEXT,
allergies TEXT,
current_medications TEXT,
emergency_contact_name TEXT,
emergency_contact_phone TEXT,
is_blood_donor INTEGER DEFAULT 0,
is_blood_group_public INTEGER DEFAULT 0,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "patient_profiles" ("id","user_id","full_name","date_of_birth","sex","height_cm","weight_kg","blood_group","conditions","allergies","current_medications","emergency_contact_name","emergency_contact_phone","is_blood_donor","is_blood_group_public","created_at","updated_at") VALUES(1,6,'Tafsirul Islam',NULL,NULL,NULL,NULL,'O+','[]',NULL,'[]',NULL,NULL,1,1,'2026-04-19 04:11:38','2026-04-19 04:11:38');
CREATE TABLE doctor_profiles (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id INTEGER NOT NULL UNIQUE,
full_name TEXT,
photo_url TEXT,
specialty TEXT,
languages TEXT,
country_of_residence TEXT,
bio TEXT,
price_amount REAL,
price_currency TEXT DEFAULT 'GBP',
availability TEXT,
scope TEXT DEFAULT 'guidance_only',
licensed_countries TEXT,
license_details TEXT,
verification_status TEXT DEFAULT 'pending',
rating REAL,
total_consultations INTEGER DEFAULT 0,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
DELETE FROM sqlite_sequence;
INSERT INTO "sqlite_sequence" ("name","seq") VALUES('users',6);
INSERT INTO "sqlite_sequence" ("name","seq") VALUES('patient_profiles',1);
CREATE INDEX idx_users_mocha_user_id ON users(mocha_user_id);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_patient_profiles_user_id ON patient_profiles(user_id);
CREATE INDEX idx_patient_profiles_blood_group ON patient_profiles(blood_group);
CREATE INDEX idx_doctor_profiles_user_id ON doctor_profiles(user_id);
CREATE INDEX idx_doctor_profiles_specialty ON doctor_profiles(specialty);
CREATE INDEX idx_doctor_profiles_verification_status ON doctor_profiles(verification_status);
