# Todo
- #64: Complete camera barcode scanning (initialize Html5Qrcode, add camera UI)
- #65: Add drink search API endpoint with AI for calories/sugar lookup
- #66: Update barcode modal with camera view + drink search tabs
- #67: Update FoodSettings to include drink/beverage goals (sugar, caffeine limits)
- #61: Add Hindi, Spanish, French, German, Urdu, Portuguese translations
- #62: Update Tracker.tsx and food pages to use t() translation function
- #63: Update Rewards, BloodDonors, Appointments pages to use translations
- #60: Add /api/supplement-recommendations AI endpoint for personalized supplement advice

- ~~#58: Update TestDetail.tsx to show 3-option collection method selection (nurse visit, self-kit, lab visit) with pricing~~ ✅
- #59: Rewrite Pharmacy.tsx with NHS approved + Carepoint + fast delivery ordering
- #60: Apply language translations throughout the app UI
- #61: Make notification bar working across the app

## Completed this session:
- ~~Renamed app from "Carely" to "Medro Health AI"~~ ✅
- ~~Updated logo throughout (Login, Header, favicon, social meta)~~ ✅
- ~~Updated all branding text across worker and frontend~~ ✅
- Floating currency button (round button with flag in corner instead of taking space)
- Doctors licensed in multiple countries now show badges with all licensed country flags
- Tests with 2+ components now show "What's included" preview in TestCard
- Gemini AI integration for Remedy Search (dynamic natural remedies)
- Gemini AI integration for Symptom Checker (AI analysis)
- New Medication Encyclopedia page (benefits, risks, long-term effects)

## Remaining:

## New Features (Current Request)
- #50: Language selector with full app translation (EN, BN, AR, ZH, ES, FR, DE, HI)
- #51: Merge Nutrition into Health Tracker as "Food & Nutrition Log"
- #52: AI-powered Health Tracker with daily recommendations
- #53: Supplement/vitamin tracking (zinc, vitamins, etc.)
- #54: NHS Appointments tracker in More section
- #55: Lab Test Results with AI analysis
- #56: NHS API integration for importing results

## Completed
- ✅ Cart system with VAT/service charge/commission breakdown
- ✅ Medication countdown timer with digital/analog switching
- ✅ Lab test cart integration with cost breakdown
- ✅ Doctor booking cart integration

## Remaining

## Phase 1: Country-Based Regulation System (NEW)
- ~~#40: Database migrations - add country fields, create doctor_profiles table~~ ✅
- ~~#41: Update signup flow with country selector~~ ✅
- ~~#42: Doctor onboarding flow (basic profile + scope + licensing)~~ ✅
- ~~#43: Country-based doctor filtering in doctor finder~~ ✅
- ~~#44: Foreign doctor notice modal + guidance-only mode~~ ✅
- #45: Safety disclaimers + emergency detection
- ~~#46: Update doctor cards with licensing/verification badges~~ ✅

## Phase 3: Additional Features (NEW)
- ~~#47: Lab tests country filter + map view for nearest labs~~ ✅
- ~~#48: Login page terms & conditions checkbox~~ ✅
- #49: Country flags in profiles (partially done - profile page complete, health profile country selector added)

## Phase 2: Remaining Features
- #24: Build consultation room (video/audio/text interface)
- #25: Add prescription issuance for doctors after consultation
- #15: Create health history timeline
- #16: Add symptom diary with calendar view
- #18: Add adherence tracking and notifications UI

## Completed Features
- ~~#11: Authentication with Google OAuth + role selection~~ ✅
- ~~#12: Patient profile with health data fields~~ ✅
- ~~#13: Blood group matching with privacy controls~~ ✅
- ~~#22-23: Doctor booking flow with payment~~ ✅
- ~~#26-29: Doctor dashboard (schedule, messages, analytics, patients)~~ ✅
- ~~#14, #17: Prescriptions, medication reminders~~ ✅
- ~~#30-34: Rewards, pharmacy ordering~~ ✅
- ~~#5, #20-21: Symptom checker, More menu, guest mode~~ ✅
