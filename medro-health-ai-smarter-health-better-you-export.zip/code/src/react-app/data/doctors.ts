export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  specialtyId: string;
  image: string;
  rating: number;
  reviews: number;
  price: number;
  currency: string;
  originalPrice?: number;
  isVerified: boolean;
  isOnline: boolean;
  languages: string[];
  hospital: string;
  experience: number;
  consultationType: ('video' | 'voice' | 'chat')[];
  nextAvailable: string;
  country: string;
  countryFlag: string;
  licensedCountries: string[];
  scope: 'guidance_only' | 'licensed_clinical';
}

export const doctors: Doctor[] = [
  // Bangladesh Doctors (BDT: ৳300-1500 typical)
  {
    id: '1',
    name: 'Dr. Sarah Ahmed',
    specialty: 'General Physician',
    specialtyId: 'general',
    image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200&h=200&fit=crop&crop=face',
    rating: 4.9,
    reviews: 234,
    price: 600,
    currency: 'BDT',
    originalPrice: 800,
    isVerified: true,
    isOnline: true,
    languages: ['English', 'Bengali'],
    hospital: 'City Medical Center',
    experience: 12,
    consultationType: ['video', 'chat'],
    nextAvailable: 'Today, 3:00 PM',
    country: 'BD',
    countryFlag: '🇧🇩',
    licensedCountries: ['BD'],
    scope: 'licensed_clinical'
  },
  {
    id: '2',
    name: 'Dr. Mohammad Rahman',
    specialty: 'Cardiologist',
    specialtyId: 'cardiology',
    image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop&crop=face',
    rating: 4.8,
    reviews: 189,
    price: 1500,
    currency: 'BDT',
    originalPrice: 2000,
    isVerified: true,
    isOnline: false,
    languages: ['English', 'Bengali', 'Arabic'],
    hospital: 'Heart Care Hospital',
    experience: 18,
    consultationType: ['video', 'voice', 'chat'],
    nextAvailable: 'Tomorrow, 10:00 AM',
    country: 'BD',
    countryFlag: '🇧🇩',
    licensedCountries: ['BD', 'IN'],
    scope: 'licensed_clinical'
  },
  {
    id: '3',
    name: 'Dr. Fatima Khan',
    specialty: 'Gynecologist',
    specialtyId: 'gynae',
    image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=200&h=200&fit=crop&crop=face',
    rating: 4.9,
    reviews: 312,
    price: 1000,
    currency: 'BDT',
    isVerified: true,
    isOnline: true,
    languages: ['English', 'Bengali'],
    hospital: 'Women\'s Health Clinic',
    experience: 15,
    consultationType: ['video', 'chat'],
    nextAvailable: 'Today, 5:30 PM',
    country: 'BD',
    countryFlag: '🇧🇩',
    licensedCountries: ['BD'],
    scope: 'licensed_clinical'
  },
  // UK Doctors (GBP: £50-150 typical)
  {
    id: '4',
    name: 'Dr. James Wilson',
    specialty: 'Dermatologist',
    specialtyId: 'dermatology',
    image: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=200&h=200&fit=crop&crop=face',
    rating: 4.7,
    reviews: 156,
    price: 75,
    currency: 'GBP',
    originalPrice: 95,
    isVerified: true,
    isOnline: true,
    languages: ['English'],
    hospital: 'London Skin Clinic',
    experience: 10,
    consultationType: ['video', 'voice', 'chat'],
    nextAvailable: 'Today, 4:00 PM',
    country: 'GB',
    countryFlag: '🇬🇧',
    licensedCountries: ['GB', 'IE'],
    scope: 'licensed_clinical'
  },
  {
    id: '5',
    name: 'Dr. Emma Thompson',
    specialty: 'Pediatrician',
    specialtyId: 'pediatrics',
    image: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=200&h=200&fit=crop&crop=face',
    rating: 4.9,
    reviews: 421,
    price: 65,
    currency: 'GBP',
    isVerified: true,
    isOnline: false,
    languages: ['English', 'French'],
    hospital: 'Great Ormond Street Hospital',
    experience: 14,
    consultationType: ['video', 'chat'],
    nextAvailable: 'Tomorrow, 11:00 AM',
    country: 'GB',
    countryFlag: '🇬🇧',
    licensedCountries: ['GB'],
    scope: 'licensed_clinical'
  },
  {
    id: '6',
    name: 'Dr. Oliver Brown',
    specialty: 'Psychiatrist',
    specialtyId: 'psychiatry',
    image: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=200&h=200&fit=crop&crop=face',
    rating: 4.8,
    reviews: 98,
    price: 120,
    currency: 'GBP',
    isVerified: true,
    isOnline: true,
    languages: ['English'],
    hospital: 'Priory Mental Health',
    experience: 20,
    consultationType: ['video', 'voice'],
    nextAvailable: 'Today, 6:00 PM',
    country: 'GB',
    countryFlag: '🇬🇧',
    licensedCountries: ['GB'],
    scope: 'licensed_clinical'
  },
  // USA Doctors (USD: $100-300 typical)
  {
    id: '7',
    name: 'Dr. Michael Chen',
    specialty: 'Cardiologist',
    specialtyId: 'cardiology',
    image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=200&h=200&fit=crop&crop=face',
    rating: 4.9,
    reviews: 567,
    price: 200,
    currency: 'USD',
    isVerified: true,
    isOnline: true,
    languages: ['English', 'Mandarin'],
    hospital: 'Mayo Clinic',
    experience: 22,
    consultationType: ['video', 'voice', 'chat'],
    nextAvailable: 'Today, 2:00 PM',
    country: 'US',
    countryFlag: '🇺🇸',
    licensedCountries: ['US', 'CA'],
    scope: 'licensed_clinical'
  },
  {
    id: '8',
    name: 'Dr. Jessica Martinez',
    specialty: 'Neurologist',
    specialtyId: 'neurology',
    image: 'https://images.unsplash.com/photo-1527613426441-4da17471b66d?w=200&h=200&fit=crop&crop=face',
    rating: 4.8,
    reviews: 234,
    price: 250,
    currency: 'USD',
    isVerified: true,
    isOnline: false,
    languages: ['English', 'Spanish'],
    hospital: 'Johns Hopkins Hospital',
    experience: 16,
    consultationType: ['video', 'chat'],
    nextAvailable: 'Tomorrow, 9:00 AM',
    country: 'US',
    countryFlag: '🇺🇸',
    licensedCountries: ['US'],
    scope: 'licensed_clinical'
  },
  // India Doctors (INR: ₹300-1000 typical)
  {
    id: '9',
    name: 'Dr. Priya Sharma',
    specialty: 'General Physician',
    specialtyId: 'general',
    image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200&h=200&fit=crop&crop=face',
    rating: 4.7,
    reviews: 445,
    price: 400,
    currency: 'INR',
    isVerified: true,
    isOnline: true,
    languages: ['English', 'Hindi', 'Bengali'],
    hospital: 'Apollo Hospital',
    experience: 11,
    consultationType: ['video', 'voice', 'chat'],
    nextAvailable: 'Today, 1:00 PM',
    country: 'IN',
    countryFlag: '🇮🇳',
    licensedCountries: ['IN', 'BD'],
    scope: 'licensed_clinical'
  },
  {
    id: '10',
    name: 'Dr. Rajesh Patel',
    specialty: 'Gastroenterologist',
    specialtyId: 'gastroenterology',
    image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop&crop=face',
    rating: 4.9,
    reviews: 312,
    price: 700,
    currency: 'INR',
    isVerified: true,
    isOnline: true,
    languages: ['English', 'Hindi', 'Gujarati'],
    hospital: 'Fortis Hospital',
    experience: 19,
    consultationType: ['video', 'chat'],
    nextAvailable: 'Today, 4:30 PM',
    country: 'IN',
    countryFlag: '🇮🇳',
    licensedCountries: ['IN'],
    scope: 'licensed_clinical'
  },
  // UAE Doctors (AED: 200-500 typical)
  {
    id: '11',
    name: 'Dr. Ahmed Al-Rashid',
    specialty: 'Endocrinologist',
    specialtyId: 'endocrinology',
    image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=200&h=200&fit=crop&crop=face',
    rating: 4.8,
    reviews: 198,
    price: 350,
    currency: 'AED',
    isVerified: true,
    isOnline: true,
    languages: ['English', 'Arabic'],
    hospital: 'Cleveland Clinic Abu Dhabi',
    experience: 15,
    consultationType: ['video', 'voice', 'chat'],
    nextAvailable: 'Tomorrow, 10:00 AM',
    country: 'AE',
    countryFlag: '🇦🇪',
    licensedCountries: ['AE', 'SA'],
    scope: 'licensed_clinical'
  },
  // Spain - Guidance-Only Doctor (EUR: €30-80 typical)
  {
    id: '12',
    name: 'Dr. Maria Garcia',
    specialty: 'Nutritionist',
    specialtyId: 'nutrition',
    image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=200&h=200&fit=crop&crop=face',
    rating: 4.6,
    reviews: 567,
    price: 45,
    currency: 'EUR',
    isVerified: true,
    isOnline: true,
    languages: ['English', 'Spanish', 'Portuguese'],
    hospital: 'Global Health Wellness',
    experience: 8,
    consultationType: ['video', 'chat'],
    nextAvailable: 'Today, 7:00 PM',
    country: 'ES',
    countryFlag: '🇪🇸',
    licensedCountries: [],
    scope: 'guidance_only'
  },
  // Canada Doctor (CAD: $100-250 typical)
  {
    id: '13',
    name: 'Dr. Sophie Laurent',
    specialty: 'Psychiatrist',
    specialtyId: 'psychiatry',
    image: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=200&h=200&fit=crop&crop=face',
    rating: 4.9,
    reviews: 289,
    price: 175,
    currency: 'CAD',
    isVerified: true,
    isOnline: true,
    languages: ['English', 'French'],
    hospital: 'Toronto Mental Health Centre',
    experience: 17,
    consultationType: ['video', 'voice'],
    nextAvailable: 'Today, 5:00 PM',
    country: 'CA',
    countryFlag: '🇨🇦',
    licensedCountries: ['CA', 'US'],
    scope: 'licensed_clinical'
  },
  // Australia Doctor (AUD: $100-200 typical)
  {
    id: '14',
    name: 'Dr. William Cooper',
    specialty: 'Orthopedist',
    specialtyId: 'orthopedics',
    image: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=200&h=200&fit=crop&crop=face',
    rating: 4.8,
    reviews: 176,
    price: 150,
    currency: 'AUD',
    isVerified: true,
    isOnline: false,
    languages: ['English'],
    hospital: 'Sydney Orthopedic Clinic',
    experience: 21,
    consultationType: ['video', 'chat'],
    nextAvailable: 'Tomorrow, 8:00 AM',
    country: 'AU',
    countryFlag: '🇦🇺',
    licensedCountries: ['AU', 'NZ'],
    scope: 'licensed_clinical'
  },
  // Veterinary Doctors
  {
    id: '15',
    name: 'Dr. Emily Parker',
    specialty: 'Veterinarian',
    specialtyId: 'veterinary',
    image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200&h=200&fit=crop&crop=face',
    rating: 4.9,
    reviews: 342,
    price: 55,
    currency: 'GBP',
    isVerified: true,
    isOnline: true,
    languages: ['English'],
    hospital: 'London Veterinary Clinic',
    experience: 12,
    consultationType: ['video', 'chat'],
    nextAvailable: 'Today, 3:30 PM',
    country: 'GB',
    countryFlag: '🇬🇧',
    licensedCountries: ['GB'],
    scope: 'licensed_clinical'
  },
  {
    id: '16',
    name: 'Dr. Robert Hughes',
    specialty: 'Veterinarian',
    specialtyId: 'veterinary',
    image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop&crop=face',
    rating: 4.8,
    reviews: 189,
    price: 120,
    currency: 'USD',
    isVerified: true,
    isOnline: true,
    languages: ['English', 'Spanish'],
    hospital: 'NYC Animal Hospital',
    experience: 15,
    consultationType: ['video', 'voice', 'chat'],
    nextAvailable: 'Today, 5:00 PM',
    country: 'US',
    countryFlag: '🇺🇸',
    licensedCountries: ['US'],
    scope: 'licensed_clinical'
  },
  {
    id: '17',
    name: 'Dr. Anwar Hossain',
    specialty: 'Veterinarian',
    specialtyId: 'veterinary',
    image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=200&h=200&fit=crop&crop=face',
    rating: 4.7,
    reviews: 156,
    price: 500,
    currency: 'BDT',
    isVerified: true,
    isOnline: true,
    languages: ['English', 'Bengali'],
    hospital: 'Dhaka Pet Care Center',
    experience: 10,
    consultationType: ['video', 'chat'],
    nextAvailable: 'Tomorrow, 10:00 AM',
    country: 'BD',
    countryFlag: '🇧🇩',
    licensedCountries: ['BD'],
    scope: 'licensed_clinical'
  },
  {
    id: '18',
    name: 'Dr. Aisha Malik',
    specialty: 'Veterinarian',
    specialtyId: 'veterinary',
    image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=200&h=200&fit=crop&crop=face',
    rating: 4.9,
    reviews: 278,
    price: 300,
    currency: 'AED',
    isVerified: true,
    isOnline: false,
    languages: ['English', 'Arabic'],
    hospital: 'Dubai Pet Hospital',
    experience: 14,
    consultationType: ['video', 'voice'],
    nextAvailable: 'Today, 6:00 PM',
    country: 'AE',
    countryFlag: '🇦🇪',
    licensedCountries: ['AE'],
    scope: 'licensed_clinical'
  },
];

export interface Specialty {
  id: string;
  name: string;
  subtitle: string;
  icon: string;
}

export const specialties: Specialty[] = [
  { id: 'general', name: 'General Physician', subtitle: 'Primary Care', icon: 'Stethoscope' },
  { id: 'pediatrics', name: 'Pediatrics', subtitle: 'Child Health Care', icon: 'Baby' },
  { id: 'gynae', name: 'Gynae & Obs', subtitle: "Women's Health", icon: 'Heart' },
  { id: 'dermatology', name: 'Dermatology', subtitle: 'Skin & Hair', icon: 'Sparkles' },
  { id: 'medicine', name: 'Internal Medicine', subtitle: 'General Health', icon: 'Pill' },
  { id: 'endocrinology', name: 'Endocrinology', subtitle: 'Diabetes & Thyroid', icon: 'Activity' },
  { id: 'neurology', name: 'Neurology', subtitle: 'Brain & Spine', icon: 'Brain' },
  { id: 'gastroenterology', name: 'Gastroenterology', subtitle: 'Stomach & Liver', icon: 'Apple' },
  { id: 'cardiology', name: 'Cardiology', subtitle: 'Heart Disease', icon: 'HeartPulse' },
  { id: 'urology', name: 'Urology', subtitle: 'Urinary Care', icon: 'Droplets' },
  { id: 'nutrition', name: 'Food & Nutrition', subtitle: 'Diet Guidance', icon: 'Salad' },
  { id: 'dentistry', name: 'Dentistry', subtitle: 'Oral Wellness', icon: 'Smile' },
  { id: 'psychiatry', name: 'Psychiatry', subtitle: 'Mental Health', icon: 'BrainCircuit' },
  { id: 'psychology', name: 'Psychology', subtitle: 'Counseling', icon: 'MessageCircleHeart' },
  { id: 'orthopedics', name: 'Orthopedics', subtitle: 'Bone & Joint', icon: 'Bone' },
  { id: 'veterinary', name: 'Veterinary', subtitle: 'Pet & Animal Care', icon: 'PawPrint' },
];

export interface Symptom {
  id: string;
  name: string;
  image: string;
  relatedSpecialties: string[];
}

export const symptoms: Symptom[] = [
  { 
    id: 'fever', 
    name: 'Fever, Cold/Flu, Allergy', 
    image: 'https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?w=200&h=200&fit=crop',
    relatedSpecialties: ['general', 'medicine']
  },
  { 
    id: 'period', 
    name: 'Period problems/Gynae', 
    image: 'https://images.unsplash.com/photo-1571942676516-bcab84649e44?w=200&h=200&fit=crop',
    relatedSpecialties: ['gynae']
  },
  { 
    id: 'child', 
    name: 'Child diseases', 
    image: 'https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?w=200&h=200&fit=crop',
    relatedSpecialties: ['pediatrics']
  },
  { 
    id: 'pregnancy', 
    name: 'Pregnancy issues', 
    image: 'https://images.unsplash.com/photo-1493894473891-10fc1e5dbd22?w=200&h=200&fit=crop',
    relatedSpecialties: ['gynae']
  },
  { 
    id: 'weight', 
    name: 'Weight lose/gain, Diet', 
    image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=200&h=200&fit=crop',
    relatedSpecialties: ['nutrition', 'endocrinology']
  },
  { 
    id: 'skin', 
    name: 'Itching, Acne & Skin problems', 
    image: 'https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?w=200&h=200&fit=crop',
    relatedSpecialties: ['dermatology']
  },
  { 
    id: 'hair', 
    name: 'Hair fall and Dandruff', 
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=200&h=200&fit=crop',
    relatedSpecialties: ['dermatology']
  },
  { 
    id: 'urine', 
    name: 'Urine infection or problems', 
    image: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=200&h=200&fit=crop',
    relatedSpecialties: ['urology']
  },
  { 
    id: 'acidity', 
    name: 'Acidity, Indigestion', 
    image: 'https://images.unsplash.com/photo-1559757175-5700dde675bc?w=200&h=200&fit=crop',
    relatedSpecialties: ['gastroenterology', 'general']
  },
  { 
    id: 'ent', 
    name: 'Ear, Nose and Throat diseases', 
    image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop',
    relatedSpecialties: ['general', 'medicine']
  },
  { 
    id: 'stress', 
    name: 'Stress or Depression', 
    image: 'https://images.unsplash.com/photo-1493836512294-502baa1986e2?w=200&h=200&fit=crop',
    relatedSpecialties: ['psychiatry', 'psychology']
  },
  { 
    id: 'joint', 
    name: 'Joint/Muscle pain, Arthritis', 
    image: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=200&h=200&fit=crop',
    relatedSpecialties: ['orthopedics']
  },
  { 
    id: 'abdominal', 
    name: 'Abdominal pain/Body pain', 
    image: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=200&h=200&fit=crop',
    relatedSpecialties: ['gastroenterology', 'general']
  },
  { 
    id: 'headache', 
    name: 'Headache or Migraine', 
    image: 'https://images.unsplash.com/photo-1616012480717-fd9867059ca0?w=200&h=200&fit=crop',
    relatedSpecialties: ['neurology', 'general']
  },
  { 
    id: 'heart', 
    name: 'Heart problems, Chest pain', 
    image: 'https://images.unsplash.com/photo-1628348068343-c6a848d2b6dd?w=200&h=200&fit=crop',
    relatedSpecialties: ['cardiology']
  },
  { 
    id: 'diabetes', 
    name: 'Diabetes & Thyroid', 
    image: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=200&h=200&fit=crop',
    relatedSpecialties: ['endocrinology']
  },
  { 
    id: 'pet', 
    name: 'Pet & Animal Health', 
    image: 'https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=200&h=200&fit=crop',
    relatedSpecialties: ['veterinary']
  },
];

// All available languages from doctors
export const doctorLanguages = [
  'English',
  'Bengali',
  'Arabic',
  'Hindi',
  'Spanish',
  'French',
  'Mandarin',
  'Portuguese',
  'Gujarati',
];

// Country data for filtering
export const doctorCountries = [
  { code: 'ALL', name: 'All Countries', flag: '🌍' },
  { code: 'GB', name: 'United Kingdom', flag: '🇬🇧' },
  { code: 'US', name: 'United States', flag: '🇺🇸' },
  { code: 'BD', name: 'Bangladesh', flag: '🇧🇩' },
  { code: 'IN', name: 'India', flag: '🇮🇳' },
  { code: 'AE', name: 'UAE', flag: '🇦🇪' },
  { code: 'CA', name: 'Canada', flag: '🇨🇦' },
  { code: 'AU', name: 'Australia', flag: '🇦🇺' },
  { code: 'ES', name: 'Spain', flag: '🇪🇸' },
];
