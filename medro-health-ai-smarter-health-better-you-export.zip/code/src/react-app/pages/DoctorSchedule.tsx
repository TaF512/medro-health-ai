import { useState } from 'react';
import { useNavigate } from 'react-router';
import { 
  ArrowLeft, 
  Calendar, 
  Clock, 
  Plus, 
  X,
  Check,
  ChevronLeft,
  ChevronRight,
  Trash2,
  Users,
  Video,
  Phone,
  MessageSquare
} from 'lucide-react';
import { cn } from '@/react-app/lib/utils';
import BottomNav from '@/react-app/components/BottomNav';

interface TimeSlot {
  id: string;
  startTime: string;
  endTime: string;
  type: 'video' | 'voice' | 'chat' | 'in-person';
  maxPatients: number;
  bookedCount: number;
  isAvailable: boolean;
}

interface DaySchedule {
  date: string;
  dayName: string;
  dayNumber: number;
  isToday: boolean;
  slots: TimeSlot[];
}

const generateWeekSchedule = (): DaySchedule[] => {
  const today = new Date();
  const days = [];
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  
  for (let i = 0; i < 7; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() + i);
    
    const slots: TimeSlot[] = i === 0 ? [
      { id: '1', startTime: '09:00', endTime: '09:30', type: 'video', maxPatients: 1, bookedCount: 1, isAvailable: true },
      { id: '2', startTime: '09:30', endTime: '10:00', type: 'video', maxPatients: 1, bookedCount: 0, isAvailable: true },
      { id: '3', startTime: '10:00', endTime: '10:30', type: 'voice', maxPatients: 1, bookedCount: 1, isAvailable: true },
      { id: '4', startTime: '11:00', endTime: '11:30', type: 'chat', maxPatients: 3, bookedCount: 2, isAvailable: true },
      { id: '5', startTime: '14:00', endTime: '14:30', type: 'video', maxPatients: 1, bookedCount: 0, isAvailable: true },
      { id: '6', startTime: '15:00', endTime: '15:30', type: 'in-person', maxPatients: 1, bookedCount: 1, isAvailable: true },
    ] : i === 1 ? [
      { id: '7', startTime: '10:00', endTime: '10:30', type: 'video', maxPatients: 1, bookedCount: 0, isAvailable: true },
      { id: '8', startTime: '11:00', endTime: '11:30', type: 'voice', maxPatients: 1, bookedCount: 0, isAvailable: true },
      { id: '9', startTime: '14:00', endTime: '15:00', type: 'chat', maxPatients: 5, bookedCount: 3, isAvailable: true },
    ] : i === 2 ? [
      { id: '10', startTime: '09:00', endTime: '12:00', type: 'in-person', maxPatients: 6, bookedCount: 4, isAvailable: true },
    ] : [];
    
    days.push({
      date: date.toISOString().split('T')[0],
      dayName: dayNames[date.getDay()],
      dayNumber: date.getDate(),
      isToday: i === 0,
      slots
    });
  }
  
  return days;
};

export default function DoctorSchedulePage() {
  const navigate = useNavigate();
  const [weekSchedule, setWeekSchedule] = useState<DaySchedule[]>(generateWeekSchedule());
  const [selectedDay, setSelectedDay] = useState(0);
  const [showAddSlot, setShowAddSlot] = useState(false);
  const [newSlot, setNewSlot] = useState({
    startTime: '09:00',
    endTime: '09:30',
    type: 'video' as TimeSlot['type'],
    maxPatients: 1
  });

  const currentDay = weekSchedule[selectedDay];
  
  const getTypeIcon = (type: TimeSlot['type']) => {
    switch (type) {
      case 'video': return Video;
      case 'voice': return Phone;
      case 'chat': return MessageSquare;
      case 'in-person': return Users;
    }
  };

  const getTypeColor = (type: TimeSlot['type']) => {
    switch (type) {
      case 'video': return 'bg-blue-100 text-blue-600 border-blue-200';
      case 'voice': return 'bg-green-100 text-green-600 border-green-200';
      case 'chat': return 'bg-purple-100 text-purple-600 border-purple-200';
      case 'in-person': return 'bg-orange-100 text-orange-600 border-orange-200';
    }
  };

  const addSlot = () => {
    const slot: TimeSlot = {
      id: Date.now().toString(),
      ...newSlot,
      bookedCount: 0,
      isAvailable: true
    };

    setWeekSchedule(prev => prev.map((day, i) => 
      i === selectedDay
        ? { ...day, slots: [...day.slots, slot].sort((a, b) => a.startTime.localeCompare(b.startTime)) }
        : day
    ));

    setShowAddSlot(false);
    setNewSlot({ startTime: '09:00', endTime: '09:30', type: 'video', maxPatients: 1 });
  };

  const removeSlot = (slotId: string) => {
    setWeekSchedule(prev => prev.map((day, i) => 
      i === selectedDay
        ? { ...day, slots: day.slots.filter(s => s.id !== slotId) }
        : day
    ));
  };

  const toggleSlotAvailability = (slotId: string) => {
    setWeekSchedule(prev => prev.map((day, i) => 
      i === selectedDay
        ? { 
            ...day, 
            slots: day.slots.map(s => 
              s.id === slotId ? { ...s, isAvailable: !s.isAvailable } : s
            ) 
          }
        : day
    ));
  };

  const totalSlots = currentDay.slots.length;
  const bookedSlots = currentDay.slots.reduce((sum, s) => sum + s.bookedCount, 0);
  const availableSlots = currentDay.slots.filter(s => s.isAvailable && s.bookedCount < s.maxPatients).length;

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="sticky top-0 bg-gradient-to-r from-primary to-teal-500 px-4 py-4 z-40">
        <div className="flex items-center gap-3 max-w-lg mx-auto">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 rounded-full hover:bg-white/20 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-white">Schedule Management</h1>
            <p className="text-sm text-white/80">Manage your availability</p>
          </div>
          <button
            onClick={() => setShowAddSlot(true)}
            className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
          >
            <Plus className="w-5 h-5 text-white" />
          </button>
        </div>
      </header>

      <main className="px-4 py-4 max-w-lg mx-auto space-y-4">
        {/* Week Navigation */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
          <div className="flex items-center justify-between mb-4">
            <button className="p-2 hover:bg-gray-100 rounded-lg">
              <ChevronLeft className="w-5 h-5 text-gray-600" />
            </button>
            <div className="text-center">
              <p className="font-semibold text-gray-900">
                {new Date(currentDay.date).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
              </p>
            </div>
            <button className="p-2 hover:bg-gray-100 rounded-lg">
              <ChevronRight className="w-5 h-5 text-gray-600" />
            </button>
          </div>

          <div className="grid grid-cols-7 gap-1">
            {weekSchedule.map((day, i) => (
              <button
                key={day.date}
                onClick={() => setSelectedDay(i)}
                className={cn(
                  'flex flex-col items-center py-2 rounded-xl transition-all',
                  selectedDay === i
                    ? 'bg-primary text-white'
                    : day.isToday
                    ? 'bg-primary/10 text-primary'
                    : 'hover:bg-gray-100'
                )}
              >
                <span className="text-xs font-medium">{day.dayName}</span>
                <span className={cn(
                  'text-lg font-bold mt-1',
                  selectedDay === i ? 'text-white' : 'text-gray-900'
                )}>
                  {day.dayNumber}
                </span>
                {day.slots.length > 0 && (
                  <div className={cn(
                    'w-1.5 h-1.5 rounded-full mt-1',
                    selectedDay === i ? 'bg-white' : 'bg-primary'
                  )} />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-white rounded-xl p-3 border border-gray-100 text-center">
            <p className="text-2xl font-bold text-gray-900">{totalSlots}</p>
            <p className="text-xs text-gray-500">Total Slots</p>
          </div>
          <div className="bg-white rounded-xl p-3 border border-gray-100 text-center">
            <p className="text-2xl font-bold text-green-600">{availableSlots}</p>
            <p className="text-xs text-gray-500">Available</p>
          </div>
          <div className="bg-white rounded-xl p-3 border border-gray-100 text-center">
            <p className="text-2xl font-bold text-blue-600">{bookedSlots}</p>
            <p className="text-xs text-gray-500">Booked</p>
          </div>
        </div>

        {/* Time Slots */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold text-gray-900">
              {currentDay.isToday ? "Today's Schedule" : `Schedule for ${currentDay.dayName}`}
            </h2>
          </div>

          {currentDay.slots.length > 0 ? (
            <div className="space-y-3">
              {currentDay.slots.map(slot => {
                const TypeIcon = getTypeIcon(slot.type);
                const isFull = slot.bookedCount >= slot.maxPatients;
                
                return (
                  <div
                    key={slot.id}
                    className={cn(
                      'bg-white rounded-2xl border shadow-sm overflow-hidden',
                      !slot.isAvailable ? 'opacity-60 border-gray-200' : 'border-gray-100'
                    )}
                  >
                    <div className="flex items-center gap-4 p-4">
                      <div className={cn(
                        'w-12 h-12 rounded-xl flex items-center justify-center border',
                        getTypeColor(slot.type)
                      )}>
                        <TypeIcon className="w-5 h-5" />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-gray-400" />
                          <span className="font-semibold text-gray-900">
                            {slot.startTime} - {slot.endTime}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <span className={cn(
                            'px-2 py-0.5 rounded-full text-xs font-medium capitalize',
                            getTypeColor(slot.type)
                          )}>
                            {slot.type}
                          </span>
                          <span className="text-sm text-gray-500">
                            {slot.bookedCount}/{slot.maxPatients} booked
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => toggleSlotAvailability(slot.id)}
                          className={cn(
                            'p-2 rounded-lg transition-colors',
                            slot.isAvailable
                              ? 'text-green-600 hover:bg-green-50'
                              : 'text-gray-400 hover:bg-gray-100'
                          )}
                        >
                          <Check className="w-5 h-5" />
                        </button>
                        <button
                          onClick={() => removeSlot(slot.id)}
                          className="p-2 text-red-400 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>

                    {slot.bookedCount > 0 && (
                      <div className="border-t border-gray-100 px-4 py-2 bg-gray-50">
                        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div 
                            className={cn(
                              'h-full rounded-full transition-all',
                              isFull ? 'bg-red-500' : 'bg-primary'
                            )}
                            style={{ width: `${(slot.bookedCount / slot.maxPatients) * 100}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-2xl border border-gray-100">
              <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No slots scheduled</p>
              <button
                onClick={() => setShowAddSlot(true)}
                className="mt-4 px-6 py-2 bg-primary text-white rounded-lg text-sm font-medium"
              >
                Add Time Slot
              </button>
            </div>
          )}
        </section>

        {/* Quick Actions */}
        <section className="grid grid-cols-2 gap-3">
          <button className="bg-white rounded-xl p-4 border border-gray-100 text-left hover:border-primary transition-colors">
            <Calendar className="w-6 h-6 text-primary mb-2" />
            <p className="font-medium text-gray-900">Copy Schedule</p>
            <p className="text-xs text-gray-500">Duplicate to next week</p>
          </button>
          <button className="bg-white rounded-xl p-4 border border-gray-100 text-left hover:border-primary transition-colors">
            <Clock className="w-6 h-6 text-primary mb-2" />
            <p className="font-medium text-gray-900">Set Recurring</p>
            <p className="text-xs text-gray-500">Weekly availability</p>
          </button>
        </section>
      </main>

      {/* Add Slot Modal */}
      {showAddSlot && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="w-full bg-white rounded-t-3xl p-6 max-w-lg mx-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Add Time Slot</h2>
              <button
                onClick={() => setShowAddSlot(false)}
                className="p-2 hover:bg-gray-100 rounded-full"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Start Time
                  </label>
                  <input
                    type="time"
                    value={newSlot.startTime}
                    onChange={(e) => setNewSlot(prev => ({ ...prev, startTime: e.target.value }))}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    End Time
                  </label>
                  <input
                    type="time"
                    value={newSlot.endTime}
                    onChange={(e) => setNewSlot(prev => ({ ...prev, endTime: e.target.value }))}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Consultation Type
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {(['video', 'voice', 'chat', 'in-person'] as const).map(type => {
                    const Icon = getTypeIcon(type);
                    return (
                      <button
                        key={type}
                        onClick={() => setNewSlot(prev => ({ ...prev, type }))}
                        className={cn(
                          'p-3 rounded-xl flex flex-col items-center gap-1 transition-all',
                          newSlot.type === type
                            ? 'bg-primary text-white'
                            : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
                        )}
                      >
                        <Icon className="w-5 h-5" />
                        <span className="text-xs capitalize">{type}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Max Patients
                </label>
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setNewSlot(prev => ({ ...prev, maxPatients: Math.max(1, prev.maxPatients - 1) }))}
                    className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center"
                  >
                    <span className="text-xl">-</span>
                  </button>
                  <span className="text-xl font-bold text-gray-900 w-12 text-center">
                    {newSlot.maxPatients}
                  </span>
                  <button
                    onClick={() => setNewSlot(prev => ({ ...prev, maxPatients: prev.maxPatients + 1 }))}
                    className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center"
                  >
                    <span className="text-xl">+</span>
                  </button>
                </div>
              </div>

              <button
                onClick={addSlot}
                className="w-full py-4 bg-primary text-white rounded-xl font-semibold hover:bg-primary/90 transition-colors"
              >
                Add Slot
              </button>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
