import { useState } from 'react';
import { Link } from 'react-router';
import { 
  ArrowLeft, Search, Star, MapPin, Phone, Mail, Clock, 
  ChevronRight, Sparkles, Video, MessageCircle,
  Filter, Globe, CheckCircle, Shield, ChevronDown, ChevronUp, X
} from 'lucide-react';
import { useCurrency } from '@/react-app/contexts/CurrencyContext';

interface Procedure {
  id: string;
  name: string;
  category: string;
  description: string;
  priceFrom: number;
  priceTo: number;
  duration: string;
  recovery: string;
}

interface Clinic {
  id: string;
  name: string;
  image: string;
  rating: number;
  reviews: number;
  location: string;
  country: string;
  countryFlag: string;
  currency: string;
  phone: string;
  email: string;
  website: string;
  consultationFee: number;
  isVerified: boolean;
  specialties: string[];
  procedures: Procedure[];
  openHours: string;
  languages: string[];
}

const clinics: Clinic[] = [
  {
    id: '1',
    name: 'Harley Street Aesthetics',
    image: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=400&h=300&fit=crop',
    rating: 4.9,
    reviews: 1234,
    location: 'Harley Street, London',
    country: 'GB',
    countryFlag: '🇬🇧',
    currency: 'GBP',
    phone: '+44 20 7946 0958',
    email: 'info@harleyaesthetics.co.uk',
    website: 'harleyaesthetics.co.uk',
    consultationFee: 150,
    isVerified: true,
    specialties: ['Hair Restoration', 'Facial Aesthetics', 'Body Contouring', 'Dental'],
    openHours: 'Mon-Sat: 9AM-7PM',
    languages: ['English', 'Arabic', 'French'],
    procedures: [
      { id: 'h1', name: 'FUE Hair Transplant', category: 'hair', description: 'Follicular Unit Extraction for natural hair restoration', priceFrom: 4000, priceTo: 12000, duration: '6-8 hours', recovery: '7-10 days' },
      { id: 'h2', name: 'Lip Fillers', category: 'face', description: 'Hyaluronic acid dermal fillers for fuller lips', priceFrom: 250, priceTo: 600, duration: '30 mins', recovery: '1-2 days' },
      { id: 'h3', name: 'Botox Treatment', category: 'face', description: 'Wrinkle reduction and facial rejuvenation', priceFrom: 200, priceTo: 450, duration: '20 mins', recovery: 'None' },
      { id: 'h4', name: 'Rhinoplasty', category: 'face', description: 'Surgical nose reshaping', priceFrom: 5000, priceTo: 8000, duration: '2-3 hours', recovery: '2-3 weeks' },
      { id: 'h5', name: 'Teeth Whitening', category: 'dental', description: 'Professional laser teeth whitening', priceFrom: 300, priceTo: 600, duration: '1 hour', recovery: 'None' },
      { id: 'h6', name: 'Dental Veneers', category: 'dental', description: 'Porcelain veneers for perfect smile', priceFrom: 500, priceTo: 1200, duration: '2 visits', recovery: '1-2 days' },
    ]
  },
  {
    id: '2',
    name: 'Transform Clinic',
    image: 'https://images.unsplash.com/photo-1631217868264-e5b90bb7e133?w=400&h=300&fit=crop',
    rating: 4.8,
    reviews: 892,
    location: 'Manchester, UK',
    country: 'GB',
    countryFlag: '🇬🇧',
    currency: 'GBP',
    phone: '+44 161 234 5678',
    email: 'bookings@transformclinic.co.uk',
    website: 'transformclinic.co.uk',
    consultationFee: 100,
    isVerified: true,
    specialties: ['Breast Surgery', 'Body Contouring', 'Facial Surgery'],
    openHours: 'Mon-Fri: 8AM-6PM',
    languages: ['English'],
    procedures: [
      { id: 't1', name: 'Breast Augmentation', category: 'breast', description: 'Breast enlargement with implants', priceFrom: 5500, priceTo: 8500, duration: '1-2 hours', recovery: '4-6 weeks' },
      { id: 't2', name: 'Breast Lift', category: 'breast', description: 'Mastopexy to lift and reshape breasts', priceFrom: 6000, priceTo: 9000, duration: '2-3 hours', recovery: '2-4 weeks' },
      { id: 't3', name: 'Tummy Tuck', category: 'body', description: 'Abdominoplasty for flatter stomach', priceFrom: 6500, priceTo: 9500, duration: '2-4 hours', recovery: '4-6 weeks' },
      { id: 't4', name: 'Liposuction', category: 'body', description: 'Fat removal and body sculpting', priceFrom: 3000, priceTo: 7000, duration: '1-3 hours', recovery: '2-4 weeks' },
      { id: 't5', name: 'Arm Lift', category: 'body', description: 'Brachioplasty for toned arms', priceFrom: 4000, priceTo: 6000, duration: '2 hours', recovery: '2-3 weeks' },
    ]
  },
  {
    id: '3',
    name: 'Beverly Hills Aesthetics',
    image: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=400&h=300&fit=crop',
    rating: 4.9,
    reviews: 2156,
    location: 'Beverly Hills, California',
    country: 'US',
    countryFlag: '🇺🇸',
    currency: 'USD',
    phone: '+1 310 555 0199',
    email: 'info@bhAesthetics.com',
    website: 'bhaesthetics.com',
    consultationFee: 250,
    isVerified: true,
    specialties: ['Brazilian Butt Lift', 'Facial Rejuvenation', 'Body Sculpting', 'Celebrity Treatments'],
    openHours: 'Mon-Sat: 8AM-8PM',
    languages: ['English', 'Spanish'],
    procedures: [
      { id: 'b1', name: 'Brazilian Butt Lift (BBL)', category: 'body', description: 'Fat transfer to buttocks for enhanced shape', priceFrom: 8000, priceTo: 15000, duration: '3-4 hours', recovery: '4-6 weeks' },
      { id: 'b2', name: 'Buttock Implants', category: 'body', description: 'Silicone implants for buttock augmentation', priceFrom: 6000, priceTo: 12000, duration: '2-3 hours', recovery: '3-4 weeks' },
      { id: 'b3', name: 'Facelift', category: 'face', description: 'Surgical facial rejuvenation', priceFrom: 12000, priceTo: 25000, duration: '4-6 hours', recovery: '2-4 weeks' },
      { id: 'b4', name: 'Mommy Makeover', category: 'body', description: 'Combined breast, tummy, and body procedures', priceFrom: 15000, priceTo: 30000, duration: '5-7 hours', recovery: '4-8 weeks' },
      { id: 'b5', name: 'Neck Lift', category: 'face', description: 'Tighten and contour neck area', priceFrom: 8000, priceTo: 15000, duration: '2-3 hours', recovery: '2 weeks' },
      { id: 'b6', name: 'Brow Lift', category: 'face', description: 'Lift sagging eyebrows', priceFrom: 5000, priceTo: 10000, duration: '1-2 hours', recovery: '1-2 weeks' },
    ]
  },
  {
    id: '4',
    name: 'Istanbul Hair Clinic',
    image: 'https://images.unsplash.com/photo-1551076805-e1869033e561?w=400&h=300&fit=crop',
    rating: 4.7,
    reviews: 3421,
    location: 'Istanbul, Turkey',
    country: 'TR',
    countryFlag: '🇹🇷',
    currency: 'USD',
    phone: '+90 212 555 0123',
    email: 'contact@istanbulhair.com',
    website: 'istanbulhair.com',
    consultationFee: 0,
    isVerified: true,
    specialties: ['Hair Transplant', 'Beard Transplant', 'Eyebrow Restoration', 'Dental Tourism'],
    openHours: 'Mon-Sun: 8AM-9PM',
    languages: ['English', 'Turkish', 'Arabic', 'German'],
    procedures: [
      { id: 'i1', name: 'FUE Hair Transplant', category: 'hair', description: '3000-5000 grafts with hotel & transfers included', priceFrom: 1800, priceTo: 3500, duration: '6-8 hours', recovery: '7-10 days' },
      { id: 'i2', name: 'DHI Hair Transplant', category: 'hair', description: 'Direct Hair Implantation technique', priceFrom: 2500, priceTo: 4500, duration: '6-8 hours', recovery: '7-10 days' },
      { id: 'i3', name: 'Beard Transplant', category: 'hair', description: 'Natural beard restoration', priceFrom: 1500, priceTo: 2500, duration: '4-6 hours', recovery: '5-7 days' },
      { id: 'i4', name: 'PRP Hair Treatment', category: 'hair', description: 'Platelet-rich plasma for hair growth', priceFrom: 200, priceTo: 400, duration: '1 hour', recovery: 'None' },
      { id: 'i5', name: 'Eyebrow Transplant', category: 'hair', description: 'Natural eyebrow restoration', priceFrom: 1200, priceTo: 2000, duration: '3-4 hours', recovery: '5-7 days' },
      { id: 'i6', name: 'Full Mouth Dental Implants', category: 'dental', description: 'Complete dental restoration', priceFrom: 8000, priceTo: 15000, duration: 'Multiple visits', recovery: '3-6 months' },
    ]
  },
  {
    id: '5',
    name: 'Dubai Cosmetic Surgery',
    image: 'https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=400&h=300&fit=crop',
    rating: 4.8,
    reviews: 987,
    location: 'Dubai Healthcare City',
    country: 'AE',
    countryFlag: '🇦🇪',
    currency: 'AED',
    phone: '+971 4 555 1234',
    email: 'info@dubaicosmetic.ae',
    website: 'dubaicosmetic.ae',
    consultationFee: 500,
    isVerified: true,
    specialties: ['Facial Surgery', 'Breast Surgery', 'Non-Surgical Treatments', 'VIP Services'],
    openHours: 'Sun-Thu: 9AM-6PM',
    languages: ['English', 'Arabic', 'Hindi', 'Urdu'],
    procedures: [
      { id: 'd1', name: 'Blepharoplasty', category: 'face', description: 'Eyelid surgery for rejuvenation', priceFrom: 15000, priceTo: 25000, duration: '1-2 hours', recovery: '1-2 weeks' },
      { id: 'd2', name: 'Chin Augmentation', category: 'face', description: 'Chin implant or filler for facial balance', priceFrom: 12000, priceTo: 20000, duration: '1-2 hours', recovery: '1-2 weeks' },
      { id: 'd3', name: 'Lip Augmentation', category: 'face', description: 'Permanent lip enhancement', priceFrom: 8000, priceTo: 15000, duration: '1 hour', recovery: '1 week' },
      { id: 'd4', name: 'Cheek Fillers', category: 'face', description: 'Volume restoration for youthful appearance', priceFrom: 3000, priceTo: 6000, duration: '30 mins', recovery: '1-2 days' },
      { id: 'd5', name: 'Jawline Contouring', category: 'face', description: 'Define and sculpt jawline', priceFrom: 5000, priceTo: 10000, duration: '45 mins', recovery: '1-2 days' },
    ]
  },
  {
    id: '6',
    name: 'SK:N Clinic',
    image: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=400&h=300&fit=crop',
    rating: 4.6,
    reviews: 2341,
    location: 'Multiple Locations, UK',
    country: 'GB',
    countryFlag: '🇬🇧',
    currency: 'GBP',
    phone: '+44 333 920 2471',
    email: 'hello@sknclinics.co.uk',
    website: 'sknclinics.co.uk',
    consultationFee: 50,
    isVerified: true,
    specialties: ['Laser Treatments', 'Skin Care', 'Non-Surgical', 'Tattoo Removal'],
    openHours: 'Mon-Sat: 9AM-6PM',
    languages: ['English'],
    procedures: [
      { id: 's1', name: 'Laser Hair Removal', category: 'skin', description: 'Permanent hair reduction', priceFrom: 50, priceTo: 350, duration: '15-60 mins', recovery: 'None' },
      { id: 's2', name: 'Chemical Peel', category: 'skin', description: 'Skin resurfacing treatment', priceFrom: 100, priceTo: 300, duration: '30 mins', recovery: '3-7 days' },
      { id: 's3', name: 'Microneedling', category: 'skin', description: 'Collagen induction therapy', priceFrom: 150, priceTo: 350, duration: '45 mins', recovery: '2-3 days' },
      { id: 's4', name: 'Thread Lift', category: 'face', description: 'Non-surgical facelift with PDO threads', priceFrom: 800, priceTo: 2000, duration: '1 hour', recovery: '1 week' },
      { id: 's5', name: 'Tattoo Removal', category: 'skin', description: 'Laser tattoo removal', priceFrom: 100, priceTo: 500, duration: '30 mins', recovery: '1-2 weeks' },
      { id: 's6', name: 'Acne Scar Treatment', category: 'skin', description: 'Reduce acne scarring', priceFrom: 200, priceTo: 500, duration: '45 mins', recovery: '3-5 days' },
    ]
  },
  {
    id: '7',
    name: 'Seoul Aesthetic Center',
    image: 'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=400&h=300&fit=crop',
    rating: 4.9,
    reviews: 4521,
    location: 'Gangnam, Seoul',
    country: 'KR',
    countryFlag: '🇰🇷',
    currency: 'USD',
    phone: '+82 2 555 1234',
    email: 'info@seoulaesthetic.kr',
    website: 'seoulaesthetic.kr',
    consultationFee: 50,
    isVerified: true,
    specialties: ['K-Beauty', 'Facial Contouring', 'Eye Surgery', 'Skin Treatments'],
    openHours: 'Mon-Sat: 9AM-8PM',
    languages: ['English', 'Korean', 'Chinese', 'Japanese'],
    procedures: [
      { id: 'k1', name: 'Double Eyelid Surgery', category: 'face', description: 'Create natural double eyelid fold', priceFrom: 1500, priceTo: 3000, duration: '1-2 hours', recovery: '1-2 weeks' },
      { id: 'k2', name: 'V-Line Surgery', category: 'face', description: 'Jaw reduction for V-shaped face', priceFrom: 5000, priceTo: 12000, duration: '2-3 hours', recovery: '2-4 weeks' },
      { id: 'k3', name: 'Rhinoplasty (Korean)', category: 'face', description: 'Natural-looking nose reshaping', priceFrom: 3000, priceTo: 8000, duration: '2 hours', recovery: '1-2 weeks' },
      { id: 'k4', name: 'Skin Whitening', category: 'skin', description: 'Glutathione IV drip treatment', priceFrom: 200, priceTo: 500, duration: '1 hour', recovery: 'None' },
      { id: 'k5', name: 'Fat Dissolving Injection', category: 'body', description: 'Non-surgical fat reduction', priceFrom: 300, priceTo: 800, duration: '30 mins', recovery: '1-2 days' },
      { id: 'k6', name: 'Glass Skin Facial', category: 'skin', description: 'Achieve radiant glass skin', priceFrom: 150, priceTo: 400, duration: '90 mins', recovery: 'None' },
    ]
  },
  {
    id: '8',
    name: 'Bangkok Beauty Hospital',
    image: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=400&h=300&fit=crop',
    rating: 4.7,
    reviews: 2876,
    location: 'Bangkok, Thailand',
    country: 'TH',
    countryFlag: '🇹🇭',
    currency: 'USD',
    phone: '+66 2 555 1234',
    email: 'info@bangkokbeauty.th',
    website: 'bangkokbeauty.th',
    consultationFee: 30,
    isVerified: true,
    specialties: ['Gender Affirmation', 'Facial Feminization', 'Body Contouring', 'Dental'],
    openHours: 'Mon-Sun: 8AM-8PM',
    languages: ['English', 'Thai', 'Chinese', 'Japanese'],
    procedures: [
      { id: 'th1', name: 'Gender Affirmation Surgery', category: 'body', description: 'Comprehensive gender transition surgery', priceFrom: 10000, priceTo: 25000, duration: '4-6 hours', recovery: '6-8 weeks' },
      { id: 'th2', name: 'Facial Feminization', category: 'face', description: 'Feminize facial features', priceFrom: 8000, priceTo: 20000, duration: '4-6 hours', recovery: '2-4 weeks' },
      { id: 'th3', name: 'Breast Augmentation', category: 'breast', description: 'Natural-looking breast enhancement', priceFrom: 3000, priceTo: 6000, duration: '2 hours', recovery: '3-4 weeks' },
      { id: 'th4', name: 'Full Body Liposuction', category: 'body', description: 'Complete body sculpting', priceFrom: 4000, priceTo: 10000, duration: '3-5 hours', recovery: '2-4 weeks' },
      { id: 'th5', name: 'Dental Crowns', category: 'dental', description: 'Premium porcelain crowns', priceFrom: 200, priceTo: 500, duration: '2 visits', recovery: '1 day' },
    ]
  },
  {
    id: '9',
    name: 'Mumbai Cosmetic Clinic',
    image: 'https://images.unsplash.com/photo-1504439468489-c8920d796a29?w=400&h=300&fit=crop',
    rating: 4.6,
    reviews: 1543,
    location: 'Mumbai, India',
    country: 'IN',
    countryFlag: '🇮🇳',
    currency: 'INR',
    phone: '+91 22 5555 1234',
    email: 'info@mumbaicosmetic.in',
    website: 'mumbaicosmetic.in',
    consultationFee: 1000,
    isVerified: true,
    specialties: ['Hair Restoration', 'Skin Care', 'Body Contouring', 'Dental'],
    openHours: 'Mon-Sat: 10AM-7PM',
    languages: ['English', 'Hindi', 'Marathi'],
    procedures: [
      { id: 'in1', name: 'FUE Hair Transplant', category: 'hair', description: 'Premium hair restoration', priceFrom: 50000, priceTo: 150000, duration: '6-8 hours', recovery: '7-10 days' },
      { id: 'in2', name: 'Rhinoplasty', category: 'face', description: 'Nose reshaping surgery', priceFrom: 80000, priceTo: 200000, duration: '2-3 hours', recovery: '2 weeks' },
      { id: 'in3', name: 'Liposuction', category: 'body', description: '360 body contouring', priceFrom: 100000, priceTo: 300000, duration: '2-4 hours', recovery: '2-4 weeks' },
      { id: 'in4', name: 'Skin Lightening', category: 'skin', description: 'Advanced skin brightening', priceFrom: 15000, priceTo: 50000, duration: 'Multiple sessions', recovery: 'None' },
      { id: 'in5', name: 'Dental Implants', category: 'dental', description: 'Titanium dental implants', priceFrom: 25000, priceTo: 50000, duration: 'Multiple visits', recovery: '3-6 months' },
    ]
  },
  {
    id: '10',
    name: 'Dhaka Beauty Center',
    image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=400&h=300&fit=crop',
    rating: 4.5,
    reviews: 876,
    location: 'Gulshan, Dhaka',
    country: 'BD',
    countryFlag: '🇧🇩',
    currency: 'BDT',
    phone: '+880 2 555 1234',
    email: 'info@dhakabeauty.bd',
    website: 'dhakabeauty.bd',
    consultationFee: 1500,
    isVerified: true,
    specialties: ['Hair Transplant', 'Skin Treatments', 'Dental', 'Non-Surgical'],
    openHours: 'Sat-Thu: 10AM-8PM',
    languages: ['English', 'Bengali'],
    procedures: [
      { id: 'bd1', name: 'FUE Hair Transplant', category: 'hair', description: 'Natural hair restoration', priceFrom: 80000, priceTo: 200000, duration: '6-8 hours', recovery: '7-10 days' },
      { id: 'bd2', name: 'Laser Skin Treatment', category: 'skin', description: 'Skin rejuvenation', priceFrom: 10000, priceTo: 30000, duration: '1 hour', recovery: '2-3 days' },
      { id: 'bd3', name: 'Teeth Whitening', category: 'dental', description: 'Professional whitening', priceFrom: 8000, priceTo: 15000, duration: '1 hour', recovery: 'None' },
      { id: 'bd4', name: 'Botox', category: 'face', description: 'Anti-wrinkle treatment', priceFrom: 15000, priceTo: 30000, duration: '30 mins', recovery: 'None' },
      { id: 'bd5', name: 'Lip Fillers', category: 'face', description: 'Lip enhancement', priceFrom: 20000, priceTo: 40000, duration: '30 mins', recovery: '1-2 days' },
    ]
  },
  {
    id: '11',
    name: 'São Paulo Plastic Surgery',
    image: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=400&h=300&fit=crop',
    rating: 4.8,
    reviews: 1987,
    location: 'São Paulo, Brazil',
    country: 'BR',
    countryFlag: '🇧🇷',
    currency: 'USD',
    phone: '+55 11 5555 1234',
    email: 'info@spplasticsurgery.br',
    website: 'spplasticsurgery.br',
    consultationFee: 150,
    isVerified: true,
    specialties: ['Brazilian Butt Lift', 'Breast Surgery', 'Body Sculpting', 'Facial'],
    openHours: 'Mon-Fri: 9AM-6PM',
    languages: ['English', 'Portuguese', 'Spanish'],
    procedures: [
      { id: 'br1', name: 'Brazilian Butt Lift (BBL)', category: 'body', description: 'World-renowned BBL expertise', priceFrom: 5000, priceTo: 10000, duration: '3-4 hours', recovery: '4-6 weeks' },
      { id: 'br2', name: 'Breast Augmentation', category: 'breast', description: 'Natural-looking enhancement', priceFrom: 4000, priceTo: 8000, duration: '2 hours', recovery: '3-4 weeks' },
      { id: 'br3', name: 'Tummy Tuck', category: 'body', description: 'Abdominoplasty with liposuction', priceFrom: 5000, priceTo: 12000, duration: '3-4 hours', recovery: '4-6 weeks' },
      { id: 'br4', name: 'Full Body Lipo', category: 'body', description: 'HD liposuction', priceFrom: 6000, priceTo: 15000, duration: '4-6 hours', recovery: '3-4 weeks' },
      { id: 'br5', name: 'Facelift', category: 'face', description: 'Comprehensive facial rejuvenation', priceFrom: 8000, priceTo: 18000, duration: '4-5 hours', recovery: '2-3 weeks' },
    ]
  },
  {
    id: '12',
    name: 'London Smile Clinic',
    image: 'https://images.unsplash.com/photo-1606811841689-23dfddce3e95?w=400&h=300&fit=crop',
    rating: 4.9,
    reviews: 3456,
    location: 'Wimpole Street, London',
    country: 'GB',
    countryFlag: '🇬🇧',
    currency: 'GBP',
    phone: '+44 20 7935 1234',
    email: 'info@londonsmile.co.uk',
    website: 'londonsmile.co.uk',
    consultationFee: 75,
    isVerified: true,
    specialties: ['Cosmetic Dentistry', 'Veneers', 'Implants', 'Smile Makeover'],
    openHours: 'Mon-Fri: 8AM-6PM',
    languages: ['English', 'French', 'Arabic'],
    procedures: [
      { id: 'ls1', name: 'Porcelain Veneers', category: 'dental', description: 'Premium porcelain veneers', priceFrom: 800, priceTo: 1500, duration: '2 visits', recovery: '1 day' },
      { id: 'ls2', name: 'Dental Implants', category: 'dental', description: 'Single tooth implants', priceFrom: 2000, priceTo: 4000, duration: '2-3 visits', recovery: '3-6 months' },
      { id: 'ls3', name: 'Invisalign', category: 'dental', description: 'Clear aligner treatment', priceFrom: 3500, priceTo: 6000, duration: '12-18 months', recovery: 'None' },
      { id: 'ls4', name: 'Composite Bonding', category: 'dental', description: 'Tooth reshaping', priceFrom: 250, priceTo: 500, duration: '1-2 hours', recovery: 'None' },
      { id: 'ls5', name: 'Gum Contouring', category: 'dental', description: 'Reshape gum line', priceFrom: 300, priceTo: 800, duration: '1 hour', recovery: '1-2 weeks' },
      { id: 'ls6', name: 'Full Smile Makeover', category: 'dental', description: 'Complete smile transformation', priceFrom: 8000, priceTo: 25000, duration: 'Multiple visits', recovery: '1-2 weeks' },
    ]
  },
];

const allServices = [
  { id: 'hair-transplant', name: 'Hair Transplant', category: 'hair' },
  { id: 'beard-transplant', name: 'Beard Transplant', category: 'hair' },
  { id: 'prp', name: 'PRP Treatment', category: 'hair' },
  { id: 'botox', name: 'Botox', category: 'face' },
  { id: 'lip-fillers', name: 'Lip Fillers', category: 'face' },
  { id: 'rhinoplasty', name: 'Rhinoplasty', category: 'face' },
  { id: 'facelift', name: 'Facelift', category: 'face' },
  { id: 'eyelid', name: 'Eyelid Surgery', category: 'face' },
  { id: 'bbl', name: 'Brazilian Butt Lift', category: 'body' },
  { id: 'liposuction', name: 'Liposuction', category: 'body' },
  { id: 'tummy-tuck', name: 'Tummy Tuck', category: 'body' },
  { id: 'breast-aug', name: 'Breast Augmentation', category: 'breast' },
  { id: 'breast-lift', name: 'Breast Lift', category: 'breast' },
  { id: 'laser', name: 'Laser Treatment', category: 'skin' },
  { id: 'chemical-peel', name: 'Chemical Peel', category: 'skin' },
  { id: 'microneedling', name: 'Microneedling', category: 'skin' },
  { id: 'veneers', name: 'Dental Veneers', category: 'dental' },
  { id: 'implants', name: 'Dental Implants', category: 'dental' },
  { id: 'whitening', name: 'Teeth Whitening', category: 'dental' },
];

const categories = [
  { id: 'all', name: 'All', icon: '✨' },
  { id: 'hair', name: 'Hair', icon: '💇' },
  { id: 'face', name: 'Face', icon: '👤' },
  { id: 'body', name: 'Body', icon: '🏃' },
  { id: 'breast', name: 'Breast', icon: '💗' },
  { id: 'skin', name: 'Skin', icon: '🧴' },
  { id: 'dental', name: 'Dental', icon: '🦷' },
];

const countries = [
  { code: 'ALL', name: 'All Countries', flag: '🌍' },
  { code: 'GB', name: 'United Kingdom', flag: '🇬🇧' },
  { code: 'US', name: 'United States', flag: '🇺🇸' },
  { code: 'AE', name: 'UAE', flag: '🇦🇪' },
  { code: 'TR', name: 'Turkey', flag: '🇹🇷' },
  { code: 'KR', name: 'South Korea', flag: '🇰🇷' },
  { code: 'TH', name: 'Thailand', flag: '🇹🇭' },
  { code: 'IN', name: 'India', flag: '🇮🇳' },
  { code: 'BD', name: 'Bangladesh', flag: '🇧🇩' },
  { code: 'BR', name: 'Brazil', flag: '🇧🇷' },
];

export default function AestheticsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedClinic, setSelectedClinic] = useState<Clinic | null>(null);
  const [selectedCountry, setSelectedCountry] = useState('ALL');
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const { convertPrice, selectedCurrency } = useCurrency();

  const toggleService = (serviceId: string) => {
    setSelectedServices(prev => 
      prev.includes(serviceId) 
        ? prev.filter(s => s !== serviceId)
        : [...prev, serviceId]
    );
  };

  const clearFilters = () => {
    setSelectedCountry('ALL');
    setSelectedCategory('all');
    setSelectedServices([]);
    setSearchQuery('');
  };

  const activeFilterCount = 
    (selectedCountry !== 'ALL' ? 1 : 0) + 
    (selectedCategory !== 'all' ? 1 : 0) + 
    selectedServices.length;

  const filteredClinics = clinics.filter(clinic => {
    const matchesSearch = searchQuery === '' || 
      clinic.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      clinic.procedures.some(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCountry = selectedCountry === 'ALL' || clinic.country === selectedCountry;
    
    const matchesCategory = selectedCategory === 'all' || 
      clinic.procedures.some(p => p.category === selectedCategory);
    
    const matchesServices = selectedServices.length === 0 || 
      selectedServices.some(serviceId => {
        const service = allServices.find(s => s.id === serviceId);
        if (!service) return false;
        return clinic.procedures.some(p => 
          p.name.toLowerCase().includes(service.name.toLowerCase().split(' ')[0])
        );
      });
    
    return matchesSearch && matchesCountry && matchesCategory && matchesServices;
  });

  const formatPrice = (amount: number, currency: string) => {
    const converted = convertPrice(amount, currency);
    return `${selectedCurrency.symbol}${Math.round(converted).toLocaleString()}`;
  };

  // Get services filtered by selected category
  const filteredServices = selectedCategory === 'all' 
    ? allServices 
    : allServices.filter(s => s.category === selectedCategory);

  if (selectedClinic) {
    return (
      <div className="min-h-screen bg-gray-50 pb-24">
        {/* Clinic Detail Header */}
        <div className="relative">
          <img 
            src={selectedClinic.image} 
            alt={selectedClinic.name}
            className="w-full h-48 object-cover"
          />
          <button 
            onClick={() => setSelectedClinic(null)}
            className="absolute top-4 left-4 w-10 h-10 bg-white/90 backdrop-blur rounded-full flex items-center justify-center shadow-lg"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        </div>

        <div className="px-4 -mt-6 relative">
          {/* Clinic Info Card */}
          <div className="bg-white rounded-2xl shadow-lg p-4 mb-4">
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl font-bold text-gray-900">{selectedClinic.name}</h1>
                  {selectedClinic.isVerified && (
                    <CheckCircle className="w-5 h-5 text-primary fill-primary/20" />
                  )}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 mt-1">
                  <MapPin className="w-4 h-4" />
                  <span>{selectedClinic.location}</span>
                  <span>{selectedClinic.countryFlag}</span>
                </div>
              </div>
              <div className="flex items-center gap-1 bg-amber-50 px-2 py-1 rounded-lg">
                <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                <span className="font-semibold text-amber-700">{selectedClinic.rating}</span>
                <span className="text-xs text-amber-600">({selectedClinic.reviews})</span>
              </div>
            </div>

            {/* Specialties */}
            <div className="flex flex-wrap gap-2 mb-4">
              {selectedClinic.specialties.map((spec, i) => (
                <span key={i} className="bg-primary/10 text-primary text-xs px-2 py-1 rounded-full">
                  {spec}
                </span>
              ))}
            </div>

            {/* Contact Info */}
            <div className="space-y-2 border-t border-gray-100 pt-4">
              <a href={`tel:${selectedClinic.phone}`} className="flex items-center gap-3 text-gray-700 hover:text-primary">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <Phone className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">{selectedClinic.phone}</p>
                  <p className="text-xs text-gray-500">Tap to call</p>
                </div>
              </a>
              <a href={`mailto:${selectedClinic.email}`} className="flex items-center gap-3 text-gray-700 hover:text-primary">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <Mail className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">{selectedClinic.email}</p>
                  <p className="text-xs text-gray-500">Tap to email</p>
                </div>
              </a>
              <div className="flex items-center gap-3 text-gray-700">
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                  <Clock className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">{selectedClinic.openHours}</p>
                  <p className="text-xs text-gray-500">Opening hours</p>
                </div>
              </div>
              <div className="flex items-center gap-3 text-gray-700">
                <div className="w-10 h-10 bg-teal-100 rounded-full flex items-center justify-center">
                  <Globe className="w-5 h-5 text-teal-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">{selectedClinic.languages.join(', ')}</p>
                  <p className="text-xs text-gray-500">Languages spoken</p>
                </div>
              </div>
            </div>
          </div>

          {/* Consultation Fee */}
          <div className="bg-gradient-to-r from-primary to-teal-500 rounded-2xl p-4 mb-4 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/80 text-sm">Consultation Fee</p>
                <p className="text-2xl font-bold">
                  {selectedClinic.consultationFee === 0 
                    ? 'FREE' 
                    : formatPrice(selectedClinic.consultationFee, selectedClinic.currency)
                  }
                </p>
              </div>
              <div className="flex gap-2">
                <button className="bg-white/20 hover:bg-white/30 p-3 rounded-full">
                  <Video className="w-5 h-5" />
                </button>
                <button className="bg-white/20 hover:bg-white/30 p-3 rounded-full">
                  <MessageCircle className="w-5 h-5" />
                </button>
              </div>
            </div>
            <Link 
              to={`/aesthetics/clinic/${selectedClinic.id}/doctors`}
              className="mt-4 w-full bg-white text-primary font-semibold py-3 rounded-xl flex items-center justify-center gap-2"
            >
              View Specialists & Book
            </Link>
          </div>

          {/* Procedures */}
          <div className="mb-4">
            <h2 className="text-lg font-bold text-gray-900 mb-3">Procedures & Pricing</h2>
            <div className="space-y-3">
              {selectedClinic.procedures.map(procedure => (
                <Link 
                  key={procedure.id} 
                  to={`/aesthetics/procedure/${encodeURIComponent(procedure.name)}/${selectedClinic.id}`}
                  className="block bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="font-semibold text-gray-900">{procedure.name}</h3>
                      <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full capitalize">
                        {procedure.category}
                      </span>
                    </div>
                    <div className="text-right">
                      <p className="text-primary font-bold">
                        {formatPrice(procedure.priceFrom, selectedClinic.currency)} - {formatPrice(procedure.priceTo, selectedClinic.currency)}
                      </p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{procedure.description}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {procedure.duration}
                      </span>
                      <span className="flex items-center gap-1">
                        <Shield className="w-3 h-3" /> Recovery: {procedure.recovery}
                      </span>
                    </div>
                    <span className="text-xs text-primary font-medium flex items-center gap-1">
                      View Details <ChevronRight className="w-3 h-3" />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <div className="bg-gradient-to-br from-pink-500 via-purple-500 to-indigo-500 text-white px-4 pt-12 pb-6">
        <div className="flex items-center gap-3 mb-4">
          <Link to="/more" className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-2xl font-bold">Cosmetics & Aesthetics</h1>
            <p className="text-white/80 text-sm">Find clinics for enhancements & procedures</p>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search procedures or clinics..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 rounded-xl bg-white text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-white/50"
          />
        </div>
      </div>

      <div className="px-4 -mt-2">
        {/* Filter Toggle Button */}
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="w-full bg-white rounded-xl p-3 shadow-sm mb-3 flex items-center justify-between"
        >
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-primary" />
            <span className="font-medium text-gray-900">Filters</span>
            {activeFilterCount > 0 && (
              <span className="bg-primary text-white text-xs px-2 py-0.5 rounded-full">
                {activeFilterCount}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {activeFilterCount > 0 && (
              <button 
                onClick={(e) => { e.stopPropagation(); clearFilters(); }}
                className="text-xs text-red-500 hover:text-red-600"
              >
                Clear all
              </button>
            )}
            {showFilters ? <ChevronUp className="w-5 h-5 text-gray-400" /> : <ChevronDown className="w-5 h-5 text-gray-400" />}
          </div>
        </button>

        {/* Collapsible Filter Panel */}
        {showFilters && (
          <div className="bg-white rounded-xl p-4 shadow-sm mb-4 space-y-4">
            {/* Country Filter */}
            <div>
              <h3 className="text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                <Globe className="w-4 h-4" /> Country
              </h3>
              <div className="flex flex-wrap gap-2">
                {countries.map(country => (
                  <button
                    key={country.code}
                    onClick={() => setSelectedCountry(country.code)}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-sm transition-colors ${
                      selectedCountry === country.code
                        ? 'bg-primary text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    <span>{country.flag}</span>
                    <span>{country.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Category Filter */}
            <div>
              <h3 className="text-sm font-semibold text-gray-700 mb-2">Category</h3>
              <div className="flex flex-wrap gap-2">
                {categories.map(cat => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-sm transition-colors ${
                      selectedCategory === cat.id
                        ? 'bg-gradient-to-r from-pink-500 to-purple-500 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    <span>{cat.icon}</span>
                    <span>{cat.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Service Filter */}
            <div>
              <h3 className="text-sm font-semibold text-gray-700 mb-2">
                Services {selectedCategory !== 'all' && `(${categories.find(c => c.id === selectedCategory)?.name})`}
              </h3>
              <div className="flex flex-wrap gap-2">
                {filteredServices.map(service => (
                  <button
                    key={service.id}
                    onClick={() => toggleService(service.id)}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-sm transition-colors ${
                      selectedServices.includes(service.id)
                        ? 'bg-indigo-500 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {selectedServices.includes(service.id) && <CheckCircle className="w-3 h-3" />}
                    <span>{service.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Active Filters Display (when collapsed) */}
        {!showFilters && activeFilterCount > 0 && (
          <div className="flex flex-wrap gap-2 mb-3">
            {selectedCountry !== 'ALL' && (
              <span className="flex items-center gap-1 bg-primary/10 text-primary text-sm px-3 py-1 rounded-full">
                {countries.find(c => c.code === selectedCountry)?.flag} {countries.find(c => c.code === selectedCountry)?.name}
                <button onClick={() => setSelectedCountry('ALL')} className="ml-1 hover:bg-primary/20 rounded-full p-0.5">
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
            {selectedCategory !== 'all' && (
              <span className="flex items-center gap-1 bg-purple-100 text-purple-700 text-sm px-3 py-1 rounded-full">
                {categories.find(c => c.id === selectedCategory)?.icon} {categories.find(c => c.id === selectedCategory)?.name}
                <button onClick={() => setSelectedCategory('all')} className="ml-1 hover:bg-purple-200 rounded-full p-0.5">
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
            {selectedServices.map(serviceId => {
              const service = allServices.find(s => s.id === serviceId);
              return service ? (
                <span key={serviceId} className="flex items-center gap-1 bg-indigo-100 text-indigo-700 text-sm px-3 py-1 rounded-full">
                  {service.name}
                  <button onClick={() => toggleService(serviceId)} className="ml-1 hover:bg-indigo-200 rounded-full p-0.5">
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ) : null;
            })}
          </div>
        )}

        {/* Disclaimer */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 mb-4">
          <p className="text-xs text-amber-800">
            <strong>Important:</strong> Always consult with qualified medical professionals. Results may vary. 
            All procedures carry risks that should be discussed during consultation.
          </p>
        </div>

        {/* Results Count */}
        <div className="flex items-center justify-between mb-3">
          <p className="text-sm text-gray-600">
            <span className="font-semibold text-gray-900">{filteredClinics.length}</span> clinics found
          </p>
        </div>

        {/* Clinics List */}
        <div className="space-y-4">
          {filteredClinics.map(clinic => (
            <button
              key={clinic.id}
              onClick={() => setSelectedClinic(clinic)}
              className="w-full bg-white rounded-2xl shadow-sm overflow-hidden text-left hover:shadow-md transition-shadow"
            >
              <div className="relative">
                <img 
                  src={clinic.image} 
                  alt={clinic.name}
                  className="w-full h-36 object-cover"
                />
                {clinic.isVerified && (
                  <div className="absolute top-2 right-2 bg-white/90 backdrop-blur px-2 py-1 rounded-full flex items-center gap-1">
                    <CheckCircle className="w-3 h-3 text-primary" />
                    <span className="text-xs font-medium text-primary">Verified</span>
                  </div>
                )}
                <div className="absolute bottom-2 left-2 bg-white/90 backdrop-blur px-2 py-1 rounded-full flex items-center gap-1">
                  <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                  <span className="text-xs font-semibold">{clinic.rating}</span>
                  <span className="text-xs text-gray-500">({clinic.reviews})</span>
                </div>
              </div>
              <div className="p-4">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold text-gray-900">{clinic.name}</h3>
                  <span>{clinic.countryFlag}</span>
                </div>
                <div className="flex items-center gap-1 text-sm text-gray-500 mb-2">
                  <MapPin className="w-3 h-3" />
                  <span>{clinic.location}</span>
                </div>
                <div className="flex flex-wrap gap-1 mb-3">
                  {clinic.specialties.slice(0, 3).map((spec, i) => (
                    <span key={i} className="bg-gray-100 text-gray-600 text-xs px-2 py-0.5 rounded-full">
                      {spec}
                    </span>
                  ))}
                  {clinic.specialties.length > 3 && (
                    <span className="text-gray-400 text-xs">+{clinic.specialties.length - 3}</span>
                  )}
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs text-gray-500">Consultation from</span>
                    <p className="text-primary font-bold">
                      {clinic.consultationFee === 0 
                        ? 'FREE' 
                        : formatPrice(clinic.consultationFee, clinic.currency)
                      }
                    </p>
                  </div>
                  <div className="flex items-center gap-1 text-primary">
                    <span className="text-sm font-medium">View Details</span>
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>

        {filteredClinics.length === 0 && (
          <div className="text-center py-12">
            <Sparkles className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 mb-2">No clinics found matching your filters</p>
            <button 
              onClick={clearFilters}
              className="text-primary text-sm font-medium hover:underline"
            >
              Clear all filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
