import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Star, Plus, Search, Trash2, Flame } from 'lucide-react';

interface FavoriteFood {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  servingSize: string;
  emoji: string;
  timesLogged: number;
}

const initialFavorites: FavoriteFood[] = [
  { id: '1', name: 'Greek Yogurt Parfait', calories: 280, protein: 18, carbs: 32, fat: 8, servingSize: '1 bowl', emoji: '🥛', timesLogged: 24 },
  { id: '2', name: 'Grilled Chicken Breast', calories: 165, protein: 31, carbs: 0, fat: 4, servingSize: '100g', emoji: '🍗', timesLogged: 18 },
  { id: '3', name: 'Avocado Toast', calories: 320, protein: 8, carbs: 35, fat: 18, servingSize: '1 slice', emoji: '🥑', timesLogged: 15 },
  { id: '4', name: 'Salmon Fillet', calories: 208, protein: 28, carbs: 0, fat: 10, servingSize: '100g', emoji: '🐟', timesLogged: 12 },
  { id: '5', name: 'Mixed Berry Smoothie', calories: 220, protein: 6, carbs: 42, fat: 4, servingSize: '1 glass', emoji: '🫐', timesLogged: 10 },
  { id: '6', name: 'Quinoa Bowl', calories: 380, protein: 14, carbs: 58, fat: 12, servingSize: '1 bowl', emoji: '🥙', timesLogged: 8 },
];

export default function FoodFavorites() {
  const navigate = useNavigate();
  const [favorites, setFavorites] = useState(initialFavorites);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredFavorites = favorites.filter(food =>
    food.name.toLowerCase().includes(searchQuery.toLowerCase())
  ).sort((a, b) => b.timesLogged - a.timesLogged);

  const removeFavorite = (id: string) => {
    setFavorites(prev => prev.filter(f => f.id !== id));
  };

  const addToLog = (food: FavoriteFood) => {
    // TODO: Add to today's log
    alert(`Added ${food.name} to today's log!`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-rose-50 to-white pb-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-rose-500 to-pink-600 text-white px-4 py-4 pb-6">
        <div className="flex items-center gap-3 mb-2">
          <button onClick={() => navigate('/tracker')} className="p-2 hover:bg-white/20 rounded-full transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-bold">Favorite Foods</h1>
        </div>
        <p className="text-rose-100 text-sm ml-10">Quick add your go-to meals</p>
      </div>

      <main className="px-4 -mt-3 max-w-lg mx-auto">
        {/* Search */}
        <div className="bg-white rounded-2xl shadow-lg p-4 mb-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search favorites..."
              className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Stats */}
        <div className="bg-gradient-to-r from-rose-500 to-pink-600 rounded-2xl p-4 mb-4 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-rose-100 text-sm">Total Favorites</p>
              <p className="text-3xl font-bold">{favorites.length}</p>
            </div>
            <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center">
              <Star className="w-7 h-7 text-white" />
            </div>
          </div>
        </div>

        {/* Favorites List */}
        <div className="space-y-3">
          {filteredFavorites.length > 0 ? (
            filteredFavorites.map(food => (
              <div key={food.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                <div className="flex items-start gap-3">
                  <div className="w-14 h-14 bg-gradient-to-br from-rose-100 to-pink-100 rounded-xl flex items-center justify-center text-2xl">
                    {food.emoji}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-gray-900">{food.name}</h3>
                        <p className="text-xs text-gray-500">{food.servingSize}</p>
                      </div>
                      <button
                        onClick={() => removeFavorite(food.id)}
                        className="p-1.5 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4 text-red-400" />
                      </button>
                    </div>
                    <div className="flex items-center gap-3 mt-2">
                      <div className="flex items-center gap-1">
                        <Flame className="w-3 h-3 text-orange-500" />
                        <span className="text-sm font-medium text-gray-900">{food.calories} kcal</span>
                      </div>
                      <span className="text-xs text-gray-400">Logged {food.timesLogged}x</span>
                    </div>
                    <div className="flex items-center gap-3 mt-1 text-xs text-gray-500">
                      <span>P: {food.protein}g</span>
                      <span>C: {food.carbs}g</span>
                      <span>F: {food.fat}g</span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => addToLog(food)}
                  className="w-full mt-3 py-2.5 bg-gradient-to-r from-rose-500 to-pink-600 text-white rounded-xl font-medium flex items-center justify-center gap-2 hover:shadow-lg transition-all"
                >
                  <Plus className="w-4 h-4" /> Add to Today
                </button>
              </div>
            ))
          ) : (
            <div className="text-center py-12 bg-white rounded-2xl">
              <Star className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No favorites found</p>
              <p className="text-sm text-gray-400">Foods you frequently log will appear here</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
