import { useState } from 'react';
import { useNavigate } from 'react-router';
import { 
  ArrowLeft, 
  Calendar, 
  Clock, 
  Video, 
  Phone, 
  MessageSquare,
  MapPin,
  AlertCircle,
  ChevronRight,
  Bell
} from 'lucide-react';
import { cn } from '@/react-app/lib/utils';
import BottomNav from '@/react-app/components/BottomNav';

type TabType = 'upcoming' | 'completed' | 'cancelled';

interface Appointment {
  id: string;
  doctor: string;
  doctorImage: string;
  specialty: string;
  date: string;
  time: string;
  type: 'video' | 'voice' | 'chat' | 'in-person';
  status: 'upcoming' | 'completed' | 'cancelled';
  hospital?: string;
  reason: string;
  reminder: boolean;
}

const appointments: Appointment[] = [
  {
    id: 'apt-1',
    doctor: 'Dr. Sarah Ahmed',
    doctorImage: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200&h=200&fit=crop&crop=face',
    specialty: 'General Physician',
    date: '2024-01-25',
    time: '10:00 AM',
    type: 'video',
    status: 'upcoming',
    reason: 'Follow-up on diabetes medication',
    reminder: true
  },
  {
    id: 'apt-2',
    doctor: 'Dr. Mohammad Rahman',
    doctorImage: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop&crop=face',
    specialty: 'Cardiologist',
    date: '2024-01-28',
    time: '2:30 PM',
    type: 'in-person',
    status: 'upcoming',
    hospital: 'Heart Care Hospital',
    reason: 'Routine heart checkup',
    reminder: true
  },
  {
    id: 'apt-3',
    doctor: 'Dr. Fatima Khan',
    doctorImage: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=200&h=200&fit=crop&crop=face',
    specialty: 'Gynecologist',
    date: '2024-02-05',
    time: '11:00 AM',
    type: 'voice',
    status: 'upcoming',
    reason: 'Monthly consultation',
    reminder: false
  },
  {
    id: 'apt-4',
    doctor: 'Dr. Rezwan Ali',
    doctorImage: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=200&h=200&fit=crop&crop=face',
    specialty: 'Dermatologist',
    date: '2024-01-15',
    time: '3:00 PM',
    type: 'video',
    status: 'completed',
    reason: 'Skin allergy treatment',
    reminder: false
  },
  {
    id: 'apt-5',
    doctor: 'Dr. Nadia Hossain',
    doctorImage: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=200&h=200&fit=crop&crop=face',
    specialty: 'Pediatrician',
    date: '2024-01-10',
    time: '9:00 AM',
    type: 'chat',
    status: 'cancelled',
    reason: 'Child vaccination query',
    reminder: false
  }
];

export default function AppointmentsPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<TabType>('upcoming');

  const filteredAppointments = appointments.filter(apt => apt.status === activeTab);

  const getTypeIcon = (type: Appointment['type']) => {
    switch (type) {
      case 'video': return Video;
      case 'voice': return Phone;
      case 'chat': return MessageSquare;
      case 'in-person': return MapPin;
    }
  };

  const getTypeLabel = (type: Appointment['type']) => {
    switch (type) {
      case 'video': return 'Video Call';
      case 'voice': return 'Voice Call';
      case 'chat': return 'Text Chat';
      case 'in-person': return 'In-Person';
    }
  };

  const getStatusColor = (status: Appointment['status']) => {
    switch (status) {
      case 'upcoming': return 'bg-blue-100 text-blue-600';
      case 'completed': return 'bg-green-100 text-green-600';
      case 'cancelled': return 'bg-red-100 text-red-600';
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    if (date.toDateString() === today.toDateString()) return 'Today';
    if (date.toDateString() === tomorrow.toDateString()) return 'Tomorrow';
    return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="sticky top-0 bg-gradient-to-r from-primary to-teal-500 px-4 py-4 z-40">
        <div className="flex items-center gap-3 max-w-lg mx-auto">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 rounded-full hover:bg-white/20 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-white">My Appointments</h1>
            <p className="text-sm text-white/80">Manage your schedule</p>
          </div>
          <button className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors relative">
            <Bell className="w-5 h-5 text-white" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
          </button>
        </div>
      </header>

      <main className="px-4 py-4 max-w-lg mx-auto space-y-4">
        {/* Tabs */}
        <div className="bg-white rounded-xl p-1 flex shadow-sm border border-gray-100">
          {[
            { id: 'upcoming', label: 'Upcoming', count: appointments.filter(a => a.status === 'upcoming').length },
            { id: 'completed', label: 'Completed', count: appointments.filter(a => a.status === 'completed').length },
            { id: 'cancelled', label: 'Cancelled', count: appointments.filter(a => a.status === 'cancelled').length }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as TabType)}
              className={cn(
                'flex-1 py-2.5 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-1.5',
                activeTab === tab.id
                  ? 'bg-primary text-white shadow-sm'
                  : 'text-gray-500 hover:text-gray-700'
              )}
            >
              {tab.label}
              {tab.count > 0 && (
                <span className={cn(
                  'px-1.5 py-0.5 rounded-full text-xs',
                  activeTab === tab.id ? 'bg-white/20' : 'bg-gray-100'
                )}>
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Upcoming Notice */}
        {activeTab === 'upcoming' && filteredAppointments.length > 0 && (
          <div className="flex gap-3 p-4 bg-blue-50 rounded-xl border border-blue-100">
            <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium text-blue-800">Reminder</p>
              <p className="text-blue-700">
                You have {filteredAppointments.length} upcoming appointment{filteredAppointments.length > 1 ? 's' : ''}. Don't forget to prepare any documents or questions.
              </p>
            </div>
          </div>
        )}

        {/* Appointments List */}
        <section className="space-y-3">
          {filteredAppointments.map(apt => {
            const TypeIcon = getTypeIcon(apt.type);
            return (
              <div
                key={apt.id}
                className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden"
              >
                <div className="p-4">
                  <div className="flex items-start gap-4">
                    <img
                      src={apt.doctorImage}
                      alt={apt.doctor}
                      className="w-14 h-14 rounded-xl object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="font-semibold text-gray-900">{apt.doctor}</p>
                          <p className="text-sm text-primary">{apt.specialty}</p>
                        </div>
                        {apt.reminder && apt.status === 'upcoming' && (
                          <Bell className="w-4 h-4 text-primary" />
                        )}
                      </div>
                      
                      <div className="flex flex-wrap items-center gap-2 mt-2">
                        <span className={cn(
                          'px-2 py-1 rounded-lg text-xs font-medium flex items-center gap-1',
                          apt.type === 'video' ? 'bg-blue-100 text-blue-600' :
                          apt.type === 'voice' ? 'bg-green-100 text-green-600' :
                          apt.type === 'chat' ? 'bg-purple-100 text-purple-600' :
                          'bg-orange-100 text-orange-600'
                        )}>
                          <TypeIcon className="w-3 h-3" />
                          {getTypeLabel(apt.type)}
                        </span>
                        <span className={cn('px-2 py-1 rounded-lg text-xs font-medium', getStatusColor(apt.status))}>
                          {apt.status.charAt(0).toUpperCase() + apt.status.slice(1)}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 p-3 bg-gray-50 rounded-xl space-y-2">
                    <div className="flex items-center gap-3 text-sm">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <span className="text-gray-900 font-medium">{formatDate(apt.date)}</span>
                      <Clock className="w-4 h-4 text-gray-400 ml-2" />
                      <span className="text-gray-900 font-medium">{apt.time}</span>
                    </div>
                    {apt.hospital && (
                      <div className="flex items-center gap-3 text-sm">
                        <MapPin className="w-4 h-4 text-gray-400" />
                        <span className="text-gray-600">{apt.hospital}</span>
                      </div>
                    )}
                    <div className="text-sm text-gray-500">
                      <span className="font-medium text-gray-600">Reason:</span> {apt.reason}
                    </div>
                  </div>
                </div>

                {apt.status === 'upcoming' && (
                  <div className="border-t border-gray-100 flex">
                    <button className="flex-1 flex items-center justify-center gap-2 py-3 text-red-500 hover:bg-red-50 transition-colors text-sm font-medium">
                      Cancel
                    </button>
                    <div className="w-px bg-gray-100" />
                    <button className="flex-1 flex items-center justify-center gap-2 py-3 text-primary hover:bg-primary/5 transition-colors text-sm font-medium">
                      Reschedule
                    </button>
                    <div className="w-px bg-gray-100" />
                    <button className="flex-1 flex items-center justify-center gap-2 py-3 text-primary hover:bg-primary/5 transition-colors text-sm font-medium">
                      Join <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                )}

                {apt.status === 'completed' && (
                  <div className="border-t border-gray-100 flex">
                    <button className="flex-1 flex items-center justify-center gap-2 py-3 text-primary hover:bg-primary/5 transition-colors text-sm font-medium">
                      View Summary
                    </button>
                    <div className="w-px bg-gray-100" />
                    <button className="flex-1 flex items-center justify-center gap-2 py-3 text-primary hover:bg-primary/5 transition-colors text-sm font-medium">
                      Book Again
                    </button>
                  </div>
                )}
              </div>
            );
          })}

          {filteredAppointments.length === 0 && (
            <div className="text-center py-12 bg-white rounded-2xl border border-gray-100">
              <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No {activeTab} appointments</p>
              {activeTab === 'upcoming' && (
                <button
                  onClick={() => navigate('/doctors')}
                  className="mt-4 px-6 py-2 bg-primary text-white rounded-lg text-sm font-medium"
                >
                  Find a Doctor
                </button>
              )}
            </div>
          )}
        </section>
      </main>

      <BottomNav />
    </div>
  );
}
