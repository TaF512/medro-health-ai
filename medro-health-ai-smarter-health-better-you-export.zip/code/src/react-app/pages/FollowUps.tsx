import { useState } from 'react';
import { useNavigate } from 'react-router';
import { 
  ArrowLeft, 
  Calendar, 
  Clock, 
  Video, 
  Phone, 
  MessageSquare,
  AlertCircle,
  ChevronRight,
  Check,
  X,
  RefreshCw
} from 'lucide-react';
import { cn } from '@/react-app/lib/utils';
import BottomNav from '@/react-app/components/BottomNav';

interface FollowUp {
  id: string;
  doctor: string;
  doctorImage: string;
  specialty: string;
  originalDate: string;
  suggestedDate: string;
  suggestedTime: string;
  type: 'video' | 'voice' | 'chat';
  reason: string;
  notes?: string;
  status: 'pending' | 'scheduled' | 'declined';
  priority: 'high' | 'medium' | 'low';
}

const followUps: FollowUp[] = [
  {
    id: 'fu-1',
    doctor: 'Dr. Sarah Ahmed',
    doctorImage: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200&h=200&fit=crop&crop=face',
    specialty: 'General Physician',
    originalDate: '2024-01-15',
    suggestedDate: '2024-02-15',
    suggestedTime: '10:00 AM',
    type: 'video',
    reason: 'Diabetes medication review',
    notes: 'Please bring your recent blood sugar logs',
    status: 'pending',
    priority: 'high'
  },
  {
    id: 'fu-2',
    doctor: 'Dr. Mohammad Rahman',
    doctorImage: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop&crop=face',
    specialty: 'Cardiologist',
    originalDate: '2024-01-08',
    suggestedDate: '2024-02-08',
    suggestedTime: '2:30 PM',
    type: 'voice',
    reason: 'Blood pressure monitoring follow-up',
    status: 'scheduled',
    priority: 'medium'
  },
  {
    id: 'fu-3',
    doctor: 'Dr. Rezwan Ali',
    doctorImage: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=200&h=200&fit=crop&crop=face',
    specialty: 'Dermatologist',
    originalDate: '2023-12-20',
    suggestedDate: '2024-01-20',
    suggestedTime: '3:00 PM',
    type: 'chat',
    reason: 'Check skin condition improvement',
    status: 'pending',
    priority: 'low'
  },
  {
    id: 'fu-4',
    doctor: 'Dr. Kamal Uddin',
    doctorImage: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=200&h=200&fit=crop&crop=face',
    specialty: 'Psychiatrist',
    originalDate: '2024-01-05',
    suggestedDate: '2024-01-19',
    suggestedTime: '5:00 PM',
    type: 'video',
    reason: 'Mental health check-in',
    notes: 'Discuss progress with current treatment plan',
    status: 'pending',
    priority: 'high'
  }
];

export default function FollowUpsPage() {
  const navigate = useNavigate();
  const [followUpList, setFollowUpList] = useState(followUps);

  const pendingCount = followUpList.filter(f => f.status === 'pending').length;
  const scheduledCount = followUpList.filter(f => f.status === 'scheduled').length;

  const getTypeIcon = (type: FollowUp['type']) => {
    switch (type) {
      case 'video': return Video;
      case 'voice': return Phone;
      case 'chat': return MessageSquare;
    }
  };

  const getPriorityColor = (priority: FollowUp['priority']) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-600 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-600 border-green-200';
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  };

  const handleAccept = (id: string) => {
    setFollowUpList(prev => prev.map(f => 
      f.id === id ? { ...f, status: 'scheduled' as const } : f
    ));
  };

  const handleDecline = (id: string) => {
    setFollowUpList(prev => prev.map(f => 
      f.id === id ? { ...f, status: 'declined' as const } : f
    ));
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="sticky top-0 bg-gradient-to-r from-amber-500 to-orange-500 px-4 py-4 z-40">
        <div className="flex items-center gap-3 max-w-lg mx-auto">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 rounded-full hover:bg-white/20 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-white">Follow-up Consultations</h1>
            <p className="text-sm text-white/80">Doctor recommended visits</p>
          </div>
          <RefreshCw className="w-5 h-5 text-white" />
        </div>
      </header>

      <main className="px-4 py-4 max-w-lg mx-auto space-y-4">
        {/* Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
                <AlertCircle className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{pendingCount}</p>
                <p className="text-sm text-gray-500">Pending</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <Check className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{scheduledCount}</p>
                <p className="text-sm text-gray-500">Scheduled</p>
              </div>
            </div>
          </div>
        </div>

        {/* Info Banner */}
        {pendingCount > 0 && (
          <div className="flex gap-3 p-4 bg-amber-50 rounded-xl border border-amber-100">
            <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium text-amber-800">Action Required</p>
              <p className="text-amber-700">
                You have {pendingCount} follow-up consultation{pendingCount > 1 ? 's' : ''} recommended by your doctors. Please confirm or reschedule.
              </p>
            </div>
          </div>
        )}

        {/* Follow-ups List */}
        <section className="space-y-3">
          <h2 className="font-semibold text-gray-900">Recommended Follow-ups</h2>

          {followUpList.filter(f => f.status !== 'declined').map(fu => {
            const TypeIcon = getTypeIcon(fu.type);
            return (
              <div
                key={fu.id}
                className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden"
              >
                <div className="p-4">
                  <div className="flex items-start gap-4">
                    <img
                      src={fu.doctorImage}
                      alt={fu.doctor}
                      className="w-14 h-14 rounded-xl object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="font-semibold text-gray-900">{fu.doctor}</p>
                          <p className="text-sm text-primary">{fu.specialty}</p>
                        </div>
                        <span className={cn(
                          'px-2 py-1 rounded-lg text-xs font-medium border',
                          getPriorityColor(fu.priority)
                        )}>
                          {fu.priority.charAt(0).toUpperCase() + fu.priority.slice(1)} Priority
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-2 mt-2">
                        <span className={cn(
                          'px-2 py-1 rounded-lg text-xs font-medium flex items-center gap-1',
                          fu.type === 'video' ? 'bg-blue-100 text-blue-600' :
                          fu.type === 'voice' ? 'bg-green-100 text-green-600' :
                          'bg-purple-100 text-purple-600'
                        )}>
                          <TypeIcon className="w-3 h-3" />
                          {fu.type === 'video' ? 'Video' : fu.type === 'voice' ? 'Voice' : 'Chat'}
                        </span>
                        {fu.status === 'scheduled' && (
                          <span className="px-2 py-1 rounded-lg text-xs font-medium bg-green-100 text-green-600">
                            ✓ Scheduled
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 p-3 bg-gray-50 rounded-xl space-y-2">
                    <div className="flex items-center gap-3 text-sm">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <span className="text-gray-600">Suggested:</span>
                      <span className="text-gray-900 font-medium">{formatDate(fu.suggestedDate)}</span>
                      <Clock className="w-4 h-4 text-gray-400 ml-2" />
                      <span className="text-gray-900 font-medium">{fu.suggestedTime}</span>
                    </div>
                    <div className="text-sm">
                      <span className="text-gray-500">Last visit:</span>
                      <span className="text-gray-700 ml-2">{formatDate(fu.originalDate)}</span>
                    </div>
                    <div className="text-sm text-gray-600">
                      <span className="font-medium">Reason:</span> {fu.reason}
                    </div>
                    {fu.notes && (
                      <div className="text-sm text-amber-700 bg-amber-50 p-2 rounded-lg">
                        <span className="font-medium">Note:</span> {fu.notes}
                      </div>
                    )}
                  </div>
                </div>

                {fu.status === 'pending' && (
                  <div className="border-t border-gray-100 flex">
                    <button
                      onClick={() => handleDecline(fu.id)}
                      className="flex-1 flex items-center justify-center gap-2 py-3 text-gray-500 hover:bg-gray-50 transition-colors text-sm font-medium"
                    >
                      <X className="w-4 h-4" />
                      Decline
                    </button>
                    <div className="w-px bg-gray-100" />
                    <button className="flex-1 flex items-center justify-center gap-2 py-3 text-primary hover:bg-primary/5 transition-colors text-sm font-medium">
                      <Calendar className="w-4 h-4" />
                      Change Date
                    </button>
                    <div className="w-px bg-gray-100" />
                    <button
                      onClick={() => handleAccept(fu.id)}
                      className="flex-1 flex items-center justify-center gap-2 py-3 bg-primary text-white hover:bg-primary/90 transition-colors text-sm font-medium"
                    >
                      <Check className="w-4 h-4" />
                      Confirm
                    </button>
                  </div>
                )}

                {fu.status === 'scheduled' && (
                  <div className="border-t border-gray-100 flex">
                    <button className="flex-1 flex items-center justify-center gap-2 py-3 text-primary hover:bg-primary/5 transition-colors text-sm font-medium">
                      View Details <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            );
          })}

          {followUpList.filter(f => f.status !== 'declined').length === 0 && (
            <div className="text-center py-12 bg-white rounded-2xl border border-gray-100">
              <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No follow-ups scheduled</p>
              <p className="text-sm text-gray-400 mt-1">Your doctors will recommend follow-ups after consultations</p>
            </div>
          )}
        </section>
      </main>

      <BottomNav />
    </div>
  );
}
