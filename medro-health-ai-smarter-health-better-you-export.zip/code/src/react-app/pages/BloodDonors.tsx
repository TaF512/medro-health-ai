import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Droplets, Search, Users, Shield, Info, Loader2, MapPin, Phone, Mail } from 'lucide-react';
import { cn } from '@/react-app/lib/utils';
import BottomNav from '@/react-app/components/BottomNav';

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

// Compatibility info for display
const COMPATIBILITY_INFO: Record<string, { canReceiveFrom: string[], canDonateTo: string[] }> = {
  'A+': { canReceiveFrom: ['A+', 'A-', 'O+', 'O-'], canDonateTo: ['A+', 'AB+'] },
  'A-': { canReceiveFrom: ['A-', 'O-'], canDonateTo: ['A+', 'A-', 'AB+', 'AB-'] },
  'B+': { canReceiveFrom: ['B+', 'B-', 'O+', 'O-'], canDonateTo: ['B+', 'AB+'] },
  'B-': { canReceiveFrom: ['B-', 'O-'], canDonateTo: ['B+', 'B-', 'AB+', 'AB-'] },
  'AB+': { canReceiveFrom: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'], canDonateTo: ['AB+'] },
  'AB-': { canReceiveFrom: ['A-', 'B-', 'AB-', 'O-'], canDonateTo: ['AB+', 'AB-'] },
  'O+': { canReceiveFrom: ['O+', 'O-'], canDonateTo: ['A+', 'B+', 'AB+', 'O+'] },
  'O-': { canReceiveFrom: ['O-'], canDonateTo: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] },
};

interface Donor {
  name: string;
  bloodGroup: string;
  avatar: string | null;
  location: string;
  phone: string;
  email: string;
}

export default function BloodDonorsPage() {
  const navigate = useNavigate();
  const [selectedBloodGroup, setSelectedBloodGroup] = useState<string>('');
  const [donors, setDonors] = useState<Donor[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  const searchDonors = async (bloodGroup: string) => {
    if (!bloodGroup) return;
    
    setIsLoading(true);
    setHasSearched(true);
    try {
      const res = await fetch(`/api/blood-donors?bloodGroup=${encodeURIComponent(bloodGroup)}`);
      const data = await res.json();
      setDonors(data.donors || []);
    } catch (error) {
      console.error('Failed to search donors:', error);
      setDonors([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectBloodGroup = (group: string) => {
    setSelectedBloodGroup(group);
    searchDonors(group);
  };

  const compatInfo = selectedBloodGroup ? COMPATIBILITY_INFO[selectedBloodGroup] : null;

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="sticky top-0 bg-gradient-to-r from-red-500 to-red-600 px-4 py-4 z-40">
        <div className="flex items-center gap-3 max-w-lg mx-auto">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 rounded-full hover:bg-white/20 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div>
            <h1 className="text-lg font-bold text-white">Find Blood Donors</h1>
            <p className="text-sm text-white/80">Search compatible donors near you</p>
          </div>
        </div>
      </header>

      <main className="px-4 py-6 max-w-lg mx-auto space-y-6">
        {/* Privacy Notice */}
        <div className="bg-blue-50 rounded-2xl p-4 border border-blue-100 flex gap-3">
          <Shield className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm text-blue-800 font-medium">Privacy Protected</p>
            <p className="text-xs text-blue-600 mt-1">
              Only users who have opted in to share their blood group publicly and are willing to donate appear in search results.
            </p>
          </div>
        </div>

        {/* Blood Group Selection */}
        <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-red-100 rounded-xl flex items-center justify-center">
              <Droplets className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <h2 className="font-semibold text-gray-900">Select Blood Group Needed</h2>
              <p className="text-sm text-gray-500">We'll find compatible donors</p>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-2">
            {BLOOD_GROUPS.map(group => (
              <button
                key={group}
                onClick={() => handleSelectBloodGroup(group)}
                className={cn(
                  'py-3 rounded-xl font-bold text-lg transition-all',
                  selectedBloodGroup === group
                    ? 'bg-red-500 text-white shadow-lg shadow-red-200 scale-105'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                )}
              >
                {group}
              </button>
            ))}
          </div>
        </section>

        {/* Compatibility Info */}
        {compatInfo && (
          <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-center gap-2 mb-4">
              <Info className="w-5 h-5 text-gray-600" />
              <h2 className="font-semibold text-gray-900">Compatibility for {selectedBloodGroup}</h2>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-green-50 rounded-xl p-3">
                <p className="text-xs font-medium text-green-800 mb-2">Can Receive From</p>
                <div className="flex flex-wrap gap-1">
                  {compatInfo.canReceiveFrom.map(bg => (
                    <span key={bg} className="px-2 py-1 bg-green-200 text-green-800 rounded text-xs font-semibold">
                      {bg}
                    </span>
                  ))}
                </div>
              </div>
              <div className="bg-blue-50 rounded-xl p-3">
                <p className="text-xs font-medium text-blue-800 mb-2">Can Donate To</p>
                <div className="flex flex-wrap gap-1">
                  {compatInfo.canDonateTo.map(bg => (
                    <span key={bg} className="px-2 py-1 bg-blue-200 text-blue-800 rounded text-xs font-semibold">
                      {bg}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Search Results */}
        {hasSearched && (
          <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center">
                <Users className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <h2 className="font-semibold text-gray-900">Available Donors</h2>
                <p className="text-sm text-gray-500">
                  {isLoading ? 'Searching...' : `${donors.length} donor${donors.length !== 1 ? 's' : ''} found`}
                </p>
              </div>
            </div>

            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-8 h-8 text-red-500 animate-spin" />
              </div>
            ) : donors.length === 0 ? (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-gray-400" />
                </div>
                <p className="text-gray-600 font-medium">No donors found</p>
                <p className="text-sm text-gray-500 mt-1">
                  No compatible donors have opted to share their blood group yet
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {donors.map((donor, idx) => (
                  <div key={idx} className="p-4 bg-gray-50 rounded-xl">
                    <div className="flex items-center gap-3 mb-3">
                      {donor.avatar ? (
                        <img src={donor.avatar} alt="" className="w-12 h-12 rounded-full" />
                      ) : (
                        <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                          <span className="text-lg font-bold text-red-600">
                            {donor.name.charAt(0)}
                          </span>
                        </div>
                      )}
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">{donor.name}</p>
                        <p className="text-sm text-gray-500">Willing to donate</p>
                      </div>
                      <span className="px-3 py-1.5 bg-red-100 text-red-700 rounded-full text-sm font-bold">
                        {donor.bloodGroup}
                      </span>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2 text-gray-600">
                        <MapPin className="w-4 h-4 text-gray-400" />
                        <span>{donor.location}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-gray-400" />
                        <a href={`tel:${donor.phone}`} className="text-primary font-medium hover:underline">
                          {donor.phone}
                        </a>
                      </div>
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-gray-400" />
                        <a href={`mailto:${donor.email}`} className="text-primary font-medium hover:underline">
                          {donor.email}
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        )}

        {/* Become a Donor CTA */}
        <div className="bg-gradient-to-r from-red-500 to-rose-500 rounded-2xl p-5 text-white">
          <h3 className="font-bold text-lg">Become a Blood Donor</h3>
          <p className="text-white/90 text-sm mt-1 mb-4">
            Help save lives by registering as a blood donor. Your contribution can make a difference.
          </p>
          <button
            onClick={() => navigate('/profile/health')}
            className="w-full py-3 bg-white text-red-600 rounded-xl font-semibold hover:bg-gray-100 transition-colors"
          >
            Update Health Profile
          </button>
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
