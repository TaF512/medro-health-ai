import { useState, useRef } from 'react';
import { useNavigate } from 'react-router';
import { 
  ArrowLeft, 
  ScanBarcode, 
  Keyboard,
  Search,
  Loader2,
  AlertTriangle,
  Plus,
  Minus,
  Save,
  X,
  Camera,
  Flashlight
} from 'lucide-react';

interface BarcodeProduct {
  found: boolean;
  barcode?: string;
  name?: string;
  brand?: string;
  imageUrl?: string;
  servingSize?: string;
  calories?: number;
  protein?: number;
  carbs?: number;
  fat?: number;
  nutritionGrade?: string;
  ingredients?: string;
  warnings?: string[];
  suggestions?: string[];
}

type TabType = 'scan' | 'manual';

const mealTypes = ['Breakfast', 'Lunch', 'Dinner', 'Snack'] as const;

// Grade colors
const gradeColors: Record<string, string> = {
  'A': 'bg-green-500',
  'B': 'bg-lime-500',
  'C': 'bg-yellow-500',
  'D': 'bg-orange-500',
  'E': 'bg-red-500',
};

export default function FoodBarcode() {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [activeTab, setActiveTab] = useState<TabType>('manual');
  const [barcodeInput, setBarcodeInput] = useState('');
  const [isLookingUp, setIsLookingUp] = useState(false);
  const [product, setProduct] = useState<BarcodeProduct | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [selectedMealType, setSelectedMealType] = useState<typeof mealTypes[number]>('Lunch');
  const [showNotFoundForm, setShowNotFoundForm] = useState(false);
  const [customProduct, setCustomProduct] = useState({
    name: '',
    brand: '',
    servingSize: '100g',
    calories: '',
    protein: '',
    carbs: '',
    fat: ''
  });
  const [isScanning, setIsScanning] = useState(false);

  const lookupBarcode = async (code: string) => {
    if (!code.trim()) return;
    
    setIsLookingUp(true);
    setError(null);
    setProduct(null);
    setShowNotFoundForm(false);

    try {
      const response = await fetch(`/api/barcode/${code.trim()}`);
      const data = await response.json();

      if (data.found) {
        setProduct(data);
      } else {
        setProduct({ found: false, barcode: code });
        setShowNotFoundForm(true);
      }
    } catch (err) {
      setError('Failed to lookup barcode. Please try again.');
      console.error(err);
    } finally {
      setIsLookingUp(false);
    }
  };

  const handleImageCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsScanning(true);
    setError(null);

    // In a real implementation, we would use a barcode detection library
    // For now, we'll show a message that camera scanning requires the manual tab
    setTimeout(() => {
      setIsScanning(false);
      setError('Camera barcode scanning requires a specialized library. Please use the manual entry tab or type the barcode number.');
      setActiveTab('manual');
    }, 1500);
  };

  const saveCustomProduct = () => {
    const newProduct: BarcodeProduct = {
      found: true,
      barcode: barcodeInput,
      name: customProduct.name,
      brand: customProduct.brand,
      servingSize: customProduct.servingSize,
      calories: parseInt(customProduct.calories) || 0,
      protein: parseFloat(customProduct.protein) || 0,
      carbs: parseFloat(customProduct.carbs) || 0,
      fat: parseFloat(customProduct.fat) || 0,
    };
    setProduct(newProduct);
    setShowNotFoundForm(false);
  };

  const addToLog = () => {
    // TODO: Save to database/context
    navigate('/food', { state: { mealSaved: true } });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white pb-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-500 to-pink-600 text-white px-4 py-4 pb-6">
        <div className="flex items-center gap-3 mb-2">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-white/20 rounded-full transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-bold">Barcode Scanner</h1>
        </div>
        <p className="text-purple-100 text-sm ml-10">Scan or enter product barcodes</p>
      </div>

      <main className="px-4 -mt-3 max-w-lg mx-auto">
        {/* Tab Selector */}
        <div className="bg-white rounded-2xl shadow-lg p-2 mb-4 flex gap-2">
          <button
            onClick={() => setActiveTab('scan')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-medium transition-all ${
              activeTab === 'scan'
                ? 'bg-gradient-to-r from-purple-500 to-pink-600 text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <Camera className="w-5 h-5" />
            Scan Barcode
          </button>
          <button
            onClick={() => setActiveTab('manual')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-medium transition-all ${
              activeTab === 'manual'
                ? 'bg-gradient-to-r from-purple-500 to-pink-600 text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <Keyboard className="w-5 h-5" />
            Enter Manually
          </button>
        </div>

        {/* Scan Tab */}
        {activeTab === 'scan' && (
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-4">
            {isScanning ? (
              <div className="text-center py-8">
                <Loader2 className="w-12 h-12 text-purple-500 animate-spin mx-auto mb-4" />
                <p className="text-gray-600">Scanning barcode...</p>
              </div>
            ) : (
              <>
                <div className="text-center mb-6">
                  <div className="w-24 h-24 bg-gradient-to-br from-purple-100 to-pink-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <ScanBarcode className="w-12 h-12 text-purple-600" />
                  </div>
                  <h2 className="text-lg font-bold text-gray-900 mb-2">Scan Product Barcode</h2>
                  <p className="text-sm text-gray-500">Point your camera at the product barcode</p>
                </div>

                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full py-4 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-xl font-semibold flex items-center justify-center gap-2 mb-4"
                >
                  <Camera className="w-5 h-5" /> Open Camera
                </button>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handleImageCapture}
                  className="hidden"
                />

                <div className="flex items-center justify-center gap-4 text-sm text-gray-500">
                  <span className="flex items-center gap-1">
                    <Flashlight className="w-4 h-4" /> Flash available
                  </span>
                </div>

                <div className="mt-6 pt-4 border-t border-gray-100">
                  <p className="text-xs text-gray-400 text-center">
                    Supported formats: EAN-13, EAN-8, UPC-A, UPC-E, QR Code
                  </p>
                </div>
              </>
            )}
          </div>
        )}

        {/* Manual Entry Tab */}
        {activeTab === 'manual' && (
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-4">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-100 to-pink-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                <Keyboard className="w-8 h-8 text-purple-600" />
              </div>
              <h2 className="text-lg font-bold text-gray-900">Enter Barcode Number</h2>
            </div>

            <div className="relative mb-4">
              <ScanBarcode className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                inputMode="numeric"
                value={barcodeInput}
                onChange={(e) => setBarcodeInput(e.target.value.replace(/\D/g, ''))}
                placeholder="Enter barcode (e.g., 5000157024671)"
                className="w-full pl-10 pr-4 py-4 border border-gray-200 rounded-xl text-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
            </div>

            <button
              onClick={() => lookupBarcode(barcodeInput)}
              disabled={!barcodeInput.trim() || isLookingUp}
              className="w-full py-4 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-xl font-semibold flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isLookingUp ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" /> Looking up...
                </>
              ) : (
                <>
                  <Search className="w-5 h-5" /> Search Product
                </>
              )}
            </button>
          </div>
        )}

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-4 flex items-start gap-2">
            <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        {/* Product Not Found Form */}
        {showNotFoundForm && (
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-4">
            <div className="flex items-center gap-2 mb-4">
              <AlertTriangle className="w-5 h-5 text-amber-500" />
              <h3 className="font-semibold text-gray-900">Product Not Found</h3>
            </div>
            <p className="text-sm text-gray-500 mb-4">
              Barcode "{barcodeInput}" not in database. Add it manually and it will be saved for future use.
            </p>

            <div className="space-y-3">
              <input
                type="text"
                value={customProduct.name}
                onChange={(e) => setCustomProduct({ ...customProduct, name: e.target.value })}
                placeholder="Product Name *"
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500"
              />
              <input
                type="text"
                value={customProduct.brand}
                onChange={(e) => setCustomProduct({ ...customProduct, brand: e.target.value })}
                placeholder="Brand (optional)"
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500"
              />
              <input
                type="text"
                value={customProduct.servingSize}
                onChange={(e) => setCustomProduct({ ...customProduct, servingSize: e.target.value })}
                placeholder="Serving Size (e.g., 100g)"
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500"
              />
              <input
                type="number"
                value={customProduct.calories}
                onChange={(e) => setCustomProduct({ ...customProduct, calories: e.target.value })}
                placeholder="Calories *"
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500"
              />
              <div className="grid grid-cols-3 gap-2">
                <input
                  type="number"
                  value={customProduct.protein}
                  onChange={(e) => setCustomProduct({ ...customProduct, protein: e.target.value })}
                  placeholder="Protein (g)"
                  className="w-full px-3 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500"
                />
                <input
                  type="number"
                  value={customProduct.carbs}
                  onChange={(e) => setCustomProduct({ ...customProduct, carbs: e.target.value })}
                  placeholder="Carbs (g)"
                  className="w-full px-3 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500"
                />
                <input
                  type="number"
                  value={customProduct.fat}
                  onChange={(e) => setCustomProduct({ ...customProduct, fat: e.target.value })}
                  placeholder="Fat (g)"
                  className="w-full px-3 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <button
                onClick={saveCustomProduct}
                disabled={!customProduct.name || !customProduct.calories}
                className="w-full py-3 bg-purple-500 text-white rounded-xl font-semibold disabled:opacity-50"
              >
                Save & Add Product
              </button>
            </div>
          </div>
        )}

        {/* Product Found */}
        {product && product.found && (
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-4">
            <div className="flex items-start gap-4 mb-4">
              {product.imageUrl ? (
                <img src={product.imageUrl} alt={product.name} className="w-20 h-20 object-contain rounded-xl bg-gray-50" />
              ) : (
                <div className="w-20 h-20 bg-gray-100 rounded-xl flex items-center justify-center">
                  <ScanBarcode className="w-8 h-8 text-gray-400" />
                </div>
              )}
              <div className="flex-1">
                <h3 className="font-bold text-gray-900">{product.name}</h3>
                {product.brand && <p className="text-sm text-gray-500">{product.brand}</p>}
                <p className="text-xs text-gray-400 mt-1">Barcode: {product.barcode}</p>
              </div>
            </div>

            {/* Nutri-Score */}
            {product.nutritionGrade && (
              <div className="flex items-center gap-2 mb-4">
                <span className="text-sm text-gray-600">Nutri-Score:</span>
                <span className={`w-8 h-8 ${gradeColors[product.nutritionGrade.toUpperCase()] || 'bg-gray-400'} text-white rounded-lg flex items-center justify-center font-bold`}>
                  {product.nutritionGrade.toUpperCase()}
                </span>
              </div>
            )}

            {/* Nutrition Info */}
            <div className="bg-purple-50 rounded-xl p-4 mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-600">Per {product.servingSize || 'serving'}</span>
                <span className="text-xl font-bold text-purple-600">{product.calories} kcal</span>
              </div>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-white rounded-lg p-2">
                  <p className="text-lg font-bold text-red-500">{product.protein}g</p>
                  <p className="text-xs text-gray-500">Protein</p>
                </div>
                <div className="bg-white rounded-lg p-2">
                  <p className="text-lg font-bold text-amber-500">{product.carbs}g</p>
                  <p className="text-xs text-gray-500">Carbs</p>
                </div>
                <div className="bg-white rounded-lg p-2">
                  <p className="text-lg font-bold text-blue-500">{product.fat}g</p>
                  <p className="text-xs text-gray-500">Fat</p>
                </div>
              </div>
            </div>

            {/* Warnings */}
            {product.warnings && product.warnings.length > 0 && (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 mb-4">
                <p className="text-sm text-amber-800 font-medium mb-1">⚠️ Health Notes</p>
                <ul className="text-xs text-amber-700 space-y-1">
                  {product.warnings.map((w, i) => (
                    <li key={i}>• {w}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Meal Type */}
            <div className="mb-4">
              <p className="text-sm font-medium text-gray-700 mb-2">Add to</p>
              <div className="flex gap-2">
                {mealTypes.map(type => (
                  <button
                    key={type}
                    onClick={() => setSelectedMealType(type)}
                    className={`flex-1 py-2 px-2 rounded-lg text-xs font-medium transition-all ${
                      selectedMealType === type
                        ? 'bg-purple-500 text-white'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity */}
            <div className="flex items-center justify-center gap-6 mb-6">
              <button
                onClick={() => setQuantity(Math.max(0.5, quantity - 0.5))}
                className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors"
              >
                <Minus className="w-5 h-5" />
              </button>
              <div className="text-center">
                <p className="text-3xl font-bold text-gray-900">{quantity}</p>
                <p className="text-sm text-gray-500">servings</p>
              </div>
              <button
                onClick={() => setQuantity(quantity + 0.5)}
                className="w-12 h-12 bg-purple-500 text-white rounded-full flex items-center justify-center hover:bg-purple-600 transition-colors"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>

            {/* Total */}
            <div className="text-center mb-4 p-3 bg-gray-50 rounded-xl">
              <p className="text-sm text-gray-500">Total</p>
              <p className="text-2xl font-bold text-gray-900">{Math.round((product.calories || 0) * quantity)} kcal</p>
            </div>

            {/* Add Button */}
            <button
              onClick={addToLog}
              className="w-full py-4 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-xl font-semibold flex items-center justify-center gap-2 shadow-lg"
            >
              <Save className="w-5 h-5" /> Add to Today's Log
            </button>

            {/* Scan Another */}
            <button
              onClick={() => {
                setProduct(null);
                setBarcodeInput('');
              }}
              className="w-full mt-3 py-3 border border-gray-200 text-gray-600 rounded-xl font-medium flex items-center justify-center gap-2"
            >
              <X className="w-4 h-4" /> Scan Another Product
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
