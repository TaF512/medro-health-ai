import { useState } from 'react';
import { ArrowLeft, Search, Send, Paperclip, MoreVertical, Check, CheckCheck, Image } from 'lucide-react';
import { useNavigate } from 'react-router';

interface Conversation {
  id: number;
  patient: string;
  avatar?: string;
  lastMessage: string;
  time: string;
  unread: number;
  online: boolean;
}

interface Message {
  id: number;
  text: string;
  time: string;
  sender: 'doctor' | 'patient';
  read: boolean;
}

const conversations: Conversation[] = [
  { id: 1, patient: 'Sarah Ahmed', lastMessage: 'Thank you doctor, I will follow the prescription', time: '2 min ago', unread: 2, online: true },
  { id: 2, patient: 'Rahim Khan', lastMessage: 'When should I come for the follow-up?', time: '15 min ago', unread: 1, online: false },
  { id: 3, patient: 'Fatima Begum', lastMessage: 'The test results are attached', time: '1 hour ago', unread: 0, online: true },
  { id: 4, patient: 'Abdul Karim', lastMessage: 'Feeling much better now', time: '3 hours ago', unread: 0, online: false },
  { id: 5, patient: 'Nusrat Jahan', lastMessage: 'Is it okay to take the medicine before food?', time: 'Yesterday', unread: 3, online: false },
  { id: 6, patient: 'Mohammad Ali', lastMessage: 'Thank you for the advice', time: 'Yesterday', unread: 0, online: false },
];

const sampleMessages: Message[] = [
  { id: 1, text: 'Good morning doctor, I have been experiencing headaches for the past 3 days', time: '9:00 AM', sender: 'patient', read: true },
  { id: 2, text: 'Good morning Sarah. Can you describe the pain? Is it on one side or both sides of your head?', time: '9:05 AM', sender: 'doctor', read: true },
  { id: 3, text: 'It\'s mostly on the right side, and it gets worse in the evening', time: '9:08 AM', sender: 'patient', read: true },
  { id: 4, text: 'I see. Have you been getting enough sleep? Any stress lately?', time: '9:10 AM', sender: 'doctor', read: true },
  { id: 5, text: 'Yes, I have been working late and sleeping only 4-5 hours', time: '9:12 AM', sender: 'patient', read: true },
  { id: 6, text: 'That could be a major factor. I recommend getting at least 7-8 hours of sleep. I\'m prescribing a mild pain reliever for now.', time: '9:15 AM', sender: 'doctor', read: true },
  { id: 7, text: 'Thank you doctor, I will follow the prescription', time: '9:18 AM', sender: 'patient', read: false },
];

export default function DoctorMessagesPage() {
  const navigate = useNavigate();
  const [selectedChat, setSelectedChat] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [newMessage, setNewMessage] = useState('');

  const filteredConversations = conversations.filter(c =>
    c.patient.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedConversation = conversations.find(c => c.id === selectedChat);

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    // In a real app, this would send the message to the backend
    setNewMessage('');
  };

  if (selectedChat) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        {/* Chat Header */}
        <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 z-40">
          <div className="flex items-center gap-3 max-w-4xl mx-auto">
            <button
              onClick={() => setSelectedChat(null)}
              className="p-2 -ml-2 rounded-full hover:bg-gray-100 transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-gray-700" />
            </button>
            <div className="w-10 h-10 bg-gradient-to-br from-primary/20 to-teal-100 rounded-full flex items-center justify-center font-semibold text-primary">
              {selectedConversation?.patient.charAt(0)}
            </div>
            <div className="flex-1">
              <h1 className="font-semibold text-gray-900">{selectedConversation?.patient}</h1>
              <p className="text-xs text-green-500">{selectedConversation?.online ? 'Online' : 'Offline'}</p>
            </div>
            <button className="p-2 rounded-full hover:bg-gray-100 transition-colors">
              <MoreVertical className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </header>

        {/* Messages */}
        <div className="flex-1 px-4 py-4 overflow-y-auto">
          <div className="max-w-4xl mx-auto space-y-3">
            {sampleMessages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.sender === 'doctor' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[75%] rounded-2xl px-4 py-2 ${
                    msg.sender === 'doctor'
                      ? 'bg-primary text-white rounded-br-md'
                      : 'bg-white border border-gray-100 text-gray-800 rounded-bl-md'
                  }`}
                >
                  <p className="text-sm">{msg.text}</p>
                  <div className={`flex items-center justify-end gap-1 mt-1 ${
                    msg.sender === 'doctor' ? 'text-white/70' : 'text-gray-400'
                  }`}>
                    <span className="text-xs">{msg.time}</span>
                    {msg.sender === 'doctor' && (
                      msg.read ? <CheckCheck className="w-3 h-3" /> : <Check className="w-3 h-3" />
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Message Input */}
        <div className="sticky bottom-0 bg-white border-t border-gray-100 px-4 py-3">
          <div className="max-w-4xl mx-auto flex items-center gap-2">
            <button className="p-2 rounded-full hover:bg-gray-100 transition-colors">
              <Paperclip className="w-5 h-5 text-gray-500" />
            </button>
            <button className="p-2 rounded-full hover:bg-gray-100 transition-colors">
              <Image className="w-5 h-5 text-gray-500" />
            </button>
            <input
              type="text"
              placeholder="Type a message..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              className="flex-1 px-4 py-2 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
            <button
              onClick={handleSendMessage}
              className="p-2 bg-primary text-white rounded-full hover:bg-primary/90 transition-colors"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 z-40">
        <div className="flex items-center gap-3 max-w-4xl mx-auto">
          <button
            onClick={() => navigate('/doctor/dashboard')}
            className="p-2 -ml-2 rounded-full hover:bg-gray-100 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
          <h1 className="text-lg font-bold text-gray-900">Messages</h1>
          <span className="ml-auto bg-primary text-white text-xs font-medium px-2 py-1 rounded-full">
            {conversations.reduce((acc, c) => acc + c.unread, 0)} new
          </span>
        </div>
      </header>

      <main className="px-4 py-4 max-w-4xl mx-auto space-y-4">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search conversations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
          />
        </div>

        {/* Conversation List */}
        <div className="space-y-2">
          {filteredConversations.map((conv) => (
            <button
              key={conv.id}
              onClick={() => setSelectedChat(conv.id)}
              className="w-full bg-white rounded-xl p-4 border border-gray-100 shadow-sm flex items-center gap-3 hover:border-primary/30 transition-colors text-left"
            >
              <div className="relative">
                <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-teal-100 rounded-full flex items-center justify-center text-lg font-semibold text-primary">
                  {conv.patient.charAt(0)}
                </div>
                {conv.online && (
                  <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <h3 className="font-semibold text-gray-900">{conv.patient}</h3>
                  <span className="text-xs text-gray-400">{conv.time}</span>
                </div>
                <p className="text-sm text-gray-500 truncate">{conv.lastMessage}</p>
              </div>
              {conv.unread > 0 && (
                <span className="w-5 h-5 bg-primary text-white text-xs font-medium rounded-full flex items-center justify-center">
                  {conv.unread}
                </span>
              )}
            </button>
          ))}
        </div>
      </main>
    </div>
  );
}
