import { useState } from 'react';
import { ArrowLeft, Search, Phone, Video, MessageSquare, Calendar, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router';

interface Patient {
  id: number;
  name: string;
  age: number;
  gender: string;
  lastVisit: string;
  condition: string;
  status: 'active' | 'follow-up' | 'new';
  phone: string;
  nextAppointment?: string;
  country: string;
  countryFlag: string;
}

const patients: Patient[] = [
  { id: 1, name: 'Sarah Ahmed', age: 32, gender: 'Female', lastVisit: '2 days ago', condition: 'Diabetes Type 2', status: 'active', phone: '+880 1712-345678', nextAppointment: 'Tomorrow, 10:00 AM', country: 'BD', countryFlag: '🇧🇩' },
  { id: 2, name: 'Rahim Khan', age: 45, gender: 'Male', lastVisit: '1 week ago', condition: 'Hypertension', status: 'follow-up', phone: '+880 1812-456789', country: 'BD', countryFlag: '🇧🇩' },
  { id: 3, name: 'Fatima Begum', age: 28, gender: 'Female', lastVisit: 'Today', condition: 'Pregnancy Checkup', status: 'active', phone: '+880 1912-567890', nextAppointment: 'Next Week', country: 'BD', countryFlag: '🇧🇩' },
  { id: 4, name: 'John Smith', age: 55, gender: 'Male', lastVisit: '3 days ago', condition: 'Cardiac Issues', status: 'active', phone: '+44 7505-847747', country: 'GB', countryFlag: '🇬🇧' },
  { id: 5, name: 'Emma Wilson', age: 38, gender: 'Female', lastVisit: 'New Patient', condition: 'General Checkup', status: 'new', phone: '+44 7700-900123', nextAppointment: 'Today, 3:00 PM', country: 'GB', countryFlag: '🇬🇧' },
  { id: 6, name: 'Mike Johnson', age: 62, gender: 'Male', lastVisit: '2 weeks ago', condition: 'Arthritis', status: 'follow-up', phone: '+1 555-123-4567', country: 'US', countryFlag: '🇺🇸' },
  { id: 7, name: 'Priya Sharma', age: 29, gender: 'Female', lastVisit: '5 days ago', condition: 'Thyroid', status: 'active', phone: '+91 98765-43210', country: 'IN', countryFlag: '🇮🇳' },
  { id: 8, name: 'Ahmed Al-Hassan', age: 41, gender: 'Male', lastVisit: '1 day ago', condition: 'Diabetes Type 2', status: 'active', phone: '+971 50-123-4567', country: 'AE', countryFlag: '🇦🇪' },
];

export default function DoctorPatientsPage() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState<'all' | 'active' | 'follow-up' | 'new'>('all');

  const filteredPatients = patients.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         p.condition.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filter === 'all' || p.status === filter;
    return matchesSearch && matchesFilter;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-700';
      case 'follow-up': return 'bg-amber-100 text-amber-700';
      case 'new': return 'bg-blue-100 text-blue-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 z-40">
        <div className="flex items-center gap-3 max-w-4xl mx-auto">
          <button
            onClick={() => navigate('/doctor/dashboard')}
            className="p-2 -ml-2 rounded-full hover:bg-gray-100 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
          <h1 className="text-lg font-bold text-gray-900">My Patients</h1>
          <span className="ml-auto text-sm text-gray-500">{patients.length} total</span>
        </div>
      </header>

      <main className="px-4 py-4 max-w-4xl mx-auto space-y-4">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search patients..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
          />
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {[
            { key: 'all', label: 'All Patients' },
            { key: 'active', label: 'Active' },
            { key: 'follow-up', label: 'Follow-up' },
            { key: 'new', label: 'New' },
          ].map((f) => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key as typeof filter)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                filter === f.key
                  ? 'bg-primary text-white'
                  : 'bg-white text-gray-600 border border-gray-200'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Patient List */}
        <div className="space-y-3">
          {filteredPatients.map((patient) => (
            <div key={patient.id} className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-teal-100 rounded-full flex items-center justify-center text-lg font-semibold text-primary">
                  {patient.name.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-lg" title={patient.country}>{patient.countryFlag}</span>
                    <h3 className="font-semibold text-gray-900">{patient.name}</h3>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium capitalize ${getStatusColor(patient.status)}`}>
                      {patient.status}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{patient.age} yrs • {patient.gender} • {patient.condition}</p>
                  <p className="text-xs text-gray-400 mt-1">Last visit: {patient.lastVisit}</p>
                  {patient.nextAppointment && (
                    <div className="flex items-center gap-1 mt-2 text-xs text-primary">
                      <Calendar className="w-3 h-3" />
                      <span>Next: {patient.nextAppointment}</span>
                    </div>
                  )}
                </div>
                <ChevronRight className="w-5 h-5 text-gray-300" />
              </div>
              
              {/* Quick Actions */}
              <div className="flex gap-2 mt-3 pt-3 border-t border-gray-100">
                <button className="flex-1 flex items-center justify-center gap-1.5 py-2 text-sm font-medium text-gray-600 hover:text-primary hover:bg-primary/5 rounded-lg transition-colors">
                  <Phone className="w-4 h-4" />
                  <span>Call</span>
                </button>
                <button className="flex-1 flex items-center justify-center gap-1.5 py-2 text-sm font-medium text-gray-600 hover:text-primary hover:bg-primary/5 rounded-lg transition-colors">
                  <Video className="w-4 h-4" />
                  <span>Video</span>
                </button>
                <button className="flex-1 flex items-center justify-center gap-1.5 py-2 text-sm font-medium text-gray-600 hover:text-primary hover:bg-primary/5 rounded-lg transition-colors">
                  <MessageSquare className="w-4 h-4" />
                  <span>Message</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
