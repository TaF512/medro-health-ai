import { useState, useRef } from 'react';
import { useNavigate, useParams } from 'react-router';
import { 
  ArrowLeft, User, UserPlus, Video, Phone, MessageSquare, 
  Upload, X, FileText, Image, Camera, CreditCard, Wallet,
  ChevronRight, Check, AlertCircle, ShoppingCart, Info
} from 'lucide-react';
import { doctors } from '@/react-app/data/doctors';
import { calculatePatientPrice, getVatLabel } from '@/react-app/lib/pricing';

const getCurrencySymbol = (country: string): string => {
  const symbols: Record<string, string> = {
    'BD': '৳', 'GB': '£', 'US': '$', 'IN': '₹', 'AE': 'AED ', 
    'CA': 'C$', 'AU': 'A$', 'DE': '€', 'FR': '€', 'SA': 'SAR '
  };
  return symbols[country] || '$';
};
import { cn } from '@/react-app/lib/utils';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { useCart } from '@/react-app/context/CartContext';

type ConsultType = 'video' | 'voice' | 'chat';
type PatientType = 'self' | 'other';
type PaymentMethod = 'card' | 'wallet' | 'bkash' | 'nagad';

interface Attachment {
  id: string;
  name: string;
  type: 'image' | 'document';
  url: string;
}

export default function BookDoctorPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, isGuest } = useAuth();
  const { addItem } = useCart();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const doctor = doctors.find(d => d.id === id);
  
  const [step, setStep] = useState(1);
  const [patientType, setPatientType] = useState<PatientType>('self');
  const [consultType, setConsultType] = useState<ConsultType>(doctor?.consultationType[0] || 'video');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('card');
  
  // Patient details (for "other" patient type)
  const [otherPatientName, setOtherPatientName] = useState('');
  const [otherPatientAge, setOtherPatientAge] = useState('');
  const [otherPatientGender, setOtherPatientGender] = useState('');
  const [otherPatientRelation, setOtherPatientRelation] = useState('');
  
  // Consultation details
  const [reasonForVisit, setReasonForVisit] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [symptomDuration, setSymptomDuration] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [shareHistory, setShareHistory] = useState(true);
  const [showPriceBreakdown, setShowPriceBreakdown] = useState(false);
  
  if (!doctor) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-500">Doctor not found</p>
      </div>
    );
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    
    Array.from(files).forEach(file => {
      const isImage = file.type.startsWith('image/');
      const url = URL.createObjectURL(file);
      setAttachments(prev => [...prev, {
        id: Math.random().toString(36).substr(2, 9),
        name: file.name,
        type: isImage ? 'image' : 'document',
        url
      }]);
    });
    
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeAttachment = (id: string) => {
    setAttachments(prev => prev.filter(a => a.id !== id));
  };

  const currencySymbol = getCurrencySymbol(doctor.country);
  
  // Calculate patient-facing price with fees
  const priceBreakdown = calculatePatientPrice(doctor.price, doctor.country, doctor.currency);
  
  const handleAddToCart = () => {
    addItem({
      id: doctor.id,
      type: 'doctor',
      name: `Consultation with ${doctor.name}`,
      description: `${consultType.charAt(0).toUpperCase() + consultType.slice(1)} consultation - ${reasonForVisit}`,
      price: priceBreakdown.totalPrice,
      currency: currencySymbol,
      doctorId: doctor.id,
      consultationType: consultType,
      country: doctor.country,
    });
    navigate('/cart');
  };

  const handleConfirmBooking = () => {
    // Add to cart and go to payment
    handleAddToCart();
  };

  const canProceedStep1 = patientType === 'self' || 
    (otherPatientName && otherPatientAge && otherPatientGender);
  
  const canProceedStep2 = reasonForVisit.trim().length > 0;

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 z-40">
        <div className="flex items-center gap-3 max-w-lg mx-auto">
          <button
            onClick={() => step > 1 ? setStep(step - 1) : navigate(-1)}
            className="p-2 -ml-2 rounded-full hover:bg-gray-100 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-gray-900">Book Consultation</h1>
            <p className="text-sm text-gray-500">Step {step} of 3</p>
          </div>
        </div>
        
        {/* Progress Bar */}
        <div className="flex gap-2 mt-3 max-w-lg mx-auto">
          {[1, 2, 3].map(s => (
            <div
              key={s}
              className={cn(
                'h-1 flex-1 rounded-full transition-colors',
                s <= step ? 'bg-primary' : 'bg-gray-200'
              )}
            />
          ))}
        </div>
      </header>

      <main className="px-4 py-6 max-w-lg mx-auto space-y-6">
        {/* Doctor Info Card */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex items-center gap-4">
          <img
            src={doctor.image}
            alt={doctor.name}
            className="w-16 h-16 rounded-xl object-cover"
          />
          <div className="flex-1">
            <h2 className="font-semibold text-gray-900">{doctor.name}</h2>
            <p className="text-sm text-primary">{doctor.specialty}</p>
            <div className="flex items-center gap-2 mt-1">
              <span className={cn(
                'w-2 h-2 rounded-full',
                doctor.isOnline ? 'bg-green-500' : 'bg-gray-300'
              )} />
              <span className="text-xs text-gray-500">
                {doctor.isOnline ? 'Online Now' : 'Offline'}
              </span>
            </div>
          </div>
          <div className="text-right relative">
            <p className="text-xs text-gray-400 line-through">{currencySymbol}{doctor.price}</p>
            <div 
              className="flex items-center gap-1 cursor-help"
              onMouseEnter={() => setShowPriceBreakdown(true)}
              onMouseLeave={() => setShowPriceBreakdown(false)}
              onClick={() => setShowPriceBreakdown(!showPriceBreakdown)}
            >
              <p className="text-lg font-bold text-gray-900">{currencySymbol}{priceBreakdown.totalPrice}</p>
              <Info className="w-3.5 h-3.5 text-gray-400" />
            </div>
            <p className="text-xs text-gray-500">inc. fees</p>
            
            {/* Price Breakdown Tooltip */}
            {showPriceBreakdown && (
              <div className="absolute top-full right-0 mt-2 bg-gray-900 text-white text-xs rounded-lg p-3 z-50 min-w-[180px] shadow-lg">
                <p className="font-medium mb-2 text-gray-300">Price Breakdown</p>
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Doctor receives</span>
                    <span>{currencySymbol}{priceBreakdown.basePrice}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Service fee (5%)</span>
                    <span>{currencySymbol}{priceBreakdown.serviceFee}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">{getVatLabel(doctor.country)} ({Math.round(priceBreakdown.vatRate * 100)}%)</span>
                    <span>{currencySymbol}{priceBreakdown.vat}</span>
                  </div>
                  <div className="border-t border-gray-700 pt-1 mt-1 flex justify-between font-medium">
                    <span>You pay</span>
                    <span className="text-green-400">{currencySymbol}{priceBreakdown.totalPrice}</span>
                  </div>
                </div>
                <div className="absolute top-0 right-4 transform -translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900" />
              </div>
            )}
          </div>
        </div>

        {/* Step 1: Who is this appointment for? */}
        {step === 1 && (
          <>
            <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-semibold text-gray-900 mb-4">Who is this appointment for?</h3>
              
              <div className="grid grid-cols-2 gap-3 mb-6">
                <button
                  onClick={() => setPatientType('self')}
                  className={cn(
                    'p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-2',
                    patientType === 'self'
                      ? 'border-primary bg-primary/5'
                      : 'border-gray-200 hover:border-gray-300'
                  )}
                >
                  <div className={cn(
                    'w-12 h-12 rounded-full flex items-center justify-center',
                    patientType === 'self' ? 'bg-primary/20' : 'bg-gray-100'
                  )}>
                    <User className={cn('w-6 h-6', patientType === 'self' ? 'text-primary' : 'text-gray-500')} />
                  </div>
                  <span className={cn('font-medium', patientType === 'self' ? 'text-primary' : 'text-gray-700')}>
                    Myself
                  </span>
                  {patientType === 'self' && !isGuest && (
                    <span className="text-xs text-gray-500">Doctor sees your history</span>
                  )}
                </button>
                
                <button
                  onClick={() => setPatientType('other')}
                  className={cn(
                    'p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-2',
                    patientType === 'other'
                      ? 'border-primary bg-primary/5'
                      : 'border-gray-200 hover:border-gray-300'
                  )}
                >
                  <div className={cn(
                    'w-12 h-12 rounded-full flex items-center justify-center',
                    patientType === 'other' ? 'bg-primary/20' : 'bg-gray-100'
                  )}>
                    <UserPlus className={cn('w-6 h-6', patientType === 'other' ? 'text-primary' : 'text-gray-500')} />
                  </div>
                  <span className={cn('font-medium', patientType === 'other' ? 'text-primary' : 'text-gray-700')}>
                    Someone Else
                  </span>
                  {patientType === 'other' && (
                    <span className="text-xs text-gray-500">Add their details</span>
                  )}
                </button>
              </div>

              {/* Self - Share History Toggle */}
              {patientType === 'self' && !isGuest && (
                <div className="flex items-center justify-between p-4 bg-blue-50 rounded-xl">
                  <div>
                    <p className="font-medium text-gray-900">Share Medical History</p>
                    <p className="text-sm text-gray-500">Doctor can view your health records</p>
                  </div>
                  <button
                    onClick={() => setShareHistory(!shareHistory)}
                    className={cn(
                      'w-12 h-7 rounded-full transition-colors relative',
                      shareHistory ? 'bg-primary' : 'bg-gray-300'
                    )}
                  >
                    <span className={cn(
                      'absolute top-1 w-5 h-5 bg-white rounded-full transition-transform shadow',
                      shareHistory ? 'right-1' : 'left-1'
                    )} />
                  </button>
                </div>
              )}

              {/* Other Patient Details */}
              {patientType === 'other' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Patient Name *</label>
                    <input
                      type="text"
                      value={otherPatientName}
                      onChange={(e) => setOtherPatientName(e.target.value)}
                      placeholder="Enter patient's full name"
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Age *</label>
                      <input
                        type="number"
                        value={otherPatientAge}
                        onChange={(e) => setOtherPatientAge(e.target.value)}
                        placeholder="Age"
                        className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Gender *</label>
                      <select
                        value={otherPatientGender}
                        onChange={(e) => setOtherPatientGender(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary bg-white"
                      >
                        <option value="">Select</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Relation to you</label>
                    <input
                      type="text"
                      value={otherPatientRelation}
                      onChange={(e) => setOtherPatientRelation(e.target.value)}
                      placeholder="e.g., Mother, Child, Friend"
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    />
                  </div>
                </div>
              )}
            </section>

            <button
              onClick={() => setStep(2)}
              disabled={!canProceedStep1}
              className={cn(
                'w-full py-4 rounded-xl font-semibold transition-colors flex items-center justify-center gap-2',
                canProceedStep1
                  ? 'bg-primary text-white hover:bg-primary/90'
                  : 'bg-gray-200 text-gray-400 cursor-not-allowed'
              )}
            >
              Continue <ChevronRight className="w-5 h-5" />
            </button>
          </>
        )}

        {/* Step 2: Consultation Details */}
        {step === 2 && (
          <>
            <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 space-y-5">
              <h3 className="font-semibold text-gray-900">Consultation Details</h3>
              
              {/* Reason for Visit */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Reason for Visit *
                </label>
                <input
                  type="text"
                  value={reasonForVisit}
                  onChange={(e) => setReasonForVisit(e.target.value)}
                  placeholder="e.g., Regular checkup, Skin rash, Headache"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                />
              </div>
              
              {/* Symptoms Description */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Describe Your Symptoms
                </label>
                <textarea
                  value={symptoms}
                  onChange={(e) => setSymptoms(e.target.value)}
                  placeholder="Describe what you're experiencing in detail..."
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary resize-none"
                />
              </div>
              
              {/* Duration */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  How long have you had these symptoms?
                </label>
                <select
                  value={symptomDuration}
                  onChange={(e) => setSymptomDuration(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary bg-white"
                >
                  <option value="">Select duration</option>
                  <option value="today">Just today</option>
                  <option value="few_days">Few days</option>
                  <option value="week">About a week</option>
                  <option value="weeks">2-4 weeks</option>
                  <option value="month">More than a month</option>
                  <option value="chronic">Ongoing/Chronic</option>
                </select>
              </div>
            </section>

            {/* Attachments */}
            <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-semibold text-gray-900 mb-3">
                Attach Documents (Optional)
              </h3>
              <p className="text-sm text-gray-500 mb-4">
                Upload previous prescriptions, test reports, or images of your condition
              </p>
              
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="image/*,.pdf,.doc,.docx"
                onChange={handleFileUpload}
                className="hidden"
              />
              
              <div className="grid grid-cols-3 gap-3 mb-4">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="aspect-square border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center gap-1 hover:border-primary hover:bg-primary/5 transition-colors"
                >
                  <Upload className="w-6 h-6 text-gray-400" />
                  <span className="text-xs text-gray-500">Upload</span>
                </button>
                
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="aspect-square border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center gap-1 hover:border-primary hover:bg-primary/5 transition-colors"
                >
                  <Camera className="w-6 h-6 text-gray-400" />
                  <span className="text-xs text-gray-500">Camera</span>
                </button>
                
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="aspect-square border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center gap-1 hover:border-primary hover:bg-primary/5 transition-colors"
                >
                  <FileText className="w-6 h-6 text-gray-400" />
                  <span className="text-xs text-gray-500">Document</span>
                </button>
              </div>
              
              {/* Attachment List */}
              {attachments.length > 0 && (
                <div className="space-y-2">
                  {attachments.map(att => (
                    <div key={att.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                      {att.type === 'image' ? (
                        <Image className="w-5 h-5 text-blue-600" />
                      ) : (
                        <FileText className="w-5 h-5 text-orange-600" />
                      )}
                      <span className="flex-1 text-sm text-gray-700 truncate">{att.name}</span>
                      <button
                        onClick={() => removeAttachment(att.id)}
                        className="p-1 hover:bg-gray-200 rounded-full"
                      >
                        <X className="w-4 h-4 text-gray-500" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* Consultation Type */}
            <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-semibold text-gray-900 mb-4">Consultation Type</h3>
              
              <div className="space-y-3">
                {[
                  { type: 'video' as ConsultType, icon: Video, label: 'Video Call', desc: 'Face-to-face consultation' },
                  { type: 'voice' as ConsultType, icon: Phone, label: 'Voice Call', desc: 'Audio only consultation' },
                  { type: 'chat' as ConsultType, icon: MessageSquare, label: 'Text Chat', desc: 'Chat with the doctor' },
                ].map(opt => (
                  <button
                    key={opt.type}
                    onClick={() => setConsultType(opt.type)}
                    disabled={!doctor.consultationType.includes(opt.type)}
                    className={cn(
                      'w-full p-4 rounded-xl border-2 transition-all flex items-center gap-4',
                      consultType === opt.type
                        ? 'border-primary bg-primary/5'
                        : 'border-gray-200 hover:border-gray-300',
                      !doctor.consultationType.includes(opt.type) && 'opacity-50 cursor-not-allowed'
                    )}
                  >
                    <div className={cn(
                      'w-12 h-12 rounded-xl flex items-center justify-center',
                      consultType === opt.type ? 'bg-primary/20' : 'bg-gray-100'
                    )}>
                      <opt.icon className={cn('w-6 h-6', consultType === opt.type ? 'text-primary' : 'text-gray-500')} />
                    </div>
                    <div className="flex-1 text-left">
                      <p className={cn('font-medium', consultType === opt.type ? 'text-primary' : 'text-gray-900')}>
                        {opt.label}
                      </p>
                      <p className="text-sm text-gray-500">{opt.desc}</p>
                    </div>
                    {consultType === opt.type && (
                      <Check className="w-5 h-5 text-primary" />
                    )}
                  </button>
                ))}
              </div>
            </section>

            <button
              onClick={() => setStep(3)}
              disabled={!canProceedStep2}
              className={cn(
                'w-full py-4 rounded-xl font-semibold transition-colors flex items-center justify-center gap-2',
                canProceedStep2
                  ? 'bg-primary text-white hover:bg-primary/90'
                  : 'bg-gray-200 text-gray-400 cursor-not-allowed'
              )}
            >
              Continue to Payment <ChevronRight className="w-5 h-5" />
            </button>
          </>
        )}

        {/* Step 3: Payment & Confirm */}
        {step === 3 && (
          <>
            {/* Summary */}
            <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-semibold text-gray-900 mb-4">Booking Summary</h3>
              
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Patient</span>
                  <span className="font-medium text-gray-900">
                    {patientType === 'self' ? (user?.name || 'You') : otherPatientName}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Reason</span>
                  <span className="font-medium text-gray-900">{reasonForVisit}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Consultation Type</span>
                  <span className="font-medium text-gray-900 capitalize">{consultType} Call</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Attachments</span>
                  <span className="font-medium text-gray-900">{attachments.length} files</span>
                </div>
                {patientType === 'self' && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Share History</span>
                    <span className="font-medium text-gray-900">{shareHistory ? 'Yes' : 'No'}</span>
                  </div>
                )}
              </div>
              
              <div className="mt-4 pt-4 border-t border-gray-100 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Doctor's fee</span>
                  <span className="text-gray-700">{currencySymbol}{priceBreakdown.basePrice}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Service fee (5%)</span>
                  <span className="text-gray-700">{currencySymbol}{priceBreakdown.serviceFee}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">{getVatLabel(doctor.country)} ({Math.round(priceBreakdown.vatRate * 100)}%)</span>
                  <span className="text-gray-700">{currencySymbol}{priceBreakdown.vat}</span>
                </div>
                <div className="flex justify-between items-center pt-2 border-t border-gray-100">
                  <span className="text-gray-700 font-medium">You Pay</span>
                  <span className="text-2xl font-bold text-primary">{currencySymbol}{priceBreakdown.totalPrice}</span>
                </div>
              </div>
            </section>

            {/* Payment Methods */}
            <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-semibold text-gray-900 mb-4">Payment Method</h3>
              
              <div className="space-y-3">
                {[
                  { method: 'card' as PaymentMethod, icon: CreditCard, label: 'Credit/Debit Card' },
                  { method: 'wallet' as PaymentMethod, icon: Wallet, label: 'Medro Wallet' },
                  { method: 'bkash' as PaymentMethod, icon: Wallet, label: 'bKash' },
                  { method: 'nagad' as PaymentMethod, icon: Wallet, label: 'Nagad' },
                ].map(opt => (
                  <button
                    key={opt.method}
                    onClick={() => setPaymentMethod(opt.method)}
                    className={cn(
                      'w-full p-4 rounded-xl border-2 transition-all flex items-center gap-4',
                      paymentMethod === opt.method
                        ? 'border-primary bg-primary/5'
                        : 'border-gray-200 hover:border-gray-300'
                    )}
                  >
                    <div className={cn(
                      'w-10 h-10 rounded-lg flex items-center justify-center',
                      paymentMethod === opt.method ? 'bg-primary/20' : 'bg-gray-100'
                    )}>
                      <opt.icon className={cn('w-5 h-5', paymentMethod === opt.method ? 'text-primary' : 'text-gray-500')} />
                    </div>
                    <span className={cn('font-medium', paymentMethod === opt.method ? 'text-primary' : 'text-gray-900')}>
                      {opt.label}
                    </span>
                    {paymentMethod === opt.method && (
                      <Check className="w-5 h-5 text-primary ml-auto" />
                    )}
                  </button>
                ))}
              </div>
            </section>

            {/* Notice */}
            <div className="flex gap-3 p-4 bg-amber-50 rounded-xl border border-amber-100">
              <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-amber-800">Important</p>
                <p className="text-amber-700">
                  After the consultation, the doctor will issue a prescription which you can view in your records.
                </p>
              </div>
            </div>

            <button
              onClick={handleConfirmBooking}
              className="w-full py-4 bg-primary text-white rounded-xl font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-2"
            >
              <ShoppingCart className="w-5 h-5" />
              Add to Cart & Checkout {currencySymbol}{priceBreakdown.totalPrice}
            </button>
          </>
        )}
      </main>
    </div>
  );
}
