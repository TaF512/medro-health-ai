import { useNavigate } from 'react-router';
import { 
  ArrowLeft, User, Heart, FileText, Shield, Bell, 
  HelpCircle, LogOut, ChevronRight, Settings, LogIn, MapPin
} from 'lucide-react';
import { useAuth } from '@/react-app/contexts/AuthContext';
import BottomNav from '@/react-app/components/BottomNav';
import { countries } from '@/react-app/data/countries';

export default function ProfilePage() {
  const navigate = useNavigate();
  const { user, isGuest, guestRole, logout, exitGuestMode } = useAuth();

  const handleLogout = async () => {
    if (isGuest) {
      exitGuestMode();
    } else {
      await logout();
    }
    navigate('/login');
  };

  const menuItems = [
    { icon: User, label: 'Personal Information', to: '/profile/edit' },
    { icon: Heart, label: 'Health Profile', to: '/profile/health' },
    { icon: FileText, label: 'Medical Records', to: '/records' },
    { icon: Shield, label: 'Privacy & Security', to: '/profile/privacy' },
    { icon: Bell, label: 'Notifications', to: '/notifications' },
    { icon: Settings, label: 'App Settings', to: '/settings' },
    { icon: HelpCircle, label: 'Help & Support', to: '/help' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 z-40">
        <div className="flex items-center gap-3 max-w-lg mx-auto">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 rounded-full hover:bg-gray-100 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
          <h1 className="text-lg font-bold text-gray-900">Profile</h1>
        </div>
      </header>

      <main className="px-4 py-6 max-w-lg mx-auto space-y-6">
        {/* User Card */}
        {isGuest ? (
          <div className={`rounded-2xl shadow-lg p-6 text-white ${guestRole === 'doctor' ? 'bg-gradient-to-br from-indigo-500 to-purple-600' : 'bg-gradient-to-br from-primary to-teal-600'}`}>
            <div className="flex items-center gap-4 mb-4">
              <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
                <User className="w-10 h-10 text-white" />
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-bold">Guest {guestRole === 'doctor' ? 'Doctor' : 'User'}</h2>
                <p className="text-white/80">Exploring Medro {guestRole === 'doctor' ? 'Doctor Portal' : ''}</p>
              </div>
            </div>
            <p className="text-white/90 text-sm mb-4">
              {guestRole === 'doctor' 
                ? 'Create an account to manage appointments, connect with patients, and grow your practice.'
                : 'Create an account to save your health data, track medications, and access personalized features.'}
            </p>
            <button
              onClick={() => navigate('/login')}
              className={`w-full flex items-center justify-center gap-2 py-3 bg-white font-semibold rounded-xl hover:bg-white/90 transition-colors ${guestRole === 'doctor' ? 'text-indigo-600' : 'text-primary'}`}
            >
              <LogIn className="w-5 h-5" />
              <span>Create Account</span>
            </button>
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <div className="flex items-center gap-4">
              {user?.avatar ? (
                <img src={user.avatar} alt="" className="w-20 h-20 rounded-full" />
              ) : (
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center">
                  <span className="text-3xl font-bold text-primary">
                    {user?.name?.charAt(0) || 'U'}
                  </span>
                </div>
              )}
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-bold text-gray-900">{user?.name || 'User'}</h2>
                  {user?.country && (
                    <span className="text-xl">
                      {countries.find(c => c.code === user.country)?.flag || '🌍'}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1 text-gray-500">
                  {user?.country && (
                    <>
                      <MapPin className="w-3.5 h-3.5" />
                      <span className="text-sm">
                        {countries.find(c => c.code === user.country)?.name}
                      </span>
                      <span className="mx-1">•</span>
                    </>
                  )}
                  <span className="text-sm">{user?.email}</span>
                </div>
                <span className="inline-block mt-2 px-3 py-1 bg-primary/10 text-primary text-sm font-medium rounded-full capitalize">
                  {user?.role || 'Patient'}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Menu Items */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm divide-y divide-gray-100">
          {menuItems.map((item) => (
            <button
              key={item.label}
              onClick={() => navigate(item.to)}
              className="w-full flex items-center gap-4 p-4 hover:bg-gray-50 transition-colors text-left"
            >
              <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center">
                <item.icon className="w-5 h-5 text-gray-600" />
              </div>
              <span className="flex-1 font-medium text-gray-900">{item.label}</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
          ))}
        </div>

        {/* Logout/Exit Guest Button */}
        <button
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-2 p-4 bg-red-50 text-red-600 rounded-2xl font-medium hover:bg-red-100 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span>{isGuest ? 'Exit Guest Mode' : 'Log Out'}</span>
        </button>

        {/* App Info */}
        <div className="text-center text-sm text-gray-400">
          <p>Medro v1.0.0</p>
          <p className="mt-1">Made with ❤️ for better health</p>
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
