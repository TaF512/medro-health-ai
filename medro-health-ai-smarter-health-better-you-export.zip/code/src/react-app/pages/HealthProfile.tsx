import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { 
  ArrowLeft, Save, Loader2, User, Calendar, Ruler, Scale,
  Droplets, Heart, AlertTriangle, Pill, Phone, Shield, MapPin, Search
} from 'lucide-react';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { Button } from '@/react-app/components/ui/button';
import { Input } from '@/react-app/components/ui/input';
import { cn } from '@/react-app/lib/utils';
import { countries } from '@/react-app/data/countries';

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
const COMMON_CONDITIONS = [
  'Diabetes', 'Hypertension', 'Asthma', 'Heart Disease', 
  'Thyroid', 'Arthritis', 'Cancer', 'Kidney Disease'
];

interface ProfileData {
  fullName: string;
  dateOfBirth: string;
  sex: string;
  heightCm: number | null;
  weightKg: number | null;
  bloodGroup: string;
  conditions: string[];
  allergies: string;
  currentMedications: string[];
  emergencyContactName: string;
  emergencyContactPhone: string;
  isBloodDonor: boolean;
  isBloodGroupPublic: boolean;
  country: string;
}

export default function HealthProfilePage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [newMedication, setNewMedication] = useState('');
  const [customCondition, setCustomCondition] = useState('');

  const [formData, setFormData] = useState<ProfileData>({
    fullName: '',
    dateOfBirth: '',
    sex: '',
    heightCm: null,
    weightKg: null,
    bloodGroup: '',
    conditions: [],
    allergies: '',
    currentMedications: [],
    emergencyContactName: '',
    emergencyContactPhone: '',
    isBloodDonor: false,
    isBloodGroupPublic: false,
    country: user?.country || '',
  });
  const [countrySearch, setCountrySearch] = useState('');

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const res = await fetch('/api/patient/profile');
      const data = await res.json();
      if (data.profile) {
        setFormData({
          ...data.profile,
          heightCm: data.profile.heightCm || null,
          weightKg: data.profile.weightKg || null,
        });
      } else if (user?.name) {
        setFormData(prev => ({ ...prev, fullName: user.name || '' }));
      }
    } catch (error) {
      console.error('Failed to fetch profile:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const res = await fetch('/api/patient/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        navigate('/profile');
      }
    } catch (error) {
      console.error('Failed to save profile:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const toggleCondition = (condition: string) => {
    setFormData(prev => ({
      ...prev,
      conditions: prev.conditions.includes(condition)
        ? prev.conditions.filter(c => c !== condition)
        : [...prev.conditions, condition]
    }));
  };

  const addCustomCondition = () => {
    if (customCondition.trim() && !formData.conditions.includes(customCondition.trim())) {
      setFormData(prev => ({
        ...prev,
        conditions: [...prev.conditions, customCondition.trim()]
      }));
      setCustomCondition('');
    }
  };

  const addMedication = () => {
    if (newMedication.trim() && !formData.currentMedications.includes(newMedication.trim())) {
      setFormData(prev => ({
        ...prev,
        currentMedications: [...prev.currentMedications, newMedication.trim()]
      }));
      setNewMedication('');
    }
  };

  const removeMedication = (med: string) => {
    setFormData(prev => ({
      ...prev,
      currentMedications: prev.currentMedications.filter(m => m !== med)
    }));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      {/* Header */}
      <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 z-40">
        <div className="flex items-center justify-between max-w-lg mx-auto">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate(-1)}
              className="p-2 -ml-2 rounded-full hover:bg-gray-100 transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-gray-700" />
            </button>
            <h1 className="text-lg font-bold text-gray-900">Health Profile</h1>
          </div>
          <Button onClick={handleSave} disabled={isSaving} size="sm">
            {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            <span className="ml-1.5">Save</span>
          </Button>
        </div>
      </header>

      <main className="px-4 py-6 max-w-lg mx-auto space-y-6">
        {/* Personal Info */}
        <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
              <User className="w-5 h-5 text-blue-600" />
            </div>
            <h2 className="text-lg font-semibold text-gray-900">Personal Information</h2>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1.5 block">Full Name</label>
              <Input
                value={formData.fullName}
                onChange={e => setFormData(prev => ({ ...prev, fullName: e.target.value }))}
                placeholder="Enter your full name"
              />
            </div>

            {/* Country Selector */}
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1.5 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5" /> Country
              </label>
              <div className="relative">
                <div className="flex items-center gap-2 px-3 py-2 border border-gray-200 rounded-md bg-white">
                  {formData.country ? (
                    <>
                      <span className="text-lg">{countries.find(c => c.code === formData.country)?.flag}</span>
                      <span className="flex-1 text-sm">{countries.find(c => c.code === formData.country)?.name}</span>
                      <button
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, country: '' }))}
                        className="text-gray-400 hover:text-gray-600"
                      >
                        ×
                      </button>
                    </>
                  ) : (
                    <>
                      <Search className="w-4 h-4 text-gray-400" />
                      <input
                        type="text"
                        value={countrySearch}
                        onChange={e => setCountrySearch(e.target.value)}
                        placeholder="Search country..."
                        className="flex-1 text-sm outline-none bg-transparent"
                      />
                    </>
                  )}
                </div>
                {!formData.country && countrySearch && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-48 overflow-y-auto z-50">
                    {countries
                      .filter(c => c.name.toLowerCase().includes(countrySearch.toLowerCase()))
                      .slice(0, 8)
                      .map(country => (
                        <button
                          key={country.code}
                          type="button"
                          onClick={() => {
                            setFormData(prev => ({ ...prev, country: country.code }));
                            setCountrySearch('');
                          }}
                          className="w-full flex items-center gap-2 px-3 py-2 hover:bg-gray-50 text-left"
                        >
                          <span className="text-lg">{country.flag}</span>
                          <span className="text-sm">{country.name}</span>
                        </button>
                      ))}
                  </div>
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1.5 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5" /> Date of Birth
                </label>
                <Input
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={e => setFormData(prev => ({ ...prev, dateOfBirth: e.target.value }))}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1.5 block">Sex</label>
                <select
                  value={formData.sex}
                  onChange={e => setFormData(prev => ({ ...prev, sex: e.target.value }))}
                  className="w-full h-10 rounded-md border border-gray-200 bg-white px-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="">Select</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1.5 flex items-center gap-1">
                  <Ruler className="w-3.5 h-3.5" /> Height (cm)
                </label>
                <Input
                  type="number"
                  value={formData.heightCm || ''}
                  onChange={e => setFormData(prev => ({ ...prev, heightCm: e.target.value ? Number(e.target.value) : null }))}
                  placeholder="170"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1.5 flex items-center gap-1">
                  <Scale className="w-3.5 h-3.5" /> Weight (kg)
                </label>
                <Input
                  type="number"
                  value={formData.weightKg || ''}
                  onChange={e => setFormData(prev => ({ ...prev, weightKg: e.target.value ? Number(e.target.value) : null }))}
                  placeholder="70"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Blood Group */}
        <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-red-100 rounded-xl flex items-center justify-center">
              <Droplets className="w-5 h-5 text-red-600" />
            </div>
            <h2 className="text-lg font-semibold text-gray-900">Blood Group</h2>
          </div>

          <div className="grid grid-cols-4 gap-2 mb-4">
            {BLOOD_GROUPS.map(group => (
              <button
                key={group}
                onClick={() => setFormData(prev => ({ ...prev, bloodGroup: group }))}
                className={cn(
                  'py-3 rounded-xl font-semibold text-sm transition-all',
                  formData.bloodGroup === group
                    ? 'bg-red-500 text-white shadow-lg shadow-red-200'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                )}
              >
                {group}
              </button>
            ))}
          </div>

          <div className="space-y-3 pt-3 border-t border-gray-100">
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.isBloodDonor}
                onChange={e => setFormData(prev => ({ ...prev, isBloodDonor: e.target.checked }))}
                className="w-5 h-5 rounded border-gray-300 text-primary focus:ring-primary"
              />
              <span className="text-sm text-gray-700">I am willing to donate blood</span>
            </label>
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.isBloodGroupPublic}
                onChange={e => setFormData(prev => ({ ...prev, isBloodGroupPublic: e.target.checked }))}
                className="w-5 h-5 rounded border-gray-300 text-primary focus:ring-primary"
              />
              <div>
                <span className="text-sm text-gray-700">Make my blood group visible to others</span>
                <p className="text-xs text-gray-500 flex items-center gap-1 mt-0.5">
                  <Shield className="w-3 h-3" /> Others can contact you for blood donation requests
                </p>
              </div>
            </label>
          </div>
        </section>

        {/* Medical Conditions */}
        <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center">
              <Heart className="w-5 h-5 text-purple-600" />
            </div>
            <h2 className="text-lg font-semibold text-gray-900">Medical Conditions</h2>
          </div>

          <div className="flex flex-wrap gap-2 mb-4">
            {COMMON_CONDITIONS.map(condition => (
              <button
                key={condition}
                onClick={() => toggleCondition(condition)}
                className={cn(
                  'px-3 py-1.5 rounded-full text-sm font-medium transition-all',
                  formData.conditions.includes(condition)
                    ? 'bg-purple-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                )}
              >
                {condition}
              </button>
            ))}
          </div>

          {/* Show custom conditions */}
          {formData.conditions.filter(c => !COMMON_CONDITIONS.includes(c)).map(condition => (
            <span
              key={condition}
              className="inline-flex items-center gap-1 px-3 py-1.5 bg-purple-100 text-purple-700 rounded-full text-sm font-medium mr-2 mb-2"
            >
              {condition}
              <button onClick={() => toggleCondition(condition)} className="hover:text-purple-900">×</button>
            </span>
          ))}

          <div className="flex gap-2 mt-2">
            <Input
              value={customCondition}
              onChange={e => setCustomCondition(e.target.value)}
              placeholder="Add other condition..."
              onKeyDown={e => e.key === 'Enter' && addCustomCondition()}
            />
            <Button variant="outline" onClick={addCustomCondition}>Add</Button>
          </div>
        </section>

        {/* Allergies */}
        <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
            </div>
            <h2 className="text-lg font-semibold text-gray-900">Allergies</h2>
          </div>
          <textarea
            value={formData.allergies}
            onChange={e => setFormData(prev => ({ ...prev, allergies: e.target.value }))}
            placeholder="List any allergies (medications, food, environmental...)"
            className="w-full h-24 rounded-xl border border-gray-200 p-3 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </section>

        {/* Current Medications */}
        <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-rose-100 rounded-xl flex items-center justify-center">
              <Pill className="w-5 h-5 text-rose-600" />
            </div>
            <h2 className="text-lg font-semibold text-gray-900">Current Medications</h2>
          </div>

          {formData.currentMedications.length > 0 && (
            <div className="space-y-2 mb-4">
              {formData.currentMedications.map(med => (
                <div key={med} className="flex items-center justify-between bg-gray-50 rounded-lg px-3 py-2">
                  <span className="text-sm text-gray-700">{med}</span>
                  <button
                    onClick={() => removeMedication(med)}
                    className="text-gray-400 hover:text-red-500"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="flex gap-2">
            <Input
              value={newMedication}
              onChange={e => setNewMedication(e.target.value)}
              placeholder="Add medication (e.g., Metformin 500mg)"
              onKeyDown={e => e.key === 'Enter' && addMedication()}
            />
            <Button variant="outline" onClick={addMedication}>Add</Button>
          </div>
        </section>

        {/* Emergency Contact */}
        <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center">
              <Phone className="w-5 h-5 text-green-600" />
            </div>
            <h2 className="text-lg font-semibold text-gray-900">Emergency Contact</h2>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1.5 block">Contact Name</label>
              <Input
                value={formData.emergencyContactName}
                onChange={e => setFormData(prev => ({ ...prev, emergencyContactName: e.target.value }))}
                placeholder="Full name of emergency contact"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1.5 block">Phone Number</label>
              <Input
                type="tel"
                value={formData.emergencyContactPhone}
                onChange={e => setFormData(prev => ({ ...prev, emergencyContactPhone: e.target.value }))}
                placeholder="+880 1XXX-XXXXXX"
              />
            </div>
          </div>
        </section>

        {/* Save Button (Bottom) */}
        <Button onClick={handleSave} disabled={isSaving} className="w-full py-6" size="lg">
          {isSaving ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <Save className="w-5 h-5 mr-2" />}
          Save Health Profile
        </Button>
      </main>
    </div>
  );
}
