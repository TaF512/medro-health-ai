import { ArrowLeft, TrendingUp, TrendingDown, Users, Calendar, Clock, Star, DollarSign } from 'lucide-react';
import { useNavigate } from 'react-router';

export default function DoctorAnalyticsPage() {
  const navigate = useNavigate();

  const stats = [
    { label: 'Total Consultations', value: '342', change: '+12%', trend: 'up', icon: Calendar },
    { label: 'Total Patients', value: '156', change: '+8%', trend: 'up', icon: Users },
    { label: 'Avg. Rating', value: '4.8', change: '+0.2', trend: 'up', icon: Star },
    { label: 'Earnings', value: '৳45,200', change: '+18%', trend: 'up', icon: DollarSign },
  ];

  const weeklyData = [
    { day: 'Mon', consultations: 8, revenue: 4800 },
    { day: 'Tue', consultations: 12, revenue: 7200 },
    { day: 'Wed', consultations: 10, revenue: 6000 },
    { day: 'Thu', consultations: 15, revenue: 9000 },
    { day: 'Fri', consultations: 11, revenue: 6600 },
    { day: 'Sat', consultations: 18, revenue: 10800 },
    { day: 'Sun', consultations: 6, revenue: 3600 },
  ];

  const maxConsultations = Math.max(...weeklyData.map(d => d.consultations));

  const consultationTypes = [
    { type: 'Video Call', count: 145, percentage: 42, color: 'bg-blue-500' },
    { type: 'In-person', count: 120, percentage: 35, color: 'bg-teal-500' },
    { type: 'Chat', count: 77, percentage: 23, color: 'bg-purple-500' },
  ];

  const topConditions = [
    { condition: 'Diabetes Management', count: 45 },
    { condition: 'Hypertension', count: 38 },
    { condition: 'General Checkup', count: 32 },
    { condition: 'Respiratory Issues', count: 28 },
    { condition: 'Cardiac Consultation', count: 22 },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      {/* Header */}
      <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 z-40">
        <div className="flex items-center gap-3 max-w-4xl mx-auto">
          <button
            onClick={() => navigate('/doctor/dashboard')}
            className="p-2 -ml-2 rounded-full hover:bg-gray-100 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
          <h1 className="text-lg font-bold text-gray-900">Analytics</h1>
        </div>
      </header>

      <main className="px-4 py-6 max-w-4xl mx-auto space-y-6">
        {/* Period Selector */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {['This Week', 'This Month', 'Last 3 Months', 'This Year'].map((period, i) => (
            <button
              key={period}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                i === 0
                  ? 'bg-primary text-white'
                  : 'bg-white text-gray-600 border border-gray-200'
              }`}
            >
              {period}
            </button>
          ))}
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          {stats.map((stat) => (
            <div key={stat.label} className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
                  <stat.icon className="w-5 h-5 text-primary" />
                </div>
                <div className={`flex items-center gap-1 text-xs font-medium ${
                  stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {stat.trend === 'up' ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                  {stat.change}
                </div>
              </div>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              <p className="text-sm text-gray-500">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Weekly Chart */}
        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
          <h2 className="font-semibold text-gray-900 mb-4">Weekly Consultations</h2>
          <div className="flex items-end justify-between gap-2 h-40">
            {weeklyData.map((day) => (
              <div key={day.day} className="flex-1 flex flex-col items-center gap-2">
                <div className="w-full bg-gray-100 rounded-t-lg relative" style={{ height: '120px' }}>
                  <div
                    className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-primary to-teal-400 rounded-t-lg transition-all"
                    style={{ height: `${(day.consultations / maxConsultations) * 100}%` }}
                  />
                </div>
                <span className="text-xs text-gray-500">{day.day}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Consultation Types */}
        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
          <h2 className="font-semibold text-gray-900 mb-4">Consultation Types</h2>
          <div className="space-y-4">
            {consultationTypes.map((type) => (
              <div key={type.type}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-700">{type.type}</span>
                  <span className="text-sm font-medium text-gray-900">{type.count} ({type.percentage}%)</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${type.color} rounded-full transition-all`}
                    style={{ width: `${type.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Conditions */}
        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
          <h2 className="font-semibold text-gray-900 mb-4">Top Conditions Treated</h2>
          <div className="space-y-3">
            {topConditions.map((item, index) => (
              <div key={item.condition} className="flex items-center gap-3">
                <span className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center text-xs font-medium text-primary">
                  {index + 1}
                </span>
                <span className="flex-1 text-sm text-gray-700">{item.condition}</span>
                <span className="text-sm font-semibold text-gray-900">{item.count}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Performance Summary */}
        <div className="bg-gradient-to-br from-primary to-teal-600 rounded-2xl p-5 text-white">
          <h2 className="font-semibold mb-3">Performance Summary</h2>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Clock className="w-4 h-4 text-white/80" />
                <span className="text-sm text-white/80">Avg. Response Time</span>
              </div>
              <p className="text-xl font-bold">2.5 min</p>
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Star className="w-4 h-4 text-white/80" />
                <span className="text-sm text-white/80">Patient Satisfaction</span>
              </div>
              <p className="text-xl font-bold">96%</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
