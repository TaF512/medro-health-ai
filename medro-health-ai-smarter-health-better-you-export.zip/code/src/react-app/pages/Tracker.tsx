import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router';
import { Html5Qrcode } from 'html5-qrcode';
import { 
  Footprints, Moon, HeartPulse, Scale, Droplets, Activity,
  Smile, Plus, X, Check,
  Flame, Brain, Wind, Dumbbell,
  Timer, Play, Pause, RotateCcw, Bell, BellOff,
  Link2, Save, UtensilsCrossed,
  Sparkles, Loader2, AlertTriangle, CheckCircle,
  Pill, ChevronRight, Zap, ArrowLeft,
  ScanBarcode, Package, Search, Camera
} from 'lucide-react';
import BottomNav from '@/react-app/components/BottomNav';
import { cn } from '@/react-app/lib/utils';

// Tabs for the tracker
type TrackerTab = 'overview' | 'nutrition' | 'supplements' | 'ai';

// Health categories
const healthCategories = [
  { id: 'activity', name: 'Activity', icon: Activity, color: 'text-orange-600', bgColor: 'bg-orange-100' },
  { id: 'heart', name: 'Heart', icon: HeartPulse, color: 'text-red-600', bgColor: 'bg-red-100' },
  { id: 'body', name: 'Body', icon: Scale, color: 'text-purple-600', bgColor: 'bg-purple-100' },
  { id: 'mindfulness', name: 'Mind', icon: Brain, color: 'text-cyan-600', bgColor: 'bg-cyan-100' },
  { id: 'sleep', name: 'Sleep', icon: Moon, color: 'text-indigo-600', bgColor: 'bg-indigo-100' },
  { id: 'hydration', name: 'Water', icon: Droplets, color: 'text-sky-600', bgColor: 'bg-sky-100' },
];

// Trackable metrics
const trackableMetrics = [
  { id: 'steps', name: 'Steps', unit: 'steps', category: 'activity', icon: Footprints },
  { id: 'calories', name: 'Active Calories', unit: 'kcal', category: 'activity', icon: Flame },
  { id: 'heart_rate', name: 'Heart Rate', unit: 'bpm', category: 'heart', icon: HeartPulse },
  { id: 'blood_pressure_sys', name: 'Blood Pressure', unit: 'mmHg', category: 'heart', icon: HeartPulse },
  { id: 'blood_oxygen', name: 'Blood Oxygen', unit: '%', category: 'respiratory', icon: Wind },
  { id: 'weight', name: 'Weight', unit: 'kg', category: 'body', icon: Scale },
  { id: 'sleep_hours', name: 'Sleep Duration', unit: 'hours', category: 'sleep', icon: Moon },
  { id: 'water', name: 'Water Intake', unit: 'ml', category: 'hydration', icon: Droplets },
  { id: 'mood', name: 'Mood Score', unit: '/10', category: 'mindfulness', icon: Smile },
  { id: 'workout_mins', name: 'Workout Minutes', unit: 'min', category: 'fitness', icon: Dumbbell },
];

// Fitness apps for syncing
const fitnessApps = [
  { id: 'apple', name: 'Apple Health', icon: '🍎', color: 'bg-gray-900' },
  { id: 'google', name: 'Google Fit', icon: '❤️', color: 'bg-red-500' },
  { id: 'fitbit', name: 'Fitbit', icon: '⌚', color: 'bg-teal-500' },
  { id: 'garmin', name: 'Garmin', icon: '🏃', color: 'bg-blue-600' },
];

// Today's stats
const todayStats = [
  { id: 'steps', value: 6842, target: 10000, icon: Footprints, color: 'text-green-600', bgColor: 'bg-green-100' },
  { id: 'calories', value: 420, target: 600, icon: Flame, color: 'text-orange-600', bgColor: 'bg-orange-100' },
  { id: 'heart_rate', value: 72, icon: HeartPulse, color: 'text-red-600', bgColor: 'bg-red-100' },
  { id: 'sleep_hours', value: 7.4, target: 8, icon: Moon, color: 'text-indigo-600', bgColor: 'bg-indigo-100' },
  { id: 'water', value: 1500, target: 2500, icon: Droplets, color: 'text-cyan-600', bgColor: 'bg-cyan-100' },
  { id: 'workout_mins', value: 25, target: 30, icon: Dumbbell, color: 'text-amber-600', bgColor: 'bg-amber-100' },
];

// Supplements data
const commonSupplements = [
  { id: 'vitamin_d', name: 'Vitamin D3', dosage: '1000 IU', icon: '☀️', benefits: 'Bone health, immunity' },
  { id: 'vitamin_c', name: 'Vitamin C', dosage: '500 mg', icon: '🍊', benefits: 'Immunity, skin health' },
  { id: 'vitamin_b12', name: 'Vitamin B12', dosage: '1000 mcg', icon: '⚡', benefits: 'Energy, brain function' },
  { id: 'zinc', name: 'Zinc', dosage: '15 mg', icon: '🛡️', benefits: 'Immunity, wound healing' },
  { id: 'magnesium', name: 'Magnesium', dosage: '400 mg', icon: '💪', benefits: 'Muscle, nerve function' },
  { id: 'omega3', name: 'Omega-3 Fish Oil', dosage: '1000 mg', icon: '🐟', benefits: 'Heart, brain health' },
  { id: 'iron', name: 'Iron', dosage: '18 mg', icon: '🩸', benefits: 'Blood health, energy' },
  { id: 'calcium', name: 'Calcium', dosage: '1000 mg', icon: '🦴', benefits: 'Bone health' },
  { id: 'probiotics', name: 'Probiotics', dosage: '10B CFU', icon: '🦠', benefits: 'Gut health, digestion' },
  { id: 'biotin', name: 'Biotin', dosage: '5000 mcg', icon: '💇', benefits: 'Hair, skin, nails' },
  { id: 'folic_acid', name: 'Folic Acid', dosage: '400 mcg', icon: '🧬', benefits: 'Cell growth' },
  { id: 'vitamin_e', name: 'Vitamin E', dosage: '400 IU', icon: '🌿', benefits: 'Antioxidant, skin' },
];

interface FoodEntry {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  time: string;
  image?: string;
  warnings?: string[];
  suggestions?: string[];
}

interface SupplementEntry {
  id: string;
  name: string;
  dosage: string;
  icon: string;
  takenToday: boolean;
  time?: string;
}

interface AIRecommendation {
  id: string;
  type: 'water' | 'food' | 'exercise' | 'sleep' | 'supplement';
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  completed: boolean;
}

export default function TrackerPage() {
  const [activeTab, setActiveTab] = useState<TrackerTab>('overview');
  const [showLogModal, setShowLogModal] = useState(false);
  const [showSyncModal, setShowSyncModal] = useState(false);
  const [showTimerModal, setShowTimerModal] = useState(false);
  const [showSupplementModal, setShowSupplementModal] = useState(false);
  const [showCustomSupplementModal, setShowCustomSupplementModal] = useState(false);
  const [showAISupplementModal, setShowAISupplementModal] = useState(false);
  const [selectedMetric, setSelectedMetric] = useState<string | null>(null);
  const [logValue, setLogValue] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  
  // Custom supplement form
  const [customSupplement, setCustomSupplement] = useState({
    name: '',
    dosage: '',
    unit: 'mg' as 'mg' | 'mcg' | 'IU' | 'g' | 'CFU',
    icon: '💊'
  });
  
  // AI supplement recommendations
  const [aiSupplementRecs, setAiSupplementRecs] = useState<Array<{
    name: string;
    dosage: string;
    reason: string;
    priority: 'high' | 'medium' | 'low';
  }>>([]);
  const [loadingSupplementAI, setLoadingSupplementAI] = useState(false);
  const [connectedApps, setConnectedApps] = useState<string[]>([]);
  
  // Water state
  const [waterReminder, setWaterReminder] = useState(true);
  const [waterIntake, setWaterIntake] = useState(1500);
  
  // Timer state
  const [timerMode, setTimerMode] = useState<'analog' | 'digital'>('digital');
  const [timerSeconds, setTimerSeconds] = useState(300);
  const [timerRunning, setTimerRunning] = useState(false);
  const [timerInitial, setTimerInitial] = useState(300);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Food & Nutrition state
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [foods, setFoods] = useState<FoodEntry[]>([
    { id: '1', name: 'Oatmeal with Berries', calories: 320, protein: 12, carbs: 54, fat: 6, time: '8:30 AM', suggestions: ['Great fiber content!'] },
    { id: '2', name: 'Grilled Chicken Salad', calories: 420, protein: 35, carbs: 18, fat: 22, time: '1:00 PM' }
  ]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showFoodModal, setShowFoodModal] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [analyzedFood, setAnalyzedFood] = useState<Partial<FoodEntry> | null>(null);

  // Barcode scanning state
  const [showBarcodeModal, setShowBarcodeModal] = useState(false);
  const [barcodeInput, setBarcodeInput] = useState('');
  const [isLookingUp, setIsLookingUp] = useState(false);
  const [isCameraScanning, setIsCameraScanning] = useState(false);
  const [scanMode, setScanMode] = useState<'camera' | 'manual'>('camera');
  const html5QrCodeRef = useRef<Html5Qrcode | null>(null);
  const [barcodeProduct, setBarcodeProduct] = useState<{
    found: boolean;
    name: string;
    brand: string;
    servingSize: string;
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    sugar?: number;
    image: string | null;
    nutritionGrade: string | null;
    warnings: string[];
    suggestions: string[];
  } | null>(null);
  const [barcodeError, setBarcodeError] = useState<string | null>(null);
  
  // Note: Camera barcode scanning and drink search to be implemented in task #64-66

  // Supplements state
  const [mySupplements, setMySupplements] = useState<SupplementEntry[]>([
    { id: 'vitamin_d', name: 'Vitamin D3', dosage: '1000 IU', icon: '☀️', takenToday: true, time: '8:00 AM' },
    { id: 'omega3', name: 'Omega-3', dosage: '1000 mg', icon: '🐟', takenToday: false },
    { id: 'zinc', name: 'Zinc', dosage: '15 mg', icon: '🛡️', takenToday: true, time: '8:00 AM' },
  ]);

  // AI Recommendations state
  const [aiRecommendations, setAiRecommendations] = useState<AIRecommendation[]>([]);
  const [loadingAI, setLoadingAI] = useState(false);

  // Timer effect
  useEffect(() => {
    if (timerRunning && timerSeconds > 0) {
      timerRef.current = setInterval(() => {
        setTimerSeconds(prev => {
          if (prev <= 1) {
            setTimerRunning(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [timerRunning]);

  // Fetch AI recommendations
  const fetchAIRecommendations = async () => {
    setLoadingAI(true);
    try {
      const response = await fetch('/api/health-recommendations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          stats: {
            waterIntake,
            steps: 6842,
            sleepHours: 7.4,
            caloriesConsumed: foods.reduce((sum, f) => sum + f.calories, 0),
            supplements: mySupplements.filter(s => s.takenToday).map(s => s.name)
          }
        })
      });

      if (response.ok) {
        const data = await response.json();
        setAiRecommendations(data.recommendations || []);
      } else {
        // Fallback recommendations
        setAiRecommendations([
          { id: '1', type: 'water', title: 'Drink Water', description: `You've had ${waterIntake}ml today. Aim for 2500ml. Have a glass now!`, priority: 'high', completed: false },
          { id: '2', type: 'exercise', title: 'Take a Walk', description: 'You have 3,158 steps to reach your 10,000 goal. A 20-min walk can help!', priority: 'medium', completed: false },
          { id: '3', type: 'food', title: 'Eat More Protein', description: 'Your protein intake is low. Consider adding chicken, fish, or legumes to dinner.', priority: 'medium', completed: false },
          { id: '4', type: 'supplement', title: 'Take Your Omega-3', description: "You haven't logged your Omega-3 supplement today.", priority: 'low', completed: false },
          { id: '5', type: 'sleep', title: 'Wind Down Early', description: 'To get 8 hours of sleep, start your bedtime routine by 10 PM.', priority: 'medium', completed: false },
        ]);
      }
    } catch {
      // Fallback recommendations
      setAiRecommendations([
        { id: '1', type: 'water', title: 'Drink Water', description: `You've had ${waterIntake}ml today. Aim for 2500ml!`, priority: 'high', completed: false },
        { id: '2', type: 'exercise', title: 'Take a Walk', description: 'A 20-minute walk can boost your energy and mood.', priority: 'medium', completed: false },
        { id: '3', type: 'food', title: 'Balanced Dinner', description: 'Include vegetables and lean protein in your next meal.', priority: 'medium', completed: false },
      ]);
    } finally {
      setLoadingAI(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'ai') {
      fetchAIRecommendations();
    }
  }, [activeTab]);

  const addWater = (ml: number) => {
    setWaterIntake(prev => prev + ml);
  };

  const handleLogData = () => {
    if (selectedMetric && logValue) {
      setShowLogModal(false);
      setSelectedMetric(null);
      setLogValue('');
    }
  };

  const toggleAppConnection = (appId: string) => {
    setConnectedApps(prev => 
      prev.includes(appId) ? prev.filter(id => id !== appId) : [...prev, appId]
    );
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const resetTimer = () => {
    setTimerRunning(false);
    setTimerSeconds(timerInitial);
  };

  // Food functions - AI-powered analysis
  const handleImageCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const imageSrc = event.target?.result as string;
      setCapturedImage(imageSrc);
      setShowFoodModal(true);
      setIsAnalyzing(true);

      try {
        // Extract base64 data and mime type
        const matches = imageSrc.match(/^data:(.+);base64,(.+)$/);
        if (!matches) throw new Error("Invalid image format");
        
        const mimeType = matches[1];
        const base64Data = matches[2];

        const response = await fetch("/api/analyze-food", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ image: base64Data, mimeType })
        });

        if (!response.ok) throw new Error("Failed to analyze food");

        const data = await response.json();
        setAnalyzedFood({
          name: data.mealName || "Food Item",
          calories: data.totals?.calories || 0,
          protein: data.totals?.protein || 0,
          carbs: data.totals?.carbs || 0,
          fat: data.totals?.fat || 0,
          warnings: data.warnings || [],
          suggestions: data.suggestions || []
        });
      } catch (error) {
        console.error("Food analysis error:", error);
        setAnalyzedFood({
          name: "Unable to analyze",
          calories: 0,
          protein: 0,
          carbs: 0,
          fat: 0,
          warnings: ["Could not analyze this image"],
          suggestions: ["Try taking a clearer photo"]
        });
      } finally {
        setIsAnalyzing(false);
      }
    };
    reader.readAsDataURL(file);
  };

  // Barcode lookup function
  const lookupBarcode = async (barcode?: string) => {
    const codeToLookup = barcode || barcodeInput.trim();
    if (!codeToLookup) return;
    
    setIsLookingUp(true);
    setBarcodeError(null);
    setBarcodeProduct(null);
    
    try {
      const response = await fetch(`/api/barcode/${codeToLookup}`);
      const data = await response.json();
      
      if (!response.ok || !data.found) {
        setBarcodeError("Product not found. Please check the barcode and try again.");
        return;
      }
      
      setBarcodeProduct(data);
    } catch (error) {
      console.error("Barcode lookup error:", error);
      setBarcodeError("Failed to lookup barcode. Please try again.");
    } finally {
      setIsLookingUp(false);
    }
  };

  // Start camera barcode scanner
  const startCameraScanner = async () => {
    try {
      setIsCameraScanning(true);
      setBarcodeError(null);
      
      const html5QrCode = new Html5Qrcode("barcode-reader");
      html5QrCodeRef.current = html5QrCode;
      
      await html5QrCode.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: { width: 250, height: 100 } },
        async (decodedText) => {
          // Barcode detected - stop scanner and lookup
          await stopCameraScanner();
          setBarcodeInput(decodedText);
          lookupBarcode(decodedText);
        },
        () => {} // Ignore scan failures
      );
    } catch (error) {
      console.error("Camera scanner error:", error);
      setIsCameraScanning(false);
      setBarcodeError("Could not access camera. Please use manual entry.");
      setScanMode('manual');
    }
  };

  // Stop camera scanner
  const stopCameraScanner = async () => {
    if (html5QrCodeRef.current) {
      try {
        await html5QrCodeRef.current.stop();
        html5QrCodeRef.current = null;
      } catch (e) {
        console.error("Error stopping scanner:", e);
      }
    }
    setIsCameraScanning(false);
  };

  // Handle barcode modal close
  const closeBarcodeModal = async () => {
    await stopCameraScanner();
    setShowBarcodeModal(false);
    setBarcodeInput('');
    setBarcodeProduct(null);
    setBarcodeError(null);
    setScanMode('camera');
  };

  // Start scanner when modal opens with camera mode
  useEffect(() => {
    if (showBarcodeModal && scanMode === 'camera' && !barcodeProduct) {
      const timer = setTimeout(() => {
        startCameraScanner();
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [showBarcodeModal, scanMode, barcodeProduct]);

  // Cleanup scanner on unmount
  useEffect(() => {
    return () => {
      if (html5QrCodeRef.current) {
        html5QrCodeRef.current.stop().catch(() => {});
      }
    };
  }, []);

  // Add barcode product to food log
  const addBarcodeProduct = () => {
    if (!barcodeProduct) return;
    
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
    
    const productName = barcodeProduct.brand 
      ? `${barcodeProduct.name} (${barcodeProduct.brand})`
      : barcodeProduct.name;
    
    setFoods(prev => [...prev, {
      id: Date.now().toString(),
      name: productName,
      calories: barcodeProduct.calories,
      protein: barcodeProduct.protein,
      carbs: barcodeProduct.carbs,
      fat: barcodeProduct.fat,
      time: timeStr,
      image: barcodeProduct.image || undefined,
      warnings: barcodeProduct.warnings,
      suggestions: barcodeProduct.suggestions
    }]);
    
    // Reset barcode modal state
    setShowBarcodeModal(false);
    setBarcodeInput('');
    setBarcodeProduct(null);
    setBarcodeError(null);
  };

  const addAnalyzedFood = () => {
    if (!analyzedFood?.name) return;
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });

    setFoods(prev => [...prev, {
      id: Date.now().toString(),
      name: analyzedFood.name!,
      calories: analyzedFood.calories || 0,
      protein: analyzedFood.protein || 0,
      carbs: analyzedFood.carbs || 0,
      fat: analyzedFood.fat || 0,
      time: timeStr,
      image: capturedImage || undefined,
      warnings: analyzedFood.warnings,
      suggestions: analyzedFood.suggestions
    }]);

    setShowFoodModal(false);
    setCapturedImage(null);
    setAnalyzedFood(null);
  };

  const toggleSupplementTaken = (id: string) => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
    setMySupplements(prev => prev.map(s => 
      s.id === id ? { ...s, takenToday: !s.takenToday, time: !s.takenToday ? timeStr : undefined } : s
    ));
  };

  const addSupplement = (supplement: typeof commonSupplements[0]) => {
    if (!mySupplements.find(s => s.id === supplement.id)) {
      setMySupplements(prev => [...prev, { ...supplement, takenToday: false }]);
    }
    setShowSupplementModal(false);
  };

  const addCustomSupplement = () => {
    if (!customSupplement.name || !customSupplement.dosage) return;
    const id = `custom_${Date.now()}`;
    setMySupplements(prev => [...prev, {
      id,
      name: customSupplement.name,
      dosage: `${customSupplement.dosage} ${customSupplement.unit}`,
      icon: customSupplement.icon,
      takenToday: false
    }]);
    setCustomSupplement({ name: '', dosage: '', unit: 'mg', icon: '💊' });
    setShowCustomSupplementModal(false);
  };

  const fetchAISupplementRecommendations = async () => {
    setLoadingSupplementAI(true);
    try {
      const response = await fetch('/api/supplement-recommendations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentSupplements: mySupplements.map(s => s.name),
          healthGoals: ['general wellness', 'energy', 'immunity'],
          diet: 'balanced',
          age: 30
        })
      });

      if (response.ok) {
        const data = await response.json();
        setAiSupplementRecs(data.recommendations || []);
      } else {
        // Fallback recommendations
        setAiSupplementRecs([
          { name: 'Vitamin D3', dosage: '2000 IU', reason: 'Essential for bone health and immunity, especially if you have limited sun exposure', priority: 'high' },
          { name: 'Omega-3 Fish Oil', dosage: '1000 mg', reason: 'Supports heart and brain health, reduces inflammation', priority: 'high' },
          { name: 'Magnesium Glycinate', dosage: '400 mg', reason: 'Helps with muscle recovery, sleep quality, and stress management', priority: 'medium' },
          { name: 'Vitamin B12', dosage: '1000 mcg', reason: 'Important for energy levels and nervous system function', priority: 'medium' },
          { name: 'Zinc', dosage: '15 mg', reason: 'Supports immune function and wound healing', priority: 'low' },
        ]);
      }
    } catch {
      setAiSupplementRecs([
        { name: 'Vitamin D3', dosage: '2000 IU', reason: 'Essential for bone health and immunity', priority: 'high' },
        { name: 'Omega-3', dosage: '1000 mg', reason: 'Supports heart and brain health', priority: 'medium' },
        { name: 'Magnesium', dosage: '400 mg', reason: 'Helps with sleep and muscle function', priority: 'medium' },
      ]);
    } finally {
      setLoadingSupplementAI(false);
    }
  };

  const handleCategoryClick = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setShowLogModal(true);
  };

  const getCategoryMetrics = (categoryId: string) => {
    return trackableMetrics.filter(m => m.category === categoryId);
  };

  const completeRecommendation = (id: string) => {
    setAiRecommendations(prev => prev.map(r => 
      r.id === id ? { ...r, completed: true } : r
    ));
  };

  const getMetricInfo = (id: string) => trackableMetrics.find(m => m.id === id);
  const totalCalories = foods.reduce((sum, f) => sum + f.calories, 0);
  const totalProtein = foods.reduce((sum, f) => sum + f.protein, 0);
  const totalCarbs = foods.reduce((sum, f) => sum + f.carbs, 0);
  const totalFat = foods.reduce((sum, f) => sum + f.fat, 0);

  const tabs = [
    { id: 'overview' as const, label: 'Overview', icon: Activity },
    { id: 'nutrition' as const, label: 'Food & Nutrition', icon: UtensilsCrossed },
    { id: 'supplements' as const, label: 'Supplements', icon: Pill },
    { id: 'ai' as const, label: 'AI Coach', icon: Sparkles },
  ];

  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header with back button */}
      <header className="sticky top-0 bg-gradient-to-r from-primary to-teal-500 px-4 py-4 z-40">
        <div className="flex items-center gap-3 max-w-lg mx-auto">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 rounded-full hover:bg-white/20 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-white">Health Tracker</h1>
            <p className="text-sm text-white/80">Track your wellness journey</p>
          </div>
          <div className="flex items-center gap-1.5 bg-white/20 px-2.5 py-1 rounded-full">
            <Sparkles className="w-3.5 h-3.5 text-white" />
            <span className="text-xs font-medium text-white">AI Powered</span>
          </div>
        </div>
      </header>
      
      <main className="px-4 py-4 max-w-lg mx-auto space-y-4">
        {/* Tab Navigation */}
        <div className="flex gap-1 bg-gray-100 p-1 rounded-xl overflow-x-auto">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                'flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all flex-1',
                activeTab === tab.id 
                  ? 'bg-white shadow text-primary' 
                  : 'text-gray-600 hover:text-gray-900'
              )}
            >
              <tab.icon className="w-4 h-4" />
              <span className="hidden sm:inline">{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <>
            {/* Quick Actions */}
            <div className="flex gap-2 overflow-x-auto pb-1">
              <button onClick={() => setShowLogModal(true)} className="flex items-center gap-2 px-4 py-2.5 bg-primary text-white rounded-xl font-medium whitespace-nowrap">
                <Plus className="w-4 h-4" /> Log Data
              </button>
              <button onClick={() => setShowSyncModal(true)} className="flex items-center gap-2 px-4 py-2.5 bg-white border border-gray-200 rounded-xl font-medium whitespace-nowrap">
                <Link2 className="w-4 h-4" /> Sync Apps
              </button>
              <button onClick={() => setShowTimerModal(true)} className="flex items-center gap-2 px-4 py-2.5 bg-white border border-gray-200 rounded-xl font-medium whitespace-nowrap">
                <Timer className="w-4 h-4" /> Timer
              </button>
            </div>

            {/* Water Card */}
            <section className="bg-gradient-to-r from-cyan-500 to-blue-500 rounded-2xl p-4 text-white">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <Droplets className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">Stay Hydrated!</h3>
                    <p className="text-cyan-100 text-sm">{waterIntake}ml / 2500ml</p>
                  </div>
                </div>
                <button onClick={() => setWaterReminder(!waterReminder)} className={cn('p-2 rounded-lg', waterReminder ? 'bg-white/20' : 'bg-white/10')}>
                  {waterReminder ? <Bell className="w-5 h-5" /> : <BellOff className="w-5 h-5" />}
                </button>
              </div>
              <div className="h-3 bg-white/20 rounded-full mb-3 overflow-hidden">
                <div className="h-full bg-white rounded-full transition-all" style={{ width: `${Math.min((waterIntake / 2500) * 100, 100)}%` }} />
              </div>
              <div className="flex gap-2">
                {[150, 250, 500].map(ml => (
                  <button key={ml} onClick={() => addWater(ml)} className="flex-1 py-2 bg-white/20 hover:bg-white/30 rounded-lg text-sm font-medium">
                    +{ml}ml
                  </button>
                ))}
              </div>
            </section>

            {/* Stats Grid */}
            <section>
              <h2 className="text-lg font-bold text-gray-900 mb-3">Today's Summary</h2>
              <div className="grid grid-cols-2 gap-3">
                {todayStats.map((stat) => {
                  const metricInfo = getMetricInfo(stat.id);
                  const progress = stat.target ? Math.round((stat.value / stat.target) * 100) : null;
                  return (
                    <div key={stat.id} className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
                      <div className="flex items-start justify-between mb-2">
                        <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center', stat.bgColor)}>
                          <stat.icon className={cn('w-5 h-5', stat.color)} />
                        </div>
                        {progress !== null && <span className="text-xs font-medium text-gray-500">{progress}%</span>}
                      </div>
                      <p className="text-sm text-gray-500 mb-1">{metricInfo?.name}</p>
                      <div className="flex items-baseline gap-1">
                        <span className="text-2xl font-bold text-gray-900">{stat.id === 'sleep_hours' ? stat.value.toFixed(1) : stat.value.toLocaleString()}</span>
                        <span className="text-sm text-gray-500">{metricInfo?.unit}</span>
                      </div>
                      {stat.target && (
                        <div className="mt-2">
                          <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                            <div className={cn('h-full rounded-full', stat.bgColor.replace('100', '500'))} style={{ width: `${Math.min(progress || 0, 100)}%` }} />
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </section>

            {/* Categories */}
            <section>
              <h2 className="text-lg font-bold text-gray-900 mb-3">Browse Categories</h2>
              <div className="grid grid-cols-3 gap-3">
                {healthCategories.map((cat) => (
                  <button 
                    key={cat.id} 
                    onClick={() => handleCategoryClick(cat.id)}
                    className="flex flex-col items-center gap-2 p-4 rounded-2xl border bg-white border-gray-100 hover:border-primary hover:shadow-md transition-all"
                  >
                    <div className={cn('w-12 h-12 rounded-xl flex items-center justify-center', cat.bgColor)}>
                      <cat.icon className={cn('w-6 h-6', cat.color)} />
                    </div>
                    <span className="text-xs font-medium text-gray-700">{cat.name}</span>
                    <span className="text-[10px] text-gray-400">
                      {getCategoryMetrics(cat.id).length} metrics
                    </span>
                  </button>
                ))}
              </div>
            </section>
          </>
        )}

        {/* Food & Nutrition Tab */}
        {activeTab === 'nutrition' && (
          <>
            {/* Today's Nutrition Card - Matching Image 1 */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold text-gray-900">Today's Nutrition</h2>
                <span className="text-sm text-gray-500">{new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</span>
              </div>
              
              {/* Calorie Ring + Stats Row */}
              <div className="flex items-center gap-6 mb-5">
                {/* Calorie Ring */}
                <div className="relative w-24 h-24 flex-shrink-0">
                  <svg className="w-24 h-24 transform -rotate-90">
                    <circle cx="48" cy="48" r="40" stroke="#e5e7eb" strokeWidth="8" fill="none" />
                    <circle 
                      cx="48" cy="48" r="40" 
                      stroke="url(#calorieGradientTracker)" 
                      strokeWidth="8" 
                      fill="none"
                      strokeLinecap="round"
                      strokeDasharray={`${(totalCalories / 2000) * 251} 251`}
                    />
                    <defs>
                      <linearGradient id="calorieGradientTracker" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#22c55e" />
                        <stop offset="100%" stopColor="#16a34a" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-2xl font-bold text-gray-900">{2000 - totalCalories}</span>
                    <span className="text-xs text-gray-500">remaining</span>
                  </div>
                </div>
                
                {/* Stats Column */}
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 bg-green-100 rounded-full flex items-center justify-center">
                      <span className="text-sm">🍎</span>
                    </div>
                    <span className="text-sm font-semibold text-gray-900">{totalCalories}</span>
                    <span className="text-xs text-gray-500">Consumed</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 bg-orange-100 rounded-full flex items-center justify-center">
                      <Flame className="w-4 h-4 text-orange-500" />
                    </div>
                    <span className="text-sm font-semibold text-gray-900">320</span>
                    <span className="text-xs text-gray-500">Burned</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-sm">🎯</span>
                    </div>
                    <span className="text-sm font-semibold text-gray-900">2000</span>
                    <span className="text-xs text-gray-500">Goal</span>
                  </div>
                </div>
              </div>
              
              {/* Macro Progress Bars */}
              <div className="flex gap-4">
                <div className="flex-1">
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full bg-red-500 rounded-full" style={{ width: `${Math.min((totalProtein / 150) * 100, 100)}%` }} />
                  </div>
                  <p className="text-center mt-1">
                    <span className="text-sm font-bold text-gray-900">{totalProtein}g</span>
                    <span className="text-xs text-gray-500 block">Protein</span>
                  </p>
                </div>
                <div className="flex-1">
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full bg-yellow-500 rounded-full" style={{ width: `${Math.min((totalCarbs / 250) * 100, 100)}%` }} />
                  </div>
                  <p className="text-center mt-1">
                    <span className="text-sm font-bold text-gray-900">{totalCarbs}g</span>
                    <span className="text-xs text-gray-500 block">Carbs</span>
                  </p>
                </div>
                <div className="flex-1">
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 rounded-full" style={{ width: `${Math.min((totalFat / 80) * 100, 100)}%` }} />
                  </div>
                  <p className="text-center mt-1">
                    <span className="text-sm font-bold text-gray-900">{totalFat}g</span>
                    <span className="text-xs text-gray-500 block">Fat</span>
                  </p>
                </div>
              </div>
            </div>

            {/* Log Food CTAs */}
            <div className="grid grid-cols-3 gap-3">
              <button onClick={() => navigate('/food/manual')} className="bg-gradient-to-r from-blue-500 to-indigo-500 rounded-2xl p-4 text-white">
                <div className="flex flex-col items-center text-center gap-2">
                  <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                    <Search className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm">Log Food</h3>
                    <p className="text-white/80 text-[10px]">Search meals</p>
                  </div>
                </div>
              </button>
              <button onClick={() => setShowBarcodeModal(true)} className="bg-gradient-to-r from-amber-400 to-yellow-500 rounded-2xl p-4 text-white">
                <div className="flex flex-col items-center text-center gap-2">
                  <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                    <ScanBarcode className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm">Barcode</h3>
                    <p className="text-white/80 text-[10px]">Scan or type</p>
                  </div>
                </div>
              </button>
              <button onClick={() => navigate('/food/scan')} className="bg-gradient-to-r from-orange-500 to-red-500 rounded-2xl p-4 text-white">
                <div className="flex flex-col items-center text-center gap-2">
                  <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm">AI Scan</h3>
                    <p className="text-white/80 text-[10px]">Photo analysis</p>
                  </div>
                </div>
              </button>
            </div>
            <input ref={fileInputRef} type="file" accept="image/*" capture="environment" onChange={handleImageCapture} className="hidden" />

            {/* Quick Actions: History, Favorites, Goals */}
            <div className="grid grid-cols-3 gap-3">
              <button onClick={() => navigate('/food/history')} className="flex flex-col items-center gap-2 p-4 bg-purple-50 rounded-2xl border border-purple-100 hover:bg-purple-100 transition-colors">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <Timer className="w-6 h-6 text-purple-600" />
                </div>
                <span className="text-sm font-medium text-gray-700">History</span>
              </button>
              <button onClick={() => navigate('/food/favorites')} className="flex flex-col items-center gap-2 p-4 bg-yellow-50 rounded-2xl border border-yellow-100 hover:bg-yellow-100 transition-colors">
                <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center">
                  <Zap className="w-6 h-6 text-yellow-600" />
                </div>
                <span className="text-sm font-medium text-gray-700">Favorites</span>
              </button>
              <button onClick={() => navigate('/food/settings')} className="flex flex-col items-center gap-2 p-4 bg-gray-50 rounded-2xl border border-gray-200 hover:bg-gray-100 transition-colors">
                <div className="w-12 h-12 bg-gray-200 rounded-xl flex items-center justify-center">
                  <Scale className="w-6 h-6 text-gray-600" />
                </div>
                <span className="text-sm font-medium text-gray-700">Goals</span>
              </button>
            </div>

            {/* Recent Meals */}
            <section>
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-semibold text-gray-900">Recent Meals</h2>
                <button onClick={() => navigate('/food/history')} className="text-sm text-primary font-medium flex items-center gap-1">
                  View All <ChevronRight className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-3">
                {foods.map(food => (
                  <div key={food.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                    <div className="flex items-center gap-4 p-4">
                      {food.image ? (
                        <img src={food.image} alt="" className="w-14 h-14 rounded-xl object-cover" />
                      ) : (
                        <div className="w-14 h-14 bg-orange-100 rounded-xl flex items-center justify-center">
                          <UtensilsCrossed className="w-6 h-6 text-orange-600" />
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-gray-900 truncate">{food.name}</p>
                        <p className="text-sm text-gray-500">{food.time}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-orange-600">{food.calories}</p>
                        <p className="text-xs text-gray-500">kcal</p>
                      </div>
                    </div>
                    <div className="border-t border-gray-100 px-4 py-2 bg-gray-50 flex gap-4 text-xs">
                      <span className="text-red-600">P: {food.protein}g</span>
                      <span className="text-amber-600">C: {food.carbs}g</span>
                      <span className="text-blue-600">F: {food.fat}g</span>
                    </div>
                    {(food.warnings?.length || food.suggestions?.length) && (
                      <div className="border-t border-gray-100 px-4 py-3 space-y-1">
                        {food.warnings?.map((w, i) => (
                          <div key={i} className="flex items-center gap-2 text-amber-700 text-sm">
                            <AlertTriangle className="w-4 h-4" /> {w}
                          </div>
                        ))}
                        {food.suggestions?.map((s, i) => (
                          <div key={i} className="flex items-center gap-2 text-green-700 text-sm">
                            <CheckCircle className="w-4 h-4" /> {s}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </section>
          </>
        )}

        {/* Supplements Tab */}
        {activeTab === 'supplements' && (
          <>
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-gray-900">My Supplements</h2>
              <div className="flex gap-2">
                <button onClick={() => setShowCustomSupplementModal(true)} className="flex items-center gap-1 px-3 py-1.5 bg-primary/10 text-primary rounded-lg font-medium text-sm">
                  <Plus className="w-4 h-4" /> Custom
                </button>
                <button onClick={() => setShowSupplementModal(true)} className="flex items-center gap-1 px-3 py-1.5 border border-gray-200 rounded-lg font-medium text-sm">
                  <Plus className="w-4 h-4" /> Browse
                </button>
              </div>
            </div>

            {/* AI Recommendations Banner */}
            <button
              onClick={() => { setShowAISupplementModal(true); fetchAISupplementRecommendations(); }}
              className="w-full bg-gradient-to-r from-violet-500 to-purple-600 rounded-2xl p-4 text-white text-left"
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold">AI Supplement Advisor</h3>
                  <p className="text-sm text-violet-200">Get personalized recommendations</p>
                </div>
                <ChevronRight className="w-5 h-5 ml-auto" />
              </div>
            </button>

            {/* Progress */}
            <div className="bg-gradient-to-r from-emerald-500 to-teal-500 rounded-2xl p-4 text-white">
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold">Today's Progress</span>
                <span className="font-bold">{mySupplements.filter(s => s.takenToday).length}/{mySupplements.length}</span>
              </div>
              <div className="h-2 bg-white/20 rounded-full overflow-hidden">
                <div className="h-full bg-white rounded-full" style={{ width: `${(mySupplements.filter(s => s.takenToday).length / mySupplements.length) * 100}%` }} />
              </div>
            </div>

            {/* Supplement List */}
            <div className="space-y-3">
              {mySupplements.map(supplement => (
                <div key={supplement.id} className={cn('bg-white rounded-2xl border p-4 transition-all', supplement.takenToday ? 'border-green-200 bg-green-50/50' : 'border-gray-100')}>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center text-2xl">
                      {supplement.icon}
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-gray-900">{supplement.name}</p>
                      <p className="text-sm text-gray-500">{supplement.dosage}</p>
                      {supplement.takenToday && supplement.time && (
                        <p className="text-xs text-green-600 mt-1">✓ Taken at {supplement.time}</p>
                      )}
                    </div>
                    <button
                      onClick={() => toggleSupplementTaken(supplement.id)}
                      className={cn(
                        'w-10 h-10 rounded-full flex items-center justify-center transition-all',
                        supplement.takenToday ? 'bg-green-500 text-white' : 'border-2 border-gray-300 text-gray-300'
                      )}
                    >
                      <Check className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Common Supplements */}
            <section>
              <h3 className="font-semibold text-gray-900 mb-3">Popular Supplements</h3>
              <div className="grid grid-cols-2 gap-2">
                {commonSupplements.filter(s => !mySupplements.find(m => m.id === s.id)).slice(0, 6).map(supp => (
                  <button
                    key={supp.id}
                    onClick={() => addSupplement(supp)}
                    className="flex items-center gap-3 p-3 bg-white rounded-xl border border-gray-100 hover:border-primary/50 text-left"
                  >
                    <span className="text-xl">{supp.icon}</span>
                    <div>
                      <p className="font-medium text-gray-900 text-sm">{supp.name}</p>
                      <p className="text-xs text-gray-500">{supp.dosage}</p>
                    </div>
                  </button>
                ))}
              </div>
            </section>
          </>
        )}

        {/* AI Coach Tab */}
        {activeTab === 'ai' && (
          <>
            <div className="bg-gradient-to-r from-violet-500 to-purple-600 rounded-2xl p-5 text-white">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="font-bold text-lg">AI Health Coach</h2>
                  <p className="text-violet-200 text-sm">Personalized recommendations</p>
                </div>
              </div>
              <p className="text-sm text-violet-100">Based on your health data, here's what you should focus on today:</p>
            </div>

            {loadingAI ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 text-primary animate-spin" />
              </div>
            ) : (
              <div className="space-y-3">
                {aiRecommendations.map(rec => (
                  <div
                    key={rec.id}
                    className={cn(
                      'bg-white rounded-2xl border p-4 transition-all',
                      rec.completed ? 'border-green-200 bg-green-50/50 opacity-60' : 'border-gray-100'
                    )}
                  >
                    <div className="flex items-start gap-4">
                      <div className={cn(
                        'w-10 h-10 rounded-xl flex items-center justify-center',
                        rec.type === 'water' ? 'bg-cyan-100' :
                        rec.type === 'food' ? 'bg-orange-100' :
                        rec.type === 'exercise' ? 'bg-green-100' :
                        rec.type === 'sleep' ? 'bg-indigo-100' :
                        'bg-purple-100'
                      )}>
                        {rec.type === 'water' && <Droplets className="w-5 h-5 text-cyan-600" />}
                        {rec.type === 'food' && <UtensilsCrossed className="w-5 h-5 text-orange-600" />}
                        {rec.type === 'exercise' && <Dumbbell className="w-5 h-5 text-green-600" />}
                        {rec.type === 'sleep' && <Moon className="w-5 h-5 text-indigo-600" />}
                        {rec.type === 'supplement' && <Pill className="w-5 h-5 text-purple-600" />}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-semibold text-gray-900">{rec.title}</p>
                          {rec.priority === 'high' && (
                            <span className="px-2 py-0.5 bg-red-100 text-red-700 text-xs font-medium rounded-full">
                              <Zap className="w-3 h-3 inline" /> Priority
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-gray-600">{rec.description}</p>
                      </div>
                      {!rec.completed && (
                        <button
                          onClick={() => completeRecommendation(rec.id)}
                          className="p-2 text-primary hover:bg-primary/10 rounded-lg"
                        >
                          <ChevronRight className="w-5 h-5" />
                        </button>
                      )}
                      {rec.completed && <Check className="w-5 h-5 text-green-500" />}
                    </div>
                  </div>
                ))}
              </div>
            )}

            <button
              onClick={fetchAIRecommendations}
              className="w-full py-3 border border-primary text-primary rounded-xl font-medium hover:bg-primary/5"
            >
              Refresh Recommendations
            </button>
          </>
        )}
      </main>

      {/* Log Data Modal */}
      {showLogModal && (
        <div className="fixed inset-0 bg-black/50 flex items-end z-50">
          <div className="bg-white w-full rounded-t-3xl p-6 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">
                {selectedCategory 
                  ? `Log ${healthCategories.find(c => c.id === selectedCategory)?.name} Data` 
                  : 'Log Health Data'}
              </h2>
              <button onClick={() => { setShowLogModal(false); setSelectedCategory(null); setSelectedMetric(null); }} className="p-2 hover:bg-gray-100 rounded-full">
                <X className="w-5 h-5" />
              </button>
            </div>
            {!selectedMetric ? (
              <div className="space-y-4">
                {selectedCategory && (
                  <div className="flex items-center gap-2 mb-4">
                    {(() => {
                      const cat = healthCategories.find(c => c.id === selectedCategory);
                      if (!cat) return null;
                      return (
                        <>
                          <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center', cat.bgColor)}>
                            <cat.icon className={cn('w-5 h-5', cat.color)} />
                          </div>
                          <div>
                            <p className="font-semibold text-gray-900">{cat.name}</p>
                            <p className="text-xs text-gray-500">Select a metric to log</p>
                          </div>
                        </>
                      );
                    })()}
                    <button 
                      onClick={() => setSelectedCategory(null)} 
                      className="ml-auto text-sm text-primary font-medium"
                    >
                      All Categories
                    </button>
                  </div>
                )}
                <div className="grid grid-cols-2 gap-2">
                  {(selectedCategory ? getCategoryMetrics(selectedCategory) : trackableMetrics).map((metric) => (
                    <button key={metric.id} onClick={() => setSelectedMetric(metric.id)} className="p-3 bg-gray-50 hover:bg-primary/10 hover:border-primary rounded-xl text-left border border-transparent transition-all">
                      <div className="flex items-center gap-2 mb-1">
                        <metric.icon className="w-4 h-4 text-gray-500" />
                        <p className="font-medium text-gray-900 text-sm">{metric.name}</p>
                      </div>
                      <p className="text-xs text-gray-500">{metric.unit}</p>
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="text-center">
                  <h3 className="text-lg font-semibold text-gray-900">{getMetricInfo(selectedMetric)?.name}</h3>
                  <p className="text-sm text-gray-500">Enter value in {getMetricInfo(selectedMetric)?.unit}</p>
                </div>
                <input type="number" value={logValue} onChange={(e) => setLogValue(e.target.value)} placeholder="Enter value..." className="w-full text-4xl font-bold text-center py-6 border-2 border-gray-200 rounded-2xl focus:border-primary focus:outline-none" />
                <div className="flex gap-3">
                  <button onClick={() => setSelectedMetric(null)} className="flex-1 py-3 border border-gray-200 rounded-xl font-medium">Back</button>
                  <button onClick={handleLogData} disabled={!logValue} className={cn('flex-1 py-3 rounded-xl font-medium flex items-center justify-center gap-2', logValue ? 'bg-primary text-white' : 'bg-gray-200 text-gray-500')}>
                    <Save className="w-5 h-5" /> Save
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Sync Modal */}
      {showSyncModal && (
        <div className="fixed inset-0 bg-black/50 flex items-end z-50">
          <div className="bg-white w-full rounded-t-3xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Connect Apps</h2>
              <button onClick={() => setShowSyncModal(false)} className="p-2 hover:bg-gray-100 rounded-full"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-3">
              {fitnessApps.map((app) => (
                <button key={app.id} onClick={() => toggleAppConnection(app.id)} className={cn('w-full flex items-center justify-between p-4 rounded-xl border-2', connectedApps.includes(app.id) ? 'border-primary bg-primary/5' : 'border-gray-200')}>
                  <div className="flex items-center gap-4">
                    <div className={cn('w-12 h-12 rounded-xl flex items-center justify-center text-2xl text-white', app.color)}>{app.icon}</div>
                    <span className="font-semibold text-gray-900">{app.name}</span>
                  </div>
                  <div className={cn('w-6 h-6 rounded-full flex items-center justify-center', connectedApps.includes(app.id) ? 'bg-primary' : 'border-2 border-gray-300')}>
                    {connectedApps.includes(app.id) && <Check className="w-4 h-4 text-white" />}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Timer Modal */}
      {showTimerModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Timer</h2>
              <button onClick={() => setShowTimerModal(false)} className="p-2 hover:bg-gray-100 rounded-full"><X className="w-5 h-5" /></button>
            </div>
            <div className="flex bg-gray-100 rounded-xl p-1 mb-6">
              <button onClick={() => setTimerMode('digital')} className={cn('flex-1 py-2 rounded-lg font-medium text-sm', timerMode === 'digital' ? 'bg-white shadow' : 'text-gray-500')}>Digital</button>
              <button onClick={() => setTimerMode('analog')} className={cn('flex-1 py-2 rounded-lg font-medium text-sm', timerMode === 'analog' ? 'bg-white shadow' : 'text-gray-500')}>Analog</button>
            </div>
            <div className="flex items-center justify-center mb-6">
              {timerMode === 'digital' ? (
                <div className="text-6xl font-mono font-bold text-gray-900">{formatTime(timerSeconds)}</div>
              ) : (
                <div className="relative w-48 h-48">
                  <svg viewBox="0 0 100 100" className="w-full h-full">
                    <circle cx="50" cy="50" r="48" fill="none" stroke="#e5e7eb" strokeWidth="2" />
                    <circle cx="50" cy="50" r="48" fill="none" stroke="#14b8a6" strokeWidth="4" strokeLinecap="round" strokeDasharray={`${(timerSeconds / timerInitial) * 301.59} 301.59`} transform="rotate(-90 50 50)" />
                    <text x="50" y="55" textAnchor="middle" className="text-lg font-mono font-bold" fill="#374151">{formatTime(timerSeconds)}</text>
                  </svg>
                </div>
              )}
            </div>
            {!timerRunning && timerSeconds === timerInitial && (
              <div className="flex gap-2 mb-6">
                {[60, 180, 300, 600].map(secs => (
                  <button key={secs} onClick={() => { setTimerSeconds(secs); setTimerInitial(secs); }} className={cn('flex-1 py-2 rounded-lg text-sm font-medium', timerInitial === secs ? 'bg-primary text-white' : 'bg-gray-100')}>
                    {secs / 60}m
                  </button>
                ))}
              </div>
            )}
            <div className="flex gap-3">
              <button onClick={resetTimer} className="flex-1 py-3 border border-gray-200 rounded-xl font-medium flex items-center justify-center gap-2">
                <RotateCcw className="w-5 h-5" /> Reset
              </button>
              <button onClick={() => setTimerRunning(!timerRunning)} className={cn('flex-1 py-3 rounded-xl font-medium flex items-center justify-center gap-2', timerRunning ? 'bg-amber-500 text-white' : 'bg-primary text-white')}>
                {timerRunning ? <><Pause className="w-5 h-5" /> Pause</> : <><Play className="w-5 h-5" /> Start</>}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Food Analysis Modal */}
      {showFoodModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="w-full bg-white rounded-t-3xl p-6 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Food Analysis</h2>
              <button onClick={() => { setShowFoodModal(false); setCapturedImage(null); setAnalyzedFood(null); }} className="p-2 hover:bg-gray-100 rounded-full"><X className="w-5 h-5" /></button>
            </div>
            {capturedImage && <img src={capturedImage} alt="Food" className="w-full h-48 object-cover rounded-xl mb-4" />}
            {isAnalyzing ? (
              <div className="text-center py-8">
                <Loader2 className="w-12 h-12 text-orange-500 animate-spin mx-auto mb-4" />
                <p className="text-gray-700 font-medium">Analyzing your food...</p>
              </div>
            ) : analyzedFood && (
              <div className="space-y-4">
                <div className="bg-orange-50 rounded-xl p-4">
                  <h3 className="font-bold text-lg text-gray-900">{analyzedFood.name}</h3>
                  <p className="text-3xl font-bold text-orange-600 mt-2">{analyzedFood.calories} kcal</p>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-red-50 rounded-xl p-3 text-center">
                    <p className="text-lg font-bold text-red-700">{analyzedFood.protein}g</p>
                    <p className="text-xs text-red-600">Protein</p>
                  </div>
                  <div className="bg-amber-50 rounded-xl p-3 text-center">
                    <p className="text-lg font-bold text-amber-700">{analyzedFood.carbs}g</p>
                    <p className="text-xs text-amber-600">Carbs</p>
                  </div>
                  <div className="bg-blue-50 rounded-xl p-3 text-center">
                    <p className="text-lg font-bold text-blue-700">{analyzedFood.fat}g</p>
                    <p className="text-xs text-blue-600">Fat</p>
                  </div>
                </div>
                {analyzedFood.warnings?.length && (
                  <div className="bg-amber-50 rounded-xl p-4 border border-amber-200">
                    {analyzedFood.warnings.map((w, i) => <p key={i} className="text-sm text-amber-700">⚠️ {w}</p>)}
                  </div>
                )}
                {analyzedFood.suggestions?.length && (
                  <div className="bg-green-50 rounded-xl p-4 border border-green-200">
                    {analyzedFood.suggestions.map((s, i) => <p key={i} className="text-sm text-green-700">✓ {s}</p>)}
                  </div>
                )}
                <button onClick={addAnalyzedFood} className="w-full py-4 bg-orange-600 text-white rounded-xl font-semibold">Add to Today's Log</button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Barcode Scan Modal */}
      {showBarcodeModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="w-full bg-white rounded-t-3xl p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-gray-900">Scan Barcode</h2>
              <button onClick={closeBarcodeModal} className="p-2 hover:bg-gray-100 rounded-full"><X className="w-5 h-5" /></button>
            </div>

            {/* Mode Toggle */}
            {!barcodeProduct && (
              <div className="flex gap-2 mb-4">
                <button
                  onClick={async () => { await stopCameraScanner(); setScanMode('camera'); }}
                  className={cn(
                    'flex-1 py-3 rounded-xl font-medium flex items-center justify-center gap-2',
                    scanMode === 'camera' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'
                  )}
                >
                  <Camera className="w-5 h-5" />
                  Camera Scan
                </button>
                <button
                  onClick={async () => { await stopCameraScanner(); setScanMode('manual'); }}
                  className={cn(
                    'flex-1 py-3 rounded-xl font-medium flex items-center justify-center gap-2',
                    scanMode === 'manual' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'
                  )}
                >
                  <Search className="w-5 h-5" />
                  Manual Entry
                </button>
              </div>
            )}

            {/* Camera Scanner View */}
            {scanMode === 'camera' && !barcodeProduct && (
              <div className="mb-4">
                <div id="barcode-reader" className="w-full rounded-xl overflow-hidden bg-black min-h-[200px]"></div>
                {isCameraScanning && (
                  <p className="text-center text-sm text-gray-500 mt-2">Point camera at barcode...</p>
                )}
                {!isCameraScanning && !barcodeError && (
                  <button
                    onClick={startCameraScanner}
                    className="w-full mt-3 py-3 bg-blue-600 text-white rounded-xl font-medium flex items-center justify-center gap-2"
                  >
                    <Camera className="w-5 h-5" />
                    Start Camera
                  </button>
                )}
              </div>
            )}

            {/* Manual Barcode Input */}
            {scanMode === 'manual' && !barcodeProduct && (
              <div className="mb-4">
                <p className="text-sm text-gray-500 mb-3">Enter the barcode number from your product packaging</p>
                <div className="flex gap-2">
                  <div className="flex-1 relative">
                    <ScanBarcode className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      value={barcodeInput}
                      onChange={(e) => setBarcodeInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && lookupBarcode()}
                      placeholder="e.g., 5000112637922"
                      className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                  <button
                    onClick={() => lookupBarcode()}
                    disabled={!barcodeInput.trim() || isLookingUp}
                    className={cn(
                      'px-4 py-3 rounded-xl font-medium',
                      barcodeInput.trim() && !isLookingUp ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'
                    )}
                  >
                    {isLookingUp ? <Loader2 className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
                  </button>
                </div>
              </div>
            )}

            {/* Loading State */}
            {isLookingUp && (
              <div className="text-center py-8">
                <Loader2 className="w-10 h-10 text-blue-600 animate-spin mx-auto mb-3" />
                <p className="text-gray-600">Looking up product...</p>
              </div>
            )}

            {/* Error Message */}
            {barcodeError && (
              <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-xl">
                <div className="flex items-center gap-2 text-red-700">
                  <AlertTriangle className="w-5 h-5" />
                  <p className="text-sm">{barcodeError}</p>
                </div>
                <button
                  onClick={() => { setBarcodeError(null); setScanMode('manual'); }}
                  className="mt-2 text-sm text-blue-600 font-medium"
                >
                  Try manual entry instead
                </button>
              </div>
            )}

            {/* Product Result */}
            {barcodeProduct && (
              <div className="space-y-4">
                <div className="bg-blue-50 rounded-xl p-4">
                  <div className="flex items-start gap-4">
                    {barcodeProduct.image ? (
                      <img src={barcodeProduct.image} alt="" className="w-20 h-20 object-contain rounded-lg bg-white" />
                    ) : (
                      <div className="w-20 h-20 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Package className="w-10 h-10 text-blue-400" />
                      </div>
                    )}
                    <div className="flex-1">
                      <h3 className="font-bold text-lg text-gray-900">{barcodeProduct.name}</h3>
                      {barcodeProduct.brand && <p className="text-sm text-gray-600">{barcodeProduct.brand}</p>}
                      {barcodeProduct.servingSize && <p className="text-xs text-gray-500 mt-1">Serving: {barcodeProduct.servingSize}</p>}
                      {barcodeProduct.nutritionGrade && (
                        <span className={cn(
                          'inline-block mt-2 px-2 py-0.5 rounded text-xs font-bold text-white',
                          barcodeProduct.nutritionGrade === 'A' ? 'bg-green-500' :
                          barcodeProduct.nutritionGrade === 'B' ? 'bg-lime-500' :
                          barcodeProduct.nutritionGrade === 'C' ? 'bg-yellow-500' :
                          barcodeProduct.nutritionGrade === 'D' ? 'bg-orange-500' : 'bg-red-500'
                        )}>
                          Nutri-Score {barcodeProduct.nutritionGrade}
                        </span>
                      )}
                    </div>
                  </div>
                  <p className="text-3xl font-bold text-blue-600 mt-4">{barcodeProduct.calories} kcal</p>
                </div>
                
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-red-50 rounded-xl p-3 text-center">
                    <p className="text-lg font-bold text-red-700">{barcodeProduct.protein}g</p>
                    <p className="text-xs text-red-600">Protein</p>
                  </div>
                  <div className="bg-amber-50 rounded-xl p-3 text-center">
                    <p className="text-lg font-bold text-amber-700">{barcodeProduct.carbs}g</p>
                    <p className="text-xs text-amber-600">Carbs</p>
                  </div>
                  <div className="bg-blue-50 rounded-xl p-3 text-center">
                    <p className="text-lg font-bold text-blue-700">{barcodeProduct.fat}g</p>
                    <p className="text-xs text-blue-600">Fat</p>
                  </div>
                </div>

                {barcodeProduct.warnings?.length > 0 && (
                  <div className="bg-amber-50 rounded-xl p-4 border border-amber-200">
                    {barcodeProduct.warnings.map((w, i) => <p key={i} className="text-sm text-amber-700">⚠️ {w}</p>)}
                  </div>
                )}
                
                {barcodeProduct.suggestions?.length > 0 && (
                  <div className="bg-green-50 rounded-xl p-4 border border-green-200">
                    {barcodeProduct.suggestions.map((s, i) => <p key={i} className="text-sm text-green-700">✓ {s}</p>)}
                  </div>
                )}

                <button onClick={addBarcodeProduct} className="w-full py-4 bg-blue-600 text-white rounded-xl font-semibold">
                  Add to Today's Log
                </button>
              </div>
            )}

            {/* Instructions when no product */}
            {!barcodeProduct && !barcodeError && !isLookingUp && (
              <div className="text-center py-8 text-gray-500">
                <ScanBarcode className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <p className="text-sm">Enter a barcode to lookup nutrition info</p>
                <p className="text-xs mt-2">Works with most packaged foods worldwide</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Add Supplement Modal */}
      {showSupplementModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="w-full bg-white rounded-t-3xl p-6 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Add Supplement</h2>
              <button onClick={() => setShowSupplementModal(false)} className="p-2 hover:bg-gray-100 rounded-full"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-2">
              {commonSupplements.map(supp => (
                <button
                  key={supp.id}
                  onClick={() => addSupplement(supp)}
                  disabled={!!mySupplements.find(s => s.id === supp.id)}
                  className={cn(
                    'w-full flex items-center gap-4 p-4 rounded-xl border text-left',
                    mySupplements.find(s => s.id === supp.id) ? 'border-gray-100 bg-gray-50 opacity-50' : 'border-gray-200 hover:border-primary'
                  )}
                >
                  <span className="text-2xl">{supp.icon}</span>
                  <div className="flex-1">
                    <p className="font-semibold text-gray-900">{supp.name}</p>
                    <p className="text-sm text-gray-500">{supp.dosage} • {supp.benefits}</p>
                  </div>
                  {mySupplements.find(s => s.id === supp.id) ? (
                    <Check className="w-5 h-5 text-green-500" />
                  ) : (
                    <Plus className="w-5 h-5 text-primary" />
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Custom Supplement Modal */}
      {showCustomSupplementModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="w-full bg-white rounded-t-3xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Add Custom Supplement</h2>
              <button onClick={() => setShowCustomSupplementModal(false)} className="p-2 hover:bg-gray-100 rounded-full"><X className="w-5 h-5" /></button>
            </div>
            
            {/* Icon Picker */}
            <div className="mb-4">
              <label className="text-sm font-medium text-gray-700 mb-2 block">Icon</label>
              <div className="flex gap-2 flex-wrap">
                {['💊', '🔶', '💧', '🧪', '🌿', '⚡', '🦴', '❤️', '🧠', '💪'].map(emoji => (
                  <button
                    key={emoji}
                    onClick={() => setCustomSupplement(prev => ({ ...prev, icon: emoji }))}
                    className={cn(
                      'w-12 h-12 text-2xl rounded-xl border-2 flex items-center justify-center',
                      customSupplement.icon === emoji ? 'border-primary bg-primary/10' : 'border-gray-200'
                    )}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>

            {/* Supplement Name */}
            <div className="mb-4">
              <label className="text-sm font-medium text-gray-700 mb-2 block">Supplement Name</label>
              <input
                type="text"
                value={customSupplement.name}
                onChange={(e) => setCustomSupplement(prev => ({ ...prev, name: e.target.value }))}
                placeholder="e.g., Vitamin D3, Omega-3"
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
            </div>

            {/* Dosage with Unit */}
            <div className="mb-6">
              <label className="text-sm font-medium text-gray-700 mb-2 block">Dosage</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  value={customSupplement.dosage}
                  onChange={(e) => setCustomSupplement(prev => ({ ...prev, dosage: e.target.value }))}
                  placeholder="Amount"
                  className="flex-1 px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary"
                />
                <select
                  value={customSupplement.unit}
                  onChange={(e) => setCustomSupplement(prev => ({ ...prev, unit: e.target.value as typeof customSupplement.unit }))}
                  className="px-4 py-3 border border-gray-200 rounded-xl bg-white focus:ring-2 focus:ring-primary/20 focus:border-primary"
                >
                  <option value="mg">mg</option>
                  <option value="mcg">mcg (μg)</option>
                  <option value="g">g</option>
                  <option value="IU">IU</option>
                  <option value="CFU">CFU (Billions)</option>
                </select>
              </div>
              <p className="text-xs text-gray-500 mt-2">
                Common: mg (milligrams), mcg (micrograms), IU (International Units), CFU (for probiotics)
              </p>
            </div>

            <button
              onClick={addCustomSupplement}
              disabled={!customSupplement.name || !customSupplement.dosage}
              className="w-full py-4 bg-primary text-white rounded-xl font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Add Supplement
            </button>
          </div>
        </div>
      )}

      {/* AI Supplement Recommendations Modal */}
      {showAISupplementModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="w-full bg-white rounded-t-3xl p-6 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-violet-500 to-purple-600 rounded-xl flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900">AI Recommendations</h2>
                  <p className="text-xs text-gray-500">Personalized for your health goals</p>
                </div>
              </div>
              <button onClick={() => setShowAISupplementModal(false)} className="p-2 hover:bg-gray-100 rounded-full"><X className="w-5 h-5" /></button>
            </div>
            
            {loadingSupplementAI ? (
              <div className="text-center py-12">
                <Loader2 className="w-12 h-12 text-violet-500 animate-spin mx-auto mb-4" />
                <p className="text-gray-700 font-medium">Analyzing your health profile...</p>
                <p className="text-sm text-gray-500 mt-1">Finding the best supplements for you</p>
              </div>
            ) : (
              <div className="space-y-3">
                {aiSupplementRecs.map((rec, index) => (
                  <div
                    key={index}
                    className={cn(
                      'p-4 rounded-2xl border-2',
                      rec.priority === 'high' ? 'border-green-200 bg-green-50' :
                      rec.priority === 'medium' ? 'border-amber-200 bg-amber-50' :
                      'border-gray-200 bg-gray-50'
                    )}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-gray-900">{rec.name}</span>
                          <span className={cn(
                            'text-xs px-2 py-0.5 rounded-full font-medium',
                            rec.priority === 'high' ? 'bg-green-200 text-green-800' :
                            rec.priority === 'medium' ? 'bg-amber-200 text-amber-800' :
                            'bg-gray-200 text-gray-700'
                          )}>
                            {rec.priority} priority
                          </span>
                        </div>
                        <p className="text-sm font-semibold text-primary mt-1">{rec.dosage}</p>
                        <p className="text-sm text-gray-600 mt-2">{rec.reason}</p>
                      </div>
                      <button
                        onClick={() => {
                          const newSupp = {
                            id: `ai_${Date.now()}_${index}`,
                            name: rec.name,
                            dosage: rec.dosage,
                            icon: '💊',
                            takenToday: false
                          };
                          if (!mySupplements.find(s => s.name.toLowerCase() === rec.name.toLowerCase())) {
                            setMySupplements(prev => [...prev, newSupp]);
                          }
                        }}
                        disabled={mySupplements.some(s => s.name.toLowerCase() === rec.name.toLowerCase())}
                        className={cn(
                          'ml-3 p-2 rounded-xl',
                          mySupplements.some(s => s.name.toLowerCase() === rec.name.toLowerCase())
                            ? 'bg-green-100 text-green-600'
                            : 'bg-violet-100 text-violet-600 hover:bg-violet-200'
                        )}
                      >
                        {mySupplements.some(s => s.name.toLowerCase() === rec.name.toLowerCase()) ? (
                          <Check className="w-5 h-5" />
                        ) : (
                          <Plus className="w-5 h-5" />
                        )}
                      </button>
                    </div>
                  </div>
                ))}

                <div className="mt-6 p-4 bg-violet-50 rounded-xl">
                  <p className="text-sm text-violet-800">
                    <span className="font-semibold">⚠️ Disclaimer:</span> These AI recommendations are for informational purposes only. 
                    Always consult with a healthcare provider before starting any new supplement regimen.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
