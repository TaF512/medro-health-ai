import { useState } from 'react';
import { Link } from 'react-router';
import { 
  ArrowLeft, 
  Pill, 
  FlaskConical, 
  Stethoscope, 
  Clock,
  Calendar,
  ChevronRight,
  Bell,
  CheckCircle2
} from 'lucide-react';
import BottomNav from '@/react-app/components/BottomNav';

type ReminderType = 'all' | 'medication' | 'test' | 'appointment';

interface Reminder {
  id: number;
  title: string;
  subtitle?: string;
  time: string;
  date: string;
  type: 'medication' | 'test' | 'appointment';
  link: string;
  completed?: boolean;
}

const allReminders: Reminder[] = [
  // Today
  { id: 1, title: 'Metformin 500mg', subtitle: 'Take with breakfast', time: '8:00 AM', date: 'Today', type: 'medication', link: '/medications' },
  { id: 2, title: 'Lisinopril 10mg', subtitle: 'Blood pressure medication', time: '9:00 AM', date: 'Today', type: 'medication', link: '/medications', completed: true },
  { id: 3, title: 'Vitamin D3', subtitle: '1000 IU supplement', time: '1:00 PM', date: 'Today', type: 'medication', link: '/medications' },
  { id: 4, title: 'Metformin 500mg', subtitle: 'Evening dose', time: '8:00 PM', date: 'Today', type: 'medication', link: '/medications' },
  
  // Tomorrow
  { id: 5, title: 'Blood Test - Lipid Profile', subtitle: 'Fasting required', time: '7:00 AM', date: 'Tomorrow', type: 'test', link: '/appointments' },
  { id: 6, title: 'Metformin 500mg', subtitle: 'Take with breakfast', time: '8:00 AM', date: 'Tomorrow', type: 'medication', link: '/medications' },
  
  // This Week
  { id: 7, title: 'Dr. Sarah Ahmed - Follow-up', subtitle: 'Video consultation', time: '3:00 PM', date: 'Dec 15', type: 'appointment', link: '/appointments' },
  { id: 8, title: 'HbA1c Test', subtitle: 'Diabetes monitoring', time: '10:00 AM', date: 'Dec 16', type: 'test', link: '/appointments' },
  { id: 9, title: 'Dr. James Wilson - Cardiology', subtitle: 'In-person visit', time: '11:30 AM', date: 'Dec 18', type: 'appointment', link: '/appointments' },
  
  // Next Week
  { id: 10, title: 'Thyroid Panel', subtitle: 'Annual checkup', time: '8:30 AM', date: 'Dec 22', type: 'test', link: '/appointments' },
  { id: 11, title: 'Dr. Emily Chen - Dermatology', subtitle: 'Skin consultation', time: '2:00 PM', date: 'Dec 23', type: 'appointment', link: '/appointments' },
];

const filterTabs: { label: string; value: ReminderType }[] = [
  { label: 'All', value: 'all' },
  { label: 'Medications', value: 'medication' },
  { label: 'Tests', value: 'test' },
  { label: 'Appointments', value: 'appointment' },
];

export default function UpcomingPage() {
  const [filter, setFilter] = useState<ReminderType>('all');

  const filteredReminders = filter === 'all' 
    ? allReminders 
    : allReminders.filter(r => r.type === filter);

  // Group by date
  const groupedReminders = filteredReminders.reduce((groups, reminder) => {
    const date = reminder.date;
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(reminder);
    return groups;
  }, {} as Record<string, Reminder[]>);

  const getIcon = (type: string) => {
    switch (type) {
      case 'medication': return Pill;
      case 'test': return FlaskConical;
      case 'appointment': return Stethoscope;
      default: return Bell;
    }
  };

  const getIconColors = (type: string) => {
    switch (type) {
      case 'medication': return { bg: 'bg-rose-100', text: 'text-rose-600' };
      case 'test': return { bg: 'bg-orange-100', text: 'text-orange-600' };
      case 'appointment': return { bg: 'bg-primary/10', text: 'text-primary' };
      default: return { bg: 'bg-gray-100', text: 'text-gray-600' };
    }
  };

  const counts = {
    all: allReminders.length,
    medication: allReminders.filter(r => r.type === 'medication').length,
    test: allReminders.filter(r => r.type === 'test').length,
    appointment: allReminders.filter(r => r.type === 'appointment').length,
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="px-4 py-4 flex items-center gap-3">
          <Link to="/" className="p-2 -ml-2 hover:bg-gray-100 rounded-full">
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </Link>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-gray-900">Upcoming</h1>
            <p className="text-sm text-gray-500">Your schedule at a glance</p>
          </div>
          <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
            <Calendar className="w-5 h-5 text-primary" />
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="px-4 pb-3 flex gap-2 overflow-x-auto">
          {filterTabs.map(tab => (
            <button
              key={tab.value}
              onClick={() => setFilter(tab.value)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors flex items-center gap-2 ${
                filter === tab.value
                  ? 'bg-primary text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {tab.label}
              <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                filter === tab.value ? 'bg-white/20' : 'bg-gray-200'
              }`}>
                {counts[tab.value]}
              </span>
            </button>
          ))}
        </div>
      </header>

      <main className="px-4 py-4 max-w-lg mx-auto space-y-4">
        {Object.entries(groupedReminders).map(([date, reminders]) => (
          <section key={date}>
            <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-2 flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              {date}
            </h2>
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm divide-y divide-gray-100">
              {reminders.map(reminder => {
                const Icon = getIcon(reminder.type);
                const colors = getIconColors(reminder.type);
                
                return (
                  <Link
                    key={reminder.id}
                    to={reminder.link}
                    className={`flex items-center gap-3 p-4 hover:bg-gray-50 transition-colors ${
                      reminder.completed ? 'opacity-60' : ''
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${colors.bg}`}>
                      {reminder.completed ? (
                        <CheckCircle2 className="w-6 h-6 text-green-600" />
                      ) : (
                        <Icon className={`w-6 h-6 ${colors.text}`} />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`font-medium text-gray-900 ${reminder.completed ? 'line-through' : ''}`}>
                        {reminder.title}
                      </p>
                      {reminder.subtitle && (
                        <p className="text-sm text-gray-500 truncate">{reminder.subtitle}</p>
                      )}
                      <p className="text-sm text-gray-400 flex items-center gap-1 mt-1">
                        <Clock className="w-3.5 h-3.5" />
                        {reminder.time}
                      </p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-400 flex-shrink-0" />
                  </Link>
                );
              })}
            </div>
          </section>
        ))}

        {filteredReminders.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Bell className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-500">No upcoming {filter === 'all' ? 'reminders' : filter + 's'}</p>
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
}
