import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Calendar, Flame, Search, ChevronLeft, ChevronRight } from 'lucide-react';

interface MealEntry {
  id: string;
  name: string;
  type: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  time: string;
  date: string;
  emoji: string;
}

const mealHistory: MealEntry[] = [
  { id: '1', name: 'Oatmeal with berries', type: 'breakfast', calories: 420, protein: 12, carbs: 65, fat: 8, time: '8:30 AM', date: '2024-01-15', emoji: '🥣' },
  { id: '2', name: 'Grilled chicken salad', type: 'lunch', calories: 580, protein: 45, carbs: 25, fat: 18, time: '1:15 PM', date: '2024-01-15', emoji: '🥗' },
  { id: '3', name: 'Apple with peanut butter', type: 'snack', calories: 250, protein: 6, carbs: 30, fat: 12, time: '4:00 PM', date: '2024-01-15', emoji: '🍎' },
  { id: '4', name: 'Salmon with vegetables', type: 'dinner', calories: 620, protein: 42, carbs: 35, fat: 28, time: '7:30 PM', date: '2024-01-15', emoji: '🐟' },
  { id: '5', name: 'Greek yogurt parfait', type: 'breakfast', calories: 380, protein: 18, carbs: 45, fat: 12, time: '8:00 AM', date: '2024-01-14', emoji: '🥛' },
  { id: '6', name: 'Turkey sandwich', type: 'lunch', calories: 520, protein: 32, carbs: 55, fat: 16, time: '12:30 PM', date: '2024-01-14', emoji: '🥪' },
  { id: '7', name: 'Mixed nuts', type: 'snack', calories: 180, protein: 5, carbs: 8, fat: 16, time: '3:30 PM', date: '2024-01-14', emoji: '🥜' },
  { id: '8', name: 'Pasta with meat sauce', type: 'dinner', calories: 750, protein: 35, carbs: 85, fat: 25, time: '8:00 PM', date: '2024-01-14', emoji: '🍝' },
];

const typeColors = {
  breakfast: 'from-orange-400 to-amber-500',
  lunch: 'from-green-400 to-emerald-500',
  dinner: 'from-blue-400 to-indigo-500',
  snack: 'from-purple-400 to-pink-500',
};

export default function FoodHistory() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [currentWeekStart, setCurrentWeekStart] = useState(() => {
    const today = new Date();
    const dayOfWeek = today.getDay();
    const diff = today.getDate() - dayOfWeek;
    return new Date(today.setDate(diff));
  });

  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const date = new Date(currentWeekStart);
    date.setDate(date.getDate() + i);
    return date;
  });

  const filteredMeals = mealHistory.filter(meal => {
    const matchesSearch = meal.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDate = !selectedDate || meal.date === selectedDate;
    return matchesSearch && matchesDate;
  });

  const groupedMeals = filteredMeals.reduce((acc, meal) => {
    if (!acc[meal.date]) acc[meal.date] = [];
    acc[meal.date].push(meal);
    return acc;
  }, {} as Record<string, MealEntry[]>);

  const getDayCalories = (date: string) => {
    return mealHistory.filter(m => m.date === date).reduce((sum, m) => sum + m.calories, 0);
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (dateStr === today.toISOString().split('T')[0]) return 'Today';
    if (dateStr === yesterday.toISOString().split('T')[0]) return 'Yesterday';
    return date.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-white pb-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-600 text-white px-4 py-4 pb-6">
        <div className="flex items-center gap-3 mb-2">
          <button onClick={() => navigate('/tracker')} className="p-2 hover:bg-white/20 rounded-full transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-bold">Food History</h1>
        </div>
        <p className="text-amber-100 text-sm ml-10">Track your eating patterns</p>
      </div>

      <main className="px-4 -mt-3 max-w-lg mx-auto">
        {/* Week Calendar */}
        <div className="bg-white rounded-2xl shadow-lg p-4 mb-4">
          <div className="flex items-center justify-between mb-3">
            <button 
              onClick={() => {
                const newDate = new Date(currentWeekStart);
                newDate.setDate(newDate.getDate() - 7);
                setCurrentWeekStart(newDate);
              }}
              className="p-2 hover:bg-gray-100 rounded-full"
            >
              <ChevronLeft className="w-5 h-5 text-gray-600" />
            </button>
            <span className="font-medium text-gray-700">
              {currentWeekStart.toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
            </span>
            <button 
              onClick={() => {
                const newDate = new Date(currentWeekStart);
                newDate.setDate(newDate.getDate() + 7);
                setCurrentWeekStart(newDate);
              }}
              className="p-2 hover:bg-gray-100 rounded-full"
            >
              <ChevronRight className="w-5 h-5 text-gray-600" />
            </button>
          </div>
          <div className="grid grid-cols-7 gap-1">
            {weekDays.map((day, i) => {
              const dateStr = day.toISOString().split('T')[0];
              const dayCalories = getDayCalories(dateStr);
              const isSelected = selectedDate === dateStr;
              const isToday = dateStr === new Date().toISOString().split('T')[0];

              return (
                <button
                  key={i}
                  onClick={() => setSelectedDate(isSelected ? null : dateStr)}
                  className={`flex flex-col items-center p-2 rounded-xl transition-all ${
                    isSelected ? 'bg-amber-500 text-white' :
                    isToday ? 'bg-amber-100 text-amber-700' :
                    'hover:bg-gray-100'
                  }`}
                >
                  <span className="text-xs font-medium mb-1">
                    {day.toLocaleDateString('en-US', { weekday: 'short' }).slice(0, 2)}
                  </span>
                  <span className="text-lg font-bold">{day.getDate()}</span>
                  {dayCalories > 0 && (
                    <span className={`text-xs mt-1 ${isSelected ? 'text-white/80' : 'text-gray-500'}`}>
                      {dayCalories}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search meals..."
            className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent"
          />
        </div>

        {/* Meals List */}
        {Object.keys(groupedMeals).length > 0 ? (
          Object.entries(groupedMeals).sort((a, b) => b[0].localeCompare(a[0])).map(([date, meals]) => (
            <div key={date} className="mb-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-gray-900">{formatDate(date)}</h3>
                <div className="flex items-center gap-1 text-sm text-gray-500">
                  <Flame className="w-4 h-4 text-orange-500" />
                  <span>{meals.reduce((sum, m) => sum + m.calories, 0)} kcal</span>
                </div>
              </div>
              <div className="space-y-3">
                {meals.map(meal => (
                  <div key={meal.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-12 h-12 bg-gradient-to-br ${typeColors[meal.type]} rounded-xl flex items-center justify-center text-white text-lg`}>
                        {meal.emoji}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">{meal.name}</p>
                        <p className="text-xs text-gray-500 capitalize">{meal.type} • {meal.time}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-gray-900">{meal.calories}</p>
                        <p className="text-xs text-gray-500">kcal</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 mt-3 pt-3 border-t border-gray-100 text-xs text-gray-500">
                      <span>P: {meal.protein}g</span>
                      <span>C: {meal.carbs}g</span>
                      <span>F: {meal.fat}g</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-12 bg-white rounded-2xl">
            <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">No meals found</p>
            <p className="text-sm text-gray-400">Try a different date or search</p>
          </div>
        )}
      </main>
    </div>
  );
}
