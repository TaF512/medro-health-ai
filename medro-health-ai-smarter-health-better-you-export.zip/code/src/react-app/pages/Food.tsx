import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { 
  Camera, 
  Search, 
  ScanBarcode, 
  History, 
  Star, 
  Settings,
  Apple,
  ChevronRight,
  Flame,
  Target,
  TrendingUp,
  ArrowLeft
} from 'lucide-react';
import BottomNav from '@/react-app/components/BottomNav';

interface DailyStats {
  consumed: number;
  goal: number;
  burned: number;
  protein: number;
  carbs: number;
  fat: number;
}

export default function Food() {
  const navigate = useNavigate();
  const [stats] = useState<DailyStats>({
    consumed: 1250,
    goal: 2000,
    burned: 320,
    protein: 65,
    carbs: 140,
    fat: 45
  });

  const remaining = stats.goal - stats.consumed + stats.burned;
  const progressPercent = Math.min((stats.consumed / stats.goal) * 100, 100);

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 to-white pb-24">
      {/* Header with back button */}
      <div className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-4 py-4">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/')} className="p-2 hover:bg-white/20 rounded-full transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-bold">Food Tracker</h1>
        </div>
      </div>
      
      <main className="px-4 pt-4 max-w-lg mx-auto">
        {/* Today's Summary Card */}
        <div className="bg-white rounded-2xl shadow-lg p-5 mb-6 border border-emerald-100">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-900">Today's Nutrition</h2>
            <span className="text-xs text-gray-500">{new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</span>
          </div>
          
          {/* Calorie Ring */}
          <div className="flex items-center gap-6 mb-4">
            <div className="relative w-28 h-28">
              <svg className="w-28 h-28 transform -rotate-90">
                <circle
                  cx="56"
                  cy="56"
                  r="48"
                  stroke="#e5e7eb"
                  strokeWidth="10"
                  fill="none"
                />
                <circle
                  cx="56"
                  cy="56"
                  r="48"
                  stroke="url(#calorieGradient)"
                  strokeWidth="10"
                  fill="none"
                  strokeLinecap="round"
                  strokeDasharray={`${progressPercent * 3.02} 302`}
                />
                <defs>
                  <linearGradient id="calorieGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#10b981" />
                    <stop offset="100%" stopColor="#059669" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-2xl font-bold text-gray-900">{remaining}</span>
                <span className="text-xs text-gray-500">remaining</span>
              </div>
            </div>
            
            <div className="flex-1 space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center">
                  <Apple className="w-4 h-4 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">{stats.consumed}</p>
                  <p className="text-xs text-gray-500">Consumed</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center">
                  <Flame className="w-4 h-4 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">{stats.burned}</p>
                  <p className="text-xs text-gray-500">Burned</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                  <Target className="w-4 h-4 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">{stats.goal}</p>
                  <p className="text-xs text-gray-500">Goal</p>
                </div>
              </div>
            </div>
          </div>

          {/* Macros */}
          <div className="grid grid-cols-3 gap-3 pt-3 border-t border-gray-100">
            <div className="text-center">
              <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden mb-1">
                <div className="h-full bg-red-500 rounded-full" style={{ width: `${(stats.protein / 150) * 100}%` }} />
              </div>
              <p className="text-sm font-semibold text-gray-900">{stats.protein}g</p>
              <p className="text-xs text-gray-500">Protein</p>
            </div>
            <div className="text-center">
              <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden mb-1">
                <div className="h-full bg-amber-500 rounded-full" style={{ width: `${(stats.carbs / 250) * 100}%` }} />
              </div>
              <p className="text-sm font-semibold text-gray-900">{stats.carbs}g</p>
              <p className="text-xs text-gray-500">Carbs</p>
            </div>
            <div className="text-center">
              <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden mb-1">
                <div className="h-full bg-blue-500 rounded-full" style={{ width: `${(stats.fat / 65) * 100}%` }} />
              </div>
              <p className="text-sm font-semibold text-gray-900">{stats.fat}g</p>
              <p className="text-xs text-gray-500">Fat</p>
            </div>
          </div>
        </div>

        {/* Main Entry Methods */}
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Log Your Food</h3>
        <div className="grid grid-cols-1 gap-3 mb-6">
          <Link to="/food/scan" className="group">
            <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl p-5 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02]">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                  <Camera className="w-7 h-7 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="text-lg font-bold text-white">Scan Photo</h4>
                  <p className="text-emerald-100 text-sm">AI-powered instant calorie recognition</p>
                </div>
                <ChevronRight className="w-5 h-5 text-white/70 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </Link>

          <Link to="/food/manual" className="group">
            <div className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl p-5 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02]">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                  <Search className="w-7 h-7 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="text-lg font-bold text-white">Manual Log</h4>
                  <p className="text-blue-100 text-sm">Search foods or create custom entries</p>
                </div>
                <ChevronRight className="w-5 h-5 text-white/70 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </Link>

          <Link to="/food/barcode" className="group">
            <div className="bg-gradient-to-r from-purple-500 to-pink-600 rounded-2xl p-5 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02]">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                  <ScanBarcode className="w-7 h-7 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="text-lg font-bold text-white">Barcode</h4>
                  <p className="text-purple-100 text-sm">Scan or enter product barcodes</p>
                </div>
                <ChevronRight className="w-5 h-5 text-white/70 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </Link>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <Link to="/food/history" className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-shadow text-center">
            <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <History className="w-5 h-5 text-amber-600" />
            </div>
            <span className="text-xs font-medium text-gray-700">History</span>
          </Link>
          <Link to="/food/favorites" className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-shadow text-center">
            <div className="w-10 h-10 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <Star className="w-5 h-5 text-rose-600" />
            </div>
            <span className="text-xs font-medium text-gray-700">Favorites</span>
          </Link>
          <Link to="/food/settings" className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-shadow text-center">
            <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <Settings className="w-5 h-5 text-gray-600" />
            </div>
            <span className="text-xs font-medium text-gray-700">Settings</span>
          </Link>
        </div>

        {/* Recent Meals */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-gray-900">Recent Meals</h3>
            <Link to="/food/history" className="text-sm text-primary font-medium flex items-center gap-1">
              View All <TrendingUp className="w-3 h-3" />
            </Link>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
              <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-amber-500 rounded-xl flex items-center justify-center text-white text-lg">
                🍳
              </div>
              <div className="flex-1">
                <p className="font-medium text-gray-900">Breakfast</p>
                <p className="text-xs text-gray-500">Oatmeal with berries • 8:30 AM</p>
              </div>
              <div className="text-right">
                <p className="font-semibold text-gray-900">420</p>
                <p className="text-xs text-gray-500">kcal</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
              <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-emerald-500 rounded-xl flex items-center justify-center text-white text-lg">
                🥗
              </div>
              <div className="flex-1">
                <p className="font-medium text-gray-900">Lunch</p>
                <p className="text-xs text-gray-500">Grilled chicken salad • 1:15 PM</p>
              </div>
              <div className="text-right">
                <p className="font-semibold text-gray-900">580</p>
                <p className="text-xs text-gray-500">kcal</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-pink-500 rounded-xl flex items-center justify-center text-white text-lg">
                🍎
              </div>
              <div className="flex-1">
                <p className="font-medium text-gray-900">Snack</p>
                <p className="text-xs text-gray-500">Apple with peanut butter • 4:00 PM</p>
              </div>
              <div className="text-right">
                <p className="font-semibold text-gray-900">250</p>
                <p className="text-xs text-gray-500">kcal</p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <BottomNav />
    </div>
  );
}
