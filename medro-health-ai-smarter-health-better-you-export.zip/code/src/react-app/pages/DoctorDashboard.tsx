import { Calendar, MessageSquare, Users, Clock, TrendingUp, LogOut, Bell, LogIn, X, User } from 'lucide-react';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { useNavigate } from 'react-router';
import { useState } from 'react';

export default function DoctorDashboardPage() {
  const { user, isGuest, logout, exitGuestMode } = useAuth();
  const navigate = useNavigate();
  const [showBanner, setShowBanner] = useState(true);

  const handleLogout = async () => {
    if (isGuest) {
      exitGuestMode();
    } else {
      await logout();
    }
    navigate('/login');
  };

  const stats = [
    { label: 'Today\'s Appointments', value: '8', icon: Calendar, color: 'bg-blue-100 text-blue-600', to: '/doctor/schedule' },
    { label: 'Pending Messages', value: '12', icon: MessageSquare, color: 'bg-teal-100 text-teal-600', to: '/doctor/messages' },
    { label: 'Total Patients', value: '156', icon: Users, color: 'bg-purple-100 text-purple-600', to: '/doctor/patients' },
    { label: 'Avg. Consult Time', value: '15m', icon: Clock, color: 'bg-amber-100 text-amber-600', to: '/doctor/analytics' },
  ];

  const upcomingAppointments = [
    { id: 1, patient: 'Sarah Ahmed', time: '10:00 AM', type: 'Video Call', status: 'confirmed' },
    { id: 2, patient: 'Rahim Khan', time: '11:30 AM', type: 'In-person', status: 'confirmed' },
    { id: 3, patient: 'Fatima Begum', time: '2:00 PM', type: 'Video Call', status: 'pending' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-100 px-4 py-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            {isGuest ? (
              <div className="w-10 h-10 bg-indigo-500 rounded-full flex items-center justify-center text-white font-medium">
                D
              </div>
            ) : user?.avatar ? (
              <img src={user.avatar} alt="" className="w-10 h-10 rounded-full" />
            ) : (
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-white font-medium">
                {user?.name?.charAt(0) || 'D'}
              </div>
            )}
            <div>
              <h1 className="font-semibold text-gray-900">
                {isGuest ? 'Dr. Guest' : `Dr. ${user?.name || 'Doctor'}`}
              </h1>
              <p className="text-sm text-gray-500">
                {isGuest ? 'Exploring Doctor Portal' : 'Good morning!'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="p-2 rounded-full hover:bg-gray-100 transition-colors relative">
              <Bell className="w-5 h-5 text-gray-600" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
            </button>
            <button
              onClick={handleLogout}
              className="p-2 rounded-full hover:bg-gray-100 transition-colors"
            >
              <LogOut className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>
      </header>

      <main className="px-4 py-6 max-w-4xl mx-auto space-y-6">
        {/* Guest Banner */}
        {isGuest && showBanner && (
          <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl p-4 text-white relative">
            <button 
              onClick={() => setShowBanner(false)}
              className="absolute top-2 right-2 p-1 rounded-full hover:bg-white/20 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
            <h3 className="font-semibold mb-1">You're exploring as a guest doctor</h3>
            <p className="text-sm text-white/90 mb-3">
              Sign up to manage real appointments, connect with patients, and grow your practice.
            </p>
            <button
              onClick={() => navigate('/login')}
              className="flex items-center gap-2 px-4 py-2 bg-white text-indigo-600 font-medium rounded-lg hover:bg-white/90 transition-colors"
            >
              <LogIn className="w-4 h-4" />
              <span>Create Doctor Account</span>
            </button>
          </div>
        )}
        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          {stats.map((stat) => (
            <button
              key={stat.label}
              onClick={() => navigate(stat.to)}
              className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm text-left hover:border-primary/30 hover:shadow-md transition-all"
            >
              <div className={`w-10 h-10 rounded-xl ${stat.color} flex items-center justify-center mb-3`}>
                <stat.icon className="w-5 h-5" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              <p className="text-sm text-gray-500">{stat.label}</p>
            </button>
          ))}
        </div>

        {/* Upcoming Appointments */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-900">Today's Appointments</h2>
            <button className="text-sm text-primary font-medium">View All</button>
          </div>

          <div className="space-y-3">
            {upcomingAppointments.map((apt) => (
              <div key={apt.id} className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center text-lg font-medium text-gray-600">
                    {apt.patient.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">{apt.patient}</h3>
                    <p className="text-sm text-gray-500">{apt.time} • {apt.type}</p>
                  </div>
                </div>
                <button className="px-4 py-2 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors">
                  Start
                </button>
              </div>
            ))}
          </div>
        </section>

        {/* Quick Actions */}
        <section>
          <h2 className="text-lg font-bold text-gray-900 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-3 gap-3">
            <button 
              onClick={() => navigate('/doctor/schedule')}
              className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm text-center hover:border-primary transition-colors"
            >
              <Calendar className="w-6 h-6 text-primary mx-auto mb-2" />
              <span className="text-sm font-medium text-gray-700">Schedule</span>
            </button>
            <button 
              onClick={() => navigate('/doctor/messages')}
              className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm text-center hover:border-primary transition-colors"
            >
              <MessageSquare className="w-6 h-6 text-primary mx-auto mb-2" />
              <span className="text-sm font-medium text-gray-700">Messages</span>
            </button>
            <button 
              onClick={() => navigate('/doctor/analytics')}
              className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm text-center hover:border-primary transition-colors"
            >
              <TrendingUp className="w-6 h-6 text-primary mx-auto mb-2" />
              <span className="text-sm font-medium text-gray-700">Analytics</span>
            </button>
          </div>
        </section>
      </main>

      {/* Doctor Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2 z-50">
        <div className="max-w-lg mx-auto flex justify-around">
          <button 
            onClick={() => navigate('/doctor/dashboard')}
            className="flex flex-col items-center gap-1 py-2 px-4 text-primary"
          >
            <Calendar className="w-5 h-5" />
            <span className="text-xs font-medium">Dashboard</span>
          </button>
          <button 
            onClick={() => navigate('/doctor/patients')}
            className="flex flex-col items-center gap-1 py-2 px-4 text-gray-400 hover:text-primary transition-colors"
          >
            <Users className="w-5 h-5" />
            <span className="text-xs font-medium">Patients</span>
          </button>
          <button 
            onClick={() => navigate('/doctor/messages')}
            className="flex flex-col items-center gap-1 py-2 px-4 text-gray-400 hover:text-primary transition-colors"
          >
            <MessageSquare className="w-5 h-5" />
            <span className="text-xs font-medium">Messages</span>
          </button>
          <button 
            onClick={() => navigate('/doctor/profile')}
            className="flex flex-col items-center gap-1 py-2 px-4 text-gray-400 hover:text-primary transition-colors"
          >
            <User className="w-5 h-5" />
            <span className="text-xs font-medium">Profile</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
