import { useState } from 'react';
import { useNavigate } from 'react-router';
import { 
  Search, 
  ArrowLeft,
  Pill,
  AlertTriangle,
  Sparkles,
  Loader2,
  ThumbsUp,
  ThumbsDown,
  Clock,
  AlertCircle,
  Leaf,
  ChevronDown,
  ChevronUp,
  Info,
  Shield
} from 'lucide-react';

import BottomNav from '@/react-app/components/BottomNav';

const popularMedications = [
  'Paracetamol',
  'Ibuprofen',
  'Aspirin',
  'Amoxicillin',
  'Metformin',
  'Omeprazole',
  'Cetirizine',
  'Lisinopril',
  'Atorvastatin',
  'Levothyroxine',
  'Amlodipine',
  'Losartan'
];

interface MedicationInfo {
  name: string;
  brandNames: string[];
  drugClass: string;
  description: string;
  uses: string[];
  benefits: string[];
  sideEffects: {
    common: string[];
    serious: string[];
  };
  longTermEffects: string[];
  dosageInfo: string;
  interactions: string[];
  precautions: string[];
  naturalAlternatives: string[];
  disclaimer: string;
}

export default function MedicationEncyclopediaPage() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [medication, setMedication] = useState<MedicationInfo | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [expandedSections, setExpandedSections] = useState<string[]>(['benefits', 'sideEffects', 'longTerm']);

  const toggleSection = (section: string) => {
    setExpandedSections(prev =>
      prev.includes(section)
        ? prev.filter(s => s !== section)
        : [...prev, section]
    );
  };

  const handleSearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) return;
    
    setQuery(searchQuery);
    setIsLoading(true);
    setError(null);
    setHasSearched(true);

    try {
      const response = await fetch('/api/medication-info', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ medication: searchQuery }),
      });

      if (!response.ok) {
        throw new Error('Failed to get medication info');
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }
      setMedication(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong');
      setMedication(null);
    } finally {
      setIsLoading(false);
    }
  };

  const goBack = () => {
    if (hasSearched) {
      setQuery('');
      setMedication(null);
      setHasSearched(false);
      setError(null);
    } else {
      navigate(-1);
    }
  };

  // Result View
  if (medication) {
    return (
      <div className="min-h-screen bg-gray-50 pb-24">
        <header className="sticky top-0 bg-gradient-to-r from-blue-500 to-indigo-600 px-4 py-4 z-40">
          <div className="flex items-center gap-3 max-w-lg mx-auto">
            <button
              onClick={goBack}
              className="p-2 -ml-2 rounded-full hover:bg-white/20 transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-white" />
            </button>
            <div>
              <h1 className="text-lg font-bold text-white">{medication.name}</h1>
              <p className="text-sm text-white/80">{medication.drugClass}</p>
            </div>
          </div>
        </header>

        <main className="px-4 py-6 max-w-lg mx-auto space-y-4">
          {/* AI Badge */}
          <div className="flex items-center gap-2 text-sm text-blue-700">
            <Sparkles className="w-4 h-4" />
            <span>AI-powered medication information</span>
          </div>

          {/* Brand Names */}
          {medication.brandNames && medication.brandNames.length > 0 && (
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
              <p className="text-sm text-gray-500 mb-2">Also known as</p>
              <div className="flex flex-wrap gap-2">
                {medication.brandNames.map((brand, idx) => (
                  <span key={idx} className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                    {brand}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Description */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <div className="flex items-start gap-3">
              <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-gray-900 mb-1">What is it?</p>
                <p className="text-sm text-gray-700">{medication.description}</p>
              </div>
            </div>
          </div>

          {/* Uses */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <div className="flex items-start gap-3">
              <Pill className="w-5 h-5 text-indigo-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-gray-900 mb-2">Common Uses</p>
                <ul className="space-y-1">
                  {medication.uses.map((use, idx) => (
                    <li key={idx} className="text-sm text-gray-700">• {use}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Benefits - Collapsible */}
          <div className="bg-green-50 rounded-2xl border border-green-200 overflow-hidden">
            <button
              onClick={() => toggleSection('benefits')}
              className="w-full flex items-center justify-between p-4"
            >
              <div className="flex items-center gap-3">
                <ThumbsUp className="w-5 h-5 text-green-600" />
                <span className="font-semibold text-gray-900">Benefits</span>
              </div>
              {expandedSections.includes('benefits') ? (
                <ChevronUp className="w-5 h-5 text-gray-400" />
              ) : (
                <ChevronDown className="w-5 h-5 text-gray-400" />
              )}
            </button>
            {expandedSections.includes('benefits') && (
              <div className="px-4 pb-4">
                <ul className="space-y-2">
                  {medication.benefits.map((benefit, idx) => (
                    <li key={idx} className="text-sm text-gray-700 flex items-start gap-2">
                      <span className="text-green-500 mt-0.5">✓</span>
                      {benefit}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Side Effects - Collapsible */}
          <div className="bg-amber-50 rounded-2xl border border-amber-200 overflow-hidden">
            <button
              onClick={() => toggleSection('sideEffects')}
              className="w-full flex items-center justify-between p-4"
            >
              <div className="flex items-center gap-3">
                <ThumbsDown className="w-5 h-5 text-amber-600" />
                <span className="font-semibold text-gray-900">Side Effects & Drawbacks</span>
              </div>
              {expandedSections.includes('sideEffects') ? (
                <ChevronUp className="w-5 h-5 text-gray-400" />
              ) : (
                <ChevronDown className="w-5 h-5 text-gray-400" />
              )}
            </button>
            {expandedSections.includes('sideEffects') && (
              <div className="px-4 pb-4 space-y-4">
                <div>
                  <p className="text-sm font-medium text-amber-700 mb-2">Common side effects:</p>
                  <ul className="space-y-1">
                    {medication.sideEffects.common.map((effect, idx) => (
                      <li key={idx} className="text-sm text-gray-700">• {effect}</li>
                    ))}
                  </ul>
                </div>
                <div className="bg-red-100 rounded-xl p-3">
                  <p className="text-sm font-medium text-red-700 mb-2">⚠️ Serious (seek medical help):</p>
                  <ul className="space-y-1">
                    {medication.sideEffects.serious.map((effect, idx) => (
                      <li key={idx} className="text-sm text-red-700">• {effect}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>

          {/* Long Term Effects - Collapsible */}
          <div className="bg-red-50 rounded-2xl border border-red-200 overflow-hidden">
            <button
              onClick={() => toggleSection('longTerm')}
              className="w-full flex items-center justify-between p-4"
            >
              <div className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-red-600" />
                <span className="font-semibold text-gray-900">Long-Term Consumption Effects</span>
              </div>
              {expandedSections.includes('longTerm') ? (
                <ChevronUp className="w-5 h-5 text-gray-400" />
              ) : (
                <ChevronDown className="w-5 h-5 text-gray-400" />
              )}
            </button>
            {expandedSections.includes('longTerm') && (
              <div className="px-4 pb-4">
                <ul className="space-y-2">
                  {medication.longTermEffects.map((effect, idx) => (
                    <li key={idx} className="text-sm text-gray-700 flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
                      {effect}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Dosage Info */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <div className="flex items-start gap-3">
              <Shield className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-gray-900 mb-1">Dosage Information</p>
                <p className="text-sm text-gray-700">{medication.dosageInfo}</p>
              </div>
            </div>
          </div>

          {/* Interactions - Collapsible */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <button
              onClick={() => toggleSection('interactions')}
              className="w-full flex items-center justify-between p-4"
            >
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-5 h-5 text-orange-500" />
                <span className="font-semibold text-gray-900">Drug Interactions</span>
              </div>
              {expandedSections.includes('interactions') ? (
                <ChevronUp className="w-5 h-5 text-gray-400" />
              ) : (
                <ChevronDown className="w-5 h-5 text-gray-400" />
              )}
            </button>
            {expandedSections.includes('interactions') && (
              <div className="px-4 pb-4">
                <ul className="space-y-1">
                  {medication.interactions.map((interaction, idx) => (
                    <li key={idx} className="text-sm text-gray-700">• {interaction}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Precautions - Collapsible */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <button
              onClick={() => toggleSection('precautions')}
              className="w-full flex items-center justify-between p-4"
            >
              <div className="flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-gray-600" />
                <span className="font-semibold text-gray-900">Who Should Avoid</span>
              </div>
              {expandedSections.includes('precautions') ? (
                <ChevronUp className="w-5 h-5 text-gray-400" />
              ) : (
                <ChevronDown className="w-5 h-5 text-gray-400" />
              )}
            </button>
            {expandedSections.includes('precautions') && (
              <div className="px-4 pb-4">
                <ul className="space-y-1">
                  {medication.precautions.map((precaution, idx) => (
                    <li key={idx} className="text-sm text-gray-700">• {precaution}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Natural Alternatives */}
          {medication.naturalAlternatives && medication.naturalAlternatives.length > 0 && (
            <div className="bg-green-50 rounded-2xl border border-green-200 overflow-hidden">
              <button
                onClick={() => toggleSection('natural')}
                className="w-full flex items-center justify-between p-4"
              >
                <div className="flex items-center gap-3">
                  <Leaf className="w-5 h-5 text-green-600" />
                  <span className="font-semibold text-gray-900">Natural Alternatives</span>
                </div>
                {expandedSections.includes('natural') ? (
                  <ChevronUp className="w-5 h-5 text-gray-400" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-400" />
                )}
              </button>
              {expandedSections.includes('natural') && (
                <div className="px-4 pb-4">
                  <ul className="space-y-1">
                    {medication.naturalAlternatives.map((alt, idx) => (
                      <li key={idx} className="text-sm text-gray-700">• {alt}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* Disclaimer */}
          <div className="bg-amber-50 rounded-2xl border border-amber-200 p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-amber-800 text-sm">Important Disclaimer</p>
                <p className="text-sm text-amber-700 mt-1">{medication.disclaimer}</p>
                <p className="text-xs text-amber-600 mt-2">
                  This is AI-generated information for educational purposes only. Always consult a healthcare professional or pharmacist before taking any medication.
                </p>
              </div>
            </div>
          </div>

          {/* Search Again */}
          <button
            onClick={goBack}
            className="w-full py-3 bg-blue-100 text-blue-700 rounded-xl font-semibold hover:bg-blue-200 transition-colors"
          >
            Search Another Medication
          </button>
        </main>

        <BottomNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header - compact when loading or error */}
      {(isLoading || error) && hasSearched ? (
        <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 z-40">
          <div className="flex items-center gap-3 max-w-lg mx-auto">
            <button
              onClick={goBack}
              className="p-2 -ml-2 rounded-full hover:bg-gray-100 transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch(query)}
                placeholder="Search medication..."
                className="w-full pl-10 pr-4 py-2.5 bg-gray-100 rounded-xl text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </header>
      ) : (
        /* Google-style landing */
        <div className="min-h-[60vh] flex flex-col items-center justify-center px-4">
          {/* Back Button */}
          <button
            onClick={() => navigate(-1)}
            className="absolute top-4 left-4 p-2 rounded-full bg-white shadow-md hover:bg-gray-100 transition-colors z-10"
          >
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </button>
          
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-400 to-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Pill className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Medication Encyclopedia</h1>
            <p className="text-gray-500">Learn about any medication's benefits & risks</p>
            <div className="flex items-center justify-center gap-2 mt-2 text-sm text-blue-600">
              <Sparkles className="w-4 h-4" />
              <span>AI Powered</span>
            </div>
          </div>

          {/* Search Bar */}
          <div className="w-full max-w-lg px-4">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch(query)}
                placeholder="Enter medication name..."
                className="w-full pl-12 pr-4 py-4 bg-white border border-gray-200 rounded-2xl text-gray-900 placeholder-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                autoFocus
              />
            </div>
            <button
              onClick={() => handleSearch(query)}
              disabled={!query.trim()}
              className="w-full mt-3 py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Get Medication Info
            </button>

            {/* Popular Medications */}
            <div className="mt-6">
              <p className="text-sm text-gray-500 mb-3 text-center">Popular medications</p>
              <div className="flex flex-wrap justify-center gap-2">
                {popularMedications.map((med) => (
                  <button
                    key={med}
                    onClick={() => handleSearch(med)}
                    className="px-4 py-2 bg-white border border-gray-200 rounded-full text-sm text-gray-700 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700 transition-all"
                  >
                    {med}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Info Box */}
          <div className="w-full max-w-lg px-4 mt-8">
            <div className="bg-blue-50 rounded-2xl p-4 border border-blue-100">
              <h3 className="font-semibold text-blue-900 mb-2">What you'll learn:</h3>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• What the medication is used for</li>
                <li>• Benefits and how it helps</li>
                <li>• Common and serious side effects</li>
                <li>• Long-term consumption effects</li>
                <li>• Drug interactions to avoid</li>
                <li>• Natural alternatives</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Loading State */}
      {isLoading && (
        <main className="px-4 py-12 max-w-lg mx-auto">
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">Researching with AI...</h3>
            <p className="text-gray-500 mt-1">Getting comprehensive info about "{query}"</p>
          </div>
        </main>
      )}

      {/* Error State */}
      {error && !isLoading && (
        <main className="px-4 py-12 max-w-lg mx-auto">
          <div className="text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">Something went wrong</h3>
            <p className="text-gray-500 mt-1 mb-4">{error}</p>
            <button
              onClick={() => handleSearch(query)}
              className="px-6 py-2 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 transition-colors"
            >
              Try Again
            </button>
          </div>
        </main>
      )}

      <BottomNav />
    </div>
  );
}
