import { Link } from 'react-router';
import { 
  Pill, 
  Droplets, 
  FileText, 
  Stethoscope,
  Activity,
  User,
  ChevronRight,
  Heart,
  Leaf,
  Calendar,
  RefreshCw,
  Gift,
  ShoppingBag,
  BookOpen,
  Sparkles,
  Building2
} from 'lucide-react';
import BottomNav from '@/react-app/components/BottomNav';
import { useAuth } from '@/react-app/contexts/AuthContext';

const menuItems = [
  {
    title: 'My Appointments',
    subtitle: 'View upcoming schedule',
    icon: Calendar,
    to: '/appointments',
    color: 'text-blue-600',
    bgColor: 'bg-blue-100',
  },
  {
    title: 'NHS Appointments',
    subtitle: 'GP & Hospital visits',
    icon: Building2,
    to: '/nhs-appointments',
    color: 'text-indigo-600',
    bgColor: 'bg-indigo-100',
  },
  {
    title: 'Follow-up Consultations',
    subtitle: 'Doctor recommended visits',
    icon: RefreshCw,
    to: '/follow-ups',
    color: 'text-amber-600',
    bgColor: 'bg-amber-100',
  },
  {
    title: 'Rewards',
    subtitle: 'Earn points & redeem gifts',
    icon: Gift,
    to: '/rewards',
    color: 'text-purple-600',
    bgColor: 'bg-purple-100',
  },
  {
    title: 'Order Medication',
    subtitle: 'Pharmacy & delivery',
    icon: ShoppingBag,
    to: '/pharmacy',
    color: 'text-emerald-600',
    bgColor: 'bg-emerald-100',
  },
  {
    title: 'Cosmetics & Aesthetics',
    subtitle: 'Hair implants, fillers & surgery',
    icon: Sparkles,
    to: '/aesthetics',
    color: 'text-pink-600',
    bgColor: 'bg-pink-100',
  },
  {
    title: 'Remedy Search',
    subtitle: 'AI-powered natural remedies',
    icon: Leaf,
    to: '/remedies',
    color: 'text-green-600',
    bgColor: 'bg-green-100',
    hasAI: true,
  },
  {
    title: 'Check Symptoms',
    subtitle: 'AI symptom analysis',
    icon: Stethoscope,
    to: '/symptoms',
    color: 'text-purple-600',
    bgColor: 'bg-purple-100',
    hasAI: true,
  },
  {
    title: 'Medication Encyclopedia',
    subtitle: 'Benefits, risks & long-term effects',
    icon: BookOpen,
    to: '/medications-info',
    color: 'text-blue-600',
    bgColor: 'bg-blue-100',
    hasAI: true,
  },
  {
    title: 'Health Tracker',
    subtitle: 'Vitals, food logging & barcode scan',
    icon: Activity,
    to: '/tracker',
    color: 'text-green-600',
    bgColor: 'bg-green-100',
  },
  {
    title: 'Medication Reminders',
    subtitle: 'Never miss a dose',
    icon: Pill,
    to: '/medications',
    color: 'text-rose-600',
    bgColor: 'bg-rose-100',
  },
  {
    title: 'Blood Donors',
    subtitle: 'Find compatible donors',
    icon: Droplets,
    to: '/blood-donors',
    color: 'text-red-600',
    bgColor: 'bg-red-100',
  },
  {
    title: 'My Records',
    subtitle: 'Health documents vault',
    icon: FileText,
    to: '/records',
    color: 'text-cyan-600',
    bgColor: 'bg-cyan-100',
  },

  {
    title: 'Health Profile',
    subtitle: 'Your medical information',
    icon: Heart,
    to: '/profile/health',
    color: 'text-pink-600',
    bgColor: 'bg-pink-100',
  },
  {
    title: 'My Account',
    subtitle: 'Settings & preferences',
    icon: User,
    to: '/profile',
    color: 'text-gray-600',
    bgColor: 'bg-gray-100',
  },
];

export default function MorePage() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-4 z-40">
        <div className="max-w-lg mx-auto">
          <h1 className="text-xl font-bold text-gray-900">More</h1>
          <p className="text-sm text-gray-500">All features & settings</p>
        </div>
      </header>

      <main className="px-4 py-6 max-w-lg mx-auto">
        {/* User Quick Card */}
        {user && (
          <Link 
            to="/profile"
            className="flex items-center gap-4 bg-gradient-to-r from-primary to-teal-500 rounded-2xl p-4 mb-6"
          >
            {user.avatar ? (
              <img src={user.avatar} alt="" className="w-14 h-14 rounded-full border-2 border-white/50" />
            ) : (
              <div className="w-14 h-14 bg-white/20 rounded-full flex items-center justify-center">
                <span className="text-2xl font-bold text-white">
                  {user.name?.charAt(0) || user.email?.charAt(0) || '?'}
                </span>
              </div>
            )}
            <div className="flex-1 text-white">
              <p className="font-semibold text-lg">{user.name || 'User'}</p>
              <p className="text-white/80 text-sm">{user.email}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-white/70" />
          </Link>
        )}

        {/* Menu Items */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm divide-y divide-gray-100">
          {menuItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="flex items-center gap-4 p-4 hover:bg-gray-50 transition-colors"
            >
              <div className={`w-11 h-11 ${item.bgColor} rounded-xl flex items-center justify-center`}>
                <item.icon className={`w-5 h-5 ${item.color}`} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-gray-900">{item.title}</p>
                  {'hasAI' in item && item.hasAI && (
                    <span className="flex items-center gap-1 px-1.5 py-0.5 bg-gradient-to-r from-blue-500 to-purple-500 rounded text-[10px] text-white font-medium">
                      <Sparkles className="w-2.5 h-2.5" />
                      AI
                    </span>
                  )}
                </div>
                <p className="text-sm text-gray-500">{item.subtitle}</p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </Link>
          ))}
        </div>

        {/* Disclaimer */}
        <p className="text-xs text-gray-500 text-center mt-6 px-4">
          Medro provides health information, not medical diagnosis. Always consult a healthcare professional for medical advice.
        </p>
      </main>

      <BottomNav />
    </div>
  );
}
