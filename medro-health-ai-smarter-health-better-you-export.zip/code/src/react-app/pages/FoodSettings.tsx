import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Target, Scale, Ruler, Bell, Save, Check } from 'lucide-react';

interface FoodSettings {
  dailyCalorieGoal: number;
  proteinGoal: number;
  carbsGoal: number;
  fatGoal: number;
  defaultPlateSize: 'small' | 'normal' | 'large';
  measurementUnit: 'metric' | 'imperial';
  mealReminders: boolean;
  breakfastTime: string;
  lunchTime: string;
  dinnerTime: string;
}

export default function FoodSettings() {
  const navigate = useNavigate();
  const [saved, setSaved] = useState(false);
  const [settings, setSettings] = useState<FoodSettings>({
    dailyCalorieGoal: 2000,
    proteinGoal: 150,
    carbsGoal: 250,
    fatGoal: 65,
    defaultPlateSize: 'normal',
    measurementUnit: 'metric',
    mealReminders: true,
    breakfastTime: '08:00',
    lunchTime: '12:30',
    dinnerTime: '19:00',
  });

  const handleSave = () => {
    // TODO: Save to database/localStorage
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const plateSizes = [
    { value: 'small', label: 'Small', desc: 'Reduce portions by 20%' },
    { value: 'normal', label: 'Normal', desc: 'Standard portions' },
    { value: 'large', label: 'Large', desc: 'Increase portions by 20%' },
  ] as const;

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white pb-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-gray-700 to-gray-900 text-white px-4 py-4 pb-6">
        <div className="flex items-center gap-3 mb-2">
          <button onClick={() => navigate('/tracker')} className="p-2 hover:bg-white/20 rounded-full transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-bold">Food Settings</h1>
        </div>
        <p className="text-gray-300 text-sm ml-10">Customize your nutrition goals</p>
      </div>

      <main className="px-4 -mt-3 max-w-lg mx-auto">
        {/* Daily Goals */}
        <div className="bg-white rounded-2xl shadow-lg p-5 mb-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center">
              <Target className="w-5 h-5 text-emerald-600" />
            </div>
            <h2 className="font-semibold text-gray-900">Daily Goals</h2>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Daily Calorie Goal
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min="1200"
                  max="4000"
                  step="50"
                  value={settings.dailyCalorieGoal}
                  onChange={(e) => setSettings({ ...settings, dailyCalorieGoal: Number(e.target.value) })}
                  className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
                <span className="w-20 text-center font-semibold text-gray-900">{settings.dailyCalorieGoal}</span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Protein (g)</label>
                <input
                  type="number"
                  value={settings.proteinGoal}
                  onChange={(e) => setSettings({ ...settings, proteinGoal: Number(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg text-center font-medium focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Carbs (g)</label>
                <input
                  type="number"
                  value={settings.carbsGoal}
                  onChange={(e) => setSettings({ ...settings, carbsGoal: Number(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg text-center font-medium focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Fat (g)</label>
                <input
                  type="number"
                  value={settings.fatGoal}
                  onChange={(e) => setSettings({ ...settings, fatGoal: Number(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg text-center font-medium focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Default Plate Size */}
        <div className="bg-white rounded-2xl shadow-lg p-5 mb-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
              <Scale className="w-5 h-5 text-blue-600" />
            </div>
            <h2 className="font-semibold text-gray-900">Default Plate Size</h2>
          </div>

          <div className="space-y-2">
            {plateSizes.map(size => (
              <button
                key={size.value}
                onClick={() => setSettings({ ...settings, defaultPlateSize: size.value })}
                className={`w-full p-3 rounded-xl border-2 transition-all flex items-center justify-between ${
                  settings.defaultPlateSize === size.value
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="text-left">
                  <p className="font-medium text-gray-900">{size.label}</p>
                  <p className="text-xs text-gray-500">{size.desc}</p>
                </div>
                {settings.defaultPlateSize === size.value && (
                  <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                    <Check className="w-4 h-4 text-white" />
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Measurement Unit */}
        <div className="bg-white rounded-2xl shadow-lg p-5 mb-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center">
              <Ruler className="w-5 h-5 text-purple-600" />
            </div>
            <h2 className="font-semibold text-gray-900">Measurement Units</h2>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {(['metric', 'imperial'] as const).map(unit => (
              <button
                key={unit}
                onClick={() => setSettings({ ...settings, measurementUnit: unit })}
                className={`p-3 rounded-xl border-2 transition-all ${
                  settings.measurementUnit === unit
                    ? 'border-purple-500 bg-purple-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <p className="font-medium text-gray-900 capitalize">{unit}</p>
                <p className="text-xs text-gray-500">
                  {unit === 'metric' ? 'g, kg, ml' : 'oz, lb, cups'}
                </p>
              </button>
            ))}
          </div>
        </div>

        {/* Meal Reminders */}
        <div className="bg-white rounded-2xl shadow-lg p-5 mb-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center">
                <Bell className="w-5 h-5 text-amber-600" />
              </div>
              <h2 className="font-semibold text-gray-900">Meal Reminders</h2>
            </div>
            <button
              onClick={() => setSettings({ ...settings, mealReminders: !settings.mealReminders })}
              className={`w-12 h-7 rounded-full transition-all ${
                settings.mealReminders ? 'bg-emerald-500' : 'bg-gray-300'
              }`}
            >
              <div className={`w-5 h-5 bg-white rounded-full shadow transform transition-transform ${
                settings.mealReminders ? 'translate-x-6' : 'translate-x-1'
              }`} />
            </button>
          </div>

          {settings.mealReminders && (
            <div className="space-y-3 pt-3 border-t border-gray-100">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Breakfast</span>
                <input
                  type="time"
                  value={settings.breakfastTime}
                  onChange={(e) => setSettings({ ...settings, breakfastTime: e.target.value })}
                  className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm"
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Lunch</span>
                <input
                  type="time"
                  value={settings.lunchTime}
                  onChange={(e) => setSettings({ ...settings, lunchTime: e.target.value })}
                  className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm"
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Dinner</span>
                <input
                  type="time"
                  value={settings.dinnerTime}
                  onChange={(e) => setSettings({ ...settings, dinnerTime: e.target.value })}
                  className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm"
                />
              </div>
            </div>
          )}
        </div>

        {/* Save Button */}
        <button
          onClick={handleSave}
          className={`w-full py-4 rounded-xl font-semibold flex items-center justify-center gap-2 shadow-lg transition-all ${
            saved
              ? 'bg-emerald-500 text-white'
              : 'bg-gradient-to-r from-gray-700 to-gray-900 text-white hover:shadow-xl'
          }`}
        >
          {saved ? (
            <>
              <Check className="w-5 h-5" /> Saved!
            </>
          ) : (
            <>
              <Save className="w-5 h-5" /> Save Settings
            </>
          )}
        </button>
      </main>
    </div>
  );
}
