import { useState } from 'react';
import { useNavigate } from 'react-router';
import { User, Stethoscope, ArrowRight, Loader2, ChevronDown, Search, MapPin } from 'lucide-react';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { cn } from '@/react-app/lib/utils';
import { countries, Country } from '@/react-app/data/countries';

export default function RoleSelectPage() {
  const navigate = useNavigate();
  const { setRole, user } = useAuth();
  const [step, setStep] = useState<'role' | 'country'>('role');
  const [selectedRole, setSelectedRole] = useState<'patient' | 'doctor' | null>(null);
  const [selectedCountry, setSelectedCountry] = useState<Country | null>(null);
  const [showCountrySearch, setShowCountrySearch] = useState(false);
  const [countrySearch, setCountrySearch] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const filteredCountries = countries.filter(c => 
    c.name.toLowerCase().includes(countrySearch.toLowerCase())
  );

  const handleRoleContinue = () => {
    if (!selectedRole) return;
    setStep('country');
  };

  const handleCountryContinue = async () => {
    if (!selectedRole || !selectedCountry) return;
    
    setIsLoading(true);
    try {
      await setRole(selectedRole, selectedCountry.code);
      if (selectedRole === 'doctor') {
        navigate('/doctor/onboarding');
      } else {
        navigate('/');
      }
    } catch (error) {
      console.error('Failed to set role:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (step === 'country') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/5 via-white to-teal-50 flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center px-6 py-12">
          <div className="w-16 h-16 bg-gradient-to-br from-primary to-teal-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-primary/20">
            <MapPin className="w-8 h-8 text-white" />
          </div>

          <h1 className="text-2xl font-bold text-gray-900 mb-2">Where are you located?</h1>
          <p className="text-gray-600 text-center max-w-sm mb-8">
            {selectedRole === 'doctor' 
              ? 'Select your country of residence. You can add licensed countries later.'
              : 'This helps us connect you with doctors licensed in your region.'
            }
          </p>

          <div className="w-full max-w-sm">
            <div className="relative">
              <button
                onClick={() => setShowCountrySearch(!showCountrySearch)}
                className="w-full p-4 bg-white border-2 border-gray-200 rounded-xl flex items-center justify-between hover:border-gray-300 transition-colors"
              >
                {selectedCountry ? (
                  <span className="flex items-center gap-3">
                    <span className="text-2xl">{selectedCountry.flag}</span>
                    <span className="font-medium text-gray-900">{selectedCountry.name}</span>
                  </span>
                ) : (
                  <span className="text-gray-400">Select your country</span>
                )}
                <ChevronDown className={cn(
                  "w-5 h-5 text-gray-400 transition-transform",
                  showCountrySearch && "rotate-180"
                )} />
              </button>

              {showCountrySearch && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl border border-gray-200 shadow-xl z-50 max-h-80 overflow-hidden">
                  <div className="p-3 border-b border-gray-100 sticky top-0 bg-white">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        type="text"
                        value={countrySearch}
                        onChange={(e) => setCountrySearch(e.target.value)}
                        placeholder="Search countries..."
                        className="w-full pl-10 pr-4 py-2 bg-gray-50 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                        autoFocus
                      />
                    </div>
                  </div>
                  <div className="overflow-y-auto max-h-60">
                    {filteredCountries.map(country => (
                      <button
                        key={country.code}
                        onClick={() => {
                          setSelectedCountry(country);
                          setShowCountrySearch(false);
                          setCountrySearch('');
                        }}
                        className={cn(
                          "w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 transition-colors",
                          selectedCountry?.code === country.code && "bg-primary/5"
                        )}
                      >
                        <span className="text-xl">{country.flag}</span>
                        <span className="text-gray-900">{country.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          <button
            onClick={handleCountryContinue}
            disabled={!selectedCountry || isLoading}
            className={cn(
              'mt-8 w-full max-w-sm flex items-center justify-center gap-2 py-4 rounded-xl font-semibold transition-all',
              selectedCountry
                ? 'bg-primary text-white hover:bg-primary/90'
                : 'bg-gray-200 text-gray-500 cursor-not-allowed'
            )}
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <span>Continue</span>
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>

          <button
            onClick={() => setStep('role')}
            className="mt-4 text-gray-500 hover:text-gray-700 text-sm"
          >
            ← Back to role selection
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-white to-teal-50 flex flex-col">
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12">
        <div className="w-20 h-20 bg-gradient-to-br from-primary to-teal-600 rounded-3xl flex items-center justify-center mb-6 shadow-lg shadow-primary/20">
          <span className="text-3xl text-white font-bold">C</span>
        </div>

        <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome to Medro</h1>
        <p className="text-gray-600 text-center max-w-sm mb-8">
          {user?.name ? `Hi ${user.name.split(' ')[0]}! ` : ''}Choose how you want to use Medro
        </p>

        <div className="w-full max-w-sm space-y-4">
          <button
            onClick={() => setSelectedRole('patient')}
            className={cn(
              'w-full p-6 rounded-2xl border-2 transition-all duration-200 text-left',
              selectedRole === 'patient'
                ? 'border-primary bg-primary/5 shadow-lg shadow-primary/10'
                : 'border-gray-200 bg-white hover:border-gray-300'
            )}
          >
            <div className="flex items-start gap-4">
              <div className={cn(
                'w-14 h-14 rounded-xl flex items-center justify-center',
                selectedRole === 'patient' ? 'bg-primary text-white' : 'bg-blue-100 text-blue-600'
              )}>
                <User className="w-7 h-7" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900">I'm a Patient</h3>
                <p className="text-sm text-gray-500 mt-1">
                  Track health, book tests, find doctors, and manage your medical records
                </p>
              </div>
            </div>
          </button>

          <button
            onClick={() => setSelectedRole('doctor')}
            className={cn(
              'w-full p-6 rounded-2xl border-2 transition-all duration-200 text-left',
              selectedRole === 'doctor'
                ? 'border-primary bg-primary/5 shadow-lg shadow-primary/10'
                : 'border-gray-200 bg-white hover:border-gray-300'
            )}
          >
            <div className="flex items-start gap-4">
              <div className={cn(
                'w-14 h-14 rounded-xl flex items-center justify-center',
                selectedRole === 'doctor' ? 'bg-primary text-white' : 'bg-teal-100 text-teal-600'
              )}>
                <Stethoscope className="w-7 h-7" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900">I'm a Doctor</h3>
                <p className="text-sm text-gray-500 mt-1">
                  Manage appointments, consult with patients, and grow your practice
                </p>
              </div>
            </div>
          </button>
        </div>

        <button
          onClick={handleRoleContinue}
          disabled={!selectedRole}
          className={cn(
            'mt-8 w-full max-w-sm flex items-center justify-center gap-2 py-4 rounded-xl font-semibold transition-all',
            selectedRole
              ? 'bg-primary text-white hover:bg-primary/90'
              : 'bg-gray-200 text-gray-500 cursor-not-allowed'
          )}
        >
          <span>Continue</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>

      <div className="px-6 py-4 text-center">
        <p className="text-xs text-gray-400">
          By continuing, you agree to our Terms of Service and Privacy Policy
        </p>
      </div>
    </div>
  );
}
