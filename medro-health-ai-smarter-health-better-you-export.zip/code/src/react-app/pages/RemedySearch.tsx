import { useState } from 'react';
import { useNavigate } from 'react-router';
import { 
  Search, 
  ArrowLeft,
  Leaf,
  AlertTriangle,
  Sparkles,
  Loader2
} from 'lucide-react';

import BottomNav from '@/react-app/components/BottomNav';

const popularSearches = [
  'Cold & Flu',
  'Headache',
  'Stress',
  'Insomnia',
  'Joint Pain',
  'Digestive Issues',
  'Anxiety',
  'High Blood Pressure',
  'Diabetes',
  'Skin Problems'
];

interface Remedy {
  food: string;
  icon: string;
  benefits: string;
  howToUse: string;
}

interface RemedyResult {
  conditionName: string;
  description: string;
  remedies: Remedy[];
  disclaimer: string;
}

export default function RemedySearchPage() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<RemedyResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) return;
    
    setQuery(searchQuery);
    setIsLoading(true);
    setError(null);
    setHasSearched(true);

    try {
      const response = await fetch('/api/remedy-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ condition: searchQuery }),
      });

      if (!response.ok) {
        throw new Error('Failed to search remedies');
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong');
      setResult(null);
    } finally {
      setIsLoading(false);
    }
  };

  const goBack = () => {
    if (hasSearched) {
      setQuery('');
      setResult(null);
      setHasSearched(false);
      setError(null);
    } else {
      navigate(-1);
    }
  };

  // Result View
  if (result) {
    return (
      <div className="min-h-screen bg-gray-50 pb-24">
        <header className="sticky top-0 bg-gradient-to-r from-green-500 to-emerald-600 px-4 py-4 z-40">
          <div className="flex items-center gap-3 max-w-lg mx-auto">
            <button
              onClick={goBack}
              className="p-2 -ml-2 rounded-full hover:bg-white/20 transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-white" />
            </button>
            <div>
              <h1 className="text-lg font-bold text-white">{result.conditionName}</h1>
              <p className="text-sm text-white/80">AI-powered natural remedies</p>
            </div>
          </div>
        </header>

        <main className="px-4 py-6 max-w-lg mx-auto space-y-6">
          {/* AI Badge */}
          <div className="flex items-center gap-2 text-sm text-green-700">
            <Sparkles className="w-4 h-4" />
            <span>Powered by AI</span>
          </div>

          {/* Description */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <p className="text-gray-700">{result.description}</p>
          </div>

          {/* Remedies List */}
          <section>
            <h2 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <Leaf className="w-5 h-5 text-green-600" />
              Recommended Foods & Remedies
            </h2>
            <div className="space-y-3">
              {result.remedies.map((remedy, idx) => (
                <div key={idx} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                  <div className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="w-14 h-14 bg-green-100 rounded-xl flex items-center justify-center text-2xl">
                        {remedy.icon}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-bold text-gray-900 text-lg">{remedy.food}</h3>
                        <p className="text-sm text-green-700 mt-1">{remedy.benefits}</p>
                      </div>
                    </div>
                    <div className="mt-4 bg-green-50 rounded-xl p-3">
                      <p className="text-sm text-gray-700">
                        <span className="font-semibold text-green-700">How to use: </span>
                        {remedy.howToUse}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Disclaimer */}
          <div className="bg-amber-50 rounded-2xl border border-amber-200 p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-amber-800 text-sm">Important Notice</p>
                <p className="text-sm text-amber-700 mt-1">{result.disclaimer}</p>
                <p className="text-xs text-amber-600 mt-2">
                  These are AI-generated wellness suggestions, not medical advice. Always consult a healthcare professional.
                </p>
              </div>
            </div>
          </div>

          {/* Search Again */}
          <button
            onClick={goBack}
            className="w-full py-3 bg-green-100 text-green-700 rounded-xl font-semibold hover:bg-green-200 transition-colors"
          >
            Search Another Condition
          </button>
        </main>

        <BottomNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header - compact when loading or error */}
      {(isLoading || error) && hasSearched ? (
        <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 z-40">
          <div className="flex items-center gap-3 max-w-lg mx-auto">
            <button
              onClick={goBack}
              className="p-2 -ml-2 rounded-full hover:bg-gray-100 transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch(query)}
                placeholder="Search illness or condition..."
                className="w-full pl-10 pr-4 py-2.5 bg-gray-100 rounded-xl text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
          </div>
        </header>
      ) : (
        /* Google-style landing */
        <div className="min-h-[60vh] flex flex-col items-center justify-center px-4">
          {/* Back button */}
          <button
            onClick={() => navigate(-1)}
            className="absolute top-4 left-4 p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </button>
          
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-green-400 to-emerald-600 rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Leaf className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Remedy Search</h1>
            <p className="text-gray-500">AI-powered natural foods & remedies</p>
            <div className="flex items-center justify-center gap-2 mt-2 text-sm text-green-600">
              <Sparkles className="w-4 h-4" />
              <span>AI Powered</span>
            </div>
          </div>

          {/* Search Bar */}
          <div className="w-full max-w-lg px-4">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch(query)}
                placeholder="Enter an illness or condition..."
                className="w-full pl-12 pr-4 py-4 bg-white border border-gray-200 rounded-2xl text-gray-900 placeholder-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent text-lg"
                autoFocus
              />
            </div>
            <button
              onClick={() => handleSearch(query)}
              disabled={!query.trim()}
              className="w-full mt-3 py-3 bg-green-600 text-white rounded-xl font-semibold hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Search Remedies
            </button>

            {/* Popular Searches */}
            <div className="mt-6">
              <p className="text-sm text-gray-500 mb-3 text-center">Popular searches</p>
              <div className="flex flex-wrap justify-center gap-2">
                {popularSearches.map((term) => (
                  <button
                    key={term}
                    onClick={() => handleSearch(term)}
                    className="px-4 py-2 bg-white border border-gray-200 rounded-full text-sm text-gray-700 hover:bg-green-50 hover:border-green-300 hover:text-green-700 transition-all"
                  >
                    {term}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Loading State */}
      {isLoading && (
        <main className="px-4 py-12 max-w-lg mx-auto">
          <div className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Loader2 className="w-8 h-8 text-green-600 animate-spin" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">Searching with AI...</h3>
            <p className="text-gray-500 mt-1">Finding natural remedies for "{query}"</p>
          </div>
        </main>
      )}

      {/* Error State */}
      {error && !isLoading && (
        <main className="px-4 py-12 max-w-lg mx-auto">
          <div className="text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">Something went wrong</h3>
            <p className="text-gray-500 mt-1 mb-4">{error}</p>
            <button
              onClick={() => handleSearch(query)}
              className="px-6 py-2 bg-green-600 text-white rounded-xl font-medium hover:bg-green-700 transition-colors"
            >
              Try Again
            </button>
          </div>
        </main>
      )}

      <BottomNav />
    </div>
  );
}
