import { useState } from 'react';
import { useNavigate } from 'react-router';
import { 
  ArrowLeft, 
  Gift, 
  Calendar, 
  Coins, 
  ChevronRight,
  Heart,
  Database,
  Gamepad2,
  ExternalLink,
  Sparkles,
  Trophy,
  RotateCw,
  Check,
  Lock
} from 'lucide-react';
import { cn } from '@/react-app/lib/utils';
import BottomNav from '@/react-app/components/BottomNav';

type TabType = 'earn' | 'redeem' | 'activity';

interface GiftCard {
  id: string;
  name: string;
  brand: string;
  image: string;
  pointsCost: number;
  value: string;
  available: number;
  availableAt?: string;
}

interface Charity {
  id: string;
  name: string;
  description: string;
  image: string;
  color: string;
  pointsCost: number;
}

interface SponsorTask {
  id: string;
  title: string;
  description: string;
  points: number;
  sponsor: string;
  type: 'visit' | 'download';
  url: string;
  completed: boolean;
}

const giftCards: GiftCard[] = [
  {
    id: 'amazon-3',
    name: 'Amazon £3 Gift Card',
    brand: 'Amazon',
    image: 'https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?w=200&h=120&fit=crop',
    pointsCost: 300,
    value: '£3',
    available: 150,
    availableAt: 'Monday at 08:30'
  },
  {
    id: 'google-5',
    name: 'Google Play £5 Gift Card',
    brand: 'Google Play',
    image: 'https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?w=200&h=120&fit=crop',
    pointsCost: 500,
    value: '£5',
    available: 39,
    availableAt: 'Monday at 14:30'
  },
  {
    id: 'boots-5',
    name: 'Boots £5 Gift Card',
    brand: 'Boots',
    image: 'https://images.unsplash.com/photo-1631729371254-42c2892f0e6e?w=200&h=120&fit=crop',
    pointsCost: 500,
    value: '£5',
    available: 75
  },
  {
    id: 'amazon-10',
    name: 'Amazon £10 Gift Card',
    brand: 'Amazon',
    image: 'https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?w=200&h=120&fit=crop',
    pointsCost: 1000,
    value: '£10',
    available: 25
  }
];

const charities: Charity[] = [
  {
    id: 'bhf',
    name: 'British Heart Foundation',
    description: 'Fighting heart disease',
    image: '❤️',
    color: 'bg-red-100 text-red-600',
    pointsCost: 100
  },
  {
    id: 'cancer-research',
    name: 'Cancer Research UK',
    description: 'Beat cancer sooner',
    image: '🎗️',
    color: 'bg-pink-100 text-pink-600',
    pointsCost: 100
  },
  {
    id: 'unicef',
    name: 'UNICEF',
    description: 'For every child',
    image: '🧒',
    color: 'bg-blue-100 text-blue-600',
    pointsCost: 100
  },
  {
    id: 'gaza-aid',
    name: 'Gaza Emergency Appeal',
    description: 'Humanitarian aid',
    image: '🕊️',
    color: 'bg-green-100 text-green-600',
    pointsCost: 100
  }
];

const sponsorTasks: SponsorTask[] = [
  {
    id: 'task-1',
    title: 'Visit Boots Wellness',
    description: 'Explore health products and vitamins',
    points: 10,
    sponsor: 'Boots',
    type: 'visit',
    url: 'https://www.boots.com/wellness',
    completed: false
  },
  {
    id: 'task-2',
    title: 'Download NHS App',
    description: 'Get the official NHS health app',
    points: 50,
    sponsor: 'NHS',
    type: 'download',
    url: 'https://www.nhs.uk/nhs-app/',
    completed: false
  },
  {
    id: 'task-3',
    title: 'Visit Holland & Barrett',
    description: 'Discover natural health supplements',
    points: 10,
    sponsor: 'Holland & Barrett',
    type: 'visit',
    url: 'https://www.hollandandbarrett.com/',
    completed: false
  },
  {
    id: 'task-4',
    title: 'Download Headspace',
    description: 'Meditation and sleep app',
    points: 30,
    sponsor: 'Headspace',
    type: 'download',
    url: 'https://www.headspace.com/',
    completed: false
  },
  {
    id: 'task-5',
    title: 'Visit Vitality Health',
    description: 'Learn about health insurance',
    points: 15,
    sponsor: 'Vitality',
    type: 'visit',
    url: 'https://www.vitality.co.uk/',
    completed: false
  }
];

const spinWheelPrizes = [5, 10, 15, 20, 25, 50, 100, 0];

export default function RewardsPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<TabType>('earn');
  const [points, setPoints] = useState(811);
  const [dailyStreak, setDailyStreak] = useState(7);
  const [hasClaimedDaily, setHasClaimedDaily] = useState(false);
  const [hasSpunToday, setHasSpunToday] = useState(false);
  const [isSpinning, setIsSpinning] = useState(false);
  const [spinResult, setSpinResult] = useState<number | null>(null);
  const [tasks, setTasks] = useState(sponsorTasks);
  const [dataSharing, setDataSharing] = useState({
    healthData: false,
    activityData: false,
    locationData: false
  });

  // Activity history
  const [activity] = useState([
    { id: 1, type: 'daily', description: 'Daily login bonus', points: 10, date: '2024-01-20' },
    { id: 2, type: 'spin', description: 'Spin wheel win', points: 25, date: '2024-01-19' },
    { id: 3, type: 'task', description: 'Visited Boots Wellness', points: 10, date: '2024-01-19' },
    { id: 4, type: 'data', description: 'Shared health data', points: 50, date: '2024-01-18' },
    { id: 5, type: 'redeem', description: 'Redeemed Amazon £3 Card', points: -300, date: '2024-01-15' },
    { id: 6, type: 'donate', description: 'Donated to UNICEF', points: -100, date: '2024-01-14' },
  ]);

  const claimDailyBonus = () => {
    if (hasClaimedDaily) return;
    const bonus = 10 + Math.min(dailyStreak, 7) * 2; // Base 10 + streak bonus
    setPoints(prev => prev + bonus);
    setHasClaimedDaily(true);
    setDailyStreak(prev => prev + 1);
  };

  const spinWheel = () => {
    if (hasSpunToday || isSpinning) return;
    setIsSpinning(true);
    setSpinResult(null);
    
    setTimeout(() => {
      const prize = spinWheelPrizes[Math.floor(Math.random() * spinWheelPrizes.length)];
      setSpinResult(prize);
      setPoints(prev => prev + prize);
      setIsSpinning(false);
      setHasSpunToday(true);
    }, 2000);
  };

  const completeTask = (taskId: string) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task || task.completed) return;
    
    window.open(task.url, '_blank');
    
    setTasks(prev => prev.map(t => 
      t.id === taskId ? { ...t, completed: true } : t
    ));
    setPoints(prev => prev + task.points);
  };

  const toggleDataSharing = (key: keyof typeof dataSharing) => {
    const wasSharing = dataSharing[key];
    setDataSharing(prev => ({ ...prev, [key]: !prev[key] }));
    
    if (!wasSharing) {
      // Award points for enabling data sharing
      const pointsAwarded = key === 'healthData' ? 50 : key === 'activityData' ? 30 : 20;
      setPoints(prev => prev + pointsAwarded);
    }
  };

  const redeemGiftCard = (card: GiftCard) => {
    if (points < card.pointsCost) return;
    setPoints(prev => prev - card.pointsCost);
    alert(`🎉 Congratulations! Your ${card.name} code will be sent to your email within 24 hours.`);
  };

  const donateToCharity = (charity: Charity) => {
    if (points < charity.pointsCost) return;
    setPoints(prev => prev - charity.pointsCost);
    alert(`❤️ Thank you! You've donated ${charity.pointsCost} points to ${charity.name}.`);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header with Points */}
      <header className="bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 px-4 pt-4 pb-8">
        <div className="flex items-center gap-3 max-w-lg mx-auto mb-6">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 rounded-full hover:bg-white/20 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <h1 className="text-lg font-bold text-white">Rewards</h1>
        </div>

        {/* Points Circle */}
        <div className="flex flex-col items-center">
          <div className="w-40 h-40 rounded-full border-8 border-white/30 flex flex-col items-center justify-center bg-white/10 backdrop-blur-sm">
            <Coins className="w-6 h-6 text-yellow-300 mb-1" />
            <span className="text-4xl font-bold text-white">{points.toLocaleString()}</span>
            <span className="text-white/80 text-sm">Points</span>
          </div>
          <button
            onClick={() => setActiveTab('activity')}
            className="mt-4 px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full text-white text-sm font-medium flex items-center gap-2"
          >
            My Activity <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Tabs */}
      <div className="sticky top-0 bg-white border-b border-gray-100 z-40">
        <div className="max-w-lg mx-auto flex">
          {[
            { id: 'earn', label: 'Earn' },
            { id: 'redeem', label: 'Redeem' },
            { id: 'activity', label: 'Activity' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as TabType)}
              className={cn(
                'flex-1 py-3 text-sm font-medium transition-all border-b-2',
                activeTab === tab.id
                  ? 'text-primary border-primary'
                  : 'text-gray-500 border-transparent hover:text-gray-700'
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <main className="px-4 py-4 max-w-lg mx-auto space-y-6">
        {/* EARN TAB */}
        {activeTab === 'earn' && (
          <>
            {/* Daily Login */}
            <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-amber-600" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">Daily Login</h3>
                  <p className="text-sm text-gray-500">{dailyStreak} day streak! 🔥</p>
                </div>
                <button
                  onClick={claimDailyBonus}
                  disabled={hasClaimedDaily}
                  className={cn(
                    'px-4 py-2 rounded-xl text-sm font-medium transition-all',
                    hasClaimedDaily
                      ? 'bg-gray-100 text-gray-400'
                      : 'bg-amber-500 text-white hover:bg-amber-600'
                  )}
                >
                  {hasClaimedDaily ? (
                    <span className="flex items-center gap-1"><Check className="w-4 h-4" /> Claimed</span>
                  ) : (
                    `+${10 + Math.min(dailyStreak, 7) * 2} pts`
                  )}
                </button>
              </div>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5, 6, 7].map(day => (
                  <div
                    key={day}
                    className={cn(
                      'flex-1 h-2 rounded-full',
                      day <= dailyStreak ? 'bg-amber-500' : 'bg-gray-200'
                    )}
                  />
                ))}
              </div>
            </section>

            {/* Spin Wheel */}
            <section className="bg-gradient-to-br from-purple-500 to-indigo-600 rounded-2xl p-4 text-white">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-semibold text-lg">Spin to Win!</h3>
                  <p className="text-sm text-white/80">Free spin every day</p>
                </div>
                <Sparkles className="w-6 h-6 text-yellow-300" />
              </div>
              
              <div className="flex items-center justify-center py-6">
                <div className={cn(
                  "w-32 h-32 rounded-full bg-white/20 flex items-center justify-center border-4 border-white/40",
                  isSpinning && "animate-spin"
                )}>
                  {spinResult !== null ? (
                    <div className="text-center">
                      <p className="text-3xl font-bold">{spinResult}</p>
                      <p className="text-sm text-white/80">points!</p>
                    </div>
                  ) : (
                    <RotateCw className="w-12 h-12 text-white/80" />
                  )}
                </div>
              </div>

              <button
                onClick={spinWheel}
                disabled={hasSpunToday || isSpinning}
                className={cn(
                  'w-full py-3 rounded-xl font-semibold transition-all',
                  hasSpunToday || isSpinning
                    ? 'bg-white/20 text-white/60'
                    : 'bg-white text-purple-600 hover:bg-white/90'
                )}
              >
                {isSpinning ? 'Spinning...' : hasSpunToday ? 'Come back tomorrow!' : 'SPIN NOW'}
              </button>
            </section>

            {/* Share Data for Points */}
            <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Database className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">Share Data & Earn</h3>
                  <p className="text-sm text-gray-500">Contribute to health research</p>
                </div>
              </div>

              <div className="space-y-3">
                {[
                  { key: 'healthData', label: 'Health Records', points: 50, desc: 'Blood tests, vitals' },
                  { key: 'activityData', label: 'Activity Data', points: 30, desc: 'Steps, sleep, exercise' },
                  { key: 'locationData', label: 'Location Data', points: 20, desc: 'Anonymous location trends' }
                ].map(item => (
                  <div key={item.key} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                    <div>
                      <p className="font-medium text-gray-900">{item.label}</p>
                      <p className="text-xs text-gray-500">{item.desc}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-green-600 font-medium">+{item.points} pts</span>
                      <button
                        onClick={() => toggleDataSharing(item.key as keyof typeof dataSharing)}
                        className={cn(
                          'w-12 h-6 rounded-full transition-colors',
                          dataSharing[item.key as keyof typeof dataSharing]
                            ? 'bg-primary'
                            : 'bg-gray-300'
                        )}
                      >
                        <div className={cn(
                          'w-5 h-5 bg-white rounded-full shadow transition-transform',
                          dataSharing[item.key as keyof typeof dataSharing]
                            ? 'translate-x-6'
                            : 'translate-x-0.5'
                        )} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Play to Earn - Sponsor Tasks */}
            <section>
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                  <Gamepad2 className="w-5 h-5 text-primary" />
                  Play to Earn
                </h3>
              </div>

              <div className="space-y-3">
                {tasks.map(task => (
                  <div
                    key={task.id}
                    className={cn(
                      'bg-white rounded-2xl border border-gray-100 shadow-sm p-4',
                      task.completed && 'opacity-60'
                    )}
                  >
                    <div className="flex items-center gap-4">
                      <div className={cn(
                        'w-12 h-12 rounded-xl flex items-center justify-center',
                        task.type === 'visit' ? 'bg-blue-100' : 'bg-green-100'
                      )}>
                        <ExternalLink className={cn(
                          'w-5 h-5',
                          task.type === 'visit' ? 'text-blue-600' : 'text-green-600'
                        )} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-gray-900">{task.title}</p>
                        <p className="text-sm text-gray-500">{task.description}</p>
                        <p className="text-xs text-primary mt-1">Sponsored by {task.sponsor}</p>
                      </div>
                      <button
                        onClick={() => completeTask(task.id)}
                        disabled={task.completed}
                        className={cn(
                          'px-3 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-1',
                          task.completed
                            ? 'bg-gray-100 text-gray-400'
                            : 'bg-primary text-white hover:bg-primary/90'
                        )}
                      >
                        {task.completed ? (
                          <><Check className="w-4 h-4" /> Done</>
                        ) : (
                          <>+{task.points} pts</>
                        )}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </>
        )}

        {/* REDEEM TAB */}
        {activeTab === 'redeem' && (
          <>
            {/* Gift Cards */}
            <section>
              <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <Gift className="w-5 h-5 text-primary" />
                Gift Cards
              </h3>
              <p className="text-sm text-gray-500 mb-4">
                Limited quantity! First come first serve. 🏃‍♂️
              </p>

              <div className="space-y-3">
                {giftCards.map(card => (
                  <div
                    key={card.id}
                    className="bg-gradient-to-r from-slate-600 to-slate-700 rounded-2xl overflow-hidden"
                  >
                    <div className="flex">
                      <div className="w-32 h-28 bg-slate-500 flex items-center justify-center p-4">
                        <span className="text-white font-bold text-lg">{card.brand}</span>
                      </div>
                      <div className="flex-1 p-4 text-white">
                        <p className="font-semibold">{card.name}</p>
                        <div className="flex items-center gap-2 mt-1">
                          {points >= card.pointsCost ? (
                            <button
                              onClick={() => redeemGiftCard(card)}
                              className="px-3 py-1 bg-white text-slate-700 rounded-lg text-sm font-medium"
                            >
                              Redeem
                            </button>
                          ) : (
                            <Lock className="w-4 h-4 text-white/60" />
                          )}
                          <span className="text-sm text-white/80">{card.pointsCost} pts</span>
                        </div>
                        <p className="text-xs text-white/60 mt-2">
                          {card.available} available {card.availableAt && `on ${card.availableAt}`}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Donate to Charity */}
            <section>
              <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <Heart className="w-5 h-5 text-red-500" />
                Donate to Charity
              </h3>
              <p className="text-sm text-gray-500 mb-4">
                Turn your points into real impact. 💫
              </p>

              <div className="grid grid-cols-2 gap-3">
                {charities.map(charity => (
                  <div
                    key={charity.id}
                    className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4"
                  >
                    <div className={cn(
                      'w-12 h-12 rounded-xl flex items-center justify-center text-2xl mb-3',
                      charity.color
                    )}>
                      {charity.image}
                    </div>
                    <p className="font-medium text-gray-900 text-sm">{charity.name}</p>
                    <p className="text-xs text-gray-500 mb-3">{charity.description}</p>
                    <button
                      onClick={() => donateToCharity(charity)}
                      disabled={points < charity.pointsCost}
                      className={cn(
                        'w-full py-2 rounded-lg text-sm font-medium transition-all',
                        points >= charity.pointsCost
                          ? 'bg-primary text-white hover:bg-primary/90'
                          : 'bg-gray-100 text-gray-400'
                      )}
                    >
                      Donate {charity.pointsCost} pts
                    </button>
                  </div>
                ))}
              </div>
            </section>
          </>
        )}

        {/* ACTIVITY TAB */}
        {activeTab === 'activity' && (
          <section>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-500" />
                Points History
              </h3>
            </div>

            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm divide-y divide-gray-100">
              {activity.map(item => (
                <div key={item.id} className="flex items-center gap-4 p-4">
                  <div className={cn(
                    'w-10 h-10 rounded-xl flex items-center justify-center',
                    item.points > 0 ? 'bg-green-100' : 'bg-red-100'
                  )}>
                    {item.type === 'daily' && <Calendar className="w-5 h-5 text-amber-600" />}
                    {item.type === 'spin' && <Sparkles className="w-5 h-5 text-purple-600" />}
                    {item.type === 'task' && <Gamepad2 className="w-5 h-5 text-blue-600" />}
                    {item.type === 'data' && <Database className="w-5 h-5 text-cyan-600" />}
                    {item.type === 'redeem' && <Gift className="w-5 h-5 text-red-600" />}
                    {item.type === 'donate' && <Heart className="w-5 h-5 text-pink-600" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900">{item.description}</p>
                    <p className="text-xs text-gray-500">{new Date(item.date).toLocaleDateString()}</p>
                  </div>
                  <span className={cn(
                    'font-semibold',
                    item.points > 0 ? 'text-green-600' : 'text-red-500'
                  )}>
                    {item.points > 0 ? '+' : ''}{item.points}
                  </span>
                </div>
              ))}
            </div>
          </section>
        )}
      </main>

      <BottomNav />
    </div>
  );
}
