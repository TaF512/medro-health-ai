import { useState } from 'react';
import { useNavigate } from 'react-router';
import { 
  ArrowRight, ArrowLeft, Loader2, Stethoscope, ShieldCheck, 
  Globe, Upload, Check, AlertTriangle, GraduationCap, FileText
} from 'lucide-react';
import { cn } from '@/react-app/lib/utils';
import { countries, Country } from '@/react-app/data/countries';
import { specialties } from '@/react-app/data/doctors';

type Scope = 'guidance_only' | 'licensed_clinical';

interface DoctorFormData {
  fullName: string;
  specialty: string;
  languages: string[];
  bio: string;
  priceAmount: number;
  priceCurrency: string;
  scope: Scope;
  licensedCountries: string[];
  licenseFile: File | null;
}

const languageOptions = [
  'English', 'Spanish', 'French', 'German', 'Arabic', 'Hindi', 
  'Bengali', 'Portuguese', 'Chinese', 'Japanese', 'Korean'
];

export default function DoctorOnboardingPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState<DoctorFormData>({
    fullName: '',
    specialty: '',
    languages: ['English'],
    bio: '',
    priceAmount: 50,
    priceCurrency: 'GBP',
    scope: 'guidance_only',
    licensedCountries: [],
    licenseFile: null,
  });
  const [showCountryPicker, setShowCountryPicker] = useState(false);
  const [countrySearch, setCountrySearch] = useState('');

  const filteredCountries = countries.filter(c => 
    c.name.toLowerCase().includes(countrySearch.toLowerCase()) &&
    !formData.licensedCountries.includes(c.code)
  );

  const addLicensedCountry = (country: Country) => {
    setFormData(prev => ({
      ...prev,
      licensedCountries: [...prev.licensedCountries, country.code]
    }));
    setShowCountryPicker(false);
    setCountrySearch('');
  };

  const removeLicensedCountry = (code: string) => {
    setFormData(prev => ({
      ...prev,
      licensedCountries: prev.licensedCountries.filter(c => c !== code)
    }));
  };

  const toggleLanguage = (lang: string) => {
    setFormData(prev => ({
      ...prev,
      languages: prev.languages.includes(lang)
        ? prev.languages.filter(l => l !== lang)
        : [...prev.languages, lang]
    }));
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      const res = await fetch('/api/doctor/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: formData.fullName,
          specialty: formData.specialty,
          languages: formData.languages,
          bio: formData.bio,
          priceAmount: formData.priceAmount,
          priceCurrency: formData.priceCurrency,
          scope: formData.scope,
          licensedCountries: formData.licensedCountries,
        }),
      });

      if (res.ok) {
        navigate('/doctor/dashboard');
      }
    } catch (error) {
      console.error('Failed to save profile:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const canProceedStep1 = formData.fullName && formData.specialty;
  const canProceedStep2 = true;
  const canSubmit = formData.scope === 'guidance_only' || formData.licensedCountries.length > 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Progress Header */}
      <div className="sticky top-0 bg-white/80 backdrop-blur-sm border-b border-gray-100 px-6 py-4 z-10">
        <div className="max-w-lg mx-auto">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-500">Step {step} of 3</span>
            <span className="text-sm font-medium text-indigo-600">
              {step === 1 ? 'Basic Info' : step === 2 ? 'Practice Scope' : 'Verification'}
            </span>
          </div>
          <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-300"
              style={{ width: `${(step / 3) * 100}%` }}
            />
          </div>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-6 py-8">
        {/* Step 1: Basic Info */}
        {step === 1 && (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Stethoscope className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">Set Up Your Profile</h1>
              <p className="text-gray-600 mt-2">Tell patients about yourself</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
              <input
                type="text"
                value={formData.fullName}
                onChange={(e) => setFormData(prev => ({ ...prev, fullName: e.target.value }))}
                placeholder="Dr. John Smith"
                className="w-full p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Specialty</label>
              <select
                value={formData.specialty}
                onChange={(e) => setFormData(prev => ({ ...prev, specialty: e.target.value }))}
                className="w-full p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none bg-white"
              >
                <option value="">Select your specialty</option>
                {specialties.map(s => (
                  <option key={s.id} value={s.name}>{s.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Languages</label>
              <div className="flex flex-wrap gap-2">
                {languageOptions.map(lang => (
                  <button
                    key={lang}
                    onClick={() => toggleLanguage(lang)}
                    className={cn(
                      "px-3 py-1.5 rounded-full text-sm font-medium transition-colors",
                      formData.languages.includes(lang)
                        ? "bg-indigo-100 text-indigo-700 border-2 border-indigo-200"
                        : "bg-gray-100 text-gray-600 border-2 border-transparent hover:bg-gray-200"
                    )}
                  >
                    {lang}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Bio</label>
              <textarea
                value={formData.bio}
                onChange={(e) => setFormData(prev => ({ ...prev, bio: e.target.value }))}
                placeholder="Tell patients about your experience and approach to care..."
                rows={4}
                className="w-full p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none resize-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Consultation Fee</label>
                <input
                  type="number"
                  value={formData.priceAmount}
                  onChange={(e) => setFormData(prev => ({ ...prev, priceAmount: Number(e.target.value) }))}
                  className="w-full p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Currency</label>
                <select
                  value={formData.priceCurrency}
                  onChange={(e) => setFormData(prev => ({ ...prev, priceCurrency: e.target.value }))}
                  className="w-full p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none bg-white"
                >
                  <option value="GBP">£ GBP</option>
                  <option value="USD">$ USD</option>
                  <option value="EUR">€ EUR</option>
                  <option value="BDT">৳ BDT</option>
                  <option value="INR">₹ INR</option>
                </select>
              </div>
            </div>

            <button
              onClick={() => setStep(2)}
              disabled={!canProceedStep1}
              className={cn(
                "w-full py-4 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all",
                canProceedStep1
                  ? "bg-gradient-to-r from-indigo-500 to-purple-600 text-white hover:opacity-90"
                  : "bg-gray-200 text-gray-500 cursor-not-allowed"
              )}
            >
              <span>Continue</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        )}

        {/* Step 2: Practice Scope */}
        {step === 2 && (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Globe className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">Practice Scope</h1>
              <p className="text-gray-600 mt-2">Define how you'll provide consultations</p>
            </div>

            <div className="space-y-4">
              <button
                onClick={() => setFormData(prev => ({ ...prev, scope: 'guidance_only' }))}
                className={cn(
                  "w-full p-5 rounded-2xl border-2 text-left transition-all",
                  formData.scope === 'guidance_only'
                    ? "border-indigo-500 bg-indigo-50"
                    : "border-gray-200 hover:border-gray-300"
                )}
              >
                <div className="flex items-start gap-4">
                  <div className={cn(
                    "w-12 h-12 rounded-xl flex items-center justify-center",
                    formData.scope === 'guidance_only'
                      ? "bg-indigo-500 text-white"
                      : "bg-gray-100 text-gray-600"
                  )}>
                    <GraduationCap className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900">General Health Guidance</h3>
                    <p className="text-sm text-gray-500 mt-1">
                      Provide educational information, wellness advice, and general health guidance. 
                      No prescriptions or clinical diagnoses.
                    </p>
                    <div className="mt-3 flex items-center gap-2 text-xs text-amber-600 bg-amber-50 px-3 py-1.5 rounded-full w-fit">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      <span>Guidance only • No verification required</span>
                    </div>
                  </div>
                </div>
              </button>

              <button
                onClick={() => setFormData(prev => ({ ...prev, scope: 'licensed_clinical' }))}
                className={cn(
                  "w-full p-5 rounded-2xl border-2 text-left transition-all",
                  formData.scope === 'licensed_clinical'
                    ? "border-indigo-500 bg-indigo-50"
                    : "border-gray-200 hover:border-gray-300"
                )}
              >
                <div className="flex items-start gap-4">
                  <div className={cn(
                    "w-12 h-12 rounded-xl flex items-center justify-center",
                    formData.scope === 'licensed_clinical'
                      ? "bg-indigo-500 text-white"
                      : "bg-gray-100 text-gray-600"
                  )}>
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900">Licensed Clinical Practice</h3>
                    <p className="text-sm text-gray-500 mt-1">
                      Provide full clinical consultations, diagnoses, and prescriptions for 
                      patients in countries where you're licensed.
                    </p>
                    <div className="mt-3 flex items-center gap-2 text-xs text-green-600 bg-green-50 px-3 py-1.5 rounded-full w-fit">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Full scope • License verification required</span>
                    </div>
                  </div>
                </div>
              </button>
            </div>

            {formData.scope === 'licensed_clinical' && (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-amber-500 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-amber-800">Important Notice</h4>
                    <p className="text-sm text-amber-700 mt-1">
                      You must hold valid medical licenses in the countries where you provide 
                      clinical services. Patients from unlicensed regions will only receive 
                      general guidance.
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="flex gap-3">
              <button
                onClick={() => setStep(1)}
                className="flex-1 py-4 rounded-xl font-semibold border-2 border-gray-200 text-gray-700 hover:bg-gray-50 flex items-center justify-center gap-2"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Back</span>
              </button>
              <button
                onClick={() => setStep(3)}
                disabled={!canProceedStep2}
                className="flex-1 py-4 rounded-xl font-semibold bg-gradient-to-r from-indigo-500 to-purple-600 text-white hover:opacity-90 flex items-center justify-center gap-2"
              >
                <span>Continue</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Verification */}
        {step === 3 && (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">
                {formData.scope === 'guidance_only' ? 'Almost Done!' : 'License Verification'}
              </h1>
              <p className="text-gray-600 mt-2">
                {formData.scope === 'guidance_only' 
                  ? 'Review and complete your profile'
                  : 'Add your licensed countries and upload documents'
                }
              </p>
            </div>

            {formData.scope === 'licensed_clinical' && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Licensed Countries
                  </label>
                  
                  <div className="flex flex-wrap gap-2 mb-3">
                    {formData.licensedCountries.map(code => {
                      const country = countries.find(c => c.code === code);
                      return country ? (
                        <span
                          key={code}
                          className="inline-flex items-center gap-2 px-3 py-1.5 bg-indigo-100 text-indigo-700 rounded-full text-sm"
                        >
                          <span>{country.flag}</span>
                          <span>{country.name}</span>
                          <button
                            onClick={() => removeLicensedCountry(code)}
                            className="ml-1 text-indigo-400 hover:text-indigo-600"
                          >
                            ×
                          </button>
                        </span>
                      ) : null;
                    })}
                  </div>

                  <div className="relative">
                    <button
                      onClick={() => setShowCountryPicker(!showCountryPicker)}
                      className="w-full p-4 border-2 border-dashed border-gray-300 rounded-xl text-gray-500 hover:border-indigo-300 hover:text-indigo-600 transition-colors flex items-center justify-center gap-2"
                    >
                      <Globe className="w-5 h-5" />
                      <span>Add Licensed Country</span>
                    </button>

                    {showCountryPicker && (
                      <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl border border-gray-200 shadow-xl z-50 max-h-60 overflow-hidden">
                        <div className="p-3 border-b border-gray-100 sticky top-0 bg-white">
                          <input
                            type="text"
                            value={countrySearch}
                            onChange={(e) => setCountrySearch(e.target.value)}
                            placeholder="Search countries..."
                            className="w-full px-4 py-2 bg-gray-50 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                            autoFocus
                          />
                        </div>
                        <div className="overflow-y-auto max-h-48">
                          {filteredCountries.map(country => (
                            <button
                              key={country.code}
                              onClick={() => addLicensedCountry(country)}
                              className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 transition-colors text-left"
                            >
                              <span className="text-xl">{country.flag}</span>
                              <span className="text-gray-900">{country.name}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Upload License Documents
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-indigo-300 transition-colors cursor-pointer">
                    <Upload className="w-10 h-10 text-gray-400 mx-auto mb-3" />
                    <p className="text-gray-600 font-medium">Click to upload</p>
                    <p className="text-sm text-gray-400 mt-1">PDF, JPG, or PNG (max 10MB)</p>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    Documents will be reviewed by our team within 24-48 hours.
                  </p>
                </div>
              </>
            )}

            {/* Summary */}
            <div className="bg-gray-50 rounded-xl p-4 space-y-3">
              <h4 className="font-medium text-gray-900">Profile Summary</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Name</span>
                  <span className="text-gray-900">{formData.fullName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Specialty</span>
                  <span className="text-gray-900">{formData.specialty}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Fee</span>
                  <span className="text-gray-900">{formData.priceCurrency} {formData.priceAmount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Scope</span>
                  <span className={cn(
                    "font-medium",
                    formData.scope === 'licensed_clinical' ? "text-green-600" : "text-amber-600"
                  )}>
                    {formData.scope === 'licensed_clinical' ? 'Licensed Clinical' : 'Guidance Only'}
                  </span>
                </div>
                {formData.licensedCountries.length > 0 && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Licensed In</span>
                    <span className="text-gray-900">
                      {formData.licensedCountries.map(c => countries.find(co => co.code === c)?.name).join(', ')}
                    </span>
                  </div>
                )}
              </div>
            </div>

            {formData.scope === 'licensed_clinical' && formData.licensedCountries.length === 0 && (
              <div className="bg-red-50 border border-red-200 rounded-xl p-4">
                <p className="text-sm text-red-700">
                  Please add at least one licensed country to proceed with clinical practice scope.
                </p>
              </div>
            )}

            <div className="flex gap-3">
              <button
                onClick={() => setStep(2)}
                className="flex-1 py-4 rounded-xl font-semibold border-2 border-gray-200 text-gray-700 hover:bg-gray-50 flex items-center justify-center gap-2"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Back</span>
              </button>
              <button
                onClick={handleSubmit}
                disabled={!canSubmit || isSubmitting}
                className={cn(
                  "flex-1 py-4 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all",
                  canSubmit
                    ? "bg-gradient-to-r from-indigo-500 to-purple-600 text-white hover:opacity-90"
                    : "bg-gray-200 text-gray-500 cursor-not-allowed"
                )}
              >
                {isSubmitting ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <Check className="w-5 h-5" />
                    <span>Complete Setup</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
