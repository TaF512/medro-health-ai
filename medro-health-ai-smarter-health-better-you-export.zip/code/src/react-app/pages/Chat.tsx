import { useState, useRef, useEffect } from 'react';
import { Send, Paperclip, Mic, MicOff, Globe, AlertTriangle, Sparkles, X, FileText } from 'lucide-react';
import Header from '@/react-app/components/Header';
import BottomNav from '@/react-app/components/BottomNav';
import { cn } from '@/react-app/lib/utils';

const quickPrompts = [
  { icon: '🩺', label: 'Explain my symptoms' },
  { icon: '📄', label: 'Explain my report' },
  { icon: '🥗', label: 'Diet plan' },
  { icon: '🏃', label: 'Workout tips' },
  { icon: '💊', label: 'Medication questions' },
  { icon: '😴', label: 'Sleep advice' },
];

const languages = [
  { code: 'en', name: 'English' },
  { code: 'bn', name: 'বাংলা' },
  { code: 'ar', name: 'العربية' },
];

interface Attachment {
  id: string;
  file: File;
  preview: string;
  type: 'image' | 'document';
}

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  attachments?: { name: string; preview?: string; type: 'image' | 'document' }[];
}

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: "Hello! I'm your AI health assistant. I can help you understand symptoms, explain medical reports, suggest diet plans, and answer general health questions. You can also attach images of reports or prescriptions for me to analyze. How can I help you today?",
      role: 'assistant',
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [isTyping, setIsTyping] = useState(false);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  // Check for speech recognition support
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      setSpeechSupported(true);
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = selectedLanguage === 'bn' ? 'bn-BD' : selectedLanguage === 'ar' ? 'ar-SA' : 'en-US';

      recognitionRef.current.onresult = (event: SpeechRecognitionEvent) => {
        let transcript = '';
        for (let i = 0; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        setInput(transcript);
      };

      recognitionRef.current.onend = () => {
        setIsRecording(false);
      };

      recognitionRef.current.onerror = () => {
        setIsRecording(false);
      };
    }
  }, [selectedLanguage]);

  // Update recognition language when selected language changes
  useEffect(() => {
    if (recognitionRef.current) {
      recognitionRef.current.lang = selectedLanguage === 'bn' ? 'bn-BD' : selectedLanguage === 'ar' ? 'ar-SA' : 'en-US';
    }
  }, [selectedLanguage]);

  const handleAttachClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      const isImage = file.type.startsWith('image/');
      const reader = new FileReader();
      
      reader.onload = (event) => {
        const newAttachment: Attachment = {
          id: Date.now().toString() + Math.random(),
          file,
          preview: event.target?.result as string,
          type: isImage ? 'image' : 'document',
        };
        setAttachments(prev => [...prev, newAttachment]);
      };

      if (isImage) {
        reader.readAsDataURL(file);
      } else {
        // For documents, just store the name
        const newAttachment: Attachment = {
          id: Date.now().toString() + Math.random(),
          file,
          preview: file.name,
          type: 'document',
        };
        setAttachments(prev => [...prev, newAttachment]);
      }
    });

    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeAttachment = (id: string) => {
    setAttachments(prev => prev.filter(a => a.id !== id));
  };

  const toggleRecording = () => {
    if (!speechSupported || !recognitionRef.current) {
      alert('Speech recognition is not supported in your browser. Please try Chrome or Edge.');
      return;
    }

    if (isRecording) {
      recognitionRef.current.stop();
      setIsRecording(false);
    } else {
      setIsRecording(true);
      recognitionRef.current.start();
    }
  };

  const handleSend = async () => {
    if (!input.trim() && attachments.length === 0) return;

    // Prepare attachment info for the message
    const messageAttachments = attachments.map(a => ({
      name: a.file.name,
      preview: a.type === 'image' ? a.preview : undefined,
      type: a.type,
    }));

    const userMessage: Message = {
      id: Date.now().toString(),
      content: input || (attachments.length > 0 ? `Attached ${attachments.length} file(s) for analysis` : ''),
      role: 'user',
      timestamp: new Date(),
      attachments: messageAttachments.length > 0 ? messageAttachments : undefined,
    };

    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    
    // Build the message content for the AI
    let aiMessageContent = input;
    if (attachments.length > 0) {
      const attachmentDescriptions = attachments.map(a => {
        if (a.type === 'image') {
          return `[User attached an image: ${a.file.name}]`;
        }
        return `[User attached a document: ${a.file.name}]`;
      }).join('\n');
      aiMessageContent = `${attachmentDescriptions}\n\n${input}`.trim();
    }

    setInput('');
    setAttachments([]);
    setIsTyping(true);

    try {
      const history = updatedMessages
        .filter(m => m.id !== '1')
        .slice(0, -1)
        .map(m => ({
          role: m.role,
          content: m.content
        }));

      // Prepare images for Gemini vision
      const images = attachments
        .filter(a => a.type === 'image')
        .map(a => ({
          data: a.preview.split(',')[1], // Remove data:image/xxx;base64, prefix
          mimeType: a.file.type,
        }));

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: aiMessageContent || 'Please analyze this image.',
          history,
          images: images.length > 0 ? images : undefined,
        }),
      });

      const data = await response.json();

      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: data.response || "I'm sorry, I couldn't process your request. Please try again.",
        role: 'assistant',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, aiResponse]);
    } catch {
      const errorResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: "I'm having trouble connecting right now. Please check your internet connection and try again.",
        role: 'assistant',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorResponse]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleQuickPrompt = (prompt: string) => {
    setInput(prompt);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24 flex flex-col">
      <Header title="AI Health Chat" />
      
      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*,.pdf,.doc,.docx"
        multiple
        onChange={handleFileChange}
        className="hidden"
      />
      
      <main className="flex-1 flex flex-col max-w-lg mx-auto w-full">
        {/* Safety Banner */}
        <div className="px-4 py-2">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex items-start gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-800">
              <span className="font-semibold">Important:</span> This AI provides general health guidance only. For emergencies, call local services. Always consult a doctor for medical advice.
            </p>
          </div>
        </div>

        {/* Language Selector */}
        <div className="px-4 py-2">
          <div className="flex items-center gap-2 overflow-x-auto">
            <Globe className="w-4 h-4 text-gray-500 flex-shrink-0" />
            {languages.map((lang) => (
              <button
                key={lang.code}
                onClick={() => setSelectedLanguage(lang.code)}
                className={cn(
                  'px-3 py-1.5 rounded-full text-sm font-medium transition-colors',
                  selectedLanguage === lang.code
                    ? 'bg-primary text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                )}
              >
                {lang.name}
              </button>
            ))}
          </div>
        </div>

        {/* Quick Prompts */}
        <div className="px-4 py-2">
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {quickPrompts.map((prompt) => (
              <button
                key={prompt.label}
                onClick={() => handleQuickPrompt(prompt.label)}
                className="flex-shrink-0 flex items-center gap-2 px-3 py-2 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors"
              >
                <span>{prompt.icon}</span>
                <span className="text-sm font-medium text-gray-700">{prompt.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={cn(
                'flex',
                message.role === 'user' ? 'justify-end' : 'justify-start'
              )}
            >
              <div
                className={cn(
                  'max-w-[85%] rounded-2xl px-4 py-3',
                  message.role === 'user'
                    ? 'bg-primary text-white rounded-br-md'
                    : 'bg-white border border-gray-200 text-gray-800 rounded-bl-md'
                )}
              >
                {message.role === 'assistant' && (
                  <div className="flex items-center gap-1.5 mb-1.5">
                    <Sparkles className="w-4 h-4 text-primary" />
                    <span className="text-xs font-semibold text-primary">Health AI</span>
                  </div>
                )}
                
                {/* Attachments */}
                {message.attachments && message.attachments.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-2">
                    {message.attachments.map((att, idx) => (
                      <div key={idx} className={cn(
                        "rounded-lg overflow-hidden",
                        message.role === 'user' ? 'bg-white/20' : 'bg-gray-100'
                      )}>
                        {att.type === 'image' && att.preview ? (
                          <img src={att.preview} alt={att.name} className="w-20 h-20 object-cover" />
                        ) : (
                          <div className="flex items-center gap-2 px-3 py-2">
                            <FileText className={cn(
                              "w-4 h-4",
                              message.role === 'user' ? 'text-white' : 'text-gray-600'
                            )} />
                            <span className={cn(
                              "text-xs",
                              message.role === 'user' ? 'text-white' : 'text-gray-600'
                            )}>{att.name}</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
                
                <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
                <p className={cn(
                  'text-xs mt-2',
                  message.role === 'user' ? 'text-white/70' : 'text-gray-400'
                )}>
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-white border border-gray-200 rounded-2xl rounded-bl-md px-4 py-3">
                <div className="flex items-center gap-1.5 mb-2">
                  <Sparkles className="w-4 h-4 text-primary" />
                  <span className="text-xs font-semibold text-primary">Health AI</span>
                </div>
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-2 h-2 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-2 h-2 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Attachment Preview */}
        {attachments.length > 0 && (
          <div className="px-4 py-2 bg-gray-50 border-t border-gray-200">
            <div className="flex gap-2 overflow-x-auto">
              {attachments.map((att) => (
                <div key={att.id} className="relative flex-shrink-0">
                  {att.type === 'image' ? (
                    <div className="relative">
                      <img src={att.preview} alt={att.file.name} className="w-16 h-16 rounded-lg object-cover" />
                      <button
                        onClick={() => removeAttachment(att.id)}
                        className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ) : (
                    <div className="relative bg-white border border-gray-200 rounded-lg px-3 py-2 flex items-center gap-2">
                      <FileText className="w-4 h-4 text-gray-500" />
                      <span className="text-xs text-gray-600 max-w-[100px] truncate">{att.file.name}</span>
                      <button
                        onClick={() => removeAttachment(att.id)}
                        className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Input Area */}
        <div className="px-4 py-3 bg-white border-t border-gray-200">
          {/* Recording indicator */}
          {isRecording && (
            <div className="flex items-center gap-2 mb-2 text-red-500">
              <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
              <span className="text-sm">Listening... Speak now</span>
            </div>
          )}
          
          <div className="flex items-center gap-2">
            <button 
              onClick={handleAttachClick}
              className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
              title="Attach image or document"
            >
              <Paperclip className="w-5 h-5 text-gray-600" />
            </button>
            <div className="flex-1 relative">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Type your health question..."
                className="w-full px-4 py-2.5 bg-gray-100 rounded-xl text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary/20"
              />
            </div>
            <button 
              onClick={toggleRecording}
              className={cn(
                "p-2 rounded-full transition-colors",
                isRecording 
                  ? "bg-red-500 text-white animate-pulse" 
                  : speechSupported 
                    ? "bg-gray-100 hover:bg-gray-200 text-gray-600"
                    : "bg-gray-100 text-gray-300 cursor-not-allowed"
              )}
              title={speechSupported ? (isRecording ? "Stop recording" : "Start voice input") : "Speech not supported"}
            >
              {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>
            <button
              onClick={handleSend}
              disabled={!input.trim() && attachments.length === 0}
              className={cn(
                'p-2.5 rounded-full transition-colors',
                input.trim() || attachments.length > 0
                  ? 'bg-primary text-white hover:bg-primary/90'
                  : 'bg-gray-100 text-gray-400'
              )}
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </main>
      
      <BottomNav />
    </div>
  );
}
