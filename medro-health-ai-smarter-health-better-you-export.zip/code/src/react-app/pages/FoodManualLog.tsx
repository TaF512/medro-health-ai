import { useState } from 'react';
import { useNavigate } from 'react-router';
import { 
  ArrowLeft, 
  Search, 
  Plus,
  Minus,
  Star,
  Clock,
  X,
  Save,
  ChevronRight
} from 'lucide-react';

interface FoodItem {
  id: string;
  name: string;
  brand?: string;
  servingSize: string;
  servingUnit: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  isFavorite?: boolean;
}

interface MealEntry {
  food: FoodItem;
  quantity: number;
}

const mealTypes = ['Breakfast', 'Lunch', 'Dinner', 'Snack'] as const;
const servingUnits = ['g', 'ml', 'piece', 'cup', 'tbsp', 'oz'];

// Mock food database
const foodDatabase: FoodItem[] = [
  { id: '1', name: 'White Rice (cooked)', servingSize: '100', servingUnit: 'g', calories: 130, protein: 2.7, carbs: 28, fat: 0.3 },
  { id: '2', name: 'Chicken Breast (grilled)', servingSize: '100', servingUnit: 'g', calories: 165, protein: 31, carbs: 0, fat: 3.6 },
  { id: '3', name: 'Banana', servingSize: '1', servingUnit: 'piece', calories: 105, protein: 1.3, carbs: 27, fat: 0.4 },
  { id: '4', name: 'Egg (boiled)', servingSize: '1', servingUnit: 'piece', calories: 78, protein: 6, carbs: 0.6, fat: 5 },
  { id: '5', name: 'Oatmeal', servingSize: '40', servingUnit: 'g', calories: 150, protein: 5, carbs: 27, fat: 3 },
  { id: '6', name: 'Apple', servingSize: '1', servingUnit: 'piece', calories: 95, protein: 0.5, carbs: 25, fat: 0.3 },
  { id: '7', name: 'Salmon (baked)', servingSize: '100', servingUnit: 'g', calories: 208, protein: 20, carbs: 0, fat: 13 },
  { id: '8', name: 'Broccoli (steamed)', servingSize: '100', servingUnit: 'g', calories: 35, protein: 2.4, carbs: 7, fat: 0.4 },
  { id: '9', name: 'Greek Yogurt', servingSize: '150', servingUnit: 'g', calories: 100, protein: 17, carbs: 6, fat: 0.7 },
  { id: '10', name: 'Almonds', servingSize: '30', servingUnit: 'g', calories: 173, protein: 6, carbs: 6, fat: 15 },
  { id: '11', name: 'Biryani (chicken)', servingSize: '250', servingUnit: 'g', calories: 450, protein: 22, carbs: 55, fat: 16 },
  { id: '12', name: 'Dal (lentils)', servingSize: '150', servingUnit: 'g', calories: 180, protein: 12, carbs: 30, fat: 1 },
  { id: '13', name: 'Roti/Chapati', servingSize: '1', servingUnit: 'piece', calories: 104, protein: 3, carbs: 18, fat: 3 },
  { id: '14', name: 'Naan Bread', servingSize: '1', servingUnit: 'piece', calories: 262, protein: 9, carbs: 45, fat: 5 },
  { id: '15', name: 'Milk (whole)', servingSize: '250', servingUnit: 'ml', calories: 150, protein: 8, carbs: 12, fat: 8 },
];

const recentFoods: FoodItem[] = foodDatabase.slice(0, 5);
const favoriteFoods: FoodItem[] = foodDatabase.slice(2, 6).map(f => ({ ...f, isFavorite: true }));

export default function FoodManualLog() {
  const navigate = useNavigate();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMealType, setSelectedMealType] = useState<typeof mealTypes[number]>('Lunch');
  const [mealEntries, setMealEntries] = useState<MealEntry[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedFood, setSelectedFood] = useState<FoodItem | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [showCustomFoodModal, setShowCustomFoodModal] = useState(false);
  const [customFood, setCustomFood] = useState({
    name: '',
    servingSize: '100',
    servingUnit: 'g',
    calories: '',
    protein: '',
    carbs: '',
    fat: ''
  });

  const searchResults = searchQuery.length > 0
    ? foodDatabase.filter(f => f.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : [];

  const totals = mealEntries.reduce((acc, entry) => ({
    calories: acc.calories + entry.food.calories * entry.quantity,
    protein: acc.protein + entry.food.protein * entry.quantity,
    carbs: acc.carbs + entry.food.carbs * entry.quantity,
    fat: acc.fat + entry.food.fat * entry.quantity,
  }), { calories: 0, protein: 0, carbs: 0, fat: 0 });

  const handleSelectFood = (food: FoodItem) => {
    setSelectedFood(food);
    setQuantity(1);
    setShowAddModal(true);
  };

  const handleAddToMeal = () => {
    if (!selectedFood) return;
    setMealEntries([...mealEntries, { food: selectedFood, quantity }]);
    setShowAddModal(false);
    setSelectedFood(null);
    setSearchQuery('');
  };

  const handleRemoveEntry = (index: number) => {
    setMealEntries(mealEntries.filter((_, i) => i !== index));
  };

  const handleSaveCustomFood = () => {
    const newFood: FoodItem = {
      id: `custom-${Date.now()}`,
      name: customFood.name,
      servingSize: customFood.servingSize,
      servingUnit: customFood.servingUnit,
      calories: parseInt(customFood.calories) || 0,
      protein: parseFloat(customFood.protein) || 0,
      carbs: parseFloat(customFood.carbs) || 0,
      fat: parseFloat(customFood.fat) || 0,
    };
    setMealEntries([...mealEntries, { food: newFood, quantity: 1 }]);
    setShowCustomFoodModal(false);
    setCustomFood({ name: '', servingSize: '100', servingUnit: 'g', calories: '', protein: '', carbs: '', fat: '' });
  };

  const saveMeal = () => {
    // TODO: Save to database/context
    navigate('/food', { state: { mealSaved: true } });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white pb-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-4 py-4 pb-6">
        <div className="flex items-center gap-3 mb-2">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-white/20 rounded-full transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-bold">Manual Food Log</h1>
        </div>
        <p className="text-blue-100 text-sm ml-10">Search or create custom foods</p>
      </div>

      <main className="px-4 -mt-3 max-w-lg mx-auto">
        {/* Meal Type Selector */}
        <div className="bg-white rounded-2xl shadow-lg p-4 mb-4">
          <p className="text-sm font-medium text-gray-700 mb-2">Meal Type</p>
          <div className="flex gap-2">
            {mealTypes.map(type => (
              <button
                key={type}
                onClick={() => setSelectedMealType(type)}
                className={`flex-1 py-2 px-2 rounded-lg text-sm font-medium transition-all ${
                  selectedMealType === type
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Search */}
        <div className="bg-white rounded-2xl shadow-lg p-4 mb-4">
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search food (e.g., biryani, banana, oats)"
              className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Search Results */}
          {searchQuery.length > 0 && (
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {searchResults.length > 0 ? (
                searchResults.map(food => (
                  <button
                    key={food.id}
                    onClick={() => handleSelectFood(food)}
                    className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-blue-50 transition-colors text-left"
                  >
                    <div>
                      <p className="font-medium text-gray-900">{food.name}</p>
                      <p className="text-xs text-gray-500">{food.servingSize}{food.servingUnit} • {food.calories} kcal</p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </button>
                ))
              ) : (
                <p className="text-sm text-gray-500 text-center py-4">No results found</p>
              )}
            </div>
          )}

          {/* Recent & Favorites */}
          {searchQuery.length === 0 && (
            <>
              <div className="mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-4 h-4 text-gray-500" />
                  <span className="text-sm font-medium text-gray-700">Recent</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {recentFoods.map(food => (
                    <button
                      key={food.id}
                      onClick={() => handleSelectFood(food)}
                      className="px-3 py-1.5 bg-gray-100 text-gray-700 rounded-full text-sm hover:bg-blue-100 transition-colors"
                    >
                      {food.name.split(' ')[0]}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Star className="w-4 h-4 text-amber-500" />
                  <span className="text-sm font-medium text-gray-700">Favorites</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {favoriteFoods.map(food => (
                    <button
                      key={food.id}
                      onClick={() => handleSelectFood(food)}
                      className="px-3 py-1.5 bg-amber-50 text-amber-700 rounded-full text-sm hover:bg-amber-100 transition-colors"
                    >
                      {food.name.split(' ')[0]}
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Create Custom Food */}
        <button
          onClick={() => setShowCustomFoodModal(true)}
          className="w-full bg-white rounded-xl shadow-sm border-2 border-dashed border-gray-200 p-4 mb-4 flex items-center justify-center gap-2 text-gray-600 hover:border-blue-300 hover:text-blue-600 transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span className="font-medium">Create Custom Food</span>
        </button>

        {/* Current Meal Items */}
        {mealEntries.length > 0 && (
          <div className="bg-white rounded-2xl shadow-lg p-4 mb-4">
            <h3 className="font-semibold text-gray-900 mb-3">{selectedMealType} Items</h3>
            <div className="space-y-3">
              {mealEntries.map((entry, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{entry.food.name}</p>
                    <p className="text-xs text-gray-500">
                      {entry.quantity} × {entry.food.servingSize}{entry.food.servingUnit} • {Math.round(entry.food.calories * entry.quantity)} kcal
                    </p>
                  </div>
                  <button
                    onClick={() => handleRemoveEntry(index)}
                    className="p-2 hover:bg-red-100 rounded-lg transition-colors"
                  >
                    <X className="w-4 h-4 text-red-500" />
                  </button>
                </div>
              ))}
            </div>

            {/* Totals */}
            <div className="mt-4 pt-4 border-t border-gray-100">
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold text-gray-900">Total</span>
                <span className="text-xl font-bold text-blue-600">{Math.round(totals.calories)} kcal</span>
              </div>
              <div className="flex items-center justify-between text-sm text-gray-600">
                <span>P: {Math.round(totals.protein)}g</span>
                <span>C: {Math.round(totals.carbs)}g</span>
                <span>F: {Math.round(totals.fat)}g</span>
              </div>
            </div>
          </div>
        )}

        {/* Save Button */}
        {mealEntries.length > 0 && (
          <button
            onClick={saveMeal}
            className="w-full py-4 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl font-semibold flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all"
          >
            <Save className="w-5 h-5" /> Save {selectedMealType}
          </button>
        )}

        {/* Add Food Modal */}
        {showAddModal && selectedFood && (
          <div className="fixed inset-0 bg-black/50 flex items-end z-50">
            <div className="bg-white w-full rounded-t-3xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold">{selectedFood.name}</h3>
                <button onClick={() => setShowAddModal(false)} className="p-2 hover:bg-gray-100 rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="bg-blue-50 rounded-xl p-4 mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-600">Per {selectedFood.servingSize}{selectedFood.servingUnit}</span>
                  <span className="font-bold text-blue-600">{selectedFood.calories} kcal</span>
                </div>
                <div className="flex items-center justify-between text-sm text-gray-600">
                  <span>Protein: {selectedFood.protein}g</span>
                  <span>Carbs: {selectedFood.carbs}g</span>
                  <span>Fat: {selectedFood.fat}g</span>
                </div>
              </div>

              <div className="flex items-center justify-center gap-6 mb-6">
                <button
                  onClick={() => setQuantity(Math.max(0.5, quantity - 0.5))}
                  className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors"
                >
                  <Minus className="w-5 h-5" />
                </button>
                <div className="text-center">
                  <p className="text-3xl font-bold text-gray-900">{quantity}</p>
                  <p className="text-sm text-gray-500">servings</p>
                </div>
                <button
                  onClick={() => setQuantity(quantity + 0.5)}
                  className="w-12 h-12 bg-blue-500 text-white rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors"
                >
                  <Plus className="w-5 h-5" />
                </button>
              </div>

              <div className="text-center mb-6 p-3 bg-gray-50 rounded-xl">
                <p className="text-sm text-gray-500">Total</p>
                <p className="text-2xl font-bold text-gray-900">{Math.round(selectedFood.calories * quantity)} kcal</p>
              </div>

              <button
                onClick={handleAddToMeal}
                className="w-full py-4 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl font-semibold"
              >
                Add to {selectedMealType}
              </button>
            </div>
          </div>
        )}

        {/* Custom Food Modal */}
        {showCustomFoodModal && (
          <div className="fixed inset-0 bg-black/50 flex items-end z-50">
            <div className="bg-white w-full rounded-t-3xl p-6 max-h-[85vh] overflow-y-auto">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold">Create Custom Food</h3>
                <button onClick={() => setShowCustomFoodModal(false)} className="p-2 hover:bg-gray-100 rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-1 block">Food Name</label>
                  <input
                    type="text"
                    value={customFood.name}
                    onChange={(e) => setCustomFood({ ...customFood, name: e.target.value })}
                    placeholder="e.g., Mom's Special Curry"
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1 block">Serving Size</label>
                    <input
                      type="number"
                      value={customFood.servingSize}
                      onChange={(e) => setCustomFood({ ...customFood, servingSize: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1 block">Unit</label>
                    <select
                      value={customFood.servingUnit}
                      onChange={(e) => setCustomFood({ ...customFood, servingUnit: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500"
                    >
                      {servingUnits.map(unit => (
                        <option key={unit} value={unit}>{unit}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700 mb-1 block">Calories</label>
                  <input
                    type="number"
                    value={customFood.calories}
                    onChange={(e) => setCustomFood({ ...customFood, calories: e.target.value })}
                    placeholder="0"
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1 block">Protein (g)</label>
                    <input
                      type="number"
                      value={customFood.protein}
                      onChange={(e) => setCustomFood({ ...customFood, protein: e.target.value })}
                      placeholder="0"
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1 block">Carbs (g)</label>
                    <input
                      type="number"
                      value={customFood.carbs}
                      onChange={(e) => setCustomFood({ ...customFood, carbs: e.target.value })}
                      placeholder="0"
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1 block">Fat (g)</label>
                    <input
                      type="number"
                      value={customFood.fat}
                      onChange={(e) => setCustomFood({ ...customFood, fat: e.target.value })}
                      placeholder="0"
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <button
                  onClick={handleSaveCustomFood}
                  disabled={!customFood.name || !customFood.calories}
                  className="w-full py-4 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl font-semibold disabled:opacity-50"
                >
                  Add Custom Food
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
