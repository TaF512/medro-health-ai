import { useState } from 'react';
import { useNavigate } from 'react-router';
import { 
  ArrowLeft, Plus, Calendar, Clock, MapPin, User, Phone,
  Bell, BellOff, Trash2, X, Check, Building2,
  Stethoscope, AlertCircle
} from 'lucide-react';
import { cn } from '@/react-app/lib/utils';
import BottomNav from '@/react-app/components/BottomNav';

interface NHSAppointment {
  id: string;
  type: 'gp' | 'hospital' | 'specialist' | 'vaccination' | 'screening';
  title: string;
  doctorName?: string;
  location: string;
  address?: string;
  date: string;
  time: string;
  notes?: string;
  reminder: boolean;
  status: 'upcoming' | 'completed' | 'cancelled';
  referenceNumber?: string;
}

const appointmentTypes = [
  { id: 'gp', name: 'GP Appointment', icon: Stethoscope, color: 'bg-blue-100 text-blue-600' },
  { id: 'hospital', name: 'Hospital Visit', icon: Building2, color: 'bg-purple-100 text-purple-600' },
  { id: 'specialist', name: 'Specialist', icon: User, color: 'bg-teal-100 text-teal-600' },
  { id: 'vaccination', name: 'Vaccination', icon: AlertCircle, color: 'bg-green-100 text-green-600' },
  { id: 'screening', name: 'Screening', icon: Calendar, color: 'bg-amber-100 text-amber-600' },
];

const initialAppointments: NHSAppointment[] = [
  {
    id: '1',
    type: 'gp',
    title: 'GP Check-up',
    doctorName: 'Dr. Sarah Thompson',
    location: 'Woodlands Health Centre',
    address: '123 High Street, London, N1 2AB',
    date: '2025-01-28',
    time: '09:30',
    reminder: true,
    status: 'upcoming',
    referenceNumber: 'NHS-2025-001234'
  },
  {
    id: '2',
    type: 'hospital',
    title: 'Blood Test',
    location: "Guy's Hospital",
    address: 'Great Maze Pond, London, SE1 9RT',
    date: '2025-02-05',
    time: '08:00',
    notes: 'Fasting required - no food 12 hours before',
    reminder: true,
    status: 'upcoming',
    referenceNumber: 'NHS-2025-005678'
  },
  {
    id: '3',
    type: 'vaccination',
    title: 'Flu Vaccination',
    location: 'Boots Pharmacy',
    address: '45 Oxford Street, London, W1D 1BS',
    date: '2024-12-15',
    time: '14:00',
    reminder: false,
    status: 'completed'
  }
];

export default function NHSAppointmentsPage() {
  const navigate = useNavigate();
  const [appointments, setAppointments] = useState<NHSAppointment[]>(initialAppointments);
  const [activeTab, setActiveTab] = useState<'upcoming' | 'past'>('upcoming');
  const [showAddModal, setShowAddModal] = useState(false);
  
  
  // Form state
  const [formData, setFormData] = useState({
    type: 'gp' as NHSAppointment['type'],
    title: '',
    doctorName: '',
    location: '',
    address: '',
    date: '',
    time: '',
    notes: '',
    referenceNumber: ''
  });

  const upcomingAppointments = appointments
    .filter(a => a.status === 'upcoming')
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  
  const pastAppointments = appointments
    .filter(a => a.status !== 'upcoming')
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const toggleReminder = (id: string) => {
    setAppointments(prev => prev.map(a => 
      a.id === id ? { ...a, reminder: !a.reminder } : a
    ));
  };

  const cancelAppointment = (id: string) => {
    setAppointments(prev => prev.map(a => 
      a.id === id ? { ...a, status: 'cancelled' as const } : a
    ));
  };

  const deleteAppointment = (id: string) => {
    setAppointments(prev => prev.filter(a => a.id !== id));
  };

  const handleAddAppointment = () => {
    if (!formData.title || !formData.location || !formData.date || !formData.time) return;

    const newAppointment: NHSAppointment = {
      id: Date.now().toString(),
      type: formData.type,
      title: formData.title,
      doctorName: formData.doctorName || undefined,
      location: formData.location,
      address: formData.address || undefined,
      date: formData.date,
      time: formData.time,
      notes: formData.notes || undefined,
      referenceNumber: formData.referenceNumber || undefined,
      reminder: true,
      status: 'upcoming'
    };

    setAppointments(prev => [...prev, newAppointment]);
    setShowAddModal(false);
    resetForm();
  };

  const resetForm = () => {
    setFormData({
      type: 'gp',
      title: '',
      doctorName: '',
      location: '',
      address: '',
      date: '',
      time: '',
      notes: '',
      referenceNumber: ''
    });
    
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
  };

  const getTypeInfo = (type: NHSAppointment['type']) => {
    return appointmentTypes.find(t => t.id === type) || appointmentTypes[0];
  };

  const getDaysUntil = (dateStr: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const appointmentDate = new Date(dateStr);
    appointmentDate.setHours(0, 0, 0, 0);
    const diffTime = appointmentDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Tomorrow';
    if (diffDays < 0) return 'Past';
    if (diffDays <= 7) return `In ${diffDays} days`;
    return formatDate(dateStr);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="sticky top-0 bg-gradient-to-r from-blue-600 to-blue-700 px-4 py-4 z-40">
        <div className="flex items-center gap-3 max-w-lg mx-auto">
          <button onClick={() => navigate(-1)} className="p-2 -ml-2 rounded-full hover:bg-white/20">
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-white">NHS Appointments</h1>
            <p className="text-sm text-blue-100">Track your GP & hospital visits</p>
          </div>
          <button onClick={() => setShowAddModal(true)} className="p-2 rounded-full bg-white/20 hover:bg-white/30">
            <Plus className="w-5 h-5 text-white" />
          </button>
        </div>
      </header>

      <main className="px-4 py-6 max-w-lg mx-auto space-y-6">
        {/* NHS Info Banner */}
        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
              <span className="text-white font-bold text-sm">NHS</span>
            </div>
            <div>
              <p className="font-semibold text-blue-900">Track your NHS appointments</p>
              <p className="text-sm text-blue-700 mt-1">
                Add your GP visits, hospital appointments, vaccinations, and screenings. Get reminders so you never miss an appointment.
              </p>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex bg-gray-100 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab('upcoming')}
            className={cn(
              'flex-1 py-2.5 rounded-lg font-medium text-sm transition-all',
              activeTab === 'upcoming' ? 'bg-white shadow text-blue-600' : 'text-gray-600'
            )}
          >
            Upcoming ({upcomingAppointments.length})
          </button>
          <button
            onClick={() => setActiveTab('past')}
            className={cn(
              'flex-1 py-2.5 rounded-lg font-medium text-sm transition-all',
              activeTab === 'past' ? 'bg-white shadow text-blue-600' : 'text-gray-600'
            )}
          >
            Past ({pastAppointments.length})
          </button>
        </div>

        {/* Appointments List */}
        <div className="space-y-3">
          {(activeTab === 'upcoming' ? upcomingAppointments : pastAppointments).map(appointment => {
            const typeInfo = getTypeInfo(appointment.type);
            const TypeIcon = typeInfo.icon;
            
            return (
              <div
                key={appointment.id}
                className={cn(
                  'bg-white rounded-2xl border shadow-sm overflow-hidden',
                  appointment.status === 'cancelled' ? 'border-red-200 bg-red-50/50' : 'border-gray-100'
                )}
              >
                {/* Date badge */}
                {activeTab === 'upcoming' && (
                  <div className="bg-blue-600 text-white px-4 py-2 text-sm font-medium">
                    {getDaysUntil(appointment.date)}
                  </div>
                )}

                <div className="p-4">
                  <div className="flex items-start gap-4">
                    <div className={cn('w-12 h-12 rounded-xl flex items-center justify-center', typeInfo.color)}>
                      <TypeIcon className="w-6 h-6" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="font-semibold text-gray-900">{appointment.title}</h3>
                          {appointment.doctorName && (
                            <p className="text-sm text-gray-600 flex items-center gap-1 mt-0.5">
                              <User className="w-3.5 h-3.5" />
                              {appointment.doctorName}
                            </p>
                          )}
                        </div>
                        {appointment.status === 'cancelled' && (
                          <span className="px-2 py-0.5 bg-red-100 text-red-700 text-xs font-medium rounded-full">
                            Cancelled
                          </span>
                        )}
                        {appointment.status === 'completed' && (
                          <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs font-medium rounded-full">
                            Completed
                          </span>
                        )}
                      </div>

                      <div className="mt-2 space-y-1 text-sm text-gray-600">
                        <p className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          {formatDate(appointment.date)}
                        </p>
                        <p className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-gray-400" />
                          {appointment.time}
                        </p>
                        <p className="flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-gray-400" />
                          {appointment.location}
                        </p>
                      </div>

                      {appointment.notes && (
                        <p className="mt-2 text-sm text-amber-700 bg-amber-50 px-3 py-2 rounded-lg">
                          📝 {appointment.notes}
                        </p>
                      )}

                      {appointment.referenceNumber && (
                        <p className="mt-2 text-xs text-gray-500">
                          Ref: {appointment.referenceNumber}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  {appointment.status === 'upcoming' && (
                    <div className="flex items-center gap-2 mt-4 pt-4 border-t border-gray-100">
                      <button
                        onClick={() => toggleReminder(appointment.id)}
                        className={cn(
                          'flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium',
                          appointment.reminder
                            ? 'bg-blue-100 text-blue-700'
                            : 'bg-gray-100 text-gray-600'
                        )}
                      >
                        {appointment.reminder ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
                        {appointment.reminder ? 'Reminder On' : 'Reminder Off'}
                      </button>
                      <button
                        onClick={() => cancelAppointment(appointment.id)}
                        className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium bg-red-100 text-red-700"
                      >
                        <X className="w-4 h-4" />
                        Cancel
                      </button>
                      {appointment.address && (
                        <a
                          href={`https://maps.google.com/?q=${encodeURIComponent(appointment.address)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium bg-gray-100 text-gray-700 ml-auto"
                        >
                          <MapPin className="w-4 h-4" />
                          Map
                        </a>
                      )}
                    </div>
                  )}

                  {appointment.status !== 'upcoming' && (
                    <div className="flex items-center gap-2 mt-4 pt-4 border-t border-gray-100">
                      <button
                        onClick={() => deleteAppointment(appointment.id)}
                        className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium bg-gray-100 text-gray-600"
                      >
                        <Trash2 className="w-4 h-4" />
                        Delete
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {((activeTab === 'upcoming' && upcomingAppointments.length === 0) ||
            (activeTab === 'past' && pastAppointments.length === 0)) && (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="font-semibold text-gray-900">No {activeTab} appointments</h3>
              <p className="text-gray-500 text-sm mt-1">
                {activeTab === 'upcoming' 
                  ? 'Add your NHS appointments to track them here'
                  : 'Your past appointments will appear here'
                }
              </p>
              {activeTab === 'upcoming' && (
                <button
                  onClick={() => setShowAddModal(true)}
                  className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-xl font-medium"
                >
                  Add Appointment
                </button>
              )}
            </div>
          )}
        </div>

        {/* NHS Contact */}
        <div className="bg-white rounded-2xl border border-gray-100 p-4">
          <h3 className="font-semibold text-gray-900 mb-3">Need Help?</h3>
          <div className="space-y-2">
            <a href="tel:111" className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl hover:bg-gray-100">
              <Phone className="w-5 h-5 text-blue-600" />
              <div>
                <p className="font-medium text-gray-900">NHS 111</p>
                <p className="text-xs text-gray-500">Non-emergency medical advice</p>
              </div>
            </a>
            <a href="tel:999" className="flex items-center gap-3 p-3 bg-red-50 rounded-xl hover:bg-red-100">
              <Phone className="w-5 h-5 text-red-600" />
              <div>
                <p className="font-medium text-gray-900">999 Emergency</p>
                <p className="text-xs text-gray-500">Life-threatening emergencies only</p>
              </div>
            </a>
          </div>
        </div>
      </main>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="w-full bg-white rounded-t-3xl p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Add NHS Appointment</h2>
              <button onClick={() => { setShowAddModal(false); resetForm(); }} className="p-2 hover:bg-gray-100 rounded-full">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              {/* Type Selection */}
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Appointment Type</label>
                <div className="grid grid-cols-3 gap-2">
                  {appointmentTypes.map(type => (
                    <button
                      key={type.id}
                      onClick={() => setFormData(prev => ({ ...prev, type: type.id as NHSAppointment['type'] }))}
                      className={cn(
                        'p-3 rounded-xl border-2 text-center transition-all',
                        formData.type === type.id
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      )}
                    >
                      <type.icon className={cn('w-5 h-5 mx-auto mb-1', formData.type === type.id ? 'text-blue-600' : 'text-gray-600')} />
                      <span className="text-xs font-medium">{type.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Title *</label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={e => setFormData(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="e.g., GP Check-up, Blood Test"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Doctor/Consultant Name</label>
                <input
                  type="text"
                  value={formData.doctorName}
                  onChange={e => setFormData(prev => ({ ...prev, doctorName: e.target.value }))}
                  placeholder="e.g., Dr. Smith"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Location *</label>
                <input
                  type="text"
                  value={formData.location}
                  onChange={e => setFormData(prev => ({ ...prev, location: e.target.value }))}
                  placeholder="e.g., Woodlands Health Centre"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Full Address</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={e => setFormData(prev => ({ ...prev, address: e.target.value }))}
                  placeholder="e.g., 123 High Street, London, N1 2AB"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-1 block">Date *</label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={e => setFormData(prev => ({ ...prev, date: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-1 block">Time *</label>
                  <input
                    type="time"
                    value={formData.time}
                    onChange={e => setFormData(prev => ({ ...prev, time: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Reference Number</label>
                <input
                  type="text"
                  value={formData.referenceNumber}
                  onChange={e => setFormData(prev => ({ ...prev, referenceNumber: e.target.value }))}
                  placeholder="e.g., NHS-2025-001234"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Notes</label>
                <textarea
                  value={formData.notes}
                  onChange={e => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                  placeholder="e.g., Fasting required, bring ID, etc."
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none resize-none"
                />
              </div>

              <button
                onClick={handleAddAppointment}
                disabled={!formData.title || !formData.location || !formData.date || !formData.time}
                className={cn(
                  'w-full py-4 rounded-xl font-semibold flex items-center justify-center gap-2',
                  formData.title && formData.location && formData.date && formData.time
                    ? 'bg-blue-600 text-white hover:bg-blue-700'
                    : 'bg-gray-200 text-gray-500'
                )}
              >
                <Check className="w-5 h-5" />
                Add Appointment
              </button>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
