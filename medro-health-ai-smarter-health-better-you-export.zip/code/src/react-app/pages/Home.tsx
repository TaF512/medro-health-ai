import { 
  MessageCircle, 
  Stethoscope, 
  FlaskConical, 
  Pill,
  FileText,
  Footprints,
  Moon,
  Scale,
  ChevronRight,
  Clock,
  Droplets,
  Activity,
  Camera
} from 'lucide-react';
import Header from '@/react-app/components/Header';
import BottomNav from '@/react-app/components/BottomNav';
import QuickActionCard from '@/react-app/components/QuickActionCard';
import DoctorCard from '@/react-app/components/DoctorCard';
import GuestBanner from '@/react-app/components/GuestBanner';
import LocaleSelector from '@/react-app/components/LocaleSelector';
import { doctors } from '@/react-app/data/doctors';
import { Link } from 'react-router';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { useLanguage } from '@/react-app/contexts/LanguageContext';
import { useState } from 'react';

const quickActions = [
  { 
    title: 'AI Health Chat', 
    subtitle: 'Ask anything', 
    icon: MessageCircle, 
    to: '/chat',
    color: 'text-blue-600',
    iconBgColor: 'bg-blue-100'
  },
  { 
    title: 'Check Symptoms', 
    subtitle: 'Quick triage', 
    icon: Stethoscope, 
    to: '/symptoms',
    color: 'text-purple-600',
    iconBgColor: 'bg-purple-100'
  },
  { 
    title: 'Find Doctor', 
    subtitle: 'Video consult', 
    icon: Stethoscope, 
    to: '/doctors',
    color: 'text-primary',
    iconBgColor: 'bg-primary/10'
  },
  { 
    title: 'Book a Test', 
    subtitle: 'Lab tests', 
    icon: FlaskConical, 
    to: '/tests',
    color: 'text-orange-600',
    iconBgColor: 'bg-orange-100'
  },
  { 
    title: 'Medications', 
    subtitle: 'Reminders', 
    icon: Pill, 
    to: '/medications',
    color: 'text-rose-600',
    iconBgColor: 'bg-rose-100'
  },
  { 
    title: 'My Records', 
    subtitle: 'Health vault', 
    icon: FileText, 
    to: '/records',
    color: 'text-cyan-600',
    iconBgColor: 'bg-cyan-100'
  },
  { 
    title: 'Blood Donors', 
    subtitle: 'Find match', 
    icon: Droplets, 
    to: '/blood-donors',
    color: 'text-red-600',
    iconBgColor: 'bg-red-100'
  },
  { 
    title: 'Health Tracker', 
    subtitle: 'Track vitals', 
    icon: Activity, 
    to: '/tracker',
    color: 'text-emerald-600',
    iconBgColor: 'bg-emerald-100'
  },
];

const healthStats = [
  { label: 'Steps', value: '6,842', icon: Footprints, color: 'text-green-600', bgColor: 'bg-green-100' },
  { label: 'Sleep', value: '7h 23m', icon: Moon, color: 'text-indigo-600', bgColor: 'bg-indigo-100' },
  { label: 'Weight', value: '72.5kg', icon: Scale, color: 'text-amber-600', bgColor: 'bg-amber-100' },
];

const upcomingReminders = [
  { id: 1, title: 'Metformin 500mg', time: '8:00 AM', type: 'medication', link: '/medications' },
  { id: 2, title: 'Blood Test - Lipid Profile', time: 'Tomorrow, 7:00 AM', type: 'test', link: '/appointments' },
  { id: 3, title: 'Dr. Sarah Ahmed - Follow-up', time: 'Dec 15, 3:00 PM', type: 'appointment', link: '/appointments' },
];

export default function HomePage() {
  const { isGuest } = useAuth();
  const { t } = useLanguage();
  const featuredDoctors = doctors.slice(0, 3);
  const [todayCalories] = useState({
    consumed: 1250,
    goal: 2000,
    burned: 320,
    protein: { current: 65, goal: 120 },
    carbs: { current: 140, goal: 250 },
    fat: { current: 45, goal: 65 },
    meals: [
      { name: 'Breakfast', description: 'Oatmeal with berries', calories: 420, time: '8:30 AM', icon: '🥣', color: 'bg-orange-400' },
      { name: 'Lunch', description: 'Grilled chicken salad', calories: 580, time: '1:15 PM', icon: '🥗', color: 'bg-pink-400' },
      { name: 'Snack', description: 'Apple with peanut butter', calories: 250, time: '4:00 PM', icon: '🍎', color: 'bg-yellow-400' },
    ]
  });

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {isGuest && <GuestBanner message="Create an account to save your health data" />}
      <Header showGreeting />
      
      <main className="px-4 py-4 max-w-lg mx-auto space-y-6">
        {/* Safety Disclaimer Banner */}
        <div className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-2xl p-4 border border-blue-100">
          <p className="text-sm text-blue-800">
            <span className="font-semibold">ℹ️ {t('home.important') || 'Important'}:</span> {t('home.disclaimer')}. {t('home.consultProfessional') || 'Always consult a healthcare professional'}.
          </p>
        </div>

        {/* Floating Locale Selector (Currency + Language) */}
        <LocaleSelector />

        {/* Quick Actions Grid */}
        <section>
          <h2 className="text-lg font-bold text-gray-900 mb-3">{t('home.quickActions')}</h2>
          <div className="grid grid-cols-2 gap-3">
            {quickActions.map((action) => (
              <QuickActionCard key={action.to + action.title} {...action} />
            ))}
          </div>
        </section>

        {/* Health Summary */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold text-gray-900">{t('home.todaysHealth') || "Today's Health"}</h2>
            <Link to="/tracker" className="text-sm text-primary font-medium flex items-center gap-1">
              {t('common.viewAll')} <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {healthStats.map((stat) => (
              <div key={stat.label} className="bg-white rounded-xl p-3 border border-gray-100 shadow-sm">
                <div className={`w-8 h-8 ${stat.bgColor} rounded-lg flex items-center justify-center mb-2`}>
                  <stat.icon className={`w-4 h-4 ${stat.color}`} />
                </div>
                <p className="text-lg font-bold text-gray-900">{stat.value}</p>
                <p className="text-xs text-gray-500">{stat.label}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Today's Nutrition - Compact Summary */}
        <section>
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-gray-900">{t('home.todaysCalories') || "Today's Nutrition"}</h2>
              <Link to="/tracker" className="text-sm text-primary font-medium">
                View All →
              </Link>
            </div>
            
            {/* Calorie Progress Ring & Stats */}
            <div className="flex items-center gap-6 mb-4">
              <div className="relative w-20 h-20">
                <svg className="w-20 h-20 transform -rotate-90">
                  <circle
                    cx="40" cy="40" r="32"
                    stroke="#e5e7eb" strokeWidth="6" fill="none"
                  />
                  <circle
                    cx="40" cy="40" r="32"
                    stroke="url(#calorieGradientHome)" strokeWidth="6" fill="none"
                    strokeLinecap="round"
                    strokeDasharray={`${(todayCalories.consumed / todayCalories.goal) * 201} 201`}
                  />
                  <defs>
                    <linearGradient id="calorieGradientHome" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#22c55e" />
                      <stop offset="100%" stopColor="#16a34a" />
                    </linearGradient>
                  </defs>
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-lg font-bold text-gray-900">{todayCalories.consumed}</span>
                  <span className="text-[10px] text-gray-500">kcal</span>
                </div>
              </div>
              <div className="flex-1">
                <div className="grid grid-cols-3 gap-2">
                  <div className="text-center">
                    <p className="text-sm font-bold text-red-600">{todayCalories.protein.current}g</p>
                    <p className="text-[10px] text-gray-500">Protein</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-bold text-amber-600">{todayCalories.carbs.current}g</p>
                    <p className="text-[10px] text-gray-500">Carbs</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-bold text-blue-600">{todayCalories.fat.current}g</p>
                    <p className="text-[10px] text-gray-500">Fat</p>
                  </div>
                </div>
                <p className="text-xs text-gray-500 mt-2 text-center">
                  {todayCalories.goal - todayCalories.consumed} kcal remaining
                </p>
              </div>
            </div>

            {/* AI Food Scan Button */}
            <Link 
              to="/food/scan"
              className="w-full bg-gradient-to-r from-green-400 to-emerald-500 text-white rounded-xl py-3 px-4 flex items-center gap-3 hover:opacity-90 transition-opacity"
            >
              <Camera className="w-5 h-5" />
              <div className="text-left flex-1">
                <p className="font-semibold">{t('home.snapFoodPhoto') || 'Snap Food Photo'}</p>
                <p className="text-xs text-white/80">AI-powered calorie recognition</p>
              </div>
              <ChevronRight className="w-5 h-5" />
            </Link>
          </div>
        </section>

        {/* Upcoming Reminders */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold text-gray-900">{t('home.upcoming') || 'Upcoming'}</h2>
            <Link to="/upcoming" className="text-sm text-primary font-medium flex items-center gap-1">
              {t('common.viewAll')} <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm divide-y divide-gray-100">
            {upcomingReminders.map((reminder) => (
              <Link 
                key={reminder.id} 
                to={reminder.link}
                className="flex items-center gap-3 p-3 hover:bg-gray-50 transition-colors"
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  reminder.type === 'medication' ? 'bg-rose-100' :
                  reminder.type === 'test' ? 'bg-orange-100' : 'bg-primary/10'
                }`}>
                  {reminder.type === 'medication' ? (
                    <Pill className="w-5 h-5 text-rose-600" />
                  ) : reminder.type === 'test' ? (
                    <FlaskConical className="w-5 h-5 text-orange-600" />
                  ) : (
                    <Stethoscope className="w-5 h-5 text-primary" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-gray-900 truncate">{reminder.title}</p>
                  <p className="text-sm text-gray-500 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    {reminder.time}
                  </p>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </Link>
            ))}
          </div>
        </section>

        {/* Featured Doctors */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold text-gray-900">{t('home.featuredDoctors')}</h2>
            <Link to="/doctors" className="text-sm text-primary font-medium flex items-center gap-1">
              {t('common.viewAll')} <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="space-y-3">
            {featuredDoctors.map((doctor) => (
              <DoctorCard key={doctor.id} doctor={doctor} compact />
            ))}
          </div>
        </section>

        {/* Popular Tests Banner */}
        <section>
          <Link 
            to="/tests"
            className="block bg-gradient-to-r from-primary to-teal-500 rounded-2xl p-5 text-white"
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold">{t('home.bookLabTests') || 'Book Lab Tests'}</h3>
                <p className="text-white/90 text-sm mt-1">{t('home.labDiscount') || 'Up to 25% off on health checkups'}</p>
                <p className="text-white/80 text-xs mt-2">{t('home.homeCollection') || 'Home sample collection available'}</p>
              </div>
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                <FlaskConical className="w-8 h-8 text-white" />
              </div>
            </div>
          </Link>
        </section>
      </main>
      
      <BottomNav />
    </div>
  );
}
