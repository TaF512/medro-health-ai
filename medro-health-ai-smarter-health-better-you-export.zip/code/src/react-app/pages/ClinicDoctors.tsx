import { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router';
import { 
  ArrowLeft, Star, Clock, Video, MessageCircle, Phone,
  Calendar, CheckCircle, Sparkles, GraduationCap, Award
} from 'lucide-react';
import { useCurrency } from '@/react-app/contexts/CurrencyContext';
import BottomNav from '@/react-app/components/BottomNav';

interface ClinicDoctor {
  id: string;
  name: string;
  image: string;
  title: string;
  specialty: string;
  experience: string;
  rating: number;
  reviews: number;
  consultationFee: number;
  currency: string;
  availability: string[];
  languages: string[];
  qualifications: string[];
  consultationTypes: ('video' | 'voice' | 'chat')[];
}

// Clinic data with doctors
const clinicDoctors: Record<string, { clinicName: string; clinicImage: string; doctors: ClinicDoctor[] }> = {
  '1': {
    clinicName: 'Harley Street Aesthetics',
    clinicImage: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=400&h=300&fit=crop',
    doctors: [
      {
        id: 'hsa-1',
        name: 'Dr. James Crawford',
        image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop&crop=face',
        title: 'Lead Surgeon',
        specialty: 'Hair Restoration & FUE',
        experience: '18 years',
        rating: 4.9,
        reviews: 456,
        consultationFee: 150,
        currency: 'GBP',
        availability: ['Mon', 'Wed', 'Fri'],
        languages: ['English', 'French'],
        qualifications: ['MBBS', 'FRCS', 'ISHRS Member'],
        consultationTypes: ['video', 'chat']
      },
      {
        id: 'hsa-2',
        name: 'Dr. Sarah Mitchell',
        image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200&h=200&fit=crop&crop=face',
        title: 'Aesthetic Specialist',
        specialty: 'Facial Aesthetics & Injectables',
        experience: '12 years',
        rating: 4.8,
        reviews: 324,
        consultationFee: 100,
        currency: 'GBP',
        availability: ['Tue', 'Thu', 'Sat'],
        languages: ['English', 'Arabic'],
        qualifications: ['MBBS', 'MSc Aesthetic Medicine', 'BCAM Certified'],
        consultationTypes: ['video', 'voice', 'chat']
      },
      {
        id: 'hsa-3',
        name: 'Dr. Ahmed Hassan',
        image: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=200&h=200&fit=crop&crop=face',
        title: 'Cosmetic Dentist',
        specialty: 'Dental Aesthetics & Veneers',
        experience: '15 years',
        rating: 4.9,
        reviews: 289,
        consultationFee: 80,
        currency: 'GBP',
        availability: ['Mon', 'Tue', 'Wed', 'Thu'],
        languages: ['English', 'Arabic', 'French'],
        qualifications: ['BDS', 'MSc Cosmetic Dentistry', 'BACD Member'],
        consultationTypes: ['video', 'chat']
      }
    ]
  },
  '2': {
    clinicName: 'Transform Clinic',
    clinicImage: 'https://images.unsplash.com/photo-1631217868264-e5b90bb7e133?w=400&h=300&fit=crop',
    doctors: [
      {
        id: 'tc-1',
        name: 'Mr. Richard Thompson',
        image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=200&h=200&fit=crop&crop=face',
        title: 'Consultant Plastic Surgeon',
        specialty: 'Breast Surgery & Body Contouring',
        experience: '22 years',
        rating: 4.9,
        reviews: 512,
        consultationFee: 150,
        currency: 'GBP',
        availability: ['Mon', 'Wed', 'Fri'],
        languages: ['English'],
        qualifications: ['MBBS', 'FRCS (Plast)', 'BAPRAS Member'],
        consultationTypes: ['video']
      },
      {
        id: 'tc-2',
        name: 'Dr. Emily Roberts',
        image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=200&h=200&fit=crop&crop=face',
        title: 'Cosmetic Surgeon',
        specialty: 'Liposuction & Body Sculpting',
        experience: '14 years',
        rating: 4.8,
        reviews: 287,
        consultationFee: 100,
        currency: 'GBP',
        availability: ['Tue', 'Thu', 'Sat'],
        languages: ['English', 'Spanish'],
        qualifications: ['MBBS', 'MSc Cosmetic Surgery', 'GMC Registered'],
        consultationTypes: ['video', 'voice', 'chat']
      }
    ]
  },
  '3': {
    clinicName: 'Beverly Hills Aesthetics',
    clinicImage: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=400&h=300&fit=crop',
    doctors: [
      {
        id: 'bha-1',
        name: 'Dr. Michael Reynolds',
        image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop&crop=face',
        title: 'Board Certified Plastic Surgeon',
        specialty: 'Facial Rejuvenation & Rhinoplasty',
        experience: '25 years',
        rating: 5.0,
        reviews: 892,
        consultationFee: 350,
        currency: 'USD',
        availability: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
        languages: ['English', 'Spanish'],
        qualifications: ['MD', 'FACS', 'ASPS Member', 'ISAPS Fellow'],
        consultationTypes: ['video']
      },
      {
        id: 'bha-2',
        name: 'Dr. Jennifer Lee',
        image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200&h=200&fit=crop&crop=face',
        title: 'Celebrity Aesthetician',
        specialty: 'Non-Surgical Treatments & Injectables',
        experience: '18 years',
        rating: 4.9,
        reviews: 756,
        consultationFee: 300,
        currency: 'USD',
        availability: ['Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        languages: ['English', 'Korean', 'Mandarin'],
        qualifications: ['MD', 'American Board of Dermatology', 'AAD Fellow'],
        consultationTypes: ['video', 'chat']
      }
    ]
  },
  '4': {
    clinicName: 'Seoul Beauty Clinic',
    clinicImage: 'https://images.unsplash.com/photo-1580281657702-257584239a55?w=400&h=300&fit=crop',
    doctors: [
      {
        id: 'sbc-1',
        name: 'Dr. Kim Min-jun',
        image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop&crop=face',
        title: 'K-Beauty Specialist',
        specialty: 'V-Line Surgery & Double Eyelid',
        experience: '20 years',
        rating: 4.9,
        reviews: 1245,
        consultationFee: 150000,
        currency: 'KRW',
        availability: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        languages: ['Korean', 'English', 'Japanese'],
        qualifications: ['MD', 'PhD', 'KSPS Certified'],
        consultationTypes: ['video', 'chat']
      }
    ]
  },
  '5': {
    clinicName: 'Bangkok Aesthetic Center',
    clinicImage: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=400&h=300&fit=crop',
    doctors: [
      {
        id: 'bac-1',
        name: 'Dr. Somchai Patel',
        image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=200&h=200&fit=crop&crop=face',
        title: 'Plastic & Reconstructive Surgeon',
        specialty: 'Gender Affirmation & Body Contouring',
        experience: '28 years',
        rating: 4.9,
        reviews: 2156,
        consultationFee: 3000,
        currency: 'THB',
        availability: ['Mon', 'Wed', 'Fri', 'Sat'],
        languages: ['Thai', 'English', 'Japanese'],
        qualifications: ['MD', 'FRCST', 'ISAPS Member'],
        consultationTypes: ['video', 'voice', 'chat']
      }
    ]
  }
};

// Default doctors for clinics without specific data
const defaultDoctors: ClinicDoctor[] = [
  {
    id: 'default-1',
    name: 'Dr. General Specialist',
    image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop&crop=face',
    title: 'Lead Consultant',
    specialty: 'Aesthetic Medicine',
    experience: '15 years',
    rating: 4.8,
    reviews: 200,
    consultationFee: 100,
    currency: 'GBP',
    availability: ['Mon', 'Wed', 'Fri'],
    languages: ['English'],
    qualifications: ['MBBS', 'Aesthetic Medicine Diploma'],
    consultationTypes: ['video', 'chat']
  }
];

type ConsultType = 'video' | 'voice' | 'chat';

const generateTimeSlots = (day: string): string[] => {
  const slots: string[] = [];
  const dayIndex = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].indexOf(day);
  const startHour = 9 + (dayIndex % 2);
  for (let i = 0; i < 6; i++) {
    const hour = startHour + i;
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour > 12 ? hour - 12 : hour;
    slots.push(`${displayHour}:00 ${ampm}`);
  }
  return slots;
};

export default function ClinicDoctorsPage() {
  const { clinicId } = useParams();
  const navigate = useNavigate();
  const [selectedDoctor, setSelectedDoctor] = useState<ClinicDoctor | null>(null);
  const [selectedConsultType, setSelectedConsultType] = useState<ConsultType | null>(null);
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const { convertPrice, selectedCurrency } = useCurrency();
  
  const timeSlots = selectedDay ? generateTimeSlots(selectedDay) : [];

  const clinicData = clinicDoctors[clinicId || ''] || { 
    clinicName: 'Aesthetic Clinic', 
    clinicImage: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=400&h=300&fit=crop',
    doctors: defaultDoctors 
  };

  const formatPrice = (amount: number, currency: string) => {
    const converted = convertPrice(amount, currency);
    return `${selectedCurrency.symbol}${Math.round(converted).toLocaleString()}`;
  };

  // Doctor detail view
  if (selectedDoctor) {
    return (
      <div className="min-h-screen bg-gray-50 pb-24">
        {/* Doctor Header */}
        <div className="bg-gradient-to-br from-pink-500 via-purple-500 to-indigo-500 text-white px-4 pt-12 pb-20">
          <div className="flex items-center gap-3 mb-6">
            <button 
              onClick={() => setSelectedDoctor(null)}
              className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <p className="text-white/80">{clinicData.clinicName}</p>
          </div>
        </div>

        <div className="px-4 -mt-16">
          {/* Doctor Card */}
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-4">
            <div className="p-4">
              <div className="flex gap-4">
                <img 
                  src={selectedDoctor.image} 
                  alt={selectedDoctor.name}
                  className="w-24 h-24 rounded-xl object-cover"
                />
                <div className="flex-1">
                  <h1 className="text-xl font-bold text-gray-900">{selectedDoctor.name}</h1>
                  <p className="text-primary font-medium">{selectedDoctor.title}</p>
                  <p className="text-sm text-gray-600 mt-1">{selectedDoctor.specialty}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <div className="flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded-full">
                      <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                      <span className="text-sm font-semibold text-amber-700">{selectedDoctor.rating}</span>
                    </div>
                    <span className="text-sm text-gray-500">({selectedDoctor.reviews} reviews)</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Info */}
            <div className="border-t border-gray-100 px-4 py-3 grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <GraduationCap className="w-4 h-4 text-blue-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">Experience</p>
                  <p className="text-sm font-medium">{selectedDoctor.experience}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <Award className="w-4 h-4 text-green-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">Languages</p>
                  <p className="text-sm font-medium">{selectedDoctor.languages.slice(0, 2).join(', ')}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Qualifications */}
          <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
            <h2 className="font-semibold text-gray-900 mb-3">Qualifications</h2>
            <div className="flex flex-wrap gap-2">
              {selectedDoctor.qualifications.map((qual, idx) => (
                <span key={idx} className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">
                  {qual}
                </span>
              ))}
            </div>
          </div>

          {/* Availability */}
          <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
            <h2 className="font-semibold text-gray-900 mb-3">Availability</h2>
            <div className="flex gap-2 mb-4">
              {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => {
                const isAvailable = selectedDoctor.availability.includes(day);
                const isSelected = selectedDay === day;
                return (
                  <button 
                    key={day}
                    onClick={() => {
                      if (isAvailable) {
                        setSelectedDay(day);
                        setSelectedTime(null);
                      }
                    }}
                    disabled={!isAvailable}
                    className={`flex-1 py-2 rounded-lg text-center text-sm font-medium transition-all ${
                      isSelected
                        ? 'bg-green-500 text-white'
                        : isAvailable
                          ? 'bg-green-100 text-green-700 hover:bg-green-200'
                          : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                    }`}
                  >
                    {day}
                  </button>
                );
              })}
            </div>
            
            {/* Time Slots */}
            {selectedDay && (
              <div>
                <p className="text-sm text-gray-600 mb-2">Select a time</p>
                <div className="flex flex-wrap gap-2">
                  {timeSlots.map(time => (
                    <button
                      key={time}
                      onClick={() => setSelectedTime(time)}
                      className={`px-3 py-2 rounded-lg text-sm font-medium transition-all border ${
                        selectedTime === time
                          ? 'bg-green-500 text-white border-green-500'
                          : 'bg-white text-gray-700 border-gray-200 hover:border-green-400'
                      }`}
                    >
                      {time}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Consultation Types */}
          <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
            <h2 className="font-semibold text-gray-900 mb-3">Consultation Options</h2>
            <div className="flex gap-3">
              {selectedDoctor.consultationTypes.includes('video') && (
                <button 
                  onClick={() => setSelectedConsultType('video')}
                  className={`flex-1 rounded-xl p-3 text-center transition-all border-2 ${
                    selectedConsultType === 'video'
                      ? 'bg-green-50 border-green-500'
                      : 'bg-gray-50 border-transparent hover:bg-gray-100'
                  }`}
                >
                  <Video className={`w-6 h-6 mx-auto mb-1 ${selectedConsultType === 'video' ? 'text-green-600' : 'text-gray-500'}`} />
                  <p className={`text-sm font-medium ${selectedConsultType === 'video' ? 'text-green-700' : 'text-gray-600'}`}>Video Call</p>
                </button>
              )}
              {selectedDoctor.consultationTypes.includes('voice') && (
                <button 
                  onClick={() => setSelectedConsultType('voice')}
                  className={`flex-1 rounded-xl p-3 text-center transition-all border-2 ${
                    selectedConsultType === 'voice'
                      ? 'bg-green-50 border-green-500'
                      : 'bg-gray-50 border-transparent hover:bg-gray-100'
                  }`}
                >
                  <Phone className={`w-6 h-6 mx-auto mb-1 ${selectedConsultType === 'voice' ? 'text-green-600' : 'text-gray-500'}`} />
                  <p className={`text-sm font-medium ${selectedConsultType === 'voice' ? 'text-green-700' : 'text-gray-600'}`}>Voice Call</p>
                </button>
              )}
              {selectedDoctor.consultationTypes.includes('chat') && (
                <button 
                  onClick={() => setSelectedConsultType('chat')}
                  className={`flex-1 rounded-xl p-3 text-center transition-all border-2 ${
                    selectedConsultType === 'chat'
                      ? 'bg-green-50 border-green-500'
                      : 'bg-gray-50 border-transparent hover:bg-gray-100'
                  }`}
                >
                  <MessageCircle className={`w-6 h-6 mx-auto mb-1 ${selectedConsultType === 'chat' ? 'text-green-600' : 'text-gray-500'}`} />
                  <p className={`text-sm font-medium ${selectedConsultType === 'chat' ? 'text-green-700' : 'text-gray-600'}`}>Chat</p>
                </button>
              )}
            </div>
          </div>

          {/* Book Button */}
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm text-gray-500">Consultation Fee</p>
                <p className="text-2xl font-bold text-primary">
                  {formatPrice(selectedDoctor.consultationFee, selectedDoctor.currency)}
                </p>
              </div>
              {selectedConsultType && selectedDay && selectedTime ? (
                <div className="flex items-center gap-1 text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full">
                  <CheckCircle className="w-3 h-3" />
                  <span>Available</span>
                </div>
              ) : (
                <p className="text-xs text-gray-400">Select options above</p>
              )}
            </div>
            {selectedConsultType && selectedDay && selectedTime ? (
              <Link
                to={`/book-aesthetics/${clinicId}/${selectedDoctor.id}?type=${selectedConsultType}&day=${selectedDay}&time=${encodeURIComponent(selectedTime)}`}
                className="block w-full bg-gradient-to-r from-pink-500 to-purple-500 text-white font-semibold py-4 rounded-xl text-center hover:opacity-90 transition-opacity"
              >
                Book Consultation
              </Link>
            ) : (
              <button
                disabled
                className="w-full bg-gray-200 text-gray-400 font-semibold py-4 rounded-xl cursor-not-allowed"
              >
                Select Day, Time & Type
              </button>
            )}
          </div>
        </div>

        <BottomNav />
      </div>
    );
  }

  // Doctors list view
  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <div className="relative">
        <img 
          src={clinicData.clinicImage} 
          alt={clinicData.clinicName}
          className="w-full h-40 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 to-black/60" />
        <button 
          onClick={() => navigate(-1)}
          className="absolute top-4 left-4 w-10 h-10 bg-white/90 backdrop-blur rounded-full flex items-center justify-center shadow-lg"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="absolute bottom-4 left-4 text-white">
          <h1 className="text-xl font-bold">{clinicData.clinicName}</h1>
          <p className="text-white/80 text-sm">Select a specialist to book consultation</p>
        </div>
      </div>

      <div className="px-4 py-4">
        {/* AI Badge */}
        <div className="flex items-center gap-2 text-sm text-purple-600 mb-4">
          <Sparkles className="w-4 h-4" />
          <span>Our specialists are verified and highly rated</span>
        </div>

        {/* Doctors List */}
        <div className="space-y-4">
          {clinicData.doctors.map(doctor => (
            <button
              key={doctor.id}
              onClick={() => {
                setSelectedDoctor(doctor);
                setSelectedConsultType(null);
                setSelectedDay(null);
                setSelectedTime(null);
              }}
              className="w-full bg-white rounded-2xl shadow-sm p-4 text-left hover:shadow-md transition-shadow"
            >
              <div className="flex gap-4">
                <img 
                  src={doctor.image} 
                  alt={doctor.name}
                  className="w-20 h-20 rounded-xl object-cover"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-semibold text-gray-900">{doctor.name}</h3>
                      <p className="text-sm text-primary">{doctor.title}</p>
                    </div>
                    <div className="flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded-full">
                      <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                      <span className="text-xs font-semibold text-amber-700">{doctor.rating}</span>
                    </div>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">{doctor.specialty}</p>
                  <div className="flex items-center justify-between mt-3">
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      <Clock className="w-3 h-3" />
                      <span>{doctor.experience} exp.</span>
                    </div>
                    <p className="font-bold text-primary">
                      {formatPrice(doctor.consultationFee, doctor.currency)}
                    </p>
                  </div>
                </div>
              </div>
              
              {/* Consultation Types */}
              <div className="flex gap-2 mt-3 pt-3 border-t border-gray-100">
                {doctor.consultationTypes.includes('video') && (
                  <span className="flex items-center gap-1 text-xs bg-blue-50 text-blue-600 px-2 py-1 rounded-full">
                    <Video className="w-3 h-3" /> Video
                  </span>
                )}
                {doctor.consultationTypes.includes('voice') && (
                  <span className="flex items-center gap-1 text-xs bg-green-50 text-green-600 px-2 py-1 rounded-full">
                    <Phone className="w-3 h-3" /> Voice
                  </span>
                )}
                {doctor.consultationTypes.includes('chat') && (
                  <span className="flex items-center gap-1 text-xs bg-purple-50 text-purple-600 px-2 py-1 rounded-full">
                    <MessageCircle className="w-3 h-3" /> Chat
                  </span>
                )}
              </div>
            </button>
          ))}
        </div>

        {clinicData.doctors.length === 0 && (
          <div className="text-center py-12 bg-white rounded-2xl">
            <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">No specialists available at this time</p>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}
