import { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router';
import { 
  ArrowLeft, Star, MapPin, Clock, Search,
  UserCheck, Package, Building2, FlaskConical
} from 'lucide-react';
import Header from '@/react-app/components/Header';
import BottomNav from '@/react-app/components/BottomNav';
import TestCard from '@/react-app/components/TestCard';
import { labs, labTests, testCategories } from '@/react-app/data/tests';
import { cn } from '@/react-app/lib/utils';

export default function LabDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const lab = labs.find(l => l.id === id);

  // Get tests available at this lab
  const labTestsFiltered = useMemo(() => {
    if (!lab) return [];
    return labTests.filter(test => {
      const matchesLab = test.country === lab.country && 
        test.labs?.some(labName => 
          labName.toLowerCase().includes(lab.name.toLowerCase().split(' ')[0])
        );
      const matchesSearch = test.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = !selectedCategory || test.categoryId === selectedCategory;
      return matchesLab && matchesSearch && matchesCategory;
    });
  }, [lab, searchQuery, selectedCategory]);

  // Get all tests for this country if no specific lab tests
  const countryTests = useMemo(() => {
    if (!lab) return [];
    return labTests.filter(test => {
      const matchesCountry = test.country === lab.country;
      const matchesSearch = test.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = !selectedCategory || test.categoryId === selectedCategory;
      return matchesCountry && matchesSearch && matchesCategory;
    });
  }, [lab, searchQuery, selectedCategory]);

  const testsToShow = labTestsFiltered.length > 0 ? labTestsFiltered : countryTests;

  // Get unique categories from available tests
  const availableCategories = useMemo(() => {
    const categoryIds = new Set(testsToShow.map(t => t.categoryId));
    return testCategories.filter(c => categoryIds.has(c.id));
  }, [testsToShow]);

  if (!lab) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-500 mb-4">Lab not found</p>
          <button
            onClick={() => navigate('/tests')}
            className="text-primary font-medium"
          >
            Back to Tests
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      <Header title={lab.name} />
      
      <main className="max-w-lg mx-auto">
        {/* Back Button */}
        <div className="px-4 py-3">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
        </div>

        {/* Lab Header */}
        <div className="px-4 pb-4">
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-start gap-4">
              <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center text-3xl">
                {lab.logo}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h1 className="text-xl font-bold text-gray-900">{lab.name}</h1>
                  <span className="text-xl">{lab.countryFlag}</span>
                </div>
                <div className="flex items-center gap-1 mt-1">
                  <MapPin className="w-4 h-4 text-gray-400" />
                  <span className="text-sm text-gray-600">{lab.address}</span>
                </div>
                <div className="flex items-center gap-3 mt-2">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                    <span className="font-medium">{lab.rating}</span>
                  </div>
                  <span className="text-xs text-gray-400">|</span>
                  <span className="text-sm text-gray-500">{lab.labType}</span>
                </div>
              </div>
            </div>

            {/* Collection Methods */}
            <div className="mt-4 pt-4 border-t border-gray-100">
              <p className="text-sm font-medium text-gray-700 mb-2">Sample Collection Options</p>
              <div className="flex flex-wrap gap-2">
                {lab.collectionMethods?.includes('nurse_visit') && (
                  <div className="flex items-center gap-1.5 bg-green-50 text-green-700 px-3 py-1.5 rounded-lg text-sm">
                    <UserCheck className="w-4 h-4" />
                    <span>Nurse Visit</span>
                    {lab.nurseVisitFee && (
                      <span className="text-green-600 font-medium">+£{lab.nurseVisitFee}</span>
                    )}
                  </div>
                )}
                {lab.collectionMethods?.includes('self_kit') && (
                  <div className="flex items-center gap-1.5 bg-blue-50 text-blue-700 px-3 py-1.5 rounded-lg text-sm">
                    <Package className="w-4 h-4" />
                    <span>Self-Kit</span>
                    {lab.selfKitFee !== undefined && (
                      <span className="text-blue-600 font-medium">
                        {lab.selfKitFee === 0 ? 'Free' : `+£${lab.selfKitFee}`}
                      </span>
                    )}
                  </div>
                )}
                {lab.collectionMethods?.includes('lab_visit') && (
                  <div className="flex items-center gap-1.5 bg-purple-50 text-purple-700 px-3 py-1.5 rounded-lg text-sm">
                    <Building2 className="w-4 h-4" />
                    <span>Visit Lab</span>
                    {lab.labVisitDiscount && (
                      <span className="text-purple-600 font-medium">-{lab.labVisitDiscount}%</span>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Quick Info */}
            <div className="mt-4 grid grid-cols-2 gap-3">
              <div className="bg-gray-50 rounded-xl p-3">
                <div className="flex items-center gap-2 text-gray-600">
                  <Clock className="w-4 h-4" />
                  <span className="text-sm">Results in 24-48h</span>
                </div>
              </div>
              <div className="bg-gray-50 rounded-xl p-3">
                <div className="flex items-center gap-2 text-gray-600">
                  <FlaskConical className="w-4 h-4" />
                  <span className="text-sm">{testsToShow.length} tests</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="px-4 pb-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search tests..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-xl text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
            />
          </div>
        </div>

        {/* Category Filter */}
        <div className="px-4 pb-4">
          <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
            <button
              onClick={() => setSelectedCategory(null)}
              className={cn(
                'flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-colors',
                !selectedCategory
                  ? 'bg-primary text-white'
                  : 'bg-white border border-gray-200 text-gray-700 hover:border-gray-300'
              )}
            >
              All Tests
            </button>
            {availableCategories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(selectedCategory === cat.id ? null : cat.id)}
                className={cn(
                  'flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-colors',
                  selectedCategory === cat.id
                    ? 'bg-primary text-white'
                    : 'bg-white border border-gray-200 text-gray-700 hover:border-gray-300'
                )}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* Tests List */}
        <div className="px-4 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-gray-900">Available Tests</h2>
            <span className="text-sm text-gray-500">{testsToShow.length} tests</span>
          </div>

          {testsToShow.length > 0 ? (
            <div className="space-y-4">
              {testsToShow.map((test) => (
                <TestCard key={test.id} test={test} />
              ))}
            </div>
          ) : (
            <div className="py-12 text-center">
              <FlaskConical className="w-16 h-16 text-gray-200 mx-auto mb-4" />
              <p className="text-gray-500 mb-2">No tests found</p>
              <p className="text-sm text-gray-400">
                Try adjusting your search or category filter
              </p>
            </div>
          )}
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
