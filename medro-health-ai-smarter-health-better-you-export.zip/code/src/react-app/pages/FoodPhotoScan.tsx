import { useState, useRef } from 'react';
import { useNavigate } from 'react-router';
import { 
  ArrowLeft, 
  Camera, 
  Upload, 
  Loader2, 
  AlertTriangle,
  CheckCircle,
  HelpCircle,
  Plus,
  X,
  Search,
  Save,
  Trash2,
  RefreshCw
} from 'lucide-react';

interface FoodItem {
  id: string;
  name: string;
  portion: string;
  portionMultiplier: number;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  confidence: 'high' | 'medium' | 'low';
}

interface AnalysisResult {
  items: FoodItem[];
  totals: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
  mealName: string;
  healthScore: number;
  warnings: string[];
  suggestions: string[];
  overallConfidence: 'high' | 'medium' | 'low';
}

const portionOptions = [
  { label: '0.5x', value: 0.5 },
  { label: '1x', value: 1 },
  { label: '1.5x', value: 1.5 },
  { label: '2x', value: 2 },
];

const plateSizes = ['Small', 'Normal', 'Large'] as const;

export default function FoodPhotoScan() {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [plateSize, setPlateSize] = useState<typeof plateSizes[number]>('Normal');
  const [clarificationQuestion, setClarificationQuestion] = useState<string | null>(null);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64 = event.target?.result as string;
      setImagePreview(base64);
      await analyzeImage(base64, file.type);
    };
    reader.readAsDataURL(file);
  };

  const analyzeImage = async (base64: string, mimeType: string) => {
    setIsAnalyzing(true);
    setError(null);
    setClarificationQuestion(null);

    try {
      // Extract just the base64 data without the data URL prefix
      const base64Data = base64.split(',')[1];

      const response = await fetch('/api/analyze-food', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: base64Data, mimeType }),
      });

      if (!response.ok) throw new Error('Failed to analyze image');

      const data = await response.json();
      
      // Add IDs and confidence to items
      const itemsWithMeta: FoodItem[] = data.items.map((item: any, idx: number) => ({
        ...item,
        id: `item-${idx}`,
        portionMultiplier: 1,
        confidence: determineConfidence(item),
      }));

      // Determine overall confidence
      const lowConfidenceItems = itemsWithMeta.filter(i => i.confidence === 'low');
      const overallConfidence: 'high' | 'medium' | 'low' = 
        lowConfidenceItems.length > 0 ? 'low' : 
        itemsWithMeta.some(i => i.confidence === 'medium') ? 'medium' : 'high';

      // Generate clarification question for low confidence
      if (overallConfidence === 'low' && lowConfidenceItems.length > 0) {
        setClarificationQuestion(`Is "${lowConfidenceItems[0].name}" correctly identified? Tap to edit if not.`);
      }

      setAnalysisResult({
        items: itemsWithMeta,
        totals: data.totals,
        mealName: data.mealName || 'Your Meal',
        healthScore: data.healthScore || 5,
        warnings: data.warnings || [],
        suggestions: data.suggestions || [],
        overallConfidence,
      });
    } catch (err) {
      setError('Failed to analyze image. Please try again.');
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const determineConfidence = (item: any): 'high' | 'medium' | 'low' => {
    // Simple heuristic based on how specific the item name is
    const name = item.name.toLowerCase();
    if (name.includes('unknown') || name.includes('possibly') || name.includes('maybe')) {
      return 'low';
    }
    if (name.includes('approximate') || name.includes('estimated')) {
      return 'medium';
    }
    return 'high';
  };

  const updateItemPortion = (itemId: string, multiplier: number) => {
    if (!analysisResult) return;

    const updatedItems = analysisResult.items.map(item => {
      if (item.id === itemId) {
        return { ...item, portionMultiplier: multiplier };
      }
      return item;
    });

    // Recalculate totals
    const totals = updatedItems.reduce((acc, item) => ({
      calories: acc.calories + Math.round(item.calories * item.portionMultiplier),
      protein: acc.protein + Math.round(item.protein * item.portionMultiplier),
      carbs: acc.carbs + Math.round(item.carbs * item.portionMultiplier),
      fat: acc.fat + Math.round(item.fat * item.portionMultiplier),
    }), { calories: 0, protein: 0, carbs: 0, fat: 0 });

    setAnalysisResult({ ...analysisResult, items: updatedItems, totals });
  };

  const removeItem = (itemId: string) => {
    if (!analysisResult) return;

    const updatedItems = analysisResult.items.filter(item => item.id !== itemId);
    
    // Recalculate totals
    const totals = updatedItems.reduce((acc, item) => ({
      calories: acc.calories + Math.round(item.calories * item.portionMultiplier),
      protein: acc.protein + Math.round(item.protein * item.portionMultiplier),
      carbs: acc.carbs + Math.round(item.carbs * item.portionMultiplier),
      fat: acc.fat + Math.round(item.fat * item.portionMultiplier),
    }), { calories: 0, protein: 0, carbs: 0, fat: 0 });

    setAnalysisResult({ ...analysisResult, items: updatedItems, totals });
  };

  const getConfidenceColor = (confidence: 'high' | 'medium' | 'low') => {
    switch (confidence) {
      case 'high': return 'text-emerald-600 bg-emerald-100';
      case 'medium': return 'text-amber-600 bg-amber-100';
      case 'low': return 'text-red-600 bg-red-100';
    }
  };

  const getConfidenceIcon = (confidence: 'high' | 'medium' | 'low') => {
    switch (confidence) {
      case 'high': return <CheckCircle className="w-3 h-3" />;
      case 'medium': return <HelpCircle className="w-3 h-3" />;
      case 'low': return <AlertTriangle className="w-3 h-3" />;
    }
  };

  const saveMeal = () => {
    // TODO: Save to database/context
    navigate('/', { state: { mealSaved: true } });
  };

  const getCalorieDisplay = () => {
    if (!analysisResult) return '0';
    const { overallConfidence, totals } = analysisResult;
    if (overallConfidence === 'low') {
      const min = Math.round(totals.calories * 0.8);
      const max = Math.round(totals.calories * 1.2);
      return `${min}–${max}`;
    }
    return totals.calories.toString();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 to-white pb-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-4 py-4 pb-6">
        <div className="flex items-center gap-3 mb-2">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-white/20 rounded-full transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-bold">AI Food Scanner</h1>
        </div>
        <p className="text-emerald-100 text-sm ml-10">Powered by Gemini Pro Vision</p>
      </div>

      <main className="px-4 -mt-3 max-w-lg mx-auto">
        {/* Image Capture */}
        {!imagePreview && !isAnalyzing && (
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-4">
            <div className="text-center mb-6">
              <div className="w-20 h-20 bg-gradient-to-br from-emerald-100 to-teal-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Camera className="w-10 h-10 text-emerald-600" />
              </div>
              <h2 className="text-lg font-bold text-gray-900 mb-2">Capture Your Meal</h2>
              <p className="text-sm text-gray-500">Take a photo or upload an image for instant AI calorie analysis</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => cameraInputRef.current?.click()}
                className="flex flex-col items-center gap-2 p-4 bg-gradient-to-br from-emerald-500 to-teal-600 text-white rounded-xl hover:shadow-lg transition-all"
              >
                <Camera className="w-8 h-8" />
                <span className="font-medium">Take Photo</span>
              </button>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex flex-col items-center gap-2 p-4 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-all"
              >
                <Upload className="w-8 h-8" />
                <span className="font-medium">Upload</span>
              </button>
            </div>

            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleImageSelect}
              className="hidden"
            />
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageSelect}
              className="hidden"
            />

            {/* Plate Size Selector */}
            <div className="mt-6 pt-4 border-t border-gray-100">
              <p className="text-sm font-medium text-gray-700 mb-2">Plate Size (helps accuracy)</p>
              <div className="flex gap-2">
                {plateSizes.map(size => (
                  <button
                    key={size}
                    onClick={() => setPlateSize(size)}
                    className={`flex-1 py-2 px-3 rounded-lg text-sm font-medium transition-all ${
                      plateSize === size 
                        ? 'bg-emerald-500 text-white' 
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Loading State */}
        {isAnalyzing && (
          <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-emerald-100 to-teal-100 rounded-2xl flex items-center justify-center mx-auto mb-4 animate-pulse">
              <Loader2 className="w-10 h-10 text-emerald-600 animate-spin" />
            </div>
            <h2 className="text-lg font-bold text-gray-900 mb-2">Analyzing Your Meal...</h2>
            <p className="text-sm text-gray-500">Our AI is identifying foods and calculating nutrition</p>
            {imagePreview && (
              <img src={imagePreview} alt="Food" className="mt-4 rounded-xl max-h-40 mx-auto object-cover" />
            )}
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-4">
            <div className="flex items-center gap-2 text-red-700">
              <AlertTriangle className="w-5 h-5" />
              <p className="font-medium">{error}</p>
            </div>
            <button
              onClick={() => {
                setError(null);
                setImagePreview(null);
              }}
              className="mt-3 text-sm text-red-600 underline"
            >
              Try again
            </button>
          </div>
        )}

        {/* Analysis Results */}
        {analysisResult && !isAnalyzing && (
          <>
            {/* Image Preview */}
            {imagePreview && (
              <div className="relative mb-4">
                <img src={imagePreview} alt="Food" className="w-full h-48 object-cover rounded-2xl shadow-lg" />
                <button
                  onClick={() => {
                    setImagePreview(null);
                    setAnalysisResult(null);
                  }}
                  className="absolute top-2 right-2 p-2 bg-black/50 text-white rounded-full hover:bg-black/70"
                >
                  <X className="w-4 h-4" />
                </button>
                <button
                  onClick={() => imagePreview && analyzeImage(imagePreview, 'image/jpeg')}
                  className="absolute top-2 left-2 p-2 bg-white/90 text-gray-700 rounded-full hover:bg-white flex items-center gap-1 text-xs font-medium px-3"
                >
                  <RefreshCw className="w-3 h-3" /> Re-analyze
                </button>
              </div>
            )}

            {/* Confidence Banner */}
            {clarificationQuestion && (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 mb-4 flex items-start gap-2">
                <HelpCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-amber-800">{clarificationQuestion}</p>
              </div>
            )}

            {/* Totals Card */}
            <div className="bg-white rounded-2xl shadow-lg p-5 mb-4">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-lg font-bold text-gray-900">{analysisResult.mealName}</h2>
                <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getConfidenceColor(analysisResult.overallConfidence)}`}>
                  {getConfidenceIcon(analysisResult.overallConfidence)}
                  {analysisResult.overallConfidence === 'high' ? 'High Accuracy' : 
                   analysisResult.overallConfidence === 'medium' ? 'Moderate' : 'Low Accuracy'}
                </div>
              </div>

              <div className="flex items-center justify-center gap-6 py-4 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-xl mb-4">
                <div className="text-center">
                  <p className="text-3xl font-bold text-emerald-600">{getCalorieDisplay()}</p>
                  <p className="text-xs text-gray-500">Calories</p>
                </div>
                <div className="w-px h-12 bg-gray-200" />
                <div className="text-center">
                  <p className="text-xl font-bold text-red-500">{analysisResult.totals.protein}g</p>
                  <p className="text-xs text-gray-500">Protein</p>
                </div>
                <div className="text-center">
                  <p className="text-xl font-bold text-amber-500">{analysisResult.totals.carbs}g</p>
                  <p className="text-xs text-gray-500">Carbs</p>
                </div>
                <div className="text-center">
                  <p className="text-xl font-bold text-blue-500">{analysisResult.totals.fat}g</p>
                  <p className="text-xs text-gray-500">Fat</p>
                </div>
              </div>

              {/* Health Score */}
              <div className="flex items-center gap-3 mb-3">
                <span className="text-sm text-gray-600">Health Score:</span>
                <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full ${
                      analysisResult.healthScore >= 7 ? 'bg-emerald-500' :
                      analysisResult.healthScore >= 4 ? 'bg-amber-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${analysisResult.healthScore * 10}%` }}
                  />
                </div>
                <span className="text-sm font-semibold">{analysisResult.healthScore}/10</span>
              </div>

              {/* Disclaimer */}
              <p className="text-xs text-gray-400 text-center">
                ⚠️ Estimate only. Oil, sugar, and hidden ingredients can change actual calories.
              </p>
            </div>

            {/* Food Items List */}
            <div className="bg-white rounded-2xl shadow-lg p-4 mb-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-gray-900">Detected Items</h3>
                <button 
                  onClick={() => setShowSearchModal(true)}
                  className="text-sm text-emerald-600 font-medium flex items-center gap-1"
                >
                  <Plus className="w-4 h-4" /> Add Item
                </button>
              </div>

              <div className="space-y-3">
                {analysisResult.items.map(item => (
                  <div key={item.id} className="bg-gray-50 rounded-xl p-3">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="font-medium text-gray-900">{item.name}</p>
                          <span className={`text-xs px-1.5 py-0.5 rounded ${getConfidenceColor(item.confidence)}`}>
                            {item.confidence}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500">{item.portion}</p>
                      </div>
                      <button
                        onClick={() => removeItem(item.id)}
                        className="p-1.5 hover:bg-red-100 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </button>
                    </div>

                    {/* Portion Controls */}
                    <div className="flex items-center gap-2 mb-2">
                      {portionOptions.map(opt => (
                        <button
                          key={opt.value}
                          onClick={() => updateItemPortion(item.id, opt.value)}
                          className={`flex-1 py-1.5 rounded-lg text-xs font-medium transition-all ${
                            item.portionMultiplier === opt.value
                              ? 'bg-emerald-500 text-white'
                              : 'bg-white border border-gray-200 text-gray-600 hover:border-emerald-300'
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>

                    {/* Macros */}
                    <div className="flex items-center justify-between text-xs text-gray-600">
                      <span>{Math.round(item.calories * item.portionMultiplier)} kcal</span>
                      <span>P: {Math.round(item.protein * item.portionMultiplier)}g</span>
                      <span>C: {Math.round(item.carbs * item.portionMultiplier)}g</span>
                      <span>F: {Math.round(item.fat * item.portionMultiplier)}g</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Warnings & Suggestions */}
            {(analysisResult.warnings.length > 0 || analysisResult.suggestions.length > 0) && (
              <div className="space-y-3 mb-4">
                {analysisResult.warnings.length > 0 && (
                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                    <h4 className="font-medium text-amber-800 mb-2 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4" /> Health Notes
                    </h4>
                    <ul className="text-sm text-amber-700 space-y-1">
                      {analysisResult.warnings.map((w, i) => (
                        <li key={i}>• {w}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {analysisResult.suggestions.length > 0 && (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4">
                    <h4 className="font-medium text-emerald-800 mb-2 flex items-center gap-2">
                      <CheckCircle className="w-4 h-4" /> Suggestions
                    </h4>
                    <ul className="text-sm text-emerald-700 space-y-1">
                      {analysisResult.suggestions.map((s, i) => (
                        <li key={i}>• {s}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}

            {/* Save Button */}
            <button
              onClick={saveMeal}
              className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl font-semibold flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all"
            >
              <Save className="w-5 h-5" /> Save to Today's Log
            </button>
          </>
        )}

        {/* Search Modal for Adding Items */}
        {showSearchModal && (
          <div className="fixed inset-0 bg-black/50 flex items-end z-50">
            <div className="bg-white w-full rounded-t-3xl p-6 max-h-[70vh] overflow-y-auto">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold">Add Food Item</h3>
                <button onClick={() => setShowSearchModal(false)} className="p-2 hover:bg-gray-100 rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search foods..."
                  className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                />
              </div>
              <p className="text-sm text-gray-500 text-center py-8">
                Type to search from our nutrition database
              </p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
