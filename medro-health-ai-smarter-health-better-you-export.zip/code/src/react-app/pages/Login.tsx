import { useState } from 'react';
import { useNavigate } from 'react-router';
import { User, Lock, Loader2, UserCog, Check } from 'lucide-react';
import { useAuth } from '@/react-app/contexts/AuthContext';

export default function LoginPage() {
  const navigate = useNavigate();
  const { redirectToLogin, enterGuestMode } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    if (!agreedToTerms) return;
    setIsLoading(true);
    try {
      await redirectToLogin();
    } catch (error) {
      console.error('Login failed:', error);
      setIsLoading(false);
    }
  };

  const handlePatientGuestMode = () => {
    enterGuestMode('patient');
    navigate('/');
  };

  const handleDoctorGuestMode = () => {
    enterGuestMode('doctor');
    navigate('/doctor/dashboard');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-400 via-teal-500 to-purple-600 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl p-8">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <img 
            src="https://019c7544-ff60-755c-b21b-4cf637d4527f.mochausercontent.com/medro-logo.png" 
            alt="Medro Health AI" 
            className="h-24 object-contain mb-3"
          />
          <p className="text-sm text-gray-500 text-center">
            Smarter Health. Better You.
          </p>
        </div>

        <h1 className="text-2xl font-bold text-gray-900 text-center mb-6">Login</h1>

        {/* Email/Username Field */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-600 mb-1.5">Username</label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Type your username"
              className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
            />
          </div>
        </div>

        {/* Password Field */}
        <div className="mb-2">
          <label className="block text-sm font-medium text-gray-600 mb-1.5">Password</label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Type your password"
              className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
            />
          </div>
        </div>

        {/* Forgot Password */}
        <div className="text-right mb-6">
          <button 
            onClick={() => navigate('/forgot-password')}
            className="text-sm text-gray-500 hover:text-primary transition-colors"
          >
            Forgot password?
          </button>
        </div>

        {/* Terms & Conditions Checkbox */}
        <label className="flex items-start gap-3 cursor-pointer mb-5">
          <button
            type="button"
            onClick={() => setAgreedToTerms(!agreedToTerms)}
            className={`mt-0.5 w-5 h-5 rounded border-2 flex items-center justify-center transition-all flex-shrink-0 ${
              agreedToTerms 
                ? 'bg-primary border-primary' 
                : 'border-gray-300 hover:border-primary'
            }`}
          >
            {agreedToTerms && <Check className="w-3 h-3 text-white" />}
          </button>
          <span className="text-sm text-gray-600">
            I agree to{' '}
            <a href="#" className="text-primary hover:underline">Terms</a>
            {' '}&{' '}
            <a href="#" className="text-primary hover:underline">Privacy Policy</a>
          </span>
        </label>

        {/* Login Button */}
        <button
          onClick={handleLogin}
          disabled={isLoading || !agreedToTerms}
          className="w-full py-3.5 bg-gradient-to-r from-cyan-400 via-teal-500 to-purple-500 rounded-full font-semibold text-white hover:opacity-90 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <Loader2 className="w-5 h-5 animate-spin mx-auto" />
          ) : (
            'LOGIN'
          )}
        </button>

        {/* Social Login */}
        <div className="mt-8">
          <p className="text-center text-sm text-gray-500 mb-4">Or Sign Up Using</p>
          <div className="flex justify-center gap-3">
            {/* Facebook */}
            <button
              onClick={handleLogin}
              disabled={!agreedToTerms}
              className="w-11 h-11 rounded-full bg-[#3b5998] flex items-center justify-center hover:opacity-90 transition-all disabled:opacity-50"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="white">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
              </svg>
            </button>

            {/* X (Twitter) */}
            <button
              onClick={handleLogin}
              disabled={!agreedToTerms}
              className="w-11 h-11 rounded-full bg-[#1DA1F2] flex items-center justify-center hover:opacity-90 transition-all disabled:opacity-50"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="white">
                <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
              </svg>
            </button>

            {/* Google */}
            <button
              onClick={handleLogin}
              disabled={!agreedToTerms}
              className="w-11 h-11 rounded-full bg-[#EA4335] flex items-center justify-center hover:opacity-90 transition-all disabled:opacity-50"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="white">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
            </button>

            {/* Apple */}
            <button
              onClick={handleLogin}
              disabled={!agreedToTerms}
              className="w-11 h-11 rounded-full bg-black flex items-center justify-center hover:opacity-90 transition-all disabled:opacity-50"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="white">
                <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09l.01-.01zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
              </svg>
            </button>
          </div>
        </div>

        {/* Sign Up Link */}
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500">Or Sign Up Using</p>
          <button className="mt-2 font-semibold text-gray-700 hover:text-primary transition-colors">
            SIGN UP
          </button>
        </div>

        {/* Divider */}
        <div className="flex items-center gap-3 my-6">
          <div className="flex-1 h-px bg-gray-200" />
          <span className="text-sm text-gray-400">or explore demo</span>
          <div className="flex-1 h-px bg-gray-200" />
        </div>

        {/* Guest Mode Buttons */}
        <div className="space-y-3">
          <button
            onClick={handlePatientGuestMode}
            className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-primary to-teal-600 rounded-full font-medium text-white hover:opacity-90 transition-all shadow-md text-sm"
          >
            <User className="w-4 h-4" />
            <span>Explore as Patient</span>
          </button>

          <button
            onClick={handleDoctorGuestMode}
            className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full font-medium text-white hover:opacity-90 transition-all shadow-md text-sm"
          >
            <UserCog className="w-4 h-4" />
            <span>Explore as Doctor</span>
          </button>
        </div>

        <p className="text-xs text-gray-400 text-center mt-4">
          Explore features without an account
        </p>
      </div>
    </div>
  );
}
