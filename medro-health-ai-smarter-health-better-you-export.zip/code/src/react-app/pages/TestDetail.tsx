import { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router';
import { 
  ArrowLeft, Clock, Star, Check, Home, MapPin, 
  Droplet, AlertCircle, Plus, Minus, ShoppingCart,
  Search, Globe, ChevronDown, FlaskConical, Info, ChevronUp,
  UserCheck, Package, Building2
} from 'lucide-react';
import BottomNav from '@/react-app/components/BottomNav';
import { labTests, labs, labCountries, Lab, CollectionMethod } from '@/react-app/data/tests';
import { useCart } from '@/react-app/context/CartContext';
import { cn } from '@/react-app/lib/utils';
import { calculatePatientPrice, getVatLabel } from '@/react-app/lib/pricing';

const currencySymbols: Record<string, string> = {
  BDT: '৳',
  GBP: '£',
  USD: '$',
  INR: '₹',
  AED: 'AED ',
  EUR: '€',
  CAD: 'C$',
  AUD: 'A$',
  SAR: 'SAR ',
};

// Map country codes to currencies
const countryCurrencies: Record<string, string> = {
  BD: 'BDT',
  GB: 'GBP',
  US: 'USD',
  IN: 'INR',
  AE: 'AED',
  CA: 'CAD',
  AU: 'AUD',
  DE: 'EUR',
  FR: 'EUR',
  SA: 'SAR',
};

export default function TestDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addItem } = useCart();
  const [selectedLab, setSelectedLab] = useState<string | null>(null);
  const [patientCount, setPatientCount] = useState(1);
  const [labSearch, setLabSearch] = useState('');
  const [showCountryFilter, setShowCountryFilter] = useState(false);
  const [cartAdded, setCartAdded] = useState(false);
  const [showComponents, setShowComponents] = useState(false);
  const [showPriceBreakdown, setShowPriceBreakdown] = useState(false);
  const [selectedCollectionMethod, setSelectedCollectionMethod] = useState<CollectionMethod | null>(null);

  const test = labTests.find(t => t.id === id);
  
  // Default to test's country and set homeCollection based on availability
  const [selectedCountry, setSelectedCountry] = useState(test?.country || 'ALL');
  const [homeCollection, setHomeCollection] = useState(test?.homeCollectionAvailable ?? false);

  if (!test) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-500">Test not found</p>
      </div>
    );
  }

  // Get labs that offer this test - filter by test's country and selected country
  const availableLabs = useMemo(() => {
    return labs.filter(lab => {
      // First, filter by country - only show labs from the test's country OR selected country
      const labCountry = selectedCountry === 'ALL' ? test.country : selectedCountry;
      if (lab.country !== labCountry) return false;
      
      // Filter by search
      const matchesSearch = labSearch === '' || 
                           lab.name.toLowerCase().includes(labSearch.toLowerCase()) ||
                           lab.address.toLowerCase().includes(labSearch.toLowerCase());
      
      // Filter by home collection preference (only if test supports it)
      const matchesCollection = !homeCollection || !test.homeCollectionAvailable || lab.homeCollection;
      
      // Filter by selected collection method
      const matchesCollectionMethod = !selectedCollectionMethod || 
                                      lab.collectionMethods.includes(selectedCollectionMethod);
      
      return matchesSearch && matchesCollection && matchesCollectionMethod;
    });
  }, [test, selectedCountry, labSearch, homeCollection, selectedCollectionMethod]);

  // Get tests offered by selected lab
  const selectedLabInfo = labs.find(l => l.id === selectedLab);
  const testsOfferedByLab = useMemo(() => {
    if (!selectedLabInfo) return [];
    return labTests.filter(t => 
      t.labs.some(testLab => 
        selectedLabInfo.name.toLowerCase().includes(testLab.toLowerCase().split(' ')[0]) ||
        testLab.toLowerCase().includes(selectedLabInfo.name.toLowerCase().split(' ')[0])
      )
    );
  }, [selectedLabInfo]);

  // Calculate price based on lab's country currency with home collection fee or lab visit discount
  const getLabPrice = (lab: Lab, includeHomeCollection: boolean) => {
    // Get the currency for the lab's country
    const labCurrency = countryCurrencies[lab.country] || test.currency;
    
    // Use the test's base price - in real app, tests would have prices per country
    // For now we use test.price as base and adjust for currency display
    let basePrice = test.price;
    
    let finalPrice = basePrice;
    let homeCollectionFee = 0;
    let labVisitDiscount = 0;
    let discountPercent = 0;
    
    if (includeHomeCollection && lab.homeCollection && test.homeCollectionAvailable) {
      // Add home collection fee
      homeCollectionFee = lab.homeCollectionFee;
      finalPrice = basePrice + homeCollectionFee;
    } else {
      // Apply lab visit discount
      discountPercent = lab.labVisitDiscount;
      labVisitDiscount = Math.round(basePrice * (lab.labVisitDiscount / 100));
      finalPrice = basePrice - labVisitDiscount;
    }
    
    return { 
      basePrice,
      finalPrice: Math.round(finalPrice), 
      currency: labCurrency,
      homeCollectionFee,
      labVisitDiscount,
      discountPercent,
      hasHomeCollection: lab.homeCollection && test.homeCollectionAvailable
    };
  };

  const selectedLabPrice = selectedLabInfo ? getLabPrice(selectedLabInfo, homeCollection) : null;
  
  // Calculate patient-facing total with fees
  const priceBreakdown = selectedLabPrice 
    ? calculatePatientPrice(selectedLabPrice.finalPrice * patientCount, selectedLabInfo?.country || test.country, selectedLabPrice.currency)
    : null;
  
  const totalPrice = priceBreakdown?.totalPrice || 0;
  // Use selected lab's country currency, or filter country currency, or test currency
  const displayCurrency = selectedLabInfo 
    ? countryCurrencies[selectedLabInfo.country] 
    : selectedCountry !== 'ALL' 
      ? countryCurrencies[selectedCountry] 
      : test.currency;
  const currencySymbol = currencySymbols[displayCurrency] || displayCurrency;

  // Count home vs lab components if test has components
  const homeComponents = test.components?.filter(c => c.homeCollection) || [];
  const labComponents = test.components?.filter(c => !c.homeCollection) || [];

  return (
    <div className="min-h-screen bg-gray-50 pb-32">
      {/* Header */}
      <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 z-40">
        <div className="flex items-center gap-3 max-w-lg mx-auto">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 rounded-full hover:bg-gray-100 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
          <h1 className="text-lg font-bold text-gray-900 truncate">{test.name}</h1>
        </div>
      </header>

      <main className="px-4 py-4 max-w-lg mx-auto space-y-5">
        {/* Test Info Card */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
          <div className="flex gap-4">
            <div className="w-24 h-24 rounded-xl bg-gradient-to-br from-teal-50 to-cyan-100 flex items-center justify-center flex-shrink-0">
              <span className="text-4xl">🩸</span>
            </div>
            <div className="flex-1">
              <h2 className="font-bold text-gray-900 text-lg">{test.name}</h2>
              <p className="text-sm text-gray-600 mt-1">{test.description}</p>
              <p className="text-primary font-medium text-sm mt-2">
                Includes {test.testsIncluded} Test{test.testsIncluded > 1 ? 's' : ''}
              </p>
            </div>
          </div>

          {/* Test Details */}
          <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-gray-100">
            <div className="text-center">
              <div className="w-10 h-10 mx-auto bg-blue-100 rounded-xl flex items-center justify-center mb-1">
                <Clock className="w-5 h-5 text-blue-600" />
              </div>
              <p className="text-xs text-gray-500">Report in</p>
              <p className="text-sm font-semibold text-gray-900">{test.reportTime}</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 mx-auto bg-red-100 rounded-xl flex items-center justify-center mb-1">
                <Droplet className="w-5 h-5 text-red-600" />
              </div>
              <p className="text-xs text-gray-500">Sample</p>
              <p className="text-sm font-semibold text-gray-900">{test.sampleType}</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 mx-auto bg-amber-100 rounded-xl flex items-center justify-center mb-1">
                <AlertCircle className="w-5 h-5 text-amber-600" />
              </div>
              <p className="text-xs text-gray-500">Fasting</p>
              <p className="text-sm font-semibold text-gray-900">{test.fasting ? 'Required' : 'Not needed'}</p>
            </div>
          </div>
        </div>

        {/* Test Components - for packages like Full Body Checkup */}
        {test.components && test.components.length > 0 && (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <button
              onClick={() => setShowComponents(!showComponents)}
              className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center">
                  <FlaskConical className="w-5 h-5 text-purple-600" />
                </div>
                <div className="text-left">
                  <h3 className="font-semibold text-gray-900">What's Included</h3>
                  <p className="text-sm text-gray-500">
                    {test.components.length} tests in this package
                  </p>
                </div>
              </div>
              {showComponents ? (
                <ChevronUp className="w-5 h-5 text-gray-400" />
              ) : (
                <ChevronDown className="w-5 h-5 text-gray-400" />
              )}
            </button>

            {showComponents && (
              <div className="px-4 pb-4 space-y-3">
                {/* Home Collection Tests */}
                {homeComponents.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Home className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-medium text-green-700">
                        Can be done at home ({homeComponents.length})
                      </span>
                    </div>
                    <div className="space-y-2 pl-6">
                      {homeComponents.map((comp, i) => (
                        <div key={i} className="flex items-center gap-2 py-2 border-b border-gray-50 last:border-0">
                          <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                          <span className="text-sm text-gray-700">{comp.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Lab Visit Required Tests */}
                {labComponents.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-gray-100">
                    <div className="flex items-center gap-2 mb-2">
                      <MapPin className="w-4 h-4 text-amber-600" />
                      <span className="text-sm font-medium text-amber-700">
                        Requires lab visit ({labComponents.length})
                      </span>
                    </div>
                    <div className="space-y-2 pl-6">
                      {labComponents.map((comp, i) => (
                        <div key={i} className="py-2 border-b border-gray-50 last:border-0">
                          <div className="flex items-center gap-2">
                            <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0" />
                            <span className="text-sm text-gray-700">{comp.name}</span>
                          </div>
                          {comp.reason && (
                            <p className="text-xs text-gray-500 ml-6 mt-0.5">{comp.reason}</p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Summary message */}
                {homeComponents.length > 0 && labComponents.length > 0 && (
                  <div className="bg-blue-50 rounded-xl p-3 mt-3">
                    <p className="text-sm text-blue-800">
                      <strong>Note:</strong> This package includes both home-collectable and lab-visit tests. 
                      You'll need to visit the lab for {labComponents.length} test{labComponents.length > 1 ? 's' : ''}.
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Patient Count */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-gray-900">Select Patients</h3>
              <p className="text-sm text-gray-500">How many people will take this test?</p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setPatientCount(Math.max(1, patientCount - 1))}
                className="w-9 h-9 rounded-lg border border-gray-200 flex items-center justify-center hover:bg-gray-50 transition-colors"
              >
                <Minus className="w-4 h-4 text-gray-600" />
              </button>
              <span className="text-lg font-bold text-primary w-8 text-center">{patientCount}</span>
              <button
                onClick={() => setPatientCount(patientCount + 1)}
                className="w-9 h-9 rounded-lg bg-primary text-white flex items-center justify-center hover:bg-primary/90 transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Sample Collection */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-gray-100">
            <h3 className="font-semibold text-gray-900">Sample Collection</h3>
          </div>
          
          {/* Status Banner */}
          {!test.homeCollectionAvailable ? (
            <div className="mx-4 mt-4 bg-amber-50 border border-amber-200 rounded-xl p-3">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-amber-800">Lab Visit Required</p>
                  <p className="text-xs text-amber-700 mt-0.5">
                    {test.sampleType.includes('MRI') || test.sampleType.includes('CT') 
                      ? 'MRI/CT scans require specialized imaging equipment only available at medical facilities.'
                      : test.sampleType.includes('X-Ray') 
                        ? 'X-Ray imaging requires radiography equipment only available at medical facilities.'
                        : test.sampleType.includes('Ultrasound')
                          ? 'Ultrasound imaging requires specialized equipment and trained sonographers.'
                          : `${test.sampleType} cannot be collected at home. Please visit a lab center.`
                    }
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="mx-4 mt-4 bg-green-50 border border-green-200 rounded-xl p-3">
              <div className="flex items-start gap-2">
                <Home className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-green-800">Self-Collection Available</p>
                  <p className="text-xs text-green-700 mt-0.5">
                    {test.sampleType.includes('Blood')
                      ? 'A certified phlebotomist will visit your home to collect your blood sample safely.'
                      : 'Sample can be collected at your home. A professional will assist or provide a self-collection kit.'
                    }
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Collection Method Selection - 3 Options */}
          <div className="p-4">
            <h4 className="text-sm font-medium text-gray-700 mb-3">Choose Collection Method</h4>
            <div className="grid grid-cols-3 gap-2">
              {/* Nurse Visit */}
              <button
                onClick={() => {
                  if (test.homeCollectionAvailable) {
                    setSelectedCollectionMethod(selectedCollectionMethod === 'nurse_visit' ? null : 'nurse_visit');
                    setHomeCollection(true);
                    setSelectedLab(null);
                  }
                }}
                disabled={!test.homeCollectionAvailable}
                className={cn(
                  'p-3 rounded-xl border-2 transition-all text-center',
                  !test.homeCollectionAvailable 
                    ? 'border-gray-100 bg-gray-50 opacity-50 cursor-not-allowed'
                    : selectedCollectionMethod === 'nurse_visit'
                      ? 'border-green-500 bg-green-50'
                      : 'border-gray-200 hover:border-green-300 bg-white'
                )}
              >
                <div className={cn(
                  'w-10 h-10 mx-auto mb-2 rounded-full flex items-center justify-center',
                  selectedCollectionMethod === 'nurse_visit' ? 'bg-green-100' : 'bg-gray-100'
                )}>
                  <UserCheck className={cn('w-5 h-5', selectedCollectionMethod === 'nurse_visit' ? 'text-green-600' : 'text-gray-400')} />
                </div>
                <p className={cn('font-medium text-xs', selectedCollectionMethod === 'nurse_visit' ? 'text-green-700' : 'text-gray-700')}>
                  🏠 Nurse Visit
                </p>
                <p className="text-[10px] text-gray-500 mt-1">At your home</p>
              </button>

              {/* Self-Kit */}
              <button
                onClick={() => {
                  if (test.homeCollectionAvailable) {
                    setSelectedCollectionMethod(selectedCollectionMethod === 'self_kit' ? null : 'self_kit');
                    setHomeCollection(true);
                    setSelectedLab(null);
                  }
                }}
                disabled={!test.homeCollectionAvailable}
                className={cn(
                  'p-3 rounded-xl border-2 transition-all text-center',
                  !test.homeCollectionAvailable 
                    ? 'border-gray-100 bg-gray-50 opacity-50 cursor-not-allowed'
                    : selectedCollectionMethod === 'self_kit'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-blue-300 bg-white'
                )}
              >
                <div className={cn(
                  'w-10 h-10 mx-auto mb-2 rounded-full flex items-center justify-center',
                  selectedCollectionMethod === 'self_kit' ? 'bg-blue-100' : 'bg-gray-100'
                )}>
                  <Package className={cn('w-5 h-5', selectedCollectionMethod === 'self_kit' ? 'text-blue-600' : 'text-gray-400')} />
                </div>
                <p className={cn('font-medium text-xs', selectedCollectionMethod === 'self_kit' ? 'text-blue-700' : 'text-gray-700')}>
                  📦 Self-Kit
                </p>
                <p className="text-[10px] text-gray-500 mt-1">Postal kit</p>
              </button>

              {/* Visit Lab */}
              <button
                onClick={() => {
                  setSelectedCollectionMethod(selectedCollectionMethod === 'lab_visit' ? null : 'lab_visit');
                  setHomeCollection(false);
                  setSelectedLab(null);
                }}
                className={cn(
                  'p-3 rounded-xl border-2 transition-all text-center',
                  selectedCollectionMethod === 'lab_visit'
                    ? 'border-purple-500 bg-purple-50'
                    : 'border-gray-200 hover:border-purple-300 bg-white'
                )}
              >
                <div className={cn(
                  'w-10 h-10 mx-auto mb-2 rounded-full flex items-center justify-center',
                  selectedCollectionMethod === 'lab_visit' ? 'bg-purple-100' : 'bg-gray-100'
                )}>
                  <Building2 className={cn('w-5 h-5', selectedCollectionMethod === 'lab_visit' ? 'text-purple-600' : 'text-gray-400')} />
                </div>
                <p className={cn('font-medium text-xs', selectedCollectionMethod === 'lab_visit' ? 'text-purple-700' : 'text-gray-700')}>
                  🏥 Visit Lab
                </p>
                <p className="text-[10px] text-gray-500 mt-1">Go to center</p>
              </button>
            </div>
            
            {/* Show matching labs count */}
            {selectedCollectionMethod && (
              <p className="text-xs text-gray-500 mt-3 text-center">
                {availableLabs.length} lab{availableLabs.length !== 1 ? 's' : ''} offer{availableLabs.length === 1 ? 's' : ''} this option
              </p>
            )}
          </div>
        </div>

        {/* Lab Selection with Country Filter */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-900">Select Lab Partner</h3>
            <span className="text-xs text-gray-500 bg-blue-50 px-2 py-1 rounded-full">
              {availableLabs.length} available
            </span>
          </div>

          {/* Country Filter */}
          <div className="mb-4">
            <button
              onClick={() => setShowCountryFilter(!showCountryFilter)}
              className="w-full flex items-center justify-between px-4 py-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-primary" />
                <span className="text-sm text-gray-600">Filter by Country:</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-gray-900">
                  {labCountries.find(c => c.code === selectedCountry)?.flag}{' '}
                  {labCountries.find(c => c.code === selectedCountry)?.name}
                </span>
                <ChevronDown className={cn('w-4 h-4 text-gray-400 transition-transform', showCountryFilter && 'rotate-180')} />
              </div>
            </button>

            {showCountryFilter && (
              <div className="mt-2 grid grid-cols-2 gap-2">
                {labCountries.map((country) => (
                  <button
                    key={country.code}
                    onClick={() => {
                      setSelectedCountry(country.code);
                      setShowCountryFilter(false);
                      setSelectedLab(null);
                    }}
                    className={cn(
                      'flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-all',
                      selectedCountry === country.code
                        ? 'bg-primary text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    )}
                  >
                    <span>{country.flag}</span>
                    <span className="truncate">{country.name}</span>
                    {selectedCountry === country.code && <Check className="w-4 h-4 ml-auto" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Search Labs */}
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search labs..."
              value={labSearch}
              onChange={(e) => setLabSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
            />
          </div>

          {/* Lab List */}
          <div className="space-y-3 max-h-80 overflow-y-auto">
            {availableLabs.length > 0 ? (
              availableLabs.map((lab) => {
                const labPrice = getLabPrice(lab, homeCollection);
                const labPriceWithFees = calculatePatientPrice(labPrice.finalPrice, lab.country, labPrice.currency);
                // Calculate original price with fees for proper strikethrough comparison
                const originalPriceWithFees = labPrice.discountPercent > 0 
                  ? calculatePatientPrice(labPrice.basePrice, lab.country, labPrice.currency)
                  : null;
                const hasRealDiscount = labPrice.discountPercent > 0 && !homeCollection && originalPriceWithFees;
                return (
                  <button
                    key={lab.id}
                    onClick={() => setSelectedLab(lab.id)}
                    className={cn(
                      'w-full flex items-center gap-3 p-4 rounded-xl border-2 transition-all text-left',
                      selectedLab === lab.id
                        ? 'border-primary bg-primary/5'
                        : 'border-gray-100 hover:border-gray-200'
                    )}
                  >
                    <div className={cn(
                      'w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0',
                      selectedLab === lab.id ? 'border-primary bg-primary' : 'border-gray-300'
                    )}>
                      {selectedLab === lab.id && <Check className="w-3 h-3 text-white" />}
                    </div>

                    <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center text-2xl flex-shrink-0">
                      {lab.logo}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-base">{lab.countryFlag}</span>
                        <h4 className="font-medium text-gray-900 truncate">{lab.name}</h4>
                      </div>
                      <p className="text-xs text-gray-500 truncate">{lab.address}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <div className="flex items-center gap-1">
                          <Star className="w-3.5 h-3.5 text-yellow-500 fill-yellow-500" />
                          <span className="text-sm text-gray-600">{lab.rating}</span>
                        </div>
                      </div>
                      {/* Collection Method Badges */}
                      <div className="flex flex-wrap gap-1 mt-1.5">
                        {lab.collectionMethods.includes('nurse_visit') && (
                          <span className="text-[10px] bg-green-100 text-green-700 px-1.5 py-0.5 rounded">
                            🏠 Nurse
                          </span>
                        )}
                        {lab.collectionMethods.includes('self_kit') && (
                          <span className="text-[10px] bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded">
                            📦 Kit
                          </span>
                        )}
                        {lab.collectionMethods.includes('lab_visit') && (
                          <span className="text-[10px] bg-purple-100 text-purple-700 px-1.5 py-0.5 rounded">
                            🏥 Lab
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="text-right">
                      {/* Only show strikethrough for actual lab visit discounts */}
                      {hasRealDiscount && originalPriceWithFees && (
                        <p className="text-xs text-gray-400 line-through">
                          {currencySymbols[labPrice.currency] || labPrice.currency}{originalPriceWithFees.totalPrice}
                        </p>
                      )}
                      <p className="text-lg font-bold text-gray-900">
                        {currencySymbols[labPrice.currency] || labPrice.currency}{labPriceWithFees.totalPrice}
                      </p>
                      {hasRealDiscount ? (
                        <p className="text-xs text-green-600">{labPrice.discountPercent}% off</p>
                      ) : (
                        <p className="text-xs text-gray-500">inc. fees</p>
                      )}
                    </div>
                  </button>
                );
              })
            ) : (
              <div className="text-center py-8">
                <FlaskConical className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">No labs found</p>
                <p className="text-sm text-gray-400">Try a different country or search term</p>
              </div>
            )}
          </div>
        </div>

        {/* Tests Offered by Selected Lab */}
        {selectedLabInfo && testsOfferedByLab.length > 0 && (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <FlaskConical className="w-5 h-5 text-primary" />
              Other Tests at {selectedLabInfo.name.split(' ')[0]}
            </h3>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {testsOfferedByLab.filter(t => t.id !== id).slice(0, 5).map((t) => {
                return (
                  <button
                    key={t.id}
                    onClick={() => navigate(`/tests/${t.id}`)}
                    className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors text-left"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 text-sm truncate">{t.name}</p>
                      <p className="text-xs text-gray-500">{t.testsIncluded} tests • {t.reportTime}</p>
                    </div>
                    <span className="text-sm font-bold text-primary ml-2">
                      {currencySymbols[t.currency] || t.currency}{t.price}
                    </span>
                  </button>
                );
              })}
              {testsOfferedByLab.filter(t => t.id !== id).length > 5 && (
                <p className="text-center text-sm text-primary font-medium pt-2">
                  +{testsOfferedByLab.filter(t => t.id !== id).length - 5} more tests available
                </p>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Cart Added Toast */}
      {cartAdded && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 bg-green-600 text-white px-6 py-3 rounded-xl shadow-lg z-50 flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <Check className="w-5 h-5" />
          <span className="font-medium">Added to cart!</span>
        </div>
      )}

      {/* Bottom CTA */}
      <div className="fixed bottom-16 left-0 right-0 bg-white border-t border-gray-200 p-4 z-40">
        <div className="max-w-lg mx-auto flex items-center justify-between">
          <div className="relative">
            <p className="text-sm text-gray-500">Total Amount</p>
            <div 
              className="flex items-center gap-1.5 cursor-help"
              onMouseEnter={() => setShowPriceBreakdown(true)}
              onMouseLeave={() => setShowPriceBreakdown(false)}
              onClick={() => setShowPriceBreakdown(!showPriceBreakdown)}
            >
              {/* Only show strikethrough when there's a lab visit discount - compare with original price including fees */}
              {selectedLab && selectedLabPrice && selectedLabPrice.discountPercent > 0 && !homeCollection && (() => {
                const originalWithFees = calculatePatientPrice(selectedLabPrice.basePrice * patientCount, selectedLabInfo?.country || test.country, selectedLabPrice.currency);
                return (
                  <span className="text-sm text-gray-400 line-through">
                    {currencySymbol}{originalWithFees.totalPrice}
                  </span>
                );
              })()}
              <span className="text-2xl font-bold text-gray-900">
                {selectedLab ? `${currencySymbol}${totalPrice}` : `${currencySymbol}0`}
              </span>
              {selectedLab && <Info className="w-4 h-4 text-gray-400" />}
            </div>
            {selectedLab && (!selectedLabPrice?.discountPercent || homeCollection) && (
              <p className="text-xs text-gray-500">inc. fees</p>
            )}
            {selectedLab && selectedLabPrice && selectedLabPrice.discountPercent > 0 && !homeCollection && (
              <p className="text-xs text-green-600">{selectedLabPrice.discountPercent}% off</p>
            )}
            {patientCount > 1 && selectedLab && selectedLabPrice && (
              <p className="text-xs text-gray-500">
                {patientCount} patients × {currencySymbol}{priceBreakdown ? Math.round(priceBreakdown.totalPrice / patientCount) : 0}
              </p>
            )}

            {/* Price Breakdown Tooltip */}
            {showPriceBreakdown && selectedLab && priceBreakdown && (
              <div className="absolute bottom-full left-0 mb-2 bg-gray-900 text-white text-xs rounded-lg p-4 z-50 min-w-[220px] shadow-lg">
                <p className="font-medium mb-2 text-gray-300">Price Breakdown</p>
                <div className="space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Lab receives</span>
                    <span>{currencySymbol}{priceBreakdown.basePrice}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Service fee (5%)</span>
                    <span>{currencySymbol}{priceBreakdown.serviceFee}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">{getVatLabel(selectedLabInfo?.country || test.country)} ({Math.round(priceBreakdown.vatRate * 100)}%)</span>
                    <span>{currencySymbol}{priceBreakdown.vat}</span>
                  </div>
                  <div className="border-t border-gray-700 pt-1.5 mt-1.5 flex justify-between font-medium">
                    <span>You pay</span>
                    <span className="text-green-400">{currencySymbol}{priceBreakdown.totalPrice}</span>
                  </div>
                </div>
                <div className="absolute bottom-0 left-8 transform translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900" />
              </div>
            )}
          </div>
          <button
            disabled={!selectedLab}
            onClick={() => {
              if (selectedLab && selectedLabInfo && selectedLabPrice && priceBreakdown) {
                // Add items for each patient - use the total price with fees
                for (let i = 0; i < patientCount; i++) {
                  addItem({
                    id: test.id,
                    type: 'test',
                    name: test.name,
                    description: test.description,
                    price: Math.round(priceBreakdown.totalPrice / patientCount),
                    currency: selectedLabPrice.currency,
                    labId: selectedLabInfo.id,
                    labName: selectedLabInfo.name,
                    homeCollection,
                    country: selectedLabInfo.country,
                  });
                }
                setCartAdded(true);
                setTimeout(() => setCartAdded(false), 2500);
              }
            }}
            className={cn(
              'flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all',
              selectedLab
                ? 'bg-primary text-white hover:bg-primary/90'
                : 'bg-gray-200 text-gray-500 cursor-not-allowed'
            )}
          >
            <ShoppingCart className="w-5 h-5" />
            <span>{cartAdded ? 'Added!' : 'Add to Cart'}</span>
          </button>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
