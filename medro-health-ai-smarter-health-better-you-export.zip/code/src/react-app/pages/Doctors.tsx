import { useState } from 'react';
import { 
  Search, Filter, ChevronRight, Stethoscope, Baby, Heart, Sparkles, Pill, 
  Activity, Brain, Apple, HeartPulse, Droplets, Salad, Smile, 
  BrainCircuit, MessageCircleHeart, Bone, Globe, ChevronDown, Check, PawPrint, Languages, X
} from 'lucide-react';
import Header from '@/react-app/components/Header';
import BottomNav from '@/react-app/components/BottomNav';
import DoctorCard from '@/react-app/components/DoctorCard';
import ForeignDoctorModal from '@/react-app/components/ForeignDoctorModal';
import { doctors, specialties, symptoms, doctorCountries, doctorLanguages, Doctor } from '@/react-app/data/doctors';
import { cn } from '@/react-app/lib/utils';
import { useLanguage } from '@/react-app/contexts/LanguageContext';

const iconMap: Record<string, React.ElementType> = {
  Stethoscope, Baby, Heart, Sparkles, Pill, Activity, Brain, Apple,
  HeartPulse, Droplets, Salad, Smile, BrainCircuit, MessageCircleHeart, Bone, PawPrint
};

function SpecialtyIcon({ iconName, className }: { iconName: string; className?: string }) {
  const IconComponent = iconMap[iconName] || Stethoscope;
  return <IconComponent className={className} />;
}

type TabType = 'departments' | 'symptoms';

export default function DoctorsPage() {
  const { t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState<string | null>(null);
  const [selectedSymptom, setSelectedSymptom] = useState<string | null>(null);
  const [showAllSpecialties, setShowAllSpecialties] = useState(false);
  const [activeTab, setActiveTab] = useState<TabType>('departments');
  
  // Country filter state
  const [selectedCountry, setSelectedCountry] = useState('ALL');
  const [patientCountry, setPatientCountry] = useState('GB'); // Default patient country
  const [showCountryFilter, setShowCountryFilter] = useState(true); // Collapsed when country selected
  const [showPatientCountryFilter, setShowPatientCountryFilter] = useState(false);
  const [licensedOnly, setLicensedOnly] = useState(false);
  
  // Language filter state
  const [selectedLanguage, setSelectedLanguage] = useState<string | null>(null);
  const [showLanguageFilter, setShowLanguageFilter] = useState(false);
  
  // Foreign doctor modal
  const [foreignDoctor, setForeignDoctor] = useState<Doctor | null>(null);

  const displayedSpecialties = showAllSpecialties ? specialties : specialties.slice(0, 6);
  const displayedSymptoms = symptoms;

  // Get related specialties when a symptom is selected
  const symptomSpecialties = selectedSymptom 
    ? symptoms.find(s => s.id === selectedSymptom)?.relatedSpecialties || []
    : [];

  const filteredDoctors = doctors.filter(doctor => {
    const matchesSearch = doctor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doctor.specialty.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Filter by doctor's country
    if (selectedCountry !== 'ALL' && doctor.country !== selectedCountry) {
      return false;
    }
    
    // Filter by licensed in patient's country only
    if (licensedOnly && !doctor.licensedCountries.includes(patientCountry)) {
      return false;
    }
    
    // Filter by language
    if (selectedLanguage && !doctor.languages.includes(selectedLanguage)) {
      return false;
    }
    
    // Filter by department
    if (activeTab === 'departments' && selectedSpecialty) {
      return matchesSearch && doctor.specialtyId === selectedSpecialty;
    }
    
    // Filter by symptom (using related specialties)
    if (activeTab === 'symptoms' && selectedSymptom) {
      return matchesSearch && symptomSpecialties.includes(doctor.specialtyId);
    }
    
    return matchesSearch;
  });

  const handleTabChange = (tab: TabType) => {
    setActiveTab(tab);
    setSelectedSpecialty(null);
    setSelectedSymptom(null);
  };

  const getResultTitle = () => {
    if (activeTab === 'departments' && selectedSpecialty) {
      return specialties.find(s => s.id === selectedSpecialty)?.name || 'All Doctors';
    }
    if (activeTab === 'symptoms' && selectedSymptom) {
      return `Doctors for "${symptoms.find(s => s.id === selectedSymptom)?.name}"`;
    }
    return 'All Doctors';
  };

  const handleForeignDoctorClick = (doctor: Doctor) => {
    setForeignDoctor(doctor);
  };

  const getPatientCountryInfo = () => {
    return doctorCountries.find(c => c.code === patientCountry) || doctorCountries[1];
  };

  const getSelectedCountryInfo = () => {
    return doctorCountries.find(c => c.code === selectedCountry) || doctorCountries[0];
  };

  const handleCountrySelect = (code: string) => {
    setSelectedCountry(code);
    // Collapse the filter when a specific country is selected
    if (code !== 'ALL') {
      setShowCountryFilter(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      <Header title={t('doctors.title')} />
      
      <main className="px-4 py-4 max-w-lg mx-auto space-y-4">
        {/* Patient Country Selector */}
        <div className="bg-white rounded-xl border border-gray-100 p-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-primary" />
              <span className="text-sm text-gray-600">{t('doctors.yourLocation')}</span>
            </div>
            <button 
              onClick={() => setShowPatientCountryFilter(!showPatientCountryFilter)}
              className="flex items-center gap-2 px-3 py-1.5 bg-primary/10 rounded-lg text-primary font-medium text-sm"
            >
              <span>{getPatientCountryInfo().flag} {getPatientCountryInfo().name}</span>
              <ChevronDown className={cn('w-4 h-4 transition-transform', showPatientCountryFilter && 'rotate-180')} />
            </button>
          </div>
          
          {showPatientCountryFilter && (
            <div className="mt-3 pt-3 border-t border-gray-100 grid grid-cols-2 gap-2">
              {doctorCountries.filter(c => c.code !== 'ALL').map((country) => (
                <button
                  key={country.code}
                  onClick={() => {
                    setPatientCountry(country.code);
                    setShowPatientCountryFilter(false);
                  }}
                  className={cn(
                    'flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-all',
                    patientCountry === country.code
                      ? 'bg-primary text-white'
                      : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                  )}
                >
                  <span>{country.flag}</span>
                  <span className="truncate">{country.name}</span>
                  {patientCountry === country.code && <Check className="w-4 h-4 ml-auto" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder={t('doctors.search')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-xl text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
          />
        </div>

        {/* Filters Row - Country & Language */}
        <div className="flex gap-2">
          {/* Country Filter - Compact */}
          <div className="flex-1 bg-white rounded-xl border border-gray-200 p-2">
            <button 
              onClick={() => {
                setShowCountryFilter(!showCountryFilter);
                setShowLanguageFilter(false);
              }}
              className="w-full flex items-center justify-between"
            >
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-primary" />
                <span className="text-xs text-gray-600">{t('doctors.country')}</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-sm font-medium">{getSelectedCountryInfo().flag}</span>
                <ChevronDown className={cn('w-3 h-3 text-gray-400 transition-transform', showCountryFilter && 'rotate-180')} />
              </div>
            </button>
          </div>
          
          {/* Language Filter - Compact */}
          <div className="flex-1 bg-white rounded-xl border border-gray-200 p-2">
            <button 
              onClick={() => {
                setShowLanguageFilter(!showLanguageFilter);
                setShowCountryFilter(false);
              }}
              className="w-full flex items-center justify-between"
            >
              <div className="flex items-center gap-2">
                <Languages className="w-4 h-4 text-primary" />
                <span className="text-xs text-gray-600">{t('doctors.language')}</span>
              </div>
              <div className="flex items-center gap-1">
                {selectedLanguage ? (
                  <span className="text-xs font-medium text-primary">{selectedLanguage}</span>
                ) : (
                  <span className="text-xs text-gray-400">All</span>
                )}
                <ChevronDown className={cn('w-3 h-3 text-gray-400 transition-transform', showLanguageFilter && 'rotate-180')} />
              </div>
            </button>
          </div>
        </div>
        
        {/* Country Filter Dropdown */}
        {showCountryFilter && (
          <div className="bg-white rounded-xl border border-gray-200 p-3 space-y-3">
            <div className="flex flex-wrap gap-2">
              {doctorCountries.map((country) => (
                <button
                  key={country.code}
                  onClick={() => {
                    handleCountrySelect(country.code);
                    setShowCountryFilter(false);
                  }}
                  className={cn(
                    'flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium transition-all',
                    selectedCountry === country.code
                      ? 'bg-primary text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  )}
                >
                  <span>{country.flag}</span>
                  <span>{country.name}</span>
                </button>
              ))}
            </div>
            
            <div className="pt-3 border-t border-gray-100">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={licensedOnly}
                  onChange={(e) => setLicensedOnly(e.target.checked)}
                  className="w-4 h-4 rounded border-gray-300 text-primary focus:ring-primary"
                />
                <span className="text-xs text-gray-700">
                  Licensed in {getPatientCountryInfo().flag} {getPatientCountryInfo().name}
                </span>
              </label>
            </div>
          </div>
        )}
        
        {/* Language Filter Dropdown */}
        {showLanguageFilter && (
          <div className="bg-white rounded-xl border border-gray-200 p-3">
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => {
                  setSelectedLanguage(null);
                  setShowLanguageFilter(false);
                }}
                className={cn(
                  'px-3 py-1.5 rounded-full text-sm font-medium transition-all',
                  !selectedLanguage
                    ? 'bg-primary text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                )}
              >
                {t('doctors.allLanguages')}
              </button>
              {doctorLanguages.map((lang) => (
                <button
                  key={lang}
                  onClick={() => {
                    setSelectedLanguage(lang);
                    setShowLanguageFilter(false);
                  }}
                  className={cn(
                    'px-3 py-1.5 rounded-full text-sm font-medium transition-all',
                    selectedLanguage === lang
                      ? 'bg-primary text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  )}
                >
                  {lang}
                </button>
              ))}
            </div>
          </div>
        )}
        
        {/* Active Filters */}
        {(selectedCountry !== 'ALL' || selectedLanguage) && (
          <div className="flex flex-wrap gap-2">
            {selectedCountry !== 'ALL' && (
              <span className="inline-flex items-center gap-1 px-2 py-1 bg-primary/10 text-primary rounded-full text-xs font-medium">
                {getSelectedCountryInfo().flag} {getSelectedCountryInfo().name}
                <button onClick={() => setSelectedCountry('ALL')} className="hover:bg-primary/20 rounded-full p-0.5">
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
            {selectedLanguage && (
              <span className="inline-flex items-center gap-1 px-2 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-medium">
                <Languages className="w-3 h-3" />
                {selectedLanguage}
                <button onClick={() => setSelectedLanguage(null)} className="hover:bg-purple-200 rounded-full p-0.5">
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
          </div>
        )}

        {/* Departments / Symptoms Toggle Tabs */}
        <div className="bg-gray-100 rounded-xl p-1 flex">
          <button
            onClick={() => handleTabChange('departments')}
            className={cn(
              'flex-1 py-2.5 rounded-lg text-sm font-medium transition-all',
              activeTab === 'departments'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-500 hover:text-gray-700'
            )}
          >
            {t('doctors.departments')}
          </button>
          <button
            onClick={() => handleTabChange('symptoms')}
            className={cn(
              'flex-1 py-2.5 rounded-lg text-sm font-medium transition-all',
              activeTab === 'symptoms'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-500 hover:text-gray-700'
            )}
          >
            {t('doctors.symptoms')}
          </button>
        </div>

        {/* Departments Grid */}
        {activeTab === 'departments' && (
          <section>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-bold text-gray-900">{t('doctors.chooseDepartment')}</h2>
              <button
                onClick={() => setShowAllSpecialties(!showAllSpecialties)}
                className="text-sm text-primary font-medium flex items-center gap-1"
              >
                {showAllSpecialties ? t('common.showLess') : t('common.viewAll')} 
                <ChevronRight className={cn('w-4 h-4 transition-transform', showAllSpecialties && 'rotate-90')} />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {displayedSpecialties.map((specialty) => (
                <button
                  key={specialty.id}
                  onClick={() => setSelectedSpecialty(
                    selectedSpecialty === specialty.id ? null : specialty.id
                  )}
                  className={cn(
                    'flex flex-col items-center gap-2 p-4 rounded-2xl border transition-all duration-200',
                    selectedSpecialty === specialty.id
                      ? 'bg-primary/10 border-primary text-primary'
                      : 'bg-white border-gray-100 text-gray-600 hover:border-gray-200 hover:shadow-sm'
                  )}
                >
                  <div className={cn(
                    'w-12 h-12 rounded-xl flex items-center justify-center',
                    selectedSpecialty === specialty.id
                      ? 'bg-primary/20'
                      : 'bg-blue-50'
                  )}>
                    <SpecialtyIcon 
                      iconName={specialty.icon} 
                      className={cn(
                        'w-6 h-6',
                        selectedSpecialty === specialty.id ? 'text-primary' : 'text-blue-600'
                      )} 
                    />
                  </div>
                  <div className="text-center">
                    <p className={cn(
                      'text-sm font-medium leading-tight',
                      selectedSpecialty === specialty.id ? 'text-primary' : 'text-gray-900'
                    )}>
                      {specialty.name}
                    </p>
                    <p className="text-xs text-gray-500 mt-0.5">{specialty.subtitle}</p>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Symptoms Grid */}
        {activeTab === 'symptoms' && (
          <section>
            <h2 className="text-lg font-bold text-gray-900 mb-3">{t('doctors.whatsConcern')}</h2>
            <div className="grid grid-cols-4 gap-2">
              {displayedSymptoms.map((symptom) => (
                <button
                  key={symptom.id}
                  onClick={() => setSelectedSymptom(
                    selectedSymptom === symptom.id ? null : symptom.id
                  )}
                  className={cn(
                    'flex flex-col items-center p-2 rounded-xl border transition-all duration-200',
                    selectedSymptom === symptom.id
                      ? 'bg-primary/10 border-primary ring-2 ring-primary/20'
                      : 'bg-white border-gray-100 hover:border-gray-200 hover:shadow-sm'
                  )}
                >
                  <div className="w-full aspect-square rounded-lg overflow-hidden mb-2">
                    <img 
                      src={symptom.image} 
                      alt={symptom.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <p className={cn(
                    'text-xs font-medium text-center leading-tight line-clamp-2',
                    selectedSymptom === symptom.id ? 'text-primary' : 'text-gray-700'
                  )}>
                    {symptom.name}
                  </p>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Recently Viewed Section */}
        {!selectedSpecialty && !selectedSymptom && (
          <section>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-bold text-gray-900">{t('doctors.recentlyViewed')}</h2>
              <button className="text-sm text-primary font-medium">{t('common.viewAll')}</button>
            </div>
            <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
              {doctors.slice(0, 4).map((doctor) => (
                <div key={doctor.id} className="flex-shrink-0 w-36">
                  <div className="bg-white rounded-2xl border border-gray-100 p-3 shadow-sm">
                    <div className="relative">
                      <img
                        src={doctor.image}
                        alt={doctor.name}
                        className="w-full h-28 rounded-xl object-cover"
                      />
                      {doctor.isOnline && (
                        <span className="absolute top-2 right-2 w-3 h-3 bg-green-500 border-2 border-white rounded-full" />
                      )}
                      <span className="absolute top-2 left-2 text-sm bg-white/90 rounded px-1">
                        {doctor.countryFlag}
                      </span>
                    </div>
                    <h3 className="font-medium text-gray-900 text-sm mt-2 truncate">{doctor.name}</h3>
                    <p className="text-xs text-primary truncate">{doctor.specialty}</p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-sm font-bold text-gray-900">
                        {doctor.currency === 'BDT' ? '৳' : doctor.currency === 'GBP' ? '£' : '$'}{doctor.price}
                      </span>
                      <ChevronRight className="w-4 h-4 text-primary" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Doctor List */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold text-gray-900">
              {getResultTitle()}
            </h2>
            <span className="text-sm text-gray-500">{filteredDoctors.length} {t('doctors.doctorsCount')}</span>
          </div>
          <div className="space-y-3">
            {filteredDoctors.length > 0 ? (
              filteredDoctors.map((doctor) => (
                <DoctorCard 
                  key={doctor.id} 
                  doctor={doctor} 
                  patientCountry={patientCountry}
                  onForeignDoctorClick={handleForeignDoctorClick}
                />
              ))
            ) : (
              <div className="text-center py-8 bg-white rounded-2xl border border-gray-100">
                <Stethoscope className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">{t('doctors.noResults')}</p>
                <p className="text-sm text-gray-400">{t('doctors.tryDifferent')}</p>
              </div>
            )}
          </div>
        </section>
      </main>
      
      <BottomNav />

      {/* Foreign Doctor Modal */}
      {foreignDoctor && (
        <ForeignDoctorModal
          doctor={foreignDoctor}
          patientCountry={patientCountry}
          onClose={() => setForeignDoctor(null)}
        />
      )}
    </div>
  );
}
