import { useNavigate } from 'react-router';
import { 
  ArrowLeft, User, Settings, Shield, Bell, CreditCard, 
  HelpCircle, LogOut, ChevronRight, Star, Calendar, Users, Award, LogIn
} from 'lucide-react';
import { useAuth } from '@/react-app/contexts/AuthContext';

export default function DoctorProfilePage() {
  const navigate = useNavigate();
  const { user, isGuest, logout, exitGuestMode } = useAuth();

  const handleLogout = async () => {
    if (isGuest) {
      exitGuestMode();
    } else {
      await logout();
    }
    navigate('/login');
  };

  const stats = [
    { icon: Star, label: 'Rating', value: '4.8' },
    { icon: Calendar, label: 'Experience', value: '8 yrs' },
    { icon: Users, label: 'Patients', value: '156' },
  ];

  const menuItems = [
    { icon: User, label: 'Edit Profile', to: '/doctor/profile/edit' },
    { icon: Calendar, label: 'Manage Schedule', to: '/doctor/schedule' },
    { icon: CreditCard, label: 'Earnings & Payments', to: '/doctor/earnings' },
    { icon: Award, label: 'Certifications', to: '/doctor/certifications' },
    { icon: Shield, label: 'Privacy & Security', to: '/doctor/privacy' },
    { icon: Bell, label: 'Notifications', to: '/doctor/notifications' },
    { icon: Settings, label: 'App Settings', to: '/doctor/settings' },
    { icon: HelpCircle, label: 'Help & Support', to: '/doctor/help' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      {/* Header */}
      <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 z-40">
        <div className="flex items-center gap-3 max-w-4xl mx-auto">
          <button
            onClick={() => navigate('/doctor/dashboard')}
            className="p-2 -ml-2 rounded-full hover:bg-gray-100 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
          <h1 className="text-lg font-bold text-gray-900">Profile</h1>
        </div>
      </header>

      <main className="px-4 py-6 max-w-4xl mx-auto space-y-6">
        {/* Doctor Card */}
        {isGuest ? (
          <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl shadow-lg p-6 text-white">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
                <User className="w-10 h-10 text-white" />
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-bold">Dr. Guest</h2>
                <p className="text-white/80">Exploring Doctor Portal</p>
              </div>
            </div>
            <p className="text-white/90 text-sm mb-4">
              Create an account to manage appointments, connect with patients, and build your practice.
            </p>
            <button
              onClick={() => navigate('/login')}
              className="w-full flex items-center justify-center gap-2 py-3 bg-white text-indigo-600 font-semibold rounded-xl hover:bg-white/90 transition-colors"
            >
              <LogIn className="w-5 h-5" />
              <span>Create Doctor Account</span>
            </button>
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <div className="flex items-center gap-4 mb-4">
              {user?.avatar ? (
                <img src={user.avatar} alt="" className="w-20 h-20 rounded-full" />
              ) : (
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center">
                  <span className="text-3xl font-bold text-primary">
                    {user?.name?.charAt(0) || 'D'}
                  </span>
                </div>
              )}
              <div className="flex-1">
                <h2 className="text-xl font-bold text-gray-900">Dr. {user?.name || 'Doctor'}</h2>
                <p className="text-gray-500">{user?.email}</p>
                <span className="inline-block mt-2 px-3 py-1 bg-indigo-100 text-indigo-700 text-sm font-medium rounded-full">
                  General Physician
                </span>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-3 pt-4 border-t border-gray-100">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-2">
                    <stat.icon className="w-5 h-5 text-primary" />
                  </div>
                  <p className="text-lg font-bold text-gray-900">{stat.value}</p>
                  <p className="text-xs text-gray-500">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Verification Badge */}
        {!isGuest && (
          <div className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
              <Award className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-white font-semibold">Verified Doctor</p>
              <p className="text-white/80 text-sm">BMDC Registration: A-12345</p>
            </div>
          </div>
        )}

        {/* Menu Items */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm divide-y divide-gray-100">
          {menuItems.map((item) => (
            <button
              key={item.label}
              onClick={() => navigate(item.to)}
              className="w-full flex items-center gap-4 p-4 hover:bg-gray-50 transition-colors text-left"
            >
              <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center">
                <item.icon className="w-5 h-5 text-gray-600" />
              </div>
              <span className="flex-1 font-medium text-gray-900">{item.label}</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
          ))}
        </div>

        {/* Logout Button */}
        <button
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-2 p-4 bg-red-50 text-red-600 rounded-2xl font-medium hover:bg-red-100 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span>{isGuest ? 'Exit Guest Mode' : 'Log Out'}</span>
        </button>

        {/* App Info */}
        <div className="text-center text-sm text-gray-400">
          <p>Medro for Doctors v1.0.0</p>
        </div>
      </main>
    </div>
  );
}
