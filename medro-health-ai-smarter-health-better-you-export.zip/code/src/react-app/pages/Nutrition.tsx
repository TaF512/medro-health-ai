import { useState, useRef } from 'react';
import { useNavigate } from 'react-router';
import { 
  ArrowLeft, 
  Camera, 
  UtensilsCrossed,
  Droplets,
  Wheat,
  Beef,
  X,
  AlertTriangle,
  CheckCircle,
  Loader2,
  ScanBarcode,
  Package,
  Search,
  Mic,
  Scale,
  Footprints
} from 'lucide-react';
import { cn } from '@/react-app/lib/utils';
import BottomNav from '@/react-app/components/BottomNav';

interface FoodEntry {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  time: string;
  image?: string;
  warnings?: string[];
  suggestions?: string[];
}

const initialFoods: FoodEntry[] = [
  {
    id: '1',
    name: 'Oatmeal with Berries',
    calories: 320,
    protein: 12,
    carbs: 54,
    fat: 6,
    time: '8:30 AM',
    suggestions: ['Great fiber content!']
  },
  {
    id: '2',
    name: 'Grilled Chicken Salad',
    calories: 420,
    protein: 35,
    carbs: 18,
    fat: 22,
    time: '1:00 PM',
    suggestions: ['Good protein source']
  }
];

interface FoodItem {
  name: string;
  portion: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

interface FoodAnalysis {
  items: FoodItem[];
  totals: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
  mealName: string;
  healthScore: number;
  warnings: string[];
  suggestions: string[];
  details: string;
}

// AI-powered food analysis using Gemini
const analyzeFoodImage = async (imageSrc: string): Promise<{ entry: Partial<FoodEntry>; analysis: FoodAnalysis | null }> => {
  try {
    // Extract base64 data and mime type from data URL
    const matches = imageSrc.match(/^data:(.+);base64,(.+)$/);
    if (!matches) {
      throw new Error("Invalid image format");
    }
    
    const mimeType = matches[1];
    const base64Data = matches[2];

    const response = await fetch("/api/analyze-food", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        image: base64Data,
        mimeType: mimeType
      })
    });

    if (!response.ok) {
      throw new Error("Failed to analyze food");
    }

    const data: FoodAnalysis = await response.json();
    
    return {
      entry: {
        name: data.mealName,
        calories: data.totals.calories,
        protein: data.totals.protein,
        carbs: data.totals.carbs,
        fat: data.totals.fat,
        warnings: data.warnings,
        suggestions: data.suggestions
      },
      analysis: data
    };
  } catch (error) {
    console.error("Food analysis error:", error);
    // Return fallback error response
    return {
      entry: {
        name: "Unable to analyze",
        calories: 0,
        protein: 0,
        carbs: 0,
        fat: 0,
        warnings: ["Could not analyze this image. Please try again with a clearer photo."],
        suggestions: ["Make sure the food is clearly visible", "Try taking the photo in good lighting"]
      },
      analysis: null
    };
  }
};

interface BarcodeProduct {
  found: boolean;
  name: string;
  brand: string;
  servingSize: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  image: string | null;
  nutritionGrade: string | null;
  warnings: string[];
  suggestions: string[];
  details: {
    sugars: number;
    fiber: number;
    sodium: number;
  };
}

export default function NutritionPage() {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [foods, setFoods] = useState<FoodEntry[]>(initialFoods);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [analyzedFood, setAnalyzedFood] = useState<Partial<FoodEntry> | null>(null);
  const [foodAnalysis, setFoodAnalysis] = useState<FoodAnalysis | null>(null);
  
  // Barcode scanning state
  const [showBarcodeModal, setShowBarcodeModal] = useState(false);
  const [barcodeInput, setBarcodeInput] = useState('');
  const [isLookingUp, setIsLookingUp] = useState(false);
  const [barcodeProduct, setBarcodeProduct] = useState<BarcodeProduct | null>(null);
  const [barcodeError, setBarcodeError] = useState<string | null>(null);
  
  // Manual food log state
  const [showLogFoodModal, setShowLogFoodModal] = useState(false);
  const [manualFood, setManualFood] = useState({ name: '', calories: '', protein: '', carbs: '', fat: '' });

  const totalCalories = foods.reduce((sum, f) => sum + f.calories, 0);
  const totalProtein = foods.reduce((sum, f) => sum + f.protein, 0);
  const totalCarbs = foods.reduce((sum, f) => sum + f.carbs, 0);
  const totalFat = foods.reduce((sum, f) => sum + f.fat, 0);

  const calorieGoal = 2000;
  const calorieProgress = Math.min((totalCalories / calorieGoal) * 100, 100);

  const handleImageCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const imageSrc = event.target?.result as string;
      setCapturedImage(imageSrc);
      setShowAddModal(true);
      setIsAnalyzing(true);

      try {
        const { entry, analysis } = await analyzeFoodImage(imageSrc);
        setAnalyzedFood(entry);
        setFoodAnalysis(analysis);
      } catch (error) {
        console.error('Failed to analyze food:', error);
      } finally {
        setIsAnalyzing(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const addAnalyzedFood = () => {
    if (!analyzedFood?.name) return;

    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });

    setFoods(prev => [...prev, {
      id: Date.now().toString(),
      name: analyzedFood.name!,
      calories: analyzedFood.calories || 0,
      protein: analyzedFood.protein || 0,
      carbs: analyzedFood.carbs || 0,
      fat: analyzedFood.fat || 0,
      time: timeStr,
      image: capturedImage || undefined,
      warnings: analyzedFood.warnings,
      suggestions: analyzedFood.suggestions
    }]);

    setShowAddModal(false);
    setCapturedImage(null);
    setAnalyzedFood(null);
    setFoodAnalysis(null);
  };

  const deleteFood = (id: string) => {
    setFoods(prev => prev.filter(f => f.id !== id));
  };

  // Barcode lookup function
  const lookupBarcode = async () => {
    if (!barcodeInput.trim()) return;
    
    setIsLookingUp(true);
    setBarcodeError(null);
    setBarcodeProduct(null);
    
    try {
      const response = await fetch(`/api/barcode/${barcodeInput.trim()}`);
      const data = await response.json();
      
      if (!response.ok || !data.found) {
        setBarcodeError("Product not found. Please check the barcode and try again.");
        return;
      }
      
      setBarcodeProduct(data as BarcodeProduct);
    } catch (error) {
      console.error("Barcode lookup error:", error);
      setBarcodeError("Failed to lookup barcode. Please try again.");
    } finally {
      setIsLookingUp(false);
    }
  };

  // Add barcode product to food log
  const addBarcodeProduct = () => {
    if (!barcodeProduct) return;
    
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
    
    const productName = barcodeProduct.brand 
      ? `${barcodeProduct.name} (${barcodeProduct.brand})`
      : barcodeProduct.name;
    
    setFoods(prev => [...prev, {
      id: Date.now().toString(),
      name: productName,
      calories: barcodeProduct.calories,
      protein: barcodeProduct.protein,
      carbs: barcodeProduct.carbs,
      fat: barcodeProduct.fat,
      time: timeStr,
      image: barcodeProduct.image || undefined,
      warnings: barcodeProduct.warnings,
      suggestions: barcodeProduct.suggestions
    }]);
    
    // Reset barcode modal state
    setShowBarcodeModal(false);
    setBarcodeInput('');
    setBarcodeProduct(null);
    setBarcodeError(null);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="sticky top-0 bg-gradient-to-r from-orange-500 to-orange-600 px-4 py-4 z-40">
        <div className="flex items-center gap-3 max-w-lg mx-auto">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 rounded-full hover:bg-white/20 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-white">What I Ate Today</h1>
            <p className="text-sm text-white/80">Track your nutrition</p>
          </div>
          <button
            onClick={() => setShowBarcodeModal(true)}
            className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
            title="Scan Barcode"
          >
            <ScanBarcode className="w-5 h-5 text-white" />
          </button>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
            title="Photo Analysis"
          >
            <Camera className="w-5 h-5 text-white" />
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleImageCapture}
            className="hidden"
          />
        </div>
      </header>

      <main className="px-4 py-6 max-w-lg mx-auto space-y-6">
        {/* Daily Summary */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-semibold text-gray-900">Today's Calories</h2>
              <p className="text-sm text-gray-500">{totalCalories} of {calorieGoal} kcal</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-orange-600">{totalCalories}</p>
              <p className="text-xs text-gray-500">kcal consumed</p>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="h-3 bg-gray-100 rounded-full overflow-hidden mb-4">
            <div 
              className={cn(
                'h-full rounded-full transition-all duration-500',
                calorieProgress > 100 ? 'bg-red-500' : 
                calorieProgress > 80 ? 'bg-amber-500' : 'bg-orange-500'
              )}
              style={{ width: `${Math.min(calorieProgress, 100)}%` }}
            />
          </div>

          {/* Macro Breakdown */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-red-50 rounded-xl p-3 text-center">
              <Beef className="w-5 h-5 text-red-600 mx-auto mb-1" />
              <p className="text-lg font-bold text-red-700">{totalProtein}g</p>
              <p className="text-xs text-red-600">Protein</p>
            </div>
            <div className="bg-amber-50 rounded-xl p-3 text-center">
              <Wheat className="w-5 h-5 text-amber-600 mx-auto mb-1" />
              <p className="text-lg font-bold text-amber-700">{totalCarbs}g</p>
              <p className="text-xs text-amber-600">Carbs</p>
            </div>
            <div className="bg-blue-50 rounded-xl p-3 text-center">
              <Droplets className="w-5 h-5 text-blue-600 mx-auto mb-1" />
              <p className="text-lg font-bold text-blue-700">{totalFat}g</p>
              <p className="text-xs text-blue-600">Fat</p>
            </div>
          </div>
        </div>

        {/* Scan Options - 2x2 Grid like reference */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
          <div className="grid grid-cols-2 gap-3">
            {/* Log Food */}
            <button
              onClick={() => setShowLogFoodModal(true)}
              className="flex flex-col items-center p-4 rounded-xl border-2 border-gray-200 bg-gray-50 hover:border-blue-400 hover:bg-blue-50 transition-all"
            >
              <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center mb-2">
                <Search className="w-5 h-5 text-white" />
              </div>
              <span className="text-sm font-medium text-gray-900">Log Food</span>
            </button>
            
            {/* Barcode Scan */}
            <button
              onClick={() => setShowBarcodeModal(true)}
              className="flex flex-col items-center p-4 rounded-xl border-2 border-gray-200 bg-gray-50 hover:border-rose-400 hover:bg-rose-50 transition-all"
            >
              <div className="w-10 h-10 bg-rose-500 rounded-full flex items-center justify-center mb-2">
                <ScanBarcode className="w-5 h-5 text-white" />
              </div>
              <span className="text-sm font-medium text-gray-900">Barcode Scan</span>
            </button>
            
            {/* Voice Log */}
            <button
              onClick={() => {/* Voice logging - future feature */}}
              className="flex flex-col items-center p-4 rounded-xl border-2 border-gray-200 bg-gray-50 hover:border-orange-400 hover:bg-orange-50 transition-all"
            >
              <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center mb-2">
                <Mic className="w-5 h-5 text-white" />
              </div>
              <span className="text-sm font-medium text-gray-900">Voice Log</span>
            </button>
            
            {/* Meal Scan */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex flex-col items-center p-4 rounded-xl border-2 border-gray-200 bg-gray-50 hover:border-teal-400 hover:bg-teal-50 transition-all"
            >
              <div className="w-10 h-10 bg-teal-500 rounded-full flex items-center justify-center mb-2">
                <Camera className="w-5 h-5 text-white" />
              </div>
              <span className="text-sm font-medium text-gray-900">Meal Scan</span>
            </button>
          </div>
          
          {/* Quick Log Options */}
          <div className="mt-4 space-y-2">
            <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-gray-50 transition-colors">
              <Droplets className="w-5 h-5 text-blue-500" />
              <span className="text-gray-700">Water</span>
            </button>
            <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-gray-50 transition-colors">
              <Scale className="w-5 h-5 text-purple-500" />
              <span className="text-gray-700">Weight</span>
            </button>
            <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-gray-50 transition-colors">
              <Footprints className="w-5 h-5 text-green-500" />
              <span className="text-gray-700">Exercise</span>
            </button>
          </div>
        </div>

        {/* Food Log */}
        <section>
          <h2 className="font-semibold text-gray-900 mb-3">Today's Meals</h2>
          <div className="space-y-3">
            {foods.map(food => (
              <div key={food.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="flex items-center gap-4 p-4">
                  {food.image ? (
                    <img src={food.image} alt="" className="w-14 h-14 rounded-xl object-cover" />
                  ) : (
                    <div className="w-14 h-14 bg-orange-100 rounded-xl flex items-center justify-center">
                      <UtensilsCrossed className="w-6 h-6 text-orange-600" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 truncate">{food.name}</p>
                    <p className="text-sm text-gray-500">{food.time}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-orange-600">{food.calories}</p>
                    <p className="text-xs text-gray-500">kcal</p>
                  </div>
                  <button
                    onClick={() => deleteFood(food.id)}
                    className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Macro details */}
                <div className="border-t border-gray-100 px-4 py-2 bg-gray-50 flex gap-4 text-xs">
                  <span className="text-red-600">P: {food.protein}g</span>
                  <span className="text-amber-600">C: {food.carbs}g</span>
                  <span className="text-blue-600">F: {food.fat}g</span>
                </div>

                {/* Warnings & Suggestions */}
                {(food.warnings?.length || food.suggestions?.length) && (
                  <div className="border-t border-gray-100 px-4 py-3 space-y-2">
                    {food.warnings?.map((warning, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-amber-700 text-sm">
                        <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                        <span>{warning}</span>
                      </div>
                    ))}
                    {food.suggestions?.map((suggestion, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-green-700 text-sm">
                        <CheckCircle className="w-4 h-4 flex-shrink-0" />
                        <span>{suggestion}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* Empty State */}
        {foods.length === 0 && (
          <div className="text-center py-12">
            <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <UtensilsCrossed className="w-10 h-10 text-orange-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">No meals logged</h3>
            <p className="text-gray-500 mt-1 mb-4">Take a photo of your food to start tracking</p>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-6 py-3 bg-orange-600 text-white rounded-xl font-semibold hover:bg-orange-700 transition-colors"
            >
              Scan Food
            </button>
          </div>
        )}
      </main>

      {/* Analysis Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="w-full bg-white rounded-t-3xl p-6 max-w-lg mx-auto max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Food Analysis</h2>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setCapturedImage(null);
                  setAnalyzedFood(null);
                  setFoodAnalysis(null);
                }}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            {/* Image Preview */}
            {capturedImage && (
              <div className="mb-4">
                <img src={capturedImage} alt="Food" className="w-full h-48 object-cover rounded-xl" />
              </div>
            )}

            {isAnalyzing ? (
              <div className="text-center py-8">
                <Loader2 className="w-12 h-12 text-orange-500 animate-spin mx-auto mb-4" />
                <p className="text-gray-700 font-medium">AI is analyzing your food...</p>
                <p className="text-sm text-gray-500 mt-1">Identifying all items and calculating accurate nutrition</p>
              </div>
            ) : analyzedFood ? (
              <div className="space-y-4">
                {/* Main Summary */}
                <div className="bg-gradient-to-r from-orange-500 to-amber-500 rounded-xl p-4 text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-bold text-lg">{analyzedFood.name}</h3>
                      {foodAnalysis && (
                        <p className="text-white/80 text-sm">{foodAnalysis.items.length} items detected</p>
                      )}
                    </div>
                    <div className="text-right">
                      <p className="text-3xl font-bold">{analyzedFood.calories}</p>
                      <p className="text-white/80 text-sm">total kcal</p>
                    </div>
                  </div>
                  {foodAnalysis && (
                    <div className="mt-3 flex items-center gap-2">
                      <span className="text-sm text-white/80">Health Score:</span>
                      <div className="flex-1 h-2 bg-white/30 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-white rounded-full"
                          style={{ width: `${foodAnalysis.healthScore * 10}%` }}
                        />
                      </div>
                      <span className="font-bold">{foodAnalysis.healthScore}/10</span>
                    </div>
                  )}
                </div>

                {/* Itemized Breakdown */}
                {foodAnalysis && foodAnalysis.items.length > 0 && (
                  <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
                    <div className="bg-gray-50 px-4 py-2 border-b border-gray-200">
                      <h4 className="font-semibold text-gray-700 text-sm">Items Detected</h4>
                    </div>
                    <div className="divide-y divide-gray-100">
                      {foodAnalysis.items.map((item, idx) => (
                        <div key={idx} className="px-4 py-3">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="font-medium text-gray-900">{item.name}</p>
                              <p className="text-xs text-gray-500">{item.portion}</p>
                            </div>
                            <p className="font-bold text-orange-600">{item.calories} kcal</p>
                          </div>
                          <div className="flex gap-3 mt-1 text-xs text-gray-500">
                            <span>P: {item.protein}g</span>
                            <span>C: {item.carbs}g</span>
                            <span>F: {item.fat}g</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Total Macros */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-red-50 rounded-xl p-3 text-center">
                    <p className="text-lg font-bold text-red-700">{analyzedFood.protein}g</p>
                    <p className="text-xs text-red-600">Protein</p>
                  </div>
                  <div className="bg-amber-50 rounded-xl p-3 text-center">
                    <p className="text-lg font-bold text-amber-700">{analyzedFood.carbs}g</p>
                    <p className="text-xs text-amber-600">Carbs</p>
                  </div>
                  <div className="bg-blue-50 rounded-xl p-3 text-center">
                    <p className="text-lg font-bold text-blue-700">{analyzedFood.fat}g</p>
                    <p className="text-xs text-blue-600">Fat</p>
                  </div>
                </div>

                {/* AI Analysis Details */}
                {foodAnalysis?.details && (
                  <div className="bg-purple-50 rounded-xl p-4 border border-purple-200">
                    <h4 className="font-semibold text-purple-800 mb-2">AI Analysis</h4>
                    <p className="text-sm text-purple-700">{foodAnalysis.details}</p>
                  </div>
                )}

                {/* Warnings */}
                {analyzedFood.warnings && analyzedFood.warnings.length > 0 && (
                  <div className="bg-amber-50 rounded-xl p-4 border border-amber-200">
                    <h4 className="font-semibold text-amber-800 mb-2 flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5" />
                      Health Warnings
                    </h4>
                    <ul className="space-y-1">
                      {analyzedFood.warnings.map((warning, idx) => (
                        <li key={idx} className="text-sm text-amber-700">• {warning}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Suggestions */}
                {analyzedFood.suggestions && analyzedFood.suggestions.length > 0 && (
                  <div className="bg-green-50 rounded-xl p-4 border border-green-200">
                    <h4 className="font-semibold text-green-800 mb-2 flex items-center gap-2">
                      <CheckCircle className="w-5 h-5" />
                      Suggestions
                    </h4>
                    <ul className="space-y-1">
                      {analyzedFood.suggestions.map((suggestion, idx) => (
                        <li key={idx} className="text-sm text-green-700">• {suggestion}</li>
                      ))}
                    </ul>
                  </div>
                )}

                <button
                  onClick={addAnalyzedFood}
                  className="w-full py-4 bg-orange-600 text-white rounded-xl font-semibold hover:bg-orange-700 transition-colors"
                >
                  Add to Today's Log
                </button>
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* Barcode Scan Modal */}
      {showBarcodeModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="w-full bg-white rounded-t-3xl p-6 max-w-lg mx-auto max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Scan Barcode</h2>
              <button
                onClick={() => {
                  setShowBarcodeModal(false);
                  setBarcodeInput('');
                  setBarcodeProduct(null);
                  setBarcodeError(null);
                }}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            {/* Barcode Input */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Enter barcode number
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={barcodeInput}
                  onChange={(e) => setBarcodeInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="e.g., 5000159407236"
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  onKeyDown={(e) => e.key === 'Enter' && lookupBarcode()}
                />
                <button
                  onClick={lookupBarcode}
                  disabled={isLookingUp || !barcodeInput.trim()}
                  className="px-5 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLookingUp ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Search'}
                </button>
              </div>
              <p className="text-xs text-gray-500 mt-2">
                Find the barcode on the product packaging (usually near ingredients)
              </p>
            </div>

            {/* Error Message */}
            {barcodeError && (
              <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-4">
                <div className="flex items-center gap-2 text-red-700">
                  <AlertTriangle className="w-5 h-5" />
                  <p className="font-medium">{barcodeError}</p>
                </div>
              </div>
            )}

            {/* Loading State */}
            {isLookingUp && (
              <div className="text-center py-8">
                <Loader2 className="w-12 h-12 text-purple-500 animate-spin mx-auto mb-4" />
                <p className="text-gray-700 font-medium">Looking up product...</p>
                <p className="text-sm text-gray-500 mt-1">Searching Open Food Facts database</p>
              </div>
            )}

            {/* Product Result */}
            {barcodeProduct && (
              <div className="space-y-4">
                {/* Product Header */}
                <div className="bg-gradient-to-r from-purple-500 to-indigo-500 rounded-xl p-4 text-white">
                  <div className="flex items-start gap-4">
                    {barcodeProduct.image ? (
                      <img 
                        src={barcodeProduct.image} 
                        alt={barcodeProduct.name}
                        className="w-16 h-16 rounded-lg object-cover bg-white"
                      />
                    ) : (
                      <div className="w-16 h-16 bg-white/20 rounded-lg flex items-center justify-center">
                        <Package className="w-8 h-8 text-white" />
                      </div>
                    )}
                    <div className="flex-1">
                      <h3 className="font-bold text-lg leading-tight">{barcodeProduct.name}</h3>
                      {barcodeProduct.brand && (
                        <p className="text-white/80 text-sm">{barcodeProduct.brand}</p>
                      )}
                      <p className="text-white/70 text-xs mt-1">{barcodeProduct.servingSize}</p>
                    </div>
                  </div>
                  <div className="mt-3 flex items-center justify-between">
                    <span className="text-white/80 text-sm">Calories</span>
                    <span className="text-2xl font-bold">{barcodeProduct.calories} kcal</span>
                  </div>
                  {barcodeProduct.nutritionGrade && (
                    <div className="mt-2 inline-flex items-center gap-2 bg-white/20 px-3 py-1 rounded-full text-sm">
                      <span>Nutri-Score:</span>
                      <span className={cn(
                        'font-bold px-2 py-0.5 rounded text-white',
                        barcodeProduct.nutritionGrade === 'a' && 'bg-green-500',
                        barcodeProduct.nutritionGrade === 'b' && 'bg-lime-500',
                        barcodeProduct.nutritionGrade === 'c' && 'bg-yellow-500',
                        barcodeProduct.nutritionGrade === 'd' && 'bg-orange-500',
                        barcodeProduct.nutritionGrade === 'e' && 'bg-red-500'
                      )}>
                        {barcodeProduct.nutritionGrade.toUpperCase()}
                      </span>
                    </div>
                  )}
                </div>

                {/* Macros */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-red-50 rounded-xl p-3 text-center">
                    <p className="text-lg font-bold text-red-700">{barcodeProduct.protein}g</p>
                    <p className="text-xs text-red-600">Protein</p>
                  </div>
                  <div className="bg-amber-50 rounded-xl p-3 text-center">
                    <p className="text-lg font-bold text-amber-700">{barcodeProduct.carbs}g</p>
                    <p className="text-xs text-amber-600">Carbs</p>
                  </div>
                  <div className="bg-blue-50 rounded-xl p-3 text-center">
                    <p className="text-lg font-bold text-blue-700">{barcodeProduct.fat}g</p>
                    <p className="text-xs text-blue-600">Fat</p>
                  </div>
                </div>

                {/* Additional Details */}
                <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                  <h4 className="font-semibold text-gray-700 text-sm mb-3">Additional Nutrients</h4>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-lg font-bold text-gray-800">{barcodeProduct.details.sugars}g</p>
                      <p className="text-xs text-gray-500">Sugars</p>
                    </div>
                    <div>
                      <p className="text-lg font-bold text-gray-800">{barcodeProduct.details.fiber}g</p>
                      <p className="text-xs text-gray-500">Fiber</p>
                    </div>
                    <div>
                      <p className="text-lg font-bold text-gray-800">{barcodeProduct.details.sodium}mg</p>
                      <p className="text-xs text-gray-500">Sodium</p>
                    </div>
                  </div>
                </div>

                {/* Warnings */}
                {barcodeProduct.warnings.length > 0 && (
                  <div className="bg-amber-50 rounded-xl p-4 border border-amber-200">
                    <h4 className="font-semibold text-amber-800 mb-2 flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5" />
                      Warnings
                    </h4>
                    <ul className="space-y-1">
                      {barcodeProduct.warnings.map((warning, idx) => (
                        <li key={idx} className="text-sm text-amber-700">• {warning}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Suggestions */}
                {barcodeProduct.suggestions.length > 0 && (
                  <div className="bg-green-50 rounded-xl p-4 border border-green-200">
                    <h4 className="font-semibold text-green-800 mb-2 flex items-center gap-2">
                      <CheckCircle className="w-5 h-5" />
                      Benefits
                    </h4>
                    <ul className="space-y-1">
                      {barcodeProduct.suggestions.map((suggestion, idx) => (
                        <li key={idx} className="text-sm text-green-700">• {suggestion}</li>
                      ))}
                    </ul>
                  </div>
                )}

                <button
                  onClick={addBarcodeProduct}
                  className="w-full py-4 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors"
                >
                  Add to Today's Log
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Log Food Modal */}
      {showLogFoodModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="w-full bg-white rounded-t-3xl p-6 max-w-lg mx-auto max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Log Food Manually</h2>
              <button
                onClick={() => {
                  setShowLogFoodModal(false);
                  setManualFood({ name: '', calories: '', protein: '', carbs: '', fat: '' });
                }}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Food Name</label>
                <input
                  type="text"
                  value={manualFood.name}
                  onChange={(e) => setManualFood(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="e.g., Chicken breast with rice"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Calories (kcal)</label>
                  <input
                    type="number"
                    value={manualFood.calories}
                    onChange={(e) => setManualFood(prev => ({ ...prev, calories: e.target.value }))}
                    placeholder="0"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Protein (g)</label>
                  <input
                    type="number"
                    value={manualFood.protein}
                    onChange={(e) => setManualFood(prev => ({ ...prev, protein: e.target.value }))}
                    placeholder="0"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Carbs (g)</label>
                  <input
                    type="number"
                    value={manualFood.carbs}
                    onChange={(e) => setManualFood(prev => ({ ...prev, carbs: e.target.value }))}
                    placeholder="0"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Fat (g)</label>
                  <input
                    type="number"
                    value={manualFood.fat}
                    onChange={(e) => setManualFood(prev => ({ ...prev, fat: e.target.value }))}
                    placeholder="0"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <button
                onClick={() => {
                  if (!manualFood.name.trim()) return;
                  const now = new Date();
                  const timeStr = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
                  setFoods(prev => [...prev, {
                    id: Date.now().toString(),
                    name: manualFood.name,
                    calories: parseInt(manualFood.calories) || 0,
                    protein: parseInt(manualFood.protein) || 0,
                    carbs: parseInt(manualFood.carbs) || 0,
                    fat: parseInt(manualFood.fat) || 0,
                    time: timeStr
                  }]);
                  setShowLogFoodModal(false);
                  setManualFood({ name: '', calories: '', protein: '', carbs: '', fat: '' });
                }}
                disabled={!manualFood.name.trim()}
                className="w-full py-4 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Add to Today's Log
              </button>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
