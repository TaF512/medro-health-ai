import { useState } from 'react';
import { useNavigate } from 'react-router';
import { 
  ArrowLeft, 
  Search, 
  MapPin,
  Star,
  ShoppingCart,
  Plus,
  Minus,
  Truck,
  Store,
  ChevronRight,
  Check,
  Heart,
  Shield,
  X
} from 'lucide-react';
import { cn } from '@/react-app/lib/utils';
import BottomNav from '@/react-app/components/BottomNav';

interface Pharmacy {
  id: string;
  name: string;
  logo: string;
  address: string;
  distance: string;
  rating: number;
  reviews: number;
  isOpen: boolean;
  openUntil: string;
  hasDelivery: boolean;
  deliveryFee: number;
  deliveryTime: string;
}

interface Medication {
  id: string;
  name: string;
  genericName: string;
  dosage: string;
  form: string;
  quantity: string;
  price: number;
  image: string;
  requiresPrescription: boolean;
  inStock: boolean;
  category: string;
}

interface CartItem {
  medication: Medication;
  quantity: number;
  pharmacy: string;
}

const pharmacies: Pharmacy[] = [
  {
    id: 'boots',
    name: 'Boots Pharmacy',
    logo: '💊',
    address: '123 High Street, London EC1A 1BB',
    distance: '0.3 miles',
    rating: 4.8,
    reviews: 1284,
    isOpen: true,
    openUntil: '10:00 PM',
    hasDelivery: true,
    deliveryFee: 3.99,
    deliveryTime: '1-2 hours'
  },
  {
    id: 'lloyds',
    name: 'LloydsPharmacy',
    logo: '🏥',
    address: '45 Market Square, London EC2V 8BX',
    distance: '0.5 miles',
    rating: 4.6,
    reviews: 892,
    isOpen: true,
    openUntil: '8:00 PM',
    hasDelivery: true,
    deliveryFee: 2.99,
    deliveryTime: '2-3 hours'
  },
  {
    id: 'superdrug',
    name: 'Superdrug Pharmacy',
    logo: '💉',
    address: '78 Oxford Street, London W1D 1BS',
    distance: '0.8 miles',
    rating: 4.5,
    reviews: 654,
    isOpen: true,
    openUntil: '9:00 PM',
    hasDelivery: false,
    deliveryFee: 0,
    deliveryTime: ''
  },
  {
    id: 'well',
    name: 'Well Pharmacy',
    logo: '⚕️',
    address: '22 Station Road, London N1 9PQ',
    distance: '1.2 miles',
    rating: 4.4,
    reviews: 432,
    isOpen: false,
    openUntil: 'Opens 8:00 AM',
    hasDelivery: true,
    deliveryFee: 4.99,
    deliveryTime: 'Same day'
  }
];

const medications: Medication[] = [
  {
    id: 'para-500',
    name: 'Paracetamol',
    genericName: 'Acetaminophen',
    dosage: '500mg',
    form: 'Tablets',
    quantity: '32 tablets',
    price: 1.99,
    image: '💊',
    requiresPrescription: false,
    inStock: true,
    category: 'Pain Relief'
  },
  {
    id: 'ibu-400',
    name: 'Ibuprofen',
    genericName: 'Ibuprofen',
    dosage: '400mg',
    form: 'Tablets',
    quantity: '24 tablets',
    price: 2.49,
    image: '💊',
    requiresPrescription: false,
    inStock: true,
    category: 'Pain Relief'
  },
  {
    id: 'cetirizine',
    name: 'Cetirizine',
    genericName: 'Cetirizine Hydrochloride',
    dosage: '10mg',
    form: 'Tablets',
    quantity: '30 tablets',
    price: 3.99,
    image: '💊',
    requiresPrescription: false,
    inStock: true,
    category: 'Allergy'
  },
  {
    id: 'omeprazole',
    name: 'Omeprazole',
    genericName: 'Omeprazole',
    dosage: '20mg',
    form: 'Capsules',
    quantity: '28 capsules',
    price: 8.99,
    image: '💊',
    requiresPrescription: true,
    inStock: true,
    category: 'Digestive'
  },
  {
    id: 'metformin',
    name: 'Metformin',
    genericName: 'Metformin Hydrochloride',
    dosage: '500mg',
    form: 'Tablets',
    quantity: '84 tablets',
    price: 12.99,
    image: '💊',
    requiresPrescription: true,
    inStock: true,
    category: 'Diabetes'
  },
  {
    id: 'vitamin-d',
    name: 'Vitamin D3',
    genericName: 'Cholecalciferol',
    dosage: '1000 IU',
    form: 'Tablets',
    quantity: '90 tablets',
    price: 5.99,
    image: '💊',
    requiresPrescription: false,
    inStock: true,
    category: 'Vitamins'
  },
  {
    id: 'amoxicillin',
    name: 'Amoxicillin',
    genericName: 'Amoxicillin',
    dosage: '500mg',
    form: 'Capsules',
    quantity: '21 capsules',
    price: 7.49,
    image: '💊',
    requiresPrescription: true,
    inStock: false,
    category: 'Antibiotics'
  }
];

const categories = ['All', 'Pain Relief', 'Allergy', 'Digestive', 'Diabetes', 'Vitamins', 'Antibiotics'];

export default function PharmacyPage() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPharmacy, setSelectedPharmacy] = useState<Pharmacy | null>(null);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCart, setShowCart] = useState(false);
  const [deliveryOption, setDeliveryOption] = useState<'delivery' | 'pickup'>('delivery');

  const filteredMedications = medications.filter(med => {
    const matchesSearch = med.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         med.genericName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || med.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const addToCart = (medication: Medication) => {
    if (!selectedPharmacy) return;
    
    const existingItem = cart.find(item => 
      item.medication.id === medication.id && item.pharmacy === selectedPharmacy.id
    );

    if (existingItem) {
      setCart(prev => prev.map(item =>
        item.medication.id === medication.id && item.pharmacy === selectedPharmacy.id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCart(prev => [...prev, { medication, quantity: 1, pharmacy: selectedPharmacy.id }]);
    }
  };

  const removeFromCart = (medicationId: string) => {
    setCart(prev => {
      const item = prev.find(i => i.medication.id === medicationId);
      if (item && item.quantity > 1) {
        return prev.map(i =>
          i.medication.id === medicationId
            ? { ...i, quantity: i.quantity - 1 }
            : i
        );
      }
      return prev.filter(i => i.medication.id !== medicationId);
    });
  };

  const getCartQuantity = (medicationId: string) => {
    return cart.find(item => item.medication.id === medicationId)?.quantity || 0;
  };

  const cartTotal = cart.reduce((sum, item) => sum + (item.medication.price * item.quantity), 0);
  const deliveryFee = deliveryOption === 'delivery' && selectedPharmacy?.hasDelivery 
    ? selectedPharmacy.deliveryFee 
    : 0;

  const handleCheckout = () => {
    alert(`🎉 Order placed successfully!\n\nTotal: £${(cartTotal + deliveryFee).toFixed(2)}\n${deliveryOption === 'delivery' ? 'Delivery in ' + selectedPharmacy?.deliveryTime : 'Ready for pickup in 30 mins'}`);
    setCart([]);
    setShowCart(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="sticky top-0 bg-gradient-to-r from-emerald-500 to-teal-600 px-4 py-4 z-40">
        <div className="flex items-center gap-3 max-w-lg mx-auto">
          <button
            onClick={() => selectedPharmacy ? setSelectedPharmacy(null) : navigate(-1)}
            className="p-2 -ml-2 rounded-full hover:bg-white/20 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-white">
              {selectedPharmacy ? selectedPharmacy.name : 'Order Medication'}
            </h1>
            <p className="text-sm text-white/80">
              {selectedPharmacy ? selectedPharmacy.address : 'Find pharmacies near you'}
            </p>
          </div>
          {cart.length > 0 && (
            <button
              onClick={() => setShowCart(true)}
              className="relative p-2 rounded-full bg-white/20"
            >
              <ShoppingCart className="w-5 h-5 text-white" />
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-xs text-white flex items-center justify-center">
                {cart.reduce((sum, item) => sum + item.quantity, 0)}
              </span>
            </button>
          )}
        </div>
      </header>

      {!selectedPharmacy ? (
        // Pharmacy List
        <main className="px-4 py-4 max-w-lg mx-auto space-y-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search pharmacies..."
              className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Features */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white rounded-xl p-3 border border-gray-100 text-center">
              <Truck className="w-6 h-6 text-emerald-600 mx-auto mb-1" />
              <p className="text-xs text-gray-600">Fast Delivery</p>
            </div>
            <div className="bg-white rounded-xl p-3 border border-gray-100 text-center">
              <Shield className="w-6 h-6 text-emerald-600 mx-auto mb-1" />
              <p className="text-xs text-gray-600">NHS Approved</p>
            </div>
            <div className="bg-white rounded-xl p-3 border border-gray-100 text-center">
              <Heart className="w-6 h-6 text-emerald-600 mx-auto mb-1" />
              <p className="text-xs text-gray-600">Care Points</p>
            </div>
          </div>

          {/* Pharmacy List */}
          <section>
            <h2 className="font-semibold text-gray-900 mb-3">Nearby Pharmacies</h2>
            <div className="space-y-3">
              {pharmacies.map(pharmacy => (
                <button
                  key={pharmacy.id}
                  onClick={() => setSelectedPharmacy(pharmacy)}
                  className="w-full bg-white rounded-2xl border border-gray-100 shadow-sm p-4 text-left hover:border-emerald-200 transition-colors"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-14 h-14 bg-emerald-100 rounded-xl flex items-center justify-center text-2xl">
                      {pharmacy.logo}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-semibold text-gray-900">{pharmacy.name}</p>
                          <div className="flex items-center gap-1 text-sm text-gray-500 mt-0.5">
                            <MapPin className="w-3.5 h-3.5" />
                            <span>{pharmacy.distance}</span>
                            <span>•</span>
                            <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                            <span>{pharmacy.rating}</span>
                          </div>
                        </div>
                        <ChevronRight className="w-5 h-5 text-gray-400" />
                      </div>
                      
                      <div className="flex items-center gap-3 mt-2">
                        <span className={cn(
                          'px-2 py-0.5 rounded-full text-xs font-medium',
                          pharmacy.isOpen
                            ? 'bg-green-100 text-green-700'
                            : 'bg-red-100 text-red-700'
                        )}>
                          {pharmacy.isOpen ? `Open until ${pharmacy.openUntil}` : pharmacy.openUntil}
                        </span>
                        {pharmacy.hasDelivery && (
                          <span className="flex items-center gap-1 text-xs text-emerald-600">
                            <Truck className="w-3.5 h-3.5" />
                            {pharmacy.deliveryTime}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </section>
        </main>
      ) : (
        // Medication List
        <main className="px-4 py-4 max-w-lg mx-auto space-y-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search medications..."
              className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Categories */}
          <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={cn(
                  'px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors',
                  selectedCategory === cat
                    ? 'bg-emerald-600 text-white'
                    : 'bg-white text-gray-600 border border-gray-200'
                )}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Delivery Options */}
          <div className="flex gap-3">
            <button
              onClick={() => setDeliveryOption('delivery')}
              disabled={!selectedPharmacy.hasDelivery}
              className={cn(
                'flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-medium transition-all',
                deliveryOption === 'delivery'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-white text-gray-600 border border-gray-200',
                !selectedPharmacy.hasDelivery && 'opacity-50 cursor-not-allowed'
              )}
            >
              <Truck className="w-4 h-4" />
              Delivery
            </button>
            <button
              onClick={() => setDeliveryOption('pickup')}
              className={cn(
                'flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-medium transition-all',
                deliveryOption === 'pickup'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-white text-gray-600 border border-gray-200'
              )}
            >
              <Store className="w-4 h-4" />
              Click & Collect
            </button>
          </div>

          {/* Medications */}
          <section>
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-semibold text-gray-900">Medications</h2>
              <p className="text-sm text-gray-500">{filteredMedications.length} items</p>
            </div>

            <div className="space-y-3">
              {filteredMedications.map(med => {
                const cartQty = getCartQuantity(med.id);
                return (
                  <div
                    key={med.id}
                    className={cn(
                      'bg-white rounded-2xl border border-gray-100 shadow-sm p-4',
                      !med.inStock && 'opacity-60'
                    )}
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-14 h-14 bg-gray-100 rounded-xl flex items-center justify-center text-2xl">
                        {med.image}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <p className="font-semibold text-gray-900">{med.name}</p>
                            <p className="text-sm text-gray-500">{med.genericName}</p>
                          </div>
                          {med.requiresPrescription && (
                            <span className="px-2 py-0.5 bg-amber-100 text-amber-700 rounded-full text-xs font-medium">
                              Rx
                            </span>
                          )}
                        </div>
                        
                        <div className="flex items-center gap-2 mt-1 text-sm text-gray-500">
                          <span>{med.dosage}</span>
                          <span>•</span>
                          <span>{med.quantity}</span>
                        </div>

                        <div className="flex items-center justify-between mt-3">
                          <p className="text-lg font-bold text-emerald-600">£{med.price.toFixed(2)}</p>
                          
                          {med.inStock ? (
                            cartQty > 0 ? (
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => removeFromCart(med.id)}
                                  className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center"
                                >
                                  <Minus className="w-4 h-4 text-gray-600" />
                                </button>
                                <span className="w-8 text-center font-semibold">{cartQty}</span>
                                <button
                                  onClick={() => addToCart(med)}
                                  className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center"
                                >
                                  <Plus className="w-4 h-4 text-white" />
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => addToCart(med)}
                                className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-medium flex items-center gap-1"
                              >
                                <Plus className="w-4 h-4" />
                                Add
                              </button>
                            )
                          ) : (
                            <span className="text-sm text-red-500 font-medium">Out of Stock</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        </main>
      )}

      {/* Cart Modal */}
      {showCart && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="w-full bg-white rounded-t-3xl max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-lg font-bold text-gray-900">Your Cart</h2>
              <button
                onClick={() => setShowCart(false)}
                className="p-2 hover:bg-gray-100 rounded-full"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {cart.map(item => (
                <div key={item.medication.id} className="flex items-center gap-4 bg-gray-50 rounded-xl p-3">
                  <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center text-xl">
                    {item.medication.image}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900">{item.medication.name}</p>
                    <p className="text-sm text-gray-500">{item.medication.dosage}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => removeFromCart(item.medication.id)}
                      className="w-7 h-7 bg-white rounded-lg flex items-center justify-center border"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-6 text-center">{item.quantity}</span>
                    <button
                      onClick={() => addToCart(item.medication)}
                      className="w-7 h-7 bg-emerald-600 rounded-lg flex items-center justify-center"
                    >
                      <Plus className="w-3 h-3 text-white" />
                    </button>
                  </div>
                  <p className="font-semibold text-gray-900 w-16 text-right">
                    £{(item.medication.price * item.quantity).toFixed(2)}
                  </p>
                </div>
              ))}
            </div>

            <div className="border-t p-4 space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Subtotal</span>
                <span className="font-medium">£{cartTotal.toFixed(2)}</span>
              </div>
              {deliveryOption === 'delivery' && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Delivery Fee</span>
                  <span className="font-medium">£{deliveryFee.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-lg font-bold">
                <span>Total</span>
                <span className="text-emerald-600">£{(cartTotal + deliveryFee).toFixed(2)}</span>
              </div>
              <button
                onClick={handleCheckout}
                className="w-full py-4 bg-emerald-600 text-white rounded-xl font-semibold hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2"
              >
                <Check className="w-5 h-5" />
                Place Order
              </button>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
