import { useState } from 'react';
import { useNavigate } from 'react-router';
import { 
  ArrowLeft, 
  Plus, 
  FileText, 
  Image, 
  Upload,
  Calendar,
  Trash2,
  Eye,
  X,
  File,
  Heart,
  User,
  Download,
  Video,
  Phone,
  MessageSquare,
  ChevronRight
} from 'lucide-react';
import { cn } from '@/react-app/lib/utils';
import BottomNav from '@/react-app/components/BottomNav';

type TabType = 'prescriptions' | 'consultations' | 'reports' | 'all';

interface Prescription {
  id: string;
  title: string;
  date: string;
  doctor: string;
  hospital: string;
  pdfUrl: string;
}

interface Consultation {
  id: string;
  doctor: string;
  doctorImage: string;
  specialty: string;
  date: string;
  type: 'video' | 'voice' | 'chat';
  duration: string;
  diagnosis?: string;
  prescriptionId?: string;
}

interface HealthRecord {
  id: string;
  type: 'prescription' | 'report' | 'scan' | 'other';
  title: string;
  date: string;
  doctor?: string;
  tags: string[];
}

// Sample prescriptions data
const prescriptions: Prescription[] = [
  {
    id: 'rx-1',
    title: 'Diabetes Medication',
    date: '2024-01-15',
    doctor: 'Dr. Sarah Ahmed',
    hospital: 'City Medical Center',
    pdfUrl: 'https://www.africau.edu/images/default/sample.pdf'
  },
  {
    id: 'rx-2',
    title: 'Blood Pressure Management',
    date: '2024-01-08',
    doctor: 'Dr. Mohammad Rahman',
    hospital: 'Heart Care Hospital',
    pdfUrl: 'https://www.africau.edu/images/default/sample.pdf'
  },
  {
    id: 'rx-3',
    title: 'Skin Allergy Treatment',
    date: '2023-12-20',
    doctor: 'Dr. Rezwan Ali',
    hospital: 'Skin Care Institute',
    pdfUrl: 'https://www.africau.edu/images/default/sample.pdf'
  }
];

// Sample past consultations
const pastConsultations: Consultation[] = [
  {
    id: 'cons-1',
    doctor: 'Dr. Sarah Ahmed',
    doctorImage: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200&h=200&fit=crop&crop=face',
    specialty: 'General Physician',
    date: '2024-01-15',
    type: 'video',
    duration: '15 min',
    diagnosis: 'Type 2 Diabetes Management',
    prescriptionId: 'rx-1'
  },
  {
    id: 'cons-2',
    doctor: 'Dr. Mohammad Rahman',
    doctorImage: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop&crop=face',
    specialty: 'Cardiologist',
    date: '2024-01-08',
    type: 'voice',
    duration: '20 min',
    diagnosis: 'Hypertension Follow-up',
    prescriptionId: 'rx-2'
  },
  {
    id: 'cons-3',
    doctor: 'Dr. Rezwan Ali',
    doctorImage: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=200&h=200&fit=crop&crop=face',
    specialty: 'Dermatologist',
    date: '2023-12-20',
    type: 'chat',
    duration: '10 min',
    diagnosis: 'Allergic Dermatitis',
    prescriptionId: 'rx-3'
  },
  {
    id: 'cons-4',
    doctor: 'Dr. Nadia Hossain',
    doctorImage: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=200&h=200&fit=crop&crop=face',
    specialty: 'Pediatrician',
    date: '2023-11-15',
    type: 'video',
    duration: '25 min',
    diagnosis: 'Child Vaccination Consultation'
  }
];

const initialRecords: HealthRecord[] = [
  {
    id: '1',
    type: 'report',
    title: 'Blood Test - Lipid Profile',
    date: '2024-01-10',
    doctor: 'HealthFirst Lab',
    tags: ['blood test', 'cholesterol']
  },
  {
    id: '2',
    type: 'scan',
    title: 'Chest X-Ray',
    date: '2024-01-05',
    doctor: 'City Hospital',
    tags: ['x-ray', 'chest']
  },
  {
    id: '3',
    type: 'report',
    title: 'Complete Blood Count (CBC)',
    date: '2023-12-28',
    doctor: 'Popular Diagnostics',
    tags: ['blood test', 'CBC']
  }
];

const recordTypes = [
  { type: 'prescription', label: 'Prescription', icon: FileText, color: 'text-blue-600', bg: 'bg-blue-100' },
  { type: 'report', label: 'Lab Report', icon: Heart, color: 'text-green-600', bg: 'bg-green-100' },
  { type: 'scan', label: 'Scan/Image', icon: Image, color: 'text-purple-600', bg: 'bg-purple-100' },
  { type: 'other', label: 'Other', icon: File, color: 'text-gray-600', bg: 'bg-gray-100' },
];

export default function RecordsPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<TabType>('prescriptions');
  const [records, setRecords] = useState<HealthRecord[]>(initialRecords);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [viewingPdf, setViewingPdf] = useState<Prescription | null>(null);
  const [newRecord, setNewRecord] = useState({
    type: 'prescription' as HealthRecord['type'],
    title: '',
    doctor: '',
    date: new Date().toISOString().split('T')[0]
  });

  const getConsultTypeIcon = (type: Consultation['type']) => {
    switch (type) {
      case 'video': return Video;
      case 'voice': return Phone;
      case 'chat': return MessageSquare;
    }
  };

  const deleteRecord = (id: string) => {
    setRecords(prev => prev.filter(r => r.id !== id));
  };

  const addRecord = () => {
    if (!newRecord.title.trim()) return;

    setRecords(prev => [...prev, {
      id: Date.now().toString(),
      type: newRecord.type,
      title: newRecord.title,
      date: newRecord.date,
      doctor: newRecord.doctor || undefined,
      tags: []
    }]);

    setNewRecord({
      type: 'prescription',
      title: '',
      doctor: '',
      date: new Date().toISOString().split('T')[0]
    });
    setShowUploadModal(false);
  };

  const getRecordIcon = (type: HealthRecord['type']) => {
    const config = recordTypes.find(r => r.type === type);
    return config || recordTypes[3];
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="sticky top-0 bg-gradient-to-r from-cyan-500 to-cyan-600 px-4 py-4 z-40">
        <div className="flex items-center gap-3 max-w-lg mx-auto">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 rounded-full hover:bg-white/20 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-white">My Health Records</h1>
            <p className="text-sm text-white/80">Secure document vault</p>
          </div>
          <button
            onClick={() => setShowUploadModal(true)}
            className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
          >
            <Plus className="w-5 h-5 text-white" />
          </button>
        </div>
      </header>

      <main className="px-4 py-4 max-w-lg mx-auto space-y-4">
        {/* Tabs */}
        <div className="bg-white rounded-xl p-1 flex shadow-sm border border-gray-100">
          {[
            { id: 'prescriptions', label: 'Prescriptions' },
            { id: 'consultations', label: 'Past Consults' },
            { id: 'reports', label: 'Reports' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as TabType)}
              className={cn(
                'flex-1 py-2.5 rounded-lg text-sm font-medium transition-all',
                activeTab === tab.id
                  ? 'bg-cyan-500 text-white shadow-sm'
                  : 'text-gray-500 hover:text-gray-700'
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Prescriptions Tab */}
        {activeTab === 'prescriptions' && (
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-gray-900">All Prescriptions</h2>
              <span className="text-sm text-gray-500">{prescriptions.length} total</span>
            </div>

            {prescriptions.map(rx => (
              <div
                key={rx.id}
                className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden"
              >
                <div className="flex items-center gap-4 p-4">
                  <div className="w-14 h-14 bg-blue-100 rounded-xl flex items-center justify-center">
                    <FileText className="w-7 h-7 text-blue-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900">{rx.title}</p>
                    <p className="text-sm text-primary">{rx.doctor}</p>
                    <div className="flex items-center gap-2 text-xs text-gray-500 mt-1">
                      <Calendar className="w-3 h-3" />
                      <span>{new Date(rx.date).toLocaleDateString()}</span>
                      <span>•</span>
                      <span>{rx.hospital}</span>
                    </div>
                  </div>
                </div>
                <div className="border-t border-gray-100 flex">
                  <button
                    onClick={() => setViewingPdf(rx)}
                    className="flex-1 flex items-center justify-center gap-2 py-3 text-cyan-600 hover:bg-cyan-50 transition-colors text-sm font-medium"
                  >
                    <Eye className="w-4 h-4" />
                    View PDF
                  </button>
                  <div className="w-px bg-gray-100" />
                  <a
                    href={rx.pdfUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 flex items-center justify-center gap-2 py-3 text-gray-600 hover:bg-gray-50 transition-colors text-sm font-medium"
                  >
                    <Download className="w-4 h-4" />
                    Download
                  </a>
                </div>
              </div>
            ))}

            {prescriptions.length === 0 && (
              <div className="text-center py-12 bg-white rounded-2xl border border-gray-100">
                <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">No prescriptions yet</p>
              </div>
            )}
          </section>
        )}

        {/* Past Consultations Tab */}
        {activeTab === 'consultations' && (
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-gray-900">Past Consultations</h2>
              <span className="text-sm text-gray-500">{pastConsultations.length} total</span>
            </div>

            {pastConsultations.map(cons => {
              const TypeIcon = getConsultTypeIcon(cons.type);
              return (
                <div
                  key={cons.id}
                  className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4"
                >
                  <div className="flex items-start gap-4">
                    <img
                      src={cons.doctorImage}
                      alt={cons.doctor}
                      className="w-14 h-14 rounded-xl object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="font-semibold text-gray-900">{cons.doctor}</p>
                          <p className="text-sm text-primary">{cons.specialty}</p>
                        </div>
                        <div className={cn(
                          'px-2 py-1 rounded-lg flex items-center gap-1 text-xs font-medium',
                          cons.type === 'video' ? 'bg-blue-100 text-blue-600' :
                          cons.type === 'voice' ? 'bg-green-100 text-green-600' :
                          'bg-purple-100 text-purple-600'
                        )}>
                          <TypeIcon className="w-3 h-3" />
                          {cons.type === 'video' ? 'Video' : cons.type === 'voice' ? 'Voice' : 'Chat'}
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2 text-xs text-gray-500 mt-2">
                        <Calendar className="w-3 h-3" />
                        <span>{new Date(cons.date).toLocaleDateString()}</span>
                        <span>•</span>
                        <span>{cons.duration}</span>
                      </div>

                      {cons.diagnosis && (
                        <div className="mt-3 p-3 bg-gray-50 rounded-xl">
                          <p className="text-xs text-gray-500 mb-1">Diagnosis</p>
                          <p className="text-sm font-medium text-gray-900">{cons.diagnosis}</p>
                        </div>
                      )}

                      {cons.prescriptionId && (
                        <button
                          onClick={() => {
                            const rx = prescriptions.find(p => p.id === cons.prescriptionId);
                            if (rx) setViewingPdf(rx);
                          }}
                          className="mt-3 flex items-center gap-2 text-sm text-cyan-600 font-medium"
                        >
                          <FileText className="w-4 h-4" />
                          View Prescription
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}

            {pastConsultations.length === 0 && (
              <div className="text-center py-12 bg-white rounded-2xl border border-gray-100">
                <User className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">No past consultations</p>
              </div>
            )}
          </section>
        )}

        {/* Reports Tab */}
        {activeTab === 'reports' && (
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-gray-900">Lab Reports & Scans</h2>
              <span className="text-sm text-gray-500">{records.length} total</span>
            </div>

            {records.map(record => {
              const iconConfig = getRecordIcon(record.type);
              return (
                <div key={record.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                  <div className="flex items-center gap-4 p-4">
                    <div className={`w-12 h-12 ${iconConfig.bg} rounded-xl flex items-center justify-center`}>
                      <iconConfig.icon className={`w-6 h-6 ${iconConfig.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-gray-900 truncate">{record.title}</p>
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <Calendar className="w-3.5 h-3.5" />
                        <span>{new Date(record.date).toLocaleDateString()}</span>
                        {record.doctor && (
                          <>
                            <span>•</span>
                            <span className="truncate">{record.doctor}</span>
                          </>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <button className="p-2 text-gray-400 hover:text-cyan-600 transition-colors">
                        <Eye className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => deleteRecord(record.id)}
                        className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                  {record.tags.length > 0 && (
                    <div className="border-t border-gray-100 px-4 py-2 bg-gray-50">
                      <div className="flex flex-wrap gap-1">
                        {record.tags.map(tag => (
                          <span key={tag} className="px-2 py-0.5 bg-gray-200 text-gray-600 rounded text-xs">
                            #{tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            {records.length === 0 && (
              <div className="text-center py-12 bg-white rounded-2xl border border-gray-100">
                <Image className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">No reports or scans</p>
              </div>
            )}
          </section>
        )}
      </main>

      {/* PDF Viewer Modal */}
      {viewingPdf && (
        <div className="fixed inset-0 bg-black/80 z-50 flex flex-col">
          <div className="flex items-center justify-between px-4 py-3 bg-white border-b">
            <div>
              <p className="font-semibold text-gray-900">{viewingPdf.title}</p>
              <p className="text-sm text-gray-500">{viewingPdf.doctor}</p>
            </div>
            <button
              onClick={() => setViewingPdf(null)}
              className="p-2 hover:bg-gray-100 rounded-full"
            >
              <X className="w-5 h-5 text-gray-600" />
            </button>
          </div>
          <div className="flex-1 bg-gray-100">
            <iframe
              src={viewingPdf.pdfUrl}
              className="w-full h-full"
              title="Prescription PDF"
            />
          </div>
        </div>
      )}

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="w-full bg-white rounded-t-3xl p-6 max-w-lg mx-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Add Health Record</h2>
              <button
                onClick={() => setShowUploadModal(false)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Record Type
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {recordTypes.map(rt => (
                    <button
                      key={rt.type}
                      onClick={() => setNewRecord(prev => ({ ...prev, type: rt.type as HealthRecord['type'] }))}
                      className={cn(
                        'p-3 rounded-xl text-center transition-all',
                        newRecord.type === rt.type
                          ? 'bg-cyan-100 border-2 border-cyan-500'
                          : 'bg-gray-50 border border-gray-200'
                      )}
                    >
                      <rt.icon className={`w-5 h-5 mx-auto mb-1 ${newRecord.type === rt.type ? 'text-cyan-600' : 'text-gray-400'}`} />
                      <p className="text-xs">{rt.label}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Title / Description
                </label>
                <input
                  type="text"
                  value={newRecord.title}
                  onChange={(e) => setNewRecord(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="e.g., Blood Test Results"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Doctor / Facility (Optional)
                </label>
                <input
                  type="text"
                  value={newRecord.doctor}
                  onChange={(e) => setNewRecord(prev => ({ ...prev, doctor: e.target.value }))}
                  placeholder="e.g., Dr. Smith"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Date
                </label>
                <input
                  type="date"
                  value={newRecord.date}
                  onChange={(e) => setNewRecord(prev => ({ ...prev, date: e.target.value }))}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>

              <div className="border-2 border-dashed border-gray-200 rounded-xl p-6 text-center">
                <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Tap to upload document</p>
                <p className="text-xs text-gray-400 mt-1">PDF, JPG, PNG up to 10MB</p>
              </div>

              <button
                onClick={addRecord}
                disabled={!newRecord.title.trim()}
                className="w-full py-4 bg-cyan-600 text-white rounded-xl font-semibold hover:bg-cyan-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Save Record
              </button>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
