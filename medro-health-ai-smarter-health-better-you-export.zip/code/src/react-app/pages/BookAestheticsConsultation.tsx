import { useState, useRef } from 'react';
import { useNavigate, useParams } from 'react-router';
import { 
  ArrowLeft, User, UserPlus, Video, Phone, MessageSquare, 
  Upload, X, Image, Camera, CreditCard, Wallet,
  ChevronRight, Check, AlertCircle, ShoppingCart, Info, Sparkles
} from 'lucide-react';
import { calculatePatientPrice, getVatLabel } from '@/react-app/lib/pricing';
import { cn } from '@/react-app/lib/utils';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { useCart } from '@/react-app/context/CartContext';
import { useCurrency } from '@/react-app/contexts/CurrencyContext';

type ConsultType = 'video' | 'voice' | 'chat';
type PatientType = 'self' | 'other';
type PaymentMethod = 'card' | 'wallet' | 'bkash' | 'nagad' | 'apple_pay' | 'google_pay';

interface Attachment {
  id: string;
  name: string;
  type: 'image' | 'document';
  url: string;
}

interface ClinicDoctor {
  id: string;
  name: string;
  image: string;
  title: string;
  specialty: string;
  experience: string;
  rating: number;
  reviews: number;
  consultationFee: number;
  currency: string;
  availability: string[];
  languages: string[];
  qualifications: string[];
  consultationTypes: ('video' | 'voice' | 'chat')[];
}

// Clinic data with doctors (same as ClinicDoctors.tsx)
const clinicDoctors: Record<string, { clinicName: string; clinicImage: string; country: string; doctors: ClinicDoctor[] }> = {
  '1': {
    clinicName: 'Harley Street Aesthetics',
    clinicImage: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=400&h=300&fit=crop',
    country: 'GB',
    doctors: [
      {
        id: 'hsa-1',
        name: 'Dr. James Crawford',
        image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop&crop=face',
        title: 'Lead Surgeon',
        specialty: 'Hair Restoration & FUE',
        experience: '18 years',
        rating: 4.9,
        reviews: 456,
        consultationFee: 150,
        currency: 'GBP',
        availability: ['Mon', 'Wed', 'Fri'],
        languages: ['English', 'French'],
        qualifications: ['MBBS', 'FRCS', 'ISHRS Member'],
        consultationTypes: ['video', 'chat']
      },
      {
        id: 'hsa-2',
        name: 'Dr. Sarah Mitchell',
        image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200&h=200&fit=crop&crop=face',
        title: 'Aesthetic Specialist',
        specialty: 'Facial Aesthetics & Injectables',
        experience: '12 years',
        rating: 4.8,
        reviews: 324,
        consultationFee: 100,
        currency: 'GBP',
        availability: ['Tue', 'Thu', 'Sat'],
        languages: ['English', 'Arabic'],
        qualifications: ['MBBS', 'MSc Aesthetic Medicine', 'BCAM Certified'],
        consultationTypes: ['video', 'voice', 'chat']
      },
      {
        id: 'hsa-3',
        name: 'Dr. Ahmed Hassan',
        image: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=200&h=200&fit=crop&crop=face',
        title: 'Cosmetic Dentist',
        specialty: 'Dental Aesthetics & Veneers',
        experience: '15 years',
        rating: 4.9,
        reviews: 289,
        consultationFee: 80,
        currency: 'GBP',
        availability: ['Mon', 'Tue', 'Wed', 'Thu'],
        languages: ['English', 'Arabic', 'French'],
        qualifications: ['BDS', 'MSc Cosmetic Dentistry', 'BACD Member'],
        consultationTypes: ['video', 'chat']
      }
    ]
  },
  '2': {
    clinicName: 'Transform Clinic',
    clinicImage: 'https://images.unsplash.com/photo-1631217868264-e5b90bb7e133?w=400&h=300&fit=crop',
    country: 'GB',
    doctors: [
      {
        id: 'tc-1',
        name: 'Mr. Richard Thompson',
        image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=200&h=200&fit=crop&crop=face',
        title: 'Consultant Plastic Surgeon',
        specialty: 'Breast Surgery & Body Contouring',
        experience: '22 years',
        rating: 4.9,
        reviews: 512,
        consultationFee: 150,
        currency: 'GBP',
        availability: ['Mon', 'Wed', 'Fri'],
        languages: ['English'],
        qualifications: ['MBBS', 'FRCS (Plast)', 'BAPRAS Member'],
        consultationTypes: ['video']
      },
      {
        id: 'tc-2',
        name: 'Dr. Emily Roberts',
        image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=200&h=200&fit=crop&crop=face',
        title: 'Cosmetic Surgeon',
        specialty: 'Liposuction & Body Sculpting',
        experience: '14 years',
        rating: 4.8,
        reviews: 287,
        consultationFee: 100,
        currency: 'GBP',
        availability: ['Tue', 'Thu', 'Sat'],
        languages: ['English', 'Spanish'],
        qualifications: ['MBBS', 'MSc Cosmetic Surgery', 'GMC Registered'],
        consultationTypes: ['video', 'voice', 'chat']
      }
    ]
  },
  '3': {
    clinicName: 'Beverly Hills Aesthetics',
    clinicImage: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=400&h=300&fit=crop',
    country: 'US',
    doctors: [
      {
        id: 'bha-1',
        name: 'Dr. Michael Reynolds',
        image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop&crop=face',
        title: 'Board Certified Plastic Surgeon',
        specialty: 'Facial Rejuvenation & Rhinoplasty',
        experience: '25 years',
        rating: 5.0,
        reviews: 892,
        consultationFee: 350,
        currency: 'USD',
        availability: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
        languages: ['English', 'Spanish'],
        qualifications: ['MD', 'FACS', 'ASPS Member', 'ISAPS Fellow'],
        consultationTypes: ['video']
      },
      {
        id: 'bha-2',
        name: 'Dr. Jennifer Lee',
        image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200&h=200&fit=crop&crop=face',
        title: 'Celebrity Aesthetician',
        specialty: 'Non-Surgical Treatments & Injectables',
        experience: '18 years',
        rating: 4.9,
        reviews: 756,
        consultationFee: 300,
        currency: 'USD',
        availability: ['Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        languages: ['English', 'Korean', 'Mandarin'],
        qualifications: ['MD', 'American Board of Dermatology', 'AAD Fellow'],
        consultationTypes: ['video', 'chat']
      }
    ]
  },
  '4': {
    clinicName: 'Seoul Beauty Clinic',
    clinicImage: 'https://images.unsplash.com/photo-1580281657702-257584239a55?w=400&h=300&fit=crop',
    country: 'KR',
    doctors: [
      {
        id: 'sbc-1',
        name: 'Dr. Kim Min-jun',
        image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop&crop=face',
        title: 'K-Beauty Specialist',
        specialty: 'V-Line Surgery & Double Eyelid',
        experience: '20 years',
        rating: 4.9,
        reviews: 1245,
        consultationFee: 150000,
        currency: 'KRW',
        availability: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        languages: ['Korean', 'English', 'Japanese'],
        qualifications: ['MD', 'PhD', 'KSPS Certified'],
        consultationTypes: ['video', 'chat']
      }
    ]
  },
  '5': {
    clinicName: 'Bangkok Aesthetic Center',
    clinicImage: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=400&h=300&fit=crop',
    country: 'TH',
    doctors: [
      {
        id: 'bac-1',
        name: 'Dr. Somchai Patel',
        image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=200&h=200&fit=crop&crop=face',
        title: 'Plastic & Reconstructive Surgeon',
        specialty: 'Gender Affirmation & Body Contouring',
        experience: '28 years',
        rating: 4.9,
        reviews: 2156,
        consultationFee: 3000,
        currency: 'THB',
        availability: ['Mon', 'Wed', 'Fri', 'Sat'],
        languages: ['Thai', 'English', 'Japanese'],
        qualifications: ['MD', 'FRCST', 'ISAPS Member'],
        consultationTypes: ['video', 'voice', 'chat']
      }
    ]
  }
};

const getCurrencySymbol = (currency: string): string => {
  const symbols: Record<string, string> = {
    'GBP': '£', 'USD': '$', 'EUR': '€', 'KRW': '₩', 'THB': '฿',
    'INR': '₹', 'BDT': '৳', 'AED': 'AED ', 'BRL': 'R$'
  };
  return symbols[currency] || currency + ' ';
};

const getCountryFromCurrency = (currency: string): string => {
  const map: Record<string, string> = {
    'GBP': 'GB', 'USD': 'US', 'EUR': 'DE', 'KRW': 'KR', 'THB': 'TH',
    'INR': 'IN', 'BDT': 'BD', 'AED': 'AE', 'BRL': 'BR'
  };
  return map[currency] || 'GB';
};

export default function BookAestheticsConsultationPage() {
  const { clinicId, doctorId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { addItem } = useCart();
  useCurrency();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const clinicData = clinicDoctors[clinicId || ''];
  const doctor = clinicData?.doctors.find(d => d.id === doctorId);
  
  const [step, setStep] = useState(1);
  const [patientType, setPatientType] = useState<PatientType>('self');
  const [consultType, setConsultType] = useState<ConsultType>(doctor?.consultationTypes[0] || 'video');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('card');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  
  // Patient details
  const [otherPatientName, setOtherPatientName] = useState('');
  const [otherPatientAge, setOtherPatientAge] = useState('');
  const [otherPatientGender, setOtherPatientGender] = useState('');
  
  // Consultation details
  const [procedureInterest, setProcedureInterest] = useState('');
  const [concerns, setConcerns] = useState('');
  const [previousProcedures, setPreviousProcedures] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [showPriceBreakdown, setShowPriceBreakdown] = useState(false);
  
  if (!clinicData || !doctor) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Sparkles className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">Specialist not found</p>
          <button 
            onClick={() => navigate(-1)}
            className="mt-4 text-primary font-medium"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    
    Array.from(files).forEach(file => {
      const isImage = file.type.startsWith('image/');
      const url = URL.createObjectURL(file);
      setAttachments(prev => [...prev, {
        id: Math.random().toString(36).substr(2, 9),
        name: file.name,
        type: isImage ? 'image' : 'document',
        url
      }]);
    });
    
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeAttachment = (id: string) => {
    setAttachments(prev => prev.filter(a => a.id !== id));
  };

  const currencySymbol = getCurrencySymbol(doctor.currency);
  const country = getCountryFromCurrency(doctor.currency);
  
  // Calculate patient-facing price with fees
  const priceBreakdown = calculatePatientPrice(doctor.consultationFee, country, doctor.currency);
  
  // Generate available dates (next 14 days, filtered by doctor availability)
  const availableDates = Array.from({ length: 14 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() + i + 1);
    const dayName = date.toLocaleDateString('en-US', { weekday: 'short' });
    return {
      date: date.toISOString().split('T')[0],
      display: date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }),
      dayName,
      available: doctor.availability.includes(dayName)
    };
  }).filter(d => d.available);

  // Time slots
  const timeSlots = [
    '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
    '14:00', '14:30', '15:00', '15:30', '16:00', '16:30'
  ];

  const handleAddToCart = () => {
    addItem({
      id: `${clinicId}-${doctor.id}`,
      type: 'doctor',
      name: `Consultation with ${doctor.name}`,
      description: `${consultType.charAt(0).toUpperCase() + consultType.slice(1)} consultation at ${clinicData.clinicName} - ${procedureInterest}`,
      price: priceBreakdown.totalPrice,
      currency: currencySymbol,
      doctorId: doctor.id,
      consultationType: consultType,
      country: country,
    });
    navigate('/cart');
  };

  const canProceedStep1 = patientType === 'self' || 
    (otherPatientName && otherPatientAge && otherPatientGender);
  
  const canProceedStep2 = procedureInterest.trim().length > 0 && selectedDate && selectedTime;

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="sticky top-0 bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 text-white px-4 py-3 z-40">
        <div className="flex items-center gap-3 max-w-lg mx-auto">
          <button
            onClick={() => step > 1 ? setStep(step - 1) : navigate(-1)}
            className="p-2 -ml-2 rounded-full hover:bg-white/20 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-bold">Book Consultation</h1>
            <p className="text-white/80 text-sm">Step {step} of 3</p>
          </div>
        </div>
        
        {/* Progress Bar */}
        <div className="flex gap-2 mt-3 max-w-lg mx-auto">
          {[1, 2, 3].map(s => (
            <div
              key={s}
              className={cn(
                'h-1 flex-1 rounded-full transition-colors',
                s <= step ? 'bg-white' : 'bg-white/30'
              )}
            />
          ))}
        </div>
      </header>

      <main className="px-4 py-6 max-w-lg mx-auto space-y-6">
        {/* Doctor Info Card */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex items-center gap-4">
          <img
            src={doctor.image}
            alt={doctor.name}
            className="w-16 h-16 rounded-xl object-cover"
          />
          <div className="flex-1">
            <h2 className="font-semibold text-gray-900">{doctor.name}</h2>
            <p className="text-sm text-purple-600">{doctor.title}</p>
            <p className="text-xs text-gray-500">{clinicData.clinicName}</p>
          </div>
          <div className="text-right relative">
            <div 
              className="flex items-center gap-1 cursor-help"
              onMouseEnter={() => setShowPriceBreakdown(true)}
              onMouseLeave={() => setShowPriceBreakdown(false)}
              onClick={() => setShowPriceBreakdown(!showPriceBreakdown)}
            >
              <p className="text-lg font-bold text-gray-900">{currencySymbol}{priceBreakdown.totalPrice}</p>
              <Info className="w-3.5 h-3.5 text-gray-400" />
            </div>
            <p className="text-xs text-gray-500">inc. fees</p>
            
            {showPriceBreakdown && (
              <div className="absolute top-full right-0 mt-2 bg-gray-900 text-white text-xs rounded-lg p-3 z-50 min-w-[180px] shadow-lg">
                <p className="font-medium mb-2 text-gray-300">Price Breakdown</p>
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Specialist fee</span>
                    <span>{currencySymbol}{priceBreakdown.basePrice}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Service fee (5%)</span>
                    <span>{currencySymbol}{priceBreakdown.serviceFee}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">{getVatLabel(country)} ({Math.round(priceBreakdown.vatRate * 100)}%)</span>
                    <span>{currencySymbol}{priceBreakdown.vat}</span>
                  </div>
                  <div className="border-t border-gray-700 pt-1 mt-1 flex justify-between font-medium">
                    <span>You pay</span>
                    <span className="text-green-400">{currencySymbol}{priceBreakdown.totalPrice}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Step 1: Patient Selection */}
        {step === 1 && (
          <>
            <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-semibold text-gray-900 mb-4">Who is this consultation for?</h3>
              
              <div className="grid grid-cols-2 gap-3 mb-6">
                <button
                  onClick={() => setPatientType('self')}
                  className={cn(
                    'p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-2',
                    patientType === 'self'
                      ? 'border-purple-500 bg-purple-50'
                      : 'border-gray-200 hover:border-gray-300'
                  )}
                >
                  <div className={cn(
                    'w-12 h-12 rounded-full flex items-center justify-center',
                    patientType === 'self' ? 'bg-purple-200' : 'bg-gray-100'
                  )}>
                    <User className={cn('w-6 h-6', patientType === 'self' ? 'text-purple-600' : 'text-gray-500')} />
                  </div>
                  <span className={cn('font-medium', patientType === 'self' ? 'text-purple-600' : 'text-gray-700')}>
                    Myself
                  </span>
                </button>
                
                <button
                  onClick={() => setPatientType('other')}
                  className={cn(
                    'p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-2',
                    patientType === 'other'
                      ? 'border-purple-500 bg-purple-50'
                      : 'border-gray-200 hover:border-gray-300'
                  )}
                >
                  <div className={cn(
                    'w-12 h-12 rounded-full flex items-center justify-center',
                    patientType === 'other' ? 'bg-purple-200' : 'bg-gray-100'
                  )}>
                    <UserPlus className={cn('w-6 h-6', patientType === 'other' ? 'text-purple-600' : 'text-gray-500')} />
                  </div>
                  <span className={cn('font-medium', patientType === 'other' ? 'text-purple-600' : 'text-gray-700')}>
                    Someone Else
                  </span>
                </button>
              </div>

              {/* Other Patient Details */}
              {patientType === 'other' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Patient Name *</label>
                    <input
                      type="text"
                      value={otherPatientName}
                      onChange={(e) => setOtherPatientName(e.target.value)}
                      placeholder="Enter patient's full name"
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Age *</label>
                      <input
                        type="number"
                        value={otherPatientAge}
                        onChange={(e) => setOtherPatientAge(e.target.value)}
                        placeholder="Age"
                        className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Gender *</label>
                      <select
                        value={otherPatientGender}
                        onChange={(e) => setOtherPatientGender(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 bg-white"
                      >
                        <option value="">Select</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}
            </section>

            <button
              onClick={() => setStep(2)}
              disabled={!canProceedStep1}
              className={cn(
                'w-full py-4 rounded-xl font-semibold transition-colors flex items-center justify-center gap-2',
                canProceedStep1
                  ? 'bg-gradient-to-r from-pink-500 to-purple-500 text-white hover:opacity-90'
                  : 'bg-gray-200 text-gray-400 cursor-not-allowed'
              )}
            >
              Continue <ChevronRight className="w-5 h-5" />
            </button>
          </>
        )}

        {/* Step 2: Consultation Details */}
        {step === 2 && (
          <>
            <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 space-y-5">
              <h3 className="font-semibold text-gray-900">Consultation Details</h3>
              
              {/* Procedure Interest */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Procedure of Interest *
                </label>
                <input
                  type="text"
                  value={procedureInterest}
                  onChange={(e) => setProcedureInterest(e.target.value)}
                  placeholder="e.g., Rhinoplasty, Lip fillers, Hair transplant"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500"
                />
              </div>
              
              {/* Concerns */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Describe Your Goals & Concerns
                </label>
                <textarea
                  value={concerns}
                  onChange={(e) => setConcerns(e.target.value)}
                  placeholder="What results are you hoping to achieve? Any specific concerns?"
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 resize-none"
                />
              </div>
              
              {/* Previous Procedures */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Previous Cosmetic Procedures (if any)
                </label>
                <input
                  type="text"
                  value={previousProcedures}
                  onChange={(e) => setPreviousProcedures(e.target.value)}
                  placeholder="e.g., Botox 2023, Filler 2022"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500"
                />
              </div>
            </section>

            {/* Date Selection */}
            <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-semibold text-gray-900 mb-3">Select Date *</h3>
              <div className="flex gap-2 overflow-x-auto pb-2">
                {availableDates.slice(0, 7).map(d => (
                  <button
                    key={d.date}
                    onClick={() => setSelectedDate(d.date)}
                    className={cn(
                      'flex-shrink-0 px-4 py-3 rounded-xl text-center transition-colors min-w-[80px]',
                      selectedDate === d.date
                        ? 'bg-purple-500 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    )}
                  >
                    <p className="text-xs">{d.dayName}</p>
                    <p className="font-medium">{d.display.split(' ')[1]} {d.display.split(' ')[2]}</p>
                  </button>
                ))}
              </div>
            </section>

            {/* Time Selection */}
            <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-semibold text-gray-900 mb-3">Select Time *</h3>
              <div className="grid grid-cols-4 gap-2">
                {timeSlots.map(time => (
                  <button
                    key={time}
                    onClick={() => setSelectedTime(time)}
                    className={cn(
                      'py-2 px-3 rounded-lg text-sm font-medium transition-colors',
                      selectedTime === time
                        ? 'bg-purple-500 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    )}
                  >
                    {time}
                  </button>
                ))}
              </div>
            </section>

            {/* Attachments */}
            <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-semibold text-gray-900 mb-3">
                Reference Photos (Optional)
              </h3>
              <p className="text-sm text-gray-500 mb-4">
                Upload photos showing your current appearance or desired results
              </p>
              
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
              
              <div className="grid grid-cols-3 gap-3 mb-4">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="aspect-square border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center gap-1 hover:border-purple-500 hover:bg-purple-50 transition-colors"
                >
                  <Upload className="w-6 h-6 text-gray-400" />
                  <span className="text-xs text-gray-500">Upload</span>
                </button>
                
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="aspect-square border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center gap-1 hover:border-purple-500 hover:bg-purple-50 transition-colors"
                >
                  <Camera className="w-6 h-6 text-gray-400" />
                  <span className="text-xs text-gray-500">Camera</span>
                </button>
                
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="aspect-square border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center gap-1 hover:border-purple-500 hover:bg-purple-50 transition-colors"
                >
                  <Image className="w-6 h-6 text-gray-400" />
                  <span className="text-xs text-gray-500">Gallery</span>
                </button>
              </div>
              
              {attachments.length > 0 && (
                <div className="space-y-2">
                  {attachments.map(att => (
                    <div key={att.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                      <Image className="w-5 h-5 text-purple-600" />
                      <span className="flex-1 text-sm text-gray-700 truncate">{att.name}</span>
                      <button
                        onClick={() => removeAttachment(att.id)}
                        className="p-1 hover:bg-gray-200 rounded-full"
                      >
                        <X className="w-4 h-4 text-gray-500" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* Consultation Type */}
            <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-semibold text-gray-900 mb-4">Consultation Type</h3>
              
              <div className="space-y-3">
                {[
                  { type: 'video' as ConsultType, icon: Video, label: 'Video Call', desc: 'Face-to-face virtual consultation' },
                  { type: 'voice' as ConsultType, icon: Phone, label: 'Voice Call', desc: 'Audio only consultation' },
                  { type: 'chat' as ConsultType, icon: MessageSquare, label: 'Text Chat', desc: 'Chat with the specialist' },
                ].map(opt => (
                  <button
                    key={opt.type}
                    onClick={() => setConsultType(opt.type)}
                    disabled={!doctor.consultationTypes.includes(opt.type)}
                    className={cn(
                      'w-full p-4 rounded-xl border-2 transition-all flex items-center gap-4',
                      consultType === opt.type
                        ? 'border-purple-500 bg-purple-50'
                        : 'border-gray-200 hover:border-gray-300',
                      !doctor.consultationTypes.includes(opt.type) && 'opacity-50 cursor-not-allowed'
                    )}
                  >
                    <div className={cn(
                      'w-12 h-12 rounded-xl flex items-center justify-center',
                      consultType === opt.type ? 'bg-purple-200' : 'bg-gray-100'
                    )}>
                      <opt.icon className={cn('w-6 h-6', consultType === opt.type ? 'text-purple-600' : 'text-gray-500')} />
                    </div>
                    <div className="flex-1 text-left">
                      <p className={cn('font-medium', consultType === opt.type ? 'text-purple-600' : 'text-gray-900')}>
                        {opt.label}
                      </p>
                      <p className="text-sm text-gray-500">{opt.desc}</p>
                    </div>
                    {consultType === opt.type && (
                      <Check className="w-5 h-5 text-purple-500" />
                    )}
                  </button>
                ))}
              </div>
            </section>

            <button
              onClick={() => setStep(3)}
              disabled={!canProceedStep2}
              className={cn(
                'w-full py-4 rounded-xl font-semibold transition-colors flex items-center justify-center gap-2',
                canProceedStep2
                  ? 'bg-gradient-to-r from-pink-500 to-purple-500 text-white hover:opacity-90'
                  : 'bg-gray-200 text-gray-400 cursor-not-allowed'
              )}
            >
              Continue to Payment <ChevronRight className="w-5 h-5" />
            </button>
          </>
        )}

        {/* Step 3: Payment & Confirm */}
        {step === 3 && (
          <>
            {/* Summary */}
            <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-semibold text-gray-900 mb-4">Booking Summary</h3>
              
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Clinic</span>
                  <span className="font-medium text-gray-900">{clinicData.clinicName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Specialist</span>
                  <span className="font-medium text-gray-900">{doctor.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Patient</span>
                  <span className="font-medium text-gray-900">
                    {patientType === 'self' ? (user?.name || 'You') : otherPatientName}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Procedure Interest</span>
                  <span className="font-medium text-gray-900">{procedureInterest}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Date & Time</span>
                  <span className="font-medium text-gray-900">
                    {new Date(selectedDate).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })} at {selectedTime}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Consultation Type</span>
                  <span className="font-medium text-gray-900 capitalize">{consultType}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Photos Attached</span>
                  <span className="font-medium text-gray-900">{attachments.length}</span>
                </div>
              </div>
              
              <div className="mt-4 pt-4 border-t border-gray-100 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Specialist fee</span>
                  <span className="text-gray-700">{currencySymbol}{priceBreakdown.basePrice}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Service fee (5%)</span>
                  <span className="text-gray-700">{currencySymbol}{priceBreakdown.serviceFee}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">{getVatLabel(country)} ({Math.round(priceBreakdown.vatRate * 100)}%)</span>
                  <span className="text-gray-700">{currencySymbol}{priceBreakdown.vat}</span>
                </div>
                <div className="flex justify-between items-center pt-2 border-t border-gray-100">
                  <span className="text-gray-700 font-medium">You Pay</span>
                  <span className="text-2xl font-bold text-purple-600">{currencySymbol}{priceBreakdown.totalPrice}</span>
                </div>
              </div>
            </section>

            {/* Payment Methods */}
            <section className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-semibold text-gray-900 mb-4">Payment Method</h3>
              
              <div className="space-y-3">
                {[
                  { method: 'card' as PaymentMethod, icon: CreditCard, label: 'Credit/Debit Card' },
                  { method: 'apple_pay' as PaymentMethod, icon: Wallet, label: 'Apple Pay' },
                  { method: 'google_pay' as PaymentMethod, icon: Wallet, label: 'Google Pay' },
                  { method: 'wallet' as PaymentMethod, icon: Wallet, label: 'Medro Wallet' },
                ].map(opt => (
                  <button
                    key={opt.method}
                    onClick={() => setPaymentMethod(opt.method)}
                    className={cn(
                      'w-full p-4 rounded-xl border-2 transition-all flex items-center gap-4',
                      paymentMethod === opt.method
                        ? 'border-purple-500 bg-purple-50'
                        : 'border-gray-200 hover:border-gray-300'
                    )}
                  >
                    <div className={cn(
                      'w-10 h-10 rounded-lg flex items-center justify-center',
                      paymentMethod === opt.method ? 'bg-purple-200' : 'bg-gray-100'
                    )}>
                      <opt.icon className={cn('w-5 h-5', paymentMethod === opt.method ? 'text-purple-600' : 'text-gray-500')} />
                    </div>
                    <span className={cn('font-medium', paymentMethod === opt.method ? 'text-purple-600' : 'text-gray-900')}>
                      {opt.label}
                    </span>
                    {paymentMethod === opt.method && (
                      <Check className="w-5 h-5 text-purple-500 ml-auto" />
                    )}
                  </button>
                ))}
              </div>
            </section>

            {/* Notice */}
            <div className="flex gap-3 p-4 bg-purple-50 rounded-xl border border-purple-100">
              <AlertCircle className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-purple-800">Cancellation Policy</p>
                <p className="text-purple-700">
                  Free cancellation up to 24 hours before your appointment. A full refund will be issued.
                </p>
              </div>
            </div>

            <button
              onClick={handleAddToCart}
              className="w-full py-4 bg-gradient-to-r from-pink-500 to-purple-500 text-white rounded-xl font-semibold hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
            >
              <ShoppingCart className="w-5 h-5" />
              Add to Cart & Checkout {currencySymbol}{priceBreakdown.totalPrice}
            </button>
          </>
        )}
      </main>
    </div>
  );
}
