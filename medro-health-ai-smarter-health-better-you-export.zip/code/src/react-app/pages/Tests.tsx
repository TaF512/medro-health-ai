import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { 
  Search, ChevronRight, Home as HomeIcon, Star, Heart, Droplet, Activity, 
  Pill, Droplets, Bone, Wind, Syringe, User, Sun, Sparkles, FlaskConical,
  MapPin, Map, List, ChevronDown, Navigation, Package, UserCheck, Building2,
  FileText, Brain, Filter
} from 'lucide-react';

import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import Header from '@/react-app/components/Header';
import BottomNav from '@/react-app/components/BottomNav';
import TestCard from '@/react-app/components/TestCard';
import { labTests, testCategories, labs, labCountries, Lab, CollectionMethod } from '@/react-app/data/tests';
import { cn } from '@/react-app/lib/utils';

// Fix leaflet default marker icon
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

const categoryIconMap: Record<string, React.ElementType> = {
  Heart, Droplet, Activity, Pill, Droplets, Bone, Wind,
  Syringe, User, Sun, Sparkles, FlaskConical
};

function CategoryIcon({ iconName, className }: { iconName: string; className?: string }) {
  const IconComponent = categoryIconMap[iconName] || FlaskConical;
  return <IconComponent className={className} />;
}

// Component to recenter map when location changes
function MapRecenter({ center }: { center: [number, number] }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, 10);
  }, [center, map]);
  return null;
}

// Reports Section with AI Analysis
function ReportsSection() {
  const [reports, setReports] = useState<{id: string; name: string; date: string; lab: string; status: 'pending' | 'ready' | 'analyzed'; file?: File}[]>([
    { id: '1', name: 'Complete Blood Count', date: '2024-01-15', lab: 'Medichecks', status: 'analyzed' },
    { id: '2', name: 'Lipid Profile', date: '2024-01-10', lab: 'Blue Horizon', status: 'ready' },
    { id: '3', name: 'Thyroid Function', date: '2024-01-08', lab: 'Thriva', status: 'pending' },
  ]);
  const [analyzing, setAnalyzing] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<{id: string; summary: string; concerns: string[]; recommendations: string[]} | null>(null);


  const analyzeReport = async (reportId: string) => {
    setAnalyzing(reportId);
    // Simulate AI analysis
    await new Promise(resolve => setTimeout(resolve, 2000));
    setAnalysisResult({
      id: reportId,
      summary: 'Overall results are within normal ranges. Your cholesterol levels are well-controlled and liver function markers are healthy.',
      concerns: ['Vitamin D slightly below optimal (28 ng/mL, optimal is 30-50)'],
      recommendations: [
        'Consider vitamin D supplementation (1000-2000 IU daily)',
        'Increase sun exposure (15-20 minutes daily)',
        'Schedule follow-up test in 3 months'
      ]
    });
    setAnalyzing(null);
    setReports(prev => prev.map(r => r.id === reportId ? { ...r, status: 'analyzed' } : r));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Add to reports list
      const newReport = {
        id: Date.now().toString(),
        name: file.name.replace(/\.[^.]+$/, ''),
        date: new Date().toISOString().split('T')[0],
        lab: 'Uploaded',
        status: 'ready' as const,
        file
      };
      setReports(prev => [newReport, ...prev]);
    }
  };

  return (
    <div className="space-y-5">
      {/* Upload Report */}
      <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-2xl p-4 border border-purple-100">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm">
            <Brain className="w-6 h-6 text-purple-600" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-gray-900">AI Report Analysis</h3>
            <p className="text-sm text-gray-600">Upload your lab report for instant AI analysis</p>
          </div>
        </div>
        <label className="mt-4 flex items-center justify-center gap-2 py-3 bg-white border-2 border-dashed border-purple-200 rounded-xl cursor-pointer hover:border-purple-400 transition-colors">
          <FileText className="w-5 h-5 text-purple-500" />
          <span className="text-sm font-medium text-purple-700">Upload Report (PDF/Image)</span>
          <input
            type="file"
            accept=".pdf,image/*"
            onChange={handleFileUpload}
            className="hidden"
          />
        </label>
      </div>

      {/* AI Analysis Result */}
      {analysisResult && (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
              <Brain className="w-5 h-5 text-primary" />
              AI Analysis Result
            </h3>
            <button
              onClick={() => setAnalysisResult(null)}
              className="text-sm text-gray-500"
            >
              Close
            </button>
          </div>
          
          <div className="bg-green-50 border border-green-200 rounded-xl p-3">
            <p className="text-sm text-green-800">{analysisResult.summary}</p>
          </div>

          {analysisResult.concerns.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-amber-700 mb-2">⚠️ Areas of Attention</h4>
              <ul className="space-y-1">
                {analysisResult.concerns.map((concern, i) => (
                  <li key={i} className="text-sm text-gray-700 pl-4 relative before:absolute before:left-0 before:top-2 before:w-1.5 before:h-1.5 before:bg-amber-400 before:rounded-full">
                    {concern}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div>
            <h4 className="text-sm font-medium text-blue-700 mb-2">💡 Recommendations</h4>
            <ul className="space-y-1">
              {analysisResult.recommendations.map((rec, i) => (
                <li key={i} className="text-sm text-gray-700 pl-4 relative before:absolute before:left-0 before:top-2 before:w-1.5 before:h-1.5 before:bg-blue-400 before:rounded-full">
                  {rec}
                </li>
              ))}
            </ul>
          </div>

          <div className="pt-3 border-t border-gray-100">
            <p className="text-xs text-gray-500 italic">
              This AI analysis is for informational purposes only and does not constitute medical advice. Please consult a healthcare professional for medical decisions.
            </p>
          </div>
        </div>
      )}

      {/* Reports List */}
      <div className="space-y-3">
        <h3 className="font-semibold text-gray-900">Your Reports</h3>
        {reports.map((report) => (
          <div
            key={report.id}
            className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm"
          >
            <div className="flex items-start justify-between">
              <div className="flex gap-3">
                <div className={cn(
                  'w-10 h-10 rounded-xl flex items-center justify-center',
                  report.status === 'analyzed' ? 'bg-green-100' : report.status === 'ready' ? 'bg-blue-100' : 'bg-gray-100'
                )}>
                  <FileText className={cn(
                    'w-5 h-5',
                    report.status === 'analyzed' ? 'text-green-600' : report.status === 'ready' ? 'text-blue-600' : 'text-gray-400'
                  )} />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">{report.name}</h4>
                  <p className="text-sm text-gray-500">{report.lab} • {report.date}</p>
                </div>
              </div>
              <span className={cn(
                'text-xs px-2 py-1 rounded-full',
                report.status === 'analyzed' ? 'bg-green-100 text-green-700' :
                report.status === 'ready' ? 'bg-blue-100 text-blue-700' :
                'bg-gray-100 text-gray-600'
              )}>
                {report.status === 'analyzed' ? 'Analyzed' : report.status === 'ready' ? 'Ready' : 'Pending'}
              </span>
            </div>
            
            {report.status !== 'pending' && (
              <div className="flex gap-2 mt-3 pt-3 border-t border-gray-100">
                <button className="flex-1 py-2 text-sm font-medium text-primary bg-primary/5 rounded-lg hover:bg-primary/10 transition-colors">
                  View Report
                </button>
                {report.status === 'ready' && (
                  <button
                    onClick={() => analyzeReport(report.id)}
                    disabled={analyzing === report.id}
                    className="flex-1 py-2 text-sm font-medium text-white bg-primary rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {analyzing === report.id ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Brain className="w-4 h-4" />
                        AI Analyze
                      </>
                    )}
                  </button>
                )}
                {report.status === 'analyzed' && (
                  <button
                    onClick={() => setAnalysisResult({
                      id: report.id,
                      summary: 'Results are within normal ranges with good overall health markers.',
                      concerns: ['Minor vitamin deficiency noted'],
                      recommendations: ['Maintain balanced diet', 'Regular exercise recommended']
                    })}
                    className="flex-1 py-2 text-sm font-medium text-primary border border-primary rounded-lg hover:bg-primary/5 transition-colors flex items-center justify-center gap-2"
                  >
                    <Brain className="w-4 h-4" />
                    View Analysis
                  </button>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

export default function TestsPage() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedCountry, setSelectedCountry] = useState('ALL');
  const [showCountryDropdown, setShowCountryDropdown] = useState(false);
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);
  const [activeTab, setActiveTab] = useState<'tests' | 'reports'>('tests');
  const [selectedCollectionMethods, setSelectedCollectionMethods] = useState<CollectionMethod[]>([]);
  const [showCollectionFilter, setShowCollectionFilter] = useState(false);
  const [locationSearch, setLocationSearch] = useState('');
  const [searchingLocation, setSearchingLocation] = useState(false);


  const collectionMethodOptions: { id: CollectionMethod; label: string; icon: React.ElementType; description: string; color: string }[] = [
    { id: 'nurse_visit', label: 'Nurse Visit', icon: UserCheck, description: 'Phlebotomist visits you', color: 'green' },
    { id: 'self_kit', label: 'Self-Kit', icon: Package, description: 'Postal kit to collect at home', color: 'blue' },
    { id: 'lab_visit', label: 'Visit Lab', icon: Building2, description: 'Go to the center', color: 'purple' },
  ];

  const toggleCollectionMethod = (method: CollectionMethod) => {
    setSelectedCollectionMethods(prev => 
      prev.includes(method) 
        ? prev.filter(m => m !== method)
        : [...prev, method]
    );
  };

  // Get user location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setUserLocation([pos.coords.latitude, pos.coords.longitude]),
        () => console.log('Location permission denied')
      );
    }
  }, []);

  // Search location by city/postcode using Nominatim API
  const searchLocation = async () => {
    if (!locationSearch.trim()) return;
    setSearchingLocation(true);
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(locationSearch)}&limit=1`,
        { headers: { 'User-Agent': 'Medro Health App' } }
      );
      const data = await response.json();
      if (data.length > 0) {
        const { lat, lon } = data[0];
        setUserLocation([parseFloat(lat), parseFloat(lon)]);
      }
    } catch (error) {
      console.error('Location search failed:', error);
    } finally {
      setSearchingLocation(false);
    }
  };

  // Filter labs by country and collection methods
  const filteredLabs = labs.filter(lab => {
    const matchesCountry = selectedCountry === 'ALL' || lab.country === selectedCountry;
    const matchesCollection = selectedCollectionMethods.length === 0 || 
      selectedCollectionMethods.some(method => lab.collectionMethods?.includes(method));
    return matchesCountry && matchesCollection;
  });

  // Filter tests by country, category, and search
  const filteredTests = labTests.filter(test => {
    const matchesSearch = test.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !selectedCategory || test.categoryId === selectedCategory;
    const matchesCountry = selectedCountry === 'ALL' || test.country === selectedCountry;
    return matchesSearch && matchesCategory && matchesCountry;
  });

  // Calculate distance from user
  const getDistance = (lab: Lab): number | null => {
    if (!userLocation) return null;
    const R = 6371; // Earth's radius in km
    const dLat = (lab.lat - userLocation[0]) * Math.PI / 180;
    const dLon = (lab.lng - userLocation[1]) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(userLocation[0] * Math.PI / 180) * Math.cos(lab.lat * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  // Sort labs by distance if user location available
  const sortedLabs = [...filteredLabs].sort((a, b) => {
    const distA = getDistance(a);
    const distB = getDistance(b);
    if (distA === null || distB === null) return 0;
    return distA - distB;
  });

  // Map center based on selected country or user location
  const getMapCenter = (): [number, number] => {
    if (userLocation && selectedCountry === 'ALL') return userLocation;
    const countryCoords: Record<string, [number, number]> = {
      'ALL': userLocation || [23.8103, 90.4125],
      'GB': [51.5074, -0.1278],
      'US': [40.7128, -74.0060],
      'BD': [23.8103, 90.4125],
      'IN': [28.6139, 77.2090],
      'AE': [25.2048, 55.2708],
    };
    return countryCoords[selectedCountry] || countryCoords['ALL'];
  };

  const selectedCountryData = labCountries.find(c => c.code === selectedCountry);

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      <Header title="Lab Tests" />
      
      <main className="px-4 py-4 max-w-lg mx-auto space-y-5">
        {/* Tabs: Tests / Reports */}
        <div className="flex bg-gray-100 rounded-xl p-1">
          <button
            onClick={() => setActiveTab('tests')}
            className={cn(
              'flex-1 flex items-center justify-center gap-2 py-3 rounded-lg font-medium transition-all',
              activeTab === 'tests' ? 'bg-white text-primary shadow-sm' : 'text-gray-600'
            )}
          >
            <FlaskConical className="w-5 h-5" />
            Book Tests
          </button>
          <button
            onClick={() => setActiveTab('reports')}
            className={cn(
              'flex-1 flex items-center justify-center gap-2 py-3 rounded-lg font-medium transition-all',
              activeTab === 'reports' ? 'bg-white text-primary shadow-sm' : 'text-gray-600'
            )}
          >
            <FileText className="w-5 h-5" />
            My Reports
          </button>
        </div>

        {activeTab === 'reports' ? (
          /* Reports Section with AI Analysis */
          <ReportsSection />
        ) : (
          <>
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search tests, packages"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-xl text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
          />
        </div>

        {/* Country Filter + View Toggle */}
        <div className="flex items-center gap-3">
          {/* Country Dropdown */}
          <div className="relative flex-1">
            <button
              onClick={() => setShowCountryDropdown(!showCountryDropdown)}
              className="w-full flex items-center justify-between gap-2 px-4 py-3 bg-white border border-gray-200 rounded-xl text-left hover:border-primary transition-colors"
            >
              <div className="flex items-center gap-2">
                <span className="text-lg">{selectedCountryData?.flag}</span>
                <span className="text-gray-900 font-medium">{selectedCountryData?.name}</span>
              </div>
              <ChevronDown className={cn(
                "w-5 h-5 text-gray-400 transition-transform",
                showCountryDropdown && "rotate-180"
              )} />
            </button>
            
            {showCountryDropdown && (
              <>
                <div 
                  className="fixed inset-0 z-10" 
                  onClick={() => setShowCountryDropdown(false)} 
                />
                <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-xl shadow-lg z-20 overflow-hidden">
                  {labCountries.map((country) => (
                    <button
                      key={country.code}
                      onClick={() => {
                        setSelectedCountry(country.code);
                        setShowCountryDropdown(false);
                      }}
                      className={cn(
                        "w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-gray-50 transition-colors",
                        selectedCountry === country.code && "bg-primary/5"
                      )}
                    >
                      <span className="text-lg">{country.flag}</span>
                      <span className="text-gray-900">{country.name}</span>
                      {selectedCountry === country.code && (
                        <div className="ml-auto w-2 h-2 bg-primary rounded-full" />
                      )}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* View Toggle */}
          <div className="flex bg-white border border-gray-200 rounded-xl overflow-hidden">
            <button
              onClick={() => setViewMode('list')}
              className={cn(
                "p-3 transition-colors",
                viewMode === 'list' ? "bg-primary text-white" : "text-gray-500 hover:bg-gray-50"
              )}
            >
              <List className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode('map')}
              className={cn(
                "p-3 transition-colors",
                viewMode === 'map' ? "bg-primary text-white" : "text-gray-500 hover:bg-gray-50"
              )}
            >
              <Map className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Collection Method Filter - Collapsible */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <button
            onClick={() => setShowCollectionFilter(!showCollectionFilter)}
            className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-teal-100 rounded-xl flex items-center justify-center">
                <Filter className="w-5 h-5 text-teal-600" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-gray-900">Sample Collection</h3>
                <p className="text-sm text-gray-500">
                  {selectedCollectionMethods.length > 0 
                    ? `${selectedCollectionMethods.length} method${selectedCollectionMethods.length > 1 ? 's' : ''} selected`
                    : 'Filter by collection method'}
                </p>
              </div>
            </div>
            <ChevronDown className={cn(
              "w-5 h-5 text-gray-400 transition-transform",
              showCollectionFilter && "rotate-180"
            )} />
          </button>

          {showCollectionFilter && (
            <div className="px-4 pb-4 space-y-3">
              <div className="grid grid-cols-3 gap-2">
                {collectionMethodOptions.map((method) => {
                  const Icon = method.icon;
                  const isSelected = selectedCollectionMethods.includes(method.id);
                  const colors = {
                    green: { bg: 'bg-green-50', border: 'border-green-500', text: 'text-green-700', icon: 'text-green-600' },
                    blue: { bg: 'bg-blue-50', border: 'border-blue-500', text: 'text-blue-700', icon: 'text-blue-600' },
                    purple: { bg: 'bg-purple-50', border: 'border-purple-500', text: 'text-purple-700', icon: 'text-purple-600' },
                  };
                  const colorScheme = colors[method.color as keyof typeof colors];
                  return (
                    <button
                      key={method.id}
                      onClick={() => toggleCollectionMethod(method.id)}
                      className={cn(
                        'flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all text-center',
                        isSelected
                          ? `${colorScheme.border} ${colorScheme.bg}`
                          : 'border-gray-200 bg-white hover:border-gray-300'
                      )}
                    >
                      <div className={cn(
                        'w-10 h-10 rounded-full flex items-center justify-center',
                        isSelected ? colorScheme.bg : 'bg-gray-100'
                      )}>
                        <Icon className={cn('w-5 h-5', isSelected ? colorScheme.icon : 'text-gray-500')} />
                      </div>
                      <div>
                        <p className={cn('font-medium text-xs', isSelected ? colorScheme.text : 'text-gray-700')}>
                          {method.label}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
              
              {selectedCollectionMethods.length > 0 && (
                <div className="flex items-center justify-between pt-2 border-t border-gray-100">
                  <p className="text-sm text-gray-600">
                    Showing {filteredLabs.length} labs
                  </p>
                  <button
                    onClick={() => setSelectedCollectionMethods([])}
                    className="text-sm text-primary font-medium"
                  >
                    Clear all
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {viewMode === 'map' ? (
          /* Map View */
          <section className="space-y-4">
            {/* City/Postcode Search */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
              <h3 className="font-semibold text-gray-900 mb-3">Find Labs Near You</h3>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Enter city or postcode..."
                    value={locationSearch}
                    onChange={(e) => setLocationSearch(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && searchLocation()}
                    className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  />
                </div>
                <button
                  onClick={searchLocation}
                  disabled={searchingLocation || !locationSearch.trim()}
                  className="px-4 py-3 bg-primary text-white rounded-xl font-medium hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  {searchingLocation ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <Search className="w-5 h-5" />
                  )}
                </button>
              </div>
              <button
                onClick={() => {
                  if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(
                      (pos) => setUserLocation([pos.coords.latitude, pos.coords.longitude]),
                      () => alert('Location permission denied')
                    );
                  }
                }}
                className="mt-3 w-full flex items-center justify-center gap-2 py-2.5 text-sm text-primary border border-primary/30 rounded-xl hover:bg-primary/5 transition-colors"
              >
                <Navigation className="w-4 h-4" />
                Use my current GPS location
              </button>
            </div>

            <div className="h-[400px] rounded-2xl overflow-hidden border border-gray-200 shadow-sm">
              <MapContainer
                center={getMapCenter()}
                zoom={10}
                style={{ height: '100%', width: '100%' }}
              >
                <TileLayer
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                <MapRecenter center={getMapCenter()} />
                
                {/* User location marker */}
                {userLocation && (
                  <Marker position={userLocation}>
                    <Popup>
                      <div className="text-center">
                        <p className="font-semibold">Your Location</p>
                      </div>
                    </Popup>
                  </Marker>
                )}
                
                {/* Lab markers */}
                {sortedLabs.map((lab) => (
                  <Marker key={lab.id} position={[lab.lat, lab.lng]}>
                    <Popup>
                      <div className="min-w-[180px]">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-xl">{lab.logo}</span>
                          <span className="text-lg">{lab.countryFlag}</span>
                        </div>
                        <h3 className="font-semibold text-gray-900">{lab.name}</h3>
                        <p className="text-sm text-gray-600">{lab.address}</p>
                        <div className="flex items-center gap-1 mt-1">
                          <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                          <span className="text-sm">{lab.rating}</span>
                        </div>
                        {lab.homeCollection && (
                          <span className="inline-block mt-2 text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
                            Home Collection
                          </span>
                        )}
                        {getDistance(lab) !== null && (
                          <p className="text-xs text-gray-500 mt-1">
                            {getDistance(lab)!.toFixed(1)} km away
                          </p>
                        )}
                      </div>
                    </Popup>
                  </Marker>
                ))}
              </MapContainer>
            </div>

            {/* Nearby Labs List */}
            <div>
              <h2 className="text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                <Navigation className="w-5 h-5 text-primary" />
                Nearby Labs
              </h2>
              <div className="space-y-3">
                {sortedLabs.slice(0, 5).map((lab) => (
                  <button
                    key={lab.id}
                    onClick={() => navigate(`/labs/${lab.id}`)}
                    className="w-full text-left bg-white rounded-xl border border-gray-100 hover:border-gray-200 p-4 shadow-sm transition-all"
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center text-2xl">
                        {lab.logo}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-medium text-gray-900">{lab.name}</h4>
                          <span className="text-lg">{lab.countryFlag}</span>
                        </div>
                        <div className="flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3 text-gray-400" />
                          <span className="text-sm text-gray-600">{lab.address}</span>
                        </div>
                        <div className="flex items-center gap-3 mt-2">
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                            <span className="text-sm text-gray-700">{lab.rating}</span>
                          </div>
                          {lab.homeCollection && (
                            <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">
                              Home Collection
                            </span>
                          )}
                          {getDistance(lab) !== null && (
                            <span className="text-xs text-gray-500">
                              {getDistance(lab)!.toFixed(1)} km
                            </span>
                          )}
                        </div>
                        {/* Collection Methods */}
                        <div className="flex flex-wrap gap-1 mt-2">
                          {lab.collectionMethods?.includes('nurse_visit') && (
                            <span className="text-[10px] bg-green-100 text-green-700 px-1.5 py-0.5 rounded">🏠 Nurse</span>
                          )}
                          {lab.collectionMethods?.includes('self_kit') && (
                            <span className="text-[10px] bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded">📦 Kit</span>
                          )}
                          {lab.collectionMethods?.includes('lab_visit') && (
                            <span className="text-[10px] bg-purple-100 text-purple-700 px-1.5 py-0.5 rounded">🏥 Lab</span>
                          )}
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-gray-400" />
                    </div>
                  </button>
                ))}
              </div>
            </div>


          </section>
        ) : (
          /* List View */
          <>
            {/* Home Collection Banner */}
            <div className="bg-gradient-to-r from-primary/10 to-teal-100 rounded-2xl p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm">
                  <HomeIcon className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">Home Sample Collection</h3>
                  <p className="text-sm text-gray-600">Book tests from the comfort of home</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </div>

            {/* Categories Grid */}
            <section>
              <h2 className="text-lg font-bold text-gray-900 mb-3">Categories</h2>
              <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
                {testCategories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(
                      selectedCategory === category.id ? null : category.id
                    )}
                    className={cn(
                      'flex-shrink-0 flex flex-col items-center gap-2 p-3 rounded-2xl border transition-all duration-200 min-w-[80px]',
                      selectedCategory === category.id
                        ? 'bg-primary/10 border-primary'
                        : 'bg-white border-gray-100 hover:border-gray-200'
                    )}
                  >
                    <div className={cn(
                      'w-12 h-12 rounded-full flex items-center justify-center',
                      category.color
                    )}>
                      <CategoryIcon iconName={category.icon} className="w-5 h-5" />
                    </div>
                    <span className={cn(
                      'text-xs font-medium',
                      selectedCategory === category.id ? 'text-primary' : 'text-gray-700'
                    )}>
                      {category.name}
                    </span>
                  </button>
                ))}
              </div>
            </section>

            {/* Lab Partners */}
            <section>
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-lg font-bold text-gray-900">Our Lab Partners</h2>
                <button 
                  onClick={() => setViewMode('map')}
                  className="text-sm text-primary font-medium flex items-center gap-1"
                >
                  <Map className="w-4 h-4" />
                  View Map
                </button>
              </div>
              <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
                {filteredLabs.map((lab) => (
                  <button
                    key={lab.id}
                    onClick={() => navigate(`/labs/${lab.id}`)}
                    className="flex-shrink-0 bg-white rounded-xl border border-gray-100 p-3 min-w-[180px] shadow-sm hover:border-gray-200 transition-colors text-left"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center text-xl">
                        {lab.logo}
                      </div>
                      <span className="text-lg">{lab.countryFlag}</span>
                    </div>
                    <h4 className="text-sm font-medium text-gray-900 truncate">{lab.name}</h4>
                    <div className="flex items-center gap-1 mt-1">
                      <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                      <span className="text-xs text-gray-600">{lab.rating}</span>
                    </div>
                    {/* Collection Methods */}
                    <div className="flex flex-wrap gap-1 mt-2">
                      {lab.collectionMethods?.includes('nurse_visit') && (
                        <span className="text-[10px] bg-green-100 text-green-700 px-1.5 py-0.5 rounded flex items-center gap-0.5">
                          <UserCheck className="w-3 h-3" /> Nurse
                        </span>
                      )}
                      {lab.collectionMethods?.includes('self_kit') && (
                        <span className="text-[10px] bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded flex items-center gap-0.5">
                          <Package className="w-3 h-3" /> Kit
                        </span>
                      )}
                      {lab.collectionMethods?.includes('lab_visit') && (
                        <span className="text-[10px] bg-purple-100 text-purple-700 px-1.5 py-0.5 rounded flex items-center gap-0.5">
                          <Building2 className="w-3 h-3" /> Lab
                        </span>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </section>

            {/* Most Booked Tests */}
            <section>
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-lg font-bold text-gray-900">
                  {selectedCategory 
                    ? testCategories.find(c => c.id === selectedCategory)?.name + ' Tests'
                    : 'Most Booked Tests'
                  }
                </h2>
                <span className="text-sm text-gray-500">{filteredTests.length} tests</span>
              </div>
              <div className="space-y-4">
                {filteredTests.map((test) => (
                  <TestCard key={test.id} test={test} />
                ))}
                {filteredTests.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    No tests available for this country yet.
                  </div>
                )}
              </div>
            </section>
          </>
        )}
          </>
        )}
      </main>
      
      <BottomNav />
    </div>
  );
}
