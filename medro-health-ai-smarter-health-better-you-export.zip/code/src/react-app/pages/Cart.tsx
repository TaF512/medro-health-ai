import { useState } from 'react';
import { useNavigate } from 'react-router';
import { 
  ArrowLeft, ShoppingCart, Trash2, Plus, Minus, 
  Tag, X, Check, CreditCard, Wallet, Smartphone,
  Building2, Receipt, BadgePercent, ChevronRight
} from 'lucide-react';
import { useCart } from '@/react-app/context/CartContext';
import { cn } from '@/react-app/lib/utils';
import BottomNav from '@/react-app/components/BottomNav';

const currencySymbols: Record<string, string> = {
  BDT: '৳',
  GBP: '£',
  USD: '$',
  INR: '₹',
  AED: 'AED ',
  EUR: '€',
  CAD: 'C$',
  AUD: 'A$',
  SAR: 'SAR ',
};

const paymentMethods = [
  { id: 'card', name: 'Credit/Debit Card', icon: CreditCard, color: 'bg-blue-100 text-blue-600' },
  { id: 'wallet', name: 'Digital Wallet', icon: Wallet, color: 'bg-purple-100 text-purple-600' },
  { id: 'bkash', name: 'bKash', icon: Smartphone, color: 'bg-pink-100 text-pink-600' },
  { id: 'nagad', name: 'Nagad', icon: Smartphone, color: 'bg-orange-100 text-orange-600' },
  { id: 'bank', name: 'Bank Transfer', icon: Building2, color: 'bg-green-100 text-green-600' },
];

export default function CartPage() {
  const navigate = useNavigate();
  const { items, updateQuantity, removeItem, clearCart, couponCode, couponDiscount, applyCoupon, removeCoupon, getBreakdown } = useCart();
  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState('');
  const [selectedPayment, setSelectedPayment] = useState('card');
  const [showPayment, setShowPayment] = useState(false);

  const breakdown = getBreakdown();
  const symbol = currencySymbols[breakdown.currency] || breakdown.currency;

  const handleApplyCoupon = () => {
    setCouponError('');
    if (applyCoupon(couponInput)) {
      setCouponInput('');
    } else {
      setCouponError('Invalid coupon code');
    }
  };

  const handleCheckout = () => {
    // Show payment selection then proceed
    if (!showPayment) {
      setShowPayment(true);
      return;
    }
    
    // Process checkout
    alert(`Order placed successfully!\n\nTotal: ${symbol}${breakdown.total}\nPayment: ${paymentMethods.find(p => p.id === selectedPayment)?.name}`);
    clearCart();
    navigate('/');
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 pb-24">
        <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 z-40">
          <div className="flex items-center gap-3 max-w-lg mx-auto">
            <button onClick={() => navigate(-1)} className="p-2 -ml-2 rounded-full hover:bg-gray-100">
              <ArrowLeft className="w-5 h-5 text-gray-700" />
            </button>
            <h1 className="text-lg font-bold text-gray-900">Your Cart</h1>
          </div>
        </header>

        <div className="flex flex-col items-center justify-center px-4 py-20">
          <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-6">
            <ShoppingCart className="w-12 h-12 text-gray-400" />
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">Your cart is empty</h2>
          <p className="text-gray-500 text-center mb-6">Add tests or doctor appointments to get started</p>
          <div className="flex gap-3">
            <button
              onClick={() => navigate('/tests')}
              className="px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-primary/90"
            >
              Browse Tests
            </button>
            <button
              onClick={() => navigate('/doctors')}
              className="px-6 py-3 border border-primary text-primary rounded-xl font-semibold hover:bg-primary/5"
            >
              Find Doctors
            </button>
          </div>
        </div>

        <BottomNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-40">
      {/* Header */}
      <header className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 z-40">
        <div className="flex items-center justify-between max-w-lg mx-auto">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate(-1)} className="p-2 -ml-2 rounded-full hover:bg-gray-100">
              <ArrowLeft className="w-5 h-5 text-gray-700" />
            </button>
            <h1 className="text-lg font-bold text-gray-900">Your Cart ({items.length})</h1>
          </div>
          <button onClick={clearCart} className="text-sm text-red-500 hover:text-red-600 font-medium">
            Clear All
          </button>
        </div>
      </header>

      <main className="px-4 py-4 max-w-lg mx-auto space-y-4">
        {/* Cart Items */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-gray-100">
            <h2 className="font-semibold text-gray-900">Items</h2>
          </div>
          <div className="divide-y divide-gray-100">
            {items.map((item) => (
              <div key={`${item.type}-${item.id}`} className="p-4">
                <div className="flex gap-3">
                  <div className="w-16 h-16 bg-gradient-to-br from-teal-50 to-cyan-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">{item.type === 'test' ? '🩺' : '👨‍⚕️'}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div>
                        <span className={cn(
                          'text-xs font-medium px-2 py-0.5 rounded-full',
                          item.type === 'test' ? 'bg-teal-100 text-teal-700' : 'bg-blue-100 text-blue-700'
                        )}>
                          {item.type === 'test' ? 'Lab Test' : 'Consultation'}
                        </span>
                        <h3 className="font-semibold text-gray-900 mt-1">{item.name}</h3>
                        <p className="text-sm text-gray-500">{item.labName || item.description}</p>
                        {item.homeCollection !== undefined && (
                          <p className="text-xs text-gray-400 mt-1">
                            {item.homeCollection ? '🏠 Home Collection' : '🏥 Lab Visit'}
                          </p>
                        )}
                      </div>
                      <button
                        onClick={() => removeItem(item.id, item.type)}
                        className="p-1.5 text-gray-400 hover:text-red-500"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => updateQuantity(item.id, item.type, item.quantity - 1)}
                          className="w-8 h-8 rounded-lg border border-gray-200 flex items-center justify-center hover:bg-gray-50"
                        >
                          <Minus className="w-4 h-4 text-gray-600" />
                        </button>
                        <span className="w-8 text-center font-semibold">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.type, item.quantity + 1)}
                          className="w-8 h-8 rounded-lg bg-primary text-white flex items-center justify-center hover:bg-primary/90"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="font-bold text-gray-900">
                        {currencySymbols[item.currency] || item.currency}{item.price * item.quantity}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Coupon Code */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
          <div className="flex items-center gap-2 mb-3">
            <Tag className="w-5 h-5 text-primary" />
            <h2 className="font-semibold text-gray-900">Apply Coupon</h2>
          </div>

          {couponCode ? (
            <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded-xl p-3">
              <div className="flex items-center gap-2">
                <BadgePercent className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-semibold text-green-700">{couponCode}</p>
                  <p className="text-sm text-green-600">{Math.round(couponDiscount * 100)}% discount applied</p>
                </div>
              </div>
              <button onClick={removeCoupon} className="p-1.5 hover:bg-green-100 rounded-full">
                <X className="w-4 h-4 text-green-600" />
              </button>
            </div>
          ) : (
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Enter coupon code"
                value={couponInput}
                onChange={(e) => setCouponInput(e.target.value)}
                className="flex-1 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20"
              />
              <button
                onClick={handleApplyCoupon}
                disabled={!couponInput.trim()}
                className="px-5 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-primary/90 disabled:opacity-50"
              >
                Apply
              </button>
            </div>
          )}
          {couponError && <p className="text-sm text-red-500 mt-2">{couponError}</p>}
          <p className="text-xs text-gray-500 mt-2">Try: CARELY10, HEALTH20, FIRSTORDER, WELLNESS25</p>
        </div>

        {/* Cost Breakdown */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
          <div className="flex items-center gap-2 mb-4">
            <Receipt className="w-5 h-5 text-primary" />
            <h2 className="font-semibold text-gray-900">Cost Breakdown</h2>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between text-gray-600">
              <span>Subtotal ({items.reduce((s, i) => s + i.quantity, 0)} items)</span>
              <span>{symbol}{breakdown.subtotal}</span>
            </div>
            
            <div className="flex justify-between text-gray-600">
              <div className="flex items-center gap-1">
                <span>Service Charge (5%)</span>
                <span className="text-xs bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded">Medro Fee</span>
              </div>
              <span>{symbol}{breakdown.serviceCharge}</span>
            </div>

            <div className="flex justify-between text-gray-600">
              <span>VAT/Tax</span>
              <span>{symbol}{breakdown.vat}</span>
            </div>

            {breakdown.discount > 0 && (
              <div className="flex justify-between text-green-600">
                <span>Coupon Discount ({Math.round(couponDiscount * 100)}%)</span>
                <span>-{symbol}{breakdown.discount}</span>
              </div>
            )}

            <div className="border-t border-gray-200 pt-3 mt-3">
              <div className="flex justify-between items-center">
                <span className="font-semibold text-gray-900">Total</span>
                <span className="text-2xl font-bold text-primary">{symbol}{breakdown.total}</span>
              </div>
            </div>

            {/* What goes where */}
            <div className="bg-gray-50 rounded-xl p-3 mt-3">
              <p className="text-xs font-medium text-gray-700 mb-2">Payment Distribution:</p>
              <div className="space-y-1 text-xs text-gray-600">
                <div className="flex justify-between">
                  <span>Test Center / Doctor receives:</span>
                  <span className="font-medium">{symbol}{breakdown.providerAmount}</span>
                </div>
                <div className="flex justify-between">
                  <span>Medro Commission:</span>
                  <span className="font-medium">{symbol}{breakdown.carelyCommission}</span>
                </div>
                <div className="flex justify-between">
                  <span>Government Tax:</span>
                  <span className="font-medium">{symbol}{breakdown.vat}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Payment Method */}
        {showPayment && (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <div className="flex items-center gap-2 mb-4">
              <CreditCard className="w-5 h-5 text-primary" />
              <h2 className="font-semibold text-gray-900">Payment Method</h2>
            </div>

            <div className="space-y-2">
              {paymentMethods.map((method) => (
                <button
                  key={method.id}
                  onClick={() => setSelectedPayment(method.id)}
                  className={cn(
                    'w-full flex items-center gap-3 p-3 rounded-xl border-2 transition-all',
                    selectedPayment === method.id
                      ? 'border-primary bg-primary/5'
                      : 'border-gray-100 hover:border-gray-200'
                  )}
                >
                  <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center', method.color)}>
                    <method.icon className="w-5 h-5" />
                  </div>
                  <span className="font-medium text-gray-900">{method.name}</span>
                  {selectedPayment === method.id && (
                    <Check className="w-5 h-5 text-primary ml-auto" />
                  )}
                </button>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Checkout Button */}
      <div className="fixed bottom-16 left-0 right-0 bg-white border-t border-gray-200 p-4 z-40">
        <div className="max-w-lg mx-auto">
          <button
            onClick={handleCheckout}
            className="w-full flex items-center justify-center gap-2 py-4 bg-primary text-white rounded-xl font-bold text-lg hover:bg-primary/90 transition-colors"
          >
            {showPayment ? (
              <>
                <Check className="w-5 h-5" />
                <span>Confirm & Pay {symbol}{breakdown.total}</span>
              </>
            ) : (
              <>
                <span>Proceed to Payment</span>
                <ChevronRight className="w-5 h-5" />
              </>
            )}
          </button>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
