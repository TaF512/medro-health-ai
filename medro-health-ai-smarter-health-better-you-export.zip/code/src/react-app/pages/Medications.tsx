import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { 
  ArrowLeft, Plus, Pill, Clock, Check, X, Trash2,
  Timer
} from 'lucide-react';
import { cn } from '@/react-app/lib/utils';
import BottomNav from '@/react-app/components/BottomNav';

interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  times: string[];
  color: string;
  taken: boolean[];
}

const initialMedications: Medication[] = [
  {
    id: '1',
    name: 'Metformin',
    dosage: '500mg',
    frequency: 'Twice daily',
    times: ['08:00', '20:00'],
    color: 'bg-blue-500',
    taken: [false, false]
  },
  {
    id: '2',
    name: 'Vitamin D3',
    dosage: '1000 IU',
    frequency: 'Once daily',
    times: ['09:00'],
    color: 'bg-amber-500',
    taken: [false]
  },
  {
    id: '3',
    name: 'Lisinopril',
    dosage: '10mg',
    frequency: 'Once daily',
    times: ['07:00'],
    color: 'bg-rose-500',
    taken: [false]
  }
];

// Parse time string to today's date
function parseTimeToDate(timeStr: string): Date {
  const [hours, minutes] = timeStr.split(':').map(Number);
  const date = new Date();
  date.setHours(hours, minutes, 0, 0);
  return date;
}

// Format time for display
function formatTime(timeStr: string): string {
  const date = parseTimeToDate(timeStr);
  return date.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
}

// Calculate next dose time
function getNextDoseTime(medications: Medication[]): { med: Medication; timeIndex: number; time: Date } | null {
  const now = new Date();
  let nextDose: { med: Medication; timeIndex: number; time: Date } | null = null;
  
  for (const med of medications) {
    for (let i = 0; i < med.times.length; i++) {
      if (med.taken[i]) continue;
      
      let doseTime = parseTimeToDate(med.times[i]);
      
      // If time has passed today, set for tomorrow
      if (doseTime <= now) {
        doseTime.setDate(doseTime.getDate() + 1);
      }
      
      if (!nextDose || doseTime < nextDose.time) {
        nextDose = { med, timeIndex: i, time: doseTime };
      }
    }
  }
  
  return nextDose;
}

export default function MedicationsPage() {
  const navigate = useNavigate();
  const [medications, setMedications] = useState<Medication[]>(initialMedications);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newMed, setNewMed] = useState({ name: '', dosageAmount: '', dosageUnit: '', time: '08:00' });
  const [timerMode, setTimerMode] = useState<'digital' | 'analog'>('digital');
  const [countdown, setCountdown] = useState({ hours: 0, minutes: 0, seconds: 0 });
  const [selectedMed, setSelectedMed] = useState<{ med: Medication; timeIndex: number } | null>(null);

  // Update countdown every second
  useEffect(() => {
    const updateCountdown = () => {
      const nextDose = selectedMed 
        ? { med: selectedMed.med, timeIndex: selectedMed.timeIndex, time: parseTimeToDate(selectedMed.med.times[selectedMed.timeIndex]) }
        : getNextDoseTime(medications);
      
      if (!nextDose) {
        setCountdown({ hours: 0, minutes: 0, seconds: 0 });
        return;
      }

      let targetTime = nextDose.time;
      const now = new Date();
      
      // If selected med time has passed, set for tomorrow
      if (selectedMed && targetTime <= now) {
        targetTime = new Date(targetTime);
        targetTime.setDate(targetTime.getDate() + 1);
      }
      
      const diff = targetTime.getTime() - now.getTime();
      
      if (diff <= 0) {
        setCountdown({ hours: 0, minutes: 0, seconds: 0 });
        return;
      }

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);
      
      setCountdown({ hours, minutes, seconds });
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [medications, selectedMed]);

  const toggleTaken = (medId: string, timeIndex: number) => {
    setMedications(prev => prev.map(med => {
      if (med.id === medId) {
        const newTaken = [...med.taken];
        newTaken[timeIndex] = !newTaken[timeIndex];
        return { ...med, taken: newTaken };
      }
      return med;
    }));
  };

  const deleteMedication = (medId: string) => {
    setMedications(prev => prev.filter(med => med.id !== medId));
    if (selectedMed?.med.id === medId) {
      setSelectedMed(null);
    }
  };

  const dosageUnits = ['mcg', 'mg', 'g', 'IU', 'ml', 'drops', 'tablets', 'capsules', 'puffs'];

  const addMedication = () => {
    if (!newMed.name.trim()) return;
    
    const colors = ['bg-blue-500', 'bg-green-500', 'bg-purple-500', 'bg-orange-500', 'bg-pink-500'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];

    // Combine amount and unit for dosage display
    let dosageDisplay = 'As prescribed';
    if (newMed.dosageAmount && newMed.dosageUnit) {
      dosageDisplay = `${newMed.dosageAmount} ${newMed.dosageUnit}`;
    } else if (newMed.dosageAmount) {
      dosageDisplay = newMed.dosageAmount;
    }

    const newMedication: Medication = {
      id: Date.now().toString(),
      name: newMed.name,
      dosage: dosageDisplay,
      frequency: 'Once daily',
      times: [newMed.time],
      color: randomColor,
      taken: [false]
    };

    setMedications(prev => [...prev, newMedication]);
    setNewMed({ name: '', dosageAmount: '', dosageUnit: '', time: '08:00' });
    setShowAddModal(false);
  };

  const selectMedicationForTimer = (med: Medication, timeIndex: number) => {
    setSelectedMed({ med, timeIndex });
  };

  const totalDoses = medications.reduce((acc, med) => acc + med.times.length, 0);
  const takenDoses = medications.reduce((acc, med) => acc + med.taken.filter(Boolean).length, 0);
  const adherenceRate = totalDoses > 0 ? Math.round((takenDoses / totalDoses) * 100) : 0;
  const nextDose = getNextDoseTime(medications);

  // Analog clock calculations
  const hourAngle = (countdown.hours / 12) * 360 - 90;
  const minuteAngle = (countdown.minutes / 60) * 360 - 90;
  const secondAngle = (countdown.seconds / 60) * 360 - 90;

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="sticky top-0 bg-gradient-to-r from-rose-500 to-rose-600 px-4 py-4 z-40">
        <div className="flex items-center gap-3 max-w-lg mx-auto">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 rounded-full hover:bg-white/20 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-white">Medication Reminders</h1>
            <p className="text-sm text-white/80">Track your daily medications</p>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
          >
            <Plus className="w-5 h-5 text-white" />
          </button>
        </div>
      </header>

      <main className="px-4 py-6 max-w-lg mx-auto space-y-6">
        {/* Countdown Timer */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Timer className="w-5 h-5 text-rose-500" />
              <h2 className="font-semibold text-gray-900">Next Dose Countdown</h2>
            </div>
            <div className="flex items-center bg-gray-100 rounded-lg p-1">
              <button
                onClick={() => setTimerMode('digital')}
                className={cn(
                  'px-3 py-1.5 text-sm font-medium rounded-md transition-all',
                  timerMode === 'digital' ? 'bg-white text-rose-600 shadow-sm' : 'text-gray-600'
                )}
              >
                Digital
              </button>
              <button
                onClick={() => setTimerMode('analog')}
                className={cn(
                  'px-3 py-1.5 text-sm font-medium rounded-md transition-all',
                  timerMode === 'analog' ? 'bg-white text-rose-600 shadow-sm' : 'text-gray-600'
                )}
              >
                Analog
              </button>
            </div>
          </div>

          {/* Selected Medication Info */}
          {(selectedMed || nextDose) && (
            <div className="bg-rose-50 rounded-xl p-3 mb-4">
              <div className="flex items-center gap-3">
                <div className={cn(
                  'w-10 h-10 rounded-xl flex items-center justify-center',
                  selectedMed?.med.color || nextDose?.med.color || 'bg-rose-500'
                )}>
                  <Pill className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-gray-900">
                    {selectedMed?.med.name || nextDose?.med.name}
                  </p>
                  <p className="text-sm text-gray-600">
                    {selectedMed?.med.dosage || nextDose?.med.dosage} at{' '}
                    {formatTime(selectedMed?.med.times[selectedMed.timeIndex] || nextDose?.med.times[nextDose.timeIndex] || '')}
                  </p>
                </div>
                {selectedMed && (
                  <button
                    onClick={() => setSelectedMed(null)}
                    className="p-1.5 hover:bg-rose-100 rounded-full"
                  >
                    <X className="w-4 h-4 text-rose-600" />
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Timer Display */}
          {timerMode === 'digital' ? (
            <div className="flex justify-center py-6">
              <div className="flex items-center gap-2">
                <div className="bg-gray-900 text-white rounded-xl px-5 py-4 text-center min-w-[80px]">
                  <p className="text-4xl font-mono font-bold">{String(countdown.hours).padStart(2, '0')}</p>
                  <p className="text-xs text-gray-400 mt-1">HOURS</p>
                </div>
                <span className="text-3xl font-bold text-gray-300">:</span>
                <div className="bg-gray-900 text-white rounded-xl px-5 py-4 text-center min-w-[80px]">
                  <p className="text-4xl font-mono font-bold">{String(countdown.minutes).padStart(2, '0')}</p>
                  <p className="text-xs text-gray-400 mt-1">MINS</p>
                </div>
                <span className="text-3xl font-bold text-gray-300">:</span>
                <div className="bg-rose-500 text-white rounded-xl px-5 py-4 text-center min-w-[80px]">
                  <p className="text-4xl font-mono font-bold">{String(countdown.seconds).padStart(2, '0')}</p>
                  <p className="text-xs text-rose-200 mt-1">SECS</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex justify-center py-6">
              <div className="relative w-48 h-48">
                {/* Clock face */}
                <svg className="w-full h-full" viewBox="0 0 200 200">
                  {/* Outer ring */}
                  <circle cx="100" cy="100" r="95" fill="none" stroke="#f3f4f6" strokeWidth="4" />
                  <circle cx="100" cy="100" r="90" fill="#fff" stroke="#e5e7eb" strokeWidth="2" />
                  
                  {/* Hour markers */}
                  {[...Array(12)].map((_, i) => {
                    const angle = (i * 30 - 90) * (Math.PI / 180);
                    const x1 = 100 + 75 * Math.cos(angle);
                    const y1 = 100 + 75 * Math.sin(angle);
                    const x2 = 100 + 85 * Math.cos(angle);
                    const y2 = 100 + 85 * Math.sin(angle);
                    return (
                      <line 
                        key={i} 
                        x1={x1} y1={y1} x2={x2} y2={y2} 
                        stroke="#9ca3af" 
                        strokeWidth={i % 3 === 0 ? 3 : 1.5} 
                      />
                    );
                  })}
                  
                  {/* Hour hand */}
                  <line
                    x1="100"
                    y1="100"
                    x2={100 + 40 * Math.cos(hourAngle * Math.PI / 180)}
                    y2={100 + 40 * Math.sin(hourAngle * Math.PI / 180)}
                    stroke="#1f2937"
                    strokeWidth="4"
                    strokeLinecap="round"
                  />
                  
                  {/* Minute hand */}
                  <line
                    x1="100"
                    y1="100"
                    x2={100 + 55 * Math.cos(minuteAngle * Math.PI / 180)}
                    y2={100 + 55 * Math.sin(minuteAngle * Math.PI / 180)}
                    stroke="#4b5563"
                    strokeWidth="3"
                    strokeLinecap="round"
                  />
                  
                  {/* Second hand */}
                  <line
                    x1="100"
                    y1="100"
                    x2={100 + 65 * Math.cos(secondAngle * Math.PI / 180)}
                    y2={100 + 65 * Math.sin(secondAngle * Math.PI / 180)}
                    stroke="#f43f5e"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                  
                  {/* Center dot */}
                  <circle cx="100" cy="100" r="6" fill="#f43f5e" />
                  <circle cx="100" cy="100" r="3" fill="#fff" />
                </svg>
                
                {/* Digital overlay */}
                <div className="absolute bottom-2 left-1/2 -translate-x-1/2 bg-gray-900 text-white px-3 py-1 rounded-lg">
                  <p className="text-sm font-mono">
                    {String(countdown.hours).padStart(2, '0')}:
                    {String(countdown.minutes).padStart(2, '0')}:
                    {String(countdown.seconds).padStart(2, '0')}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Today's Progress */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-semibold text-gray-900">Today's Progress</h2>
              <p className="text-sm text-gray-500">{takenDoses} of {totalDoses} doses taken</p>
            </div>
            <div className="relative w-16 h-16">
              <svg className="w-16 h-16 transform -rotate-90">
                <circle cx="32" cy="32" r="28" stroke="#e5e7eb" strokeWidth="6" fill="none" />
                <circle
                  cx="32"
                  cy="32"
                  r="28"
                  stroke="#f43f5e"
                  strokeWidth="6"
                  fill="none"
                  strokeDasharray={`${adherenceRate * 1.76} 176`}
                  strokeLinecap="round"
                />
              </svg>
              <span className="absolute inset-0 flex items-center justify-center text-sm font-bold text-gray-900">
                {adherenceRate}%
              </span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="bg-green-50 rounded-xl p-3 text-center">
              <Check className="w-5 h-5 text-green-600 mx-auto mb-1" />
              <p className="text-lg font-bold text-green-700">{takenDoses}</p>
              <p className="text-xs text-green-600">Taken</p>
            </div>
            <div className="bg-amber-50 rounded-xl p-3 text-center">
              <Clock className="w-5 h-5 text-amber-600 mx-auto mb-1" />
              <p className="text-lg font-bold text-amber-700">{totalDoses - takenDoses}</p>
              <p className="text-xs text-amber-600">Pending</p>
            </div>
            <div className="bg-blue-50 rounded-xl p-3 text-center">
              <Pill className="w-5 h-5 text-blue-600 mx-auto mb-1" />
              <p className="text-lg font-bold text-blue-700">{medications.length}</p>
              <p className="text-xs text-blue-600">Medications</p>
            </div>
          </div>
        </div>

        {/* Medication List */}
        <section>
          <h2 className="font-semibold text-gray-900 mb-3">Your Medications</h2>
          <p className="text-sm text-gray-500 mb-3">Tap a time to set countdown timer</p>
          <div className="space-y-3">
            {medications.map(med => (
              <div key={med.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="flex items-center gap-4 p-4">
                  <div className={`w-12 h-12 ${med.color} rounded-xl flex items-center justify-center`}>
                    <Pill className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-gray-900">{med.name}</p>
                    <p className="text-sm text-gray-500">{med.dosage} • {med.frequency}</p>
                  </div>
                  <button
                    onClick={() => deleteMedication(med.id)}
                    className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
                <div className="border-t border-gray-100 px-4 py-3 bg-gray-50">
                  <div className="flex flex-wrap gap-2">
                    {med.times.map((time, idx) => (
                      <div key={idx} className="flex items-center gap-1">
                        <button
                          onClick={() => selectMedicationForTimer(med, idx)}
                          className={cn(
                            'flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium transition-all',
                            selectedMed?.med.id === med.id && selectedMed?.timeIndex === idx
                              ? 'bg-rose-100 text-rose-700 ring-2 ring-rose-500'
                              : 'bg-white text-gray-600 border border-gray-200 hover:border-rose-300'
                          )}
                        >
                          <Timer className="w-4 h-4" />
                          {formatTime(time)}
                        </button>
                        <button
                          onClick={() => toggleTaken(med.id, idx)}
                          className={cn(
                            'p-2 rounded-xl transition-all',
                            med.taken[idx]
                              ? 'bg-green-100 text-green-700'
                              : 'bg-gray-100 text-gray-500 hover:bg-green-50'
                          )}
                        >
                          <Check className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Empty State */}
        {medications.length === 0 && (
          <div className="text-center py-12">
            <div className="w-20 h-20 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Pill className="w-10 h-10 text-rose-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">No Medications</h3>
            <p className="text-gray-500 mt-1 mb-4">Add your medications to set up reminders</p>
            <button
              onClick={() => setShowAddModal(true)}
              className="px-6 py-3 bg-rose-600 text-white rounded-xl font-semibold hover:bg-rose-700 transition-colors"
            >
              Add Medication
            </button>
          </div>
        )}
      </main>

      {/* Add Medication Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="w-full bg-white rounded-t-3xl p-6 max-w-lg mx-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Add Medication</h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Medication Name</label>
                <input
                  type="text"
                  value={newMed.name}
                  onChange={(e) => setNewMed(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="e.g., Aspirin"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Dosage</label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    value={newMed.dosageAmount}
                    onChange={(e) => setNewMed(prev => ({ ...prev, dosageAmount: e.target.value }))}
                    placeholder="Amount"
                    min="0"
                    step="any"
                    className="flex-1 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                  <select
                    value={newMed.dosageUnit}
                    onChange={(e) => setNewMed(prev => ({ ...prev, dosageUnit: e.target.value }))}
                    className="px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500 min-w-[110px]"
                  >
                    <option value="">Unit</option>
                    {dosageUnits.map(unit => (
                      <option key={unit} value={unit}>{unit}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Reminder Time</label>
                <input
                  type="time"
                  value={newMed.time}
                  onChange={(e) => setNewMed(prev => ({ ...prev, time: e.target.value }))}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>

              <button
                onClick={addMedication}
                disabled={!newMed.name.trim()}
                className="w-full py-4 bg-rose-600 text-white rounded-xl font-semibold hover:bg-rose-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed mt-4"
              >
                Add Medication
              </button>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
