import { useState } from 'react';
import { Link, useParams } from 'react-router';
import { 
  ArrowLeft, Clock, Shield, AlertTriangle, CheckCircle, 
  Calendar, Stethoscope, Heart, Star, Phone, Mail,
  ChevronDown, ChevronUp, Sparkles
} from 'lucide-react';
import { useCurrency } from '@/react-app/contexts/CurrencyContext';
import { useLanguage } from '@/react-app/contexts/LanguageContext';

interface ProcedureInfo {
  id: string;
  name: string;
  category: string;
  description: string;
  overview: string;
  duration: string;
  recovery: string;
  priceRange: { from: number; to: number };
  howItWorks: string[];
  preparation: string[];
  aftercare: string[];
  risks: string[];
  benefits: string[];
  idealCandidates: string[];
  notRecommendedFor: string[];
  resultsTimeline: string;
  maintenanceRequired: string;
  anesthesia: string;
  hospitalStay: string;
}

// Comprehensive procedure database with detailed information
const procedureDatabase: Record<string, ProcedureInfo> = {
  'lip-fillers': {
    id: 'lip-fillers',
    name: 'Lip Fillers',
    category: 'face',
    description: 'Hyaluronic acid dermal fillers for fuller, more defined lips',
    overview: 'Lip fillers are injectable treatments that add volume, shape, and structure to the lips using hyaluronic acid-based dermal fillers. The procedure is minimally invasive and provides natural-looking results.',
    duration: '15-30 minutes',
    recovery: '1-2 days swelling',
    priceRange: { from: 200, to: 600 },
    howItWorks: [
      'Consultation to discuss desired lip shape and volume',
      'Topical numbing cream applied to lips (10-15 minutes)',
      'Small injections of hyaluronic acid filler into strategic points',
      'Gentle massage to distribute filler evenly',
      'Immediate results visible with final results in 2 weeks'
    ],
    preparation: [
      'Avoid blood thinners and alcohol 24-48 hours before',
      'Stop taking vitamin E, fish oil, and aspirin 1 week prior',
      'Inform practitioner of any cold sore history',
      'Come with clean, makeup-free lips',
      'Eat a light meal before the appointment'
    ],
    aftercare: [
      'Apply ice packs to reduce swelling (first 24 hours)',
      'Avoid touching or pressing on lips for 24 hours',
      'Sleep with head elevated for first 2 nights',
      'Avoid intense exercise for 24-48 hours',
      'Stay hydrated and avoid alcohol',
      'Avoid hot drinks and spicy food for 24 hours',
      'No kissing or makeup on lips for 24 hours'
    ],
    risks: [
      'Temporary swelling and bruising',
      'Mild pain or tenderness',
      'Lumps or asymmetry (can be corrected)',
      'Infection (rare)',
      'Allergic reaction (very rare)',
      'Vascular occlusion (extremely rare, serious)'
    ],
    benefits: [
      'Immediate volume enhancement',
      'Natural-looking results',
      'Reversible with hyaluronidase',
      'Minimal downtime',
      'Gradual results prevent drastic changes',
      'Can correct asymmetry',
      'Boosts confidence'
    ],
    idealCandidates: [
      'Adults over 18 with thin lips',
      'Those wanting to restore lost volume',
      'People with asymmetric lips',
      'Those in good overall health',
      'Non-smokers or willing to quit temporarily'
    ],
    notRecommendedFor: [
      'Pregnant or breastfeeding women',
      'Those with active cold sores or infections',
      'People with blood clotting disorders',
      'Those with unrealistic expectations',
      'Anyone allergic to hyaluronic acid'
    ],
    resultsTimeline: 'Immediate results, final results in 2 weeks after swelling subsides. Results last 6-12 months.',
    maintenanceRequired: 'Touch-up treatments every 6-12 months to maintain results',
    anesthesia: 'Topical numbing cream',
    hospitalStay: 'None - outpatient procedure'
  },
  'botox': {
    id: 'botox',
    name: 'Botox Treatment',
    category: 'face',
    description: 'Botulinum toxin injections for wrinkle reduction and facial rejuvenation',
    overview: 'Botox is a purified protein that temporarily relaxes facial muscles, reducing the appearance of dynamic wrinkles and preventing new ones from forming.',
    duration: '15-30 minutes',
    recovery: 'None - return to activities immediately',
    priceRange: { from: 150, to: 500 },
    howItWorks: [
      'Consultation to identify treatment areas',
      'Face is cleaned and marked for injection sites',
      'Small amounts of Botox injected into targeted muscles',
      'Multiple small injections per treatment area',
      'Results develop over 3-14 days'
    ],
    preparation: [
      'Avoid alcohol for 24 hours before',
      'Stop blood thinners if medically safe',
      'Arrive with clean skin, no makeup',
      'Discuss any medications with practitioner',
      'Avoid strenuous exercise on treatment day'
    ],
    aftercare: [
      'Remain upright for 4 hours after treatment',
      'Avoid touching or rubbing treated areas',
      'No intense exercise for 24 hours',
      'Avoid heat (saunas, hot yoga) for 24 hours',
      'Do not lie face down for 4 hours',
      'Avoid facials or massages for 2 weeks'
    ],
    risks: [
      'Temporary bruising at injection sites',
      'Headache (usually resolves in 24-48 hours)',
      'Drooping eyelid (rare, temporary)',
      'Flu-like symptoms (rare)',
      'Asymmetry (can be corrected)'
    ],
    benefits: [
      'Smooths forehead lines and crow\'s feet',
      'Prevents new wrinkles from forming',
      'Non-surgical and minimally invasive',
      'No downtime required',
      'Results last 3-4 months',
      'Can lift eyebrows naturally'
    ],
    idealCandidates: [
      'Adults 18-65 with dynamic wrinkles',
      'Those with realistic expectations',
      'Non-pregnant individuals',
      'Those wanting preventative treatment',
      'People in good general health'
    ],
    notRecommendedFor: [
      'Pregnant or breastfeeding women',
      'Those with neuromuscular disorders',
      'People allergic to botulinum toxin',
      'Those with infection at injection sites',
      'Anyone on certain antibiotics'
    ],
    resultsTimeline: 'Results appear in 3-5 days, full effect in 14 days. Lasts 3-4 months.',
    maintenanceRequired: 'Repeat treatments every 3-4 months',
    anesthesia: 'None required, some practitioners use ice',
    hospitalStay: 'None - outpatient procedure'
  },
  'hair-transplant': {
    id: 'hair-transplant',
    name: 'FUE Hair Transplant',
    category: 'hair',
    description: 'Follicular Unit Extraction for permanent, natural hair restoration',
    overview: 'FUE (Follicular Unit Extraction) is an advanced hair transplant technique where individual hair follicles are extracted from the donor area and implanted into balding areas for permanent, natural-looking results.',
    duration: '6-8 hours',
    recovery: '7-10 days initial, 12 months for full results',
    priceRange: { from: 2000, to: 15000 },
    howItWorks: [
      'Donor area (usually back of head) is trimmed and prepared',
      'Local anesthesia administered to donor and recipient areas',
      'Individual follicles extracted using micro-punch tool',
      'Recipient area prepared with tiny incisions',
      'Follicles carefully implanted at correct angle and depth',
      'Process repeated for 2000-5000+ grafts'
    ],
    preparation: [
      'Stop smoking 2 weeks before surgery',
      'Avoid alcohol 1 week prior',
      'Stop blood thinners as advised',
      'Wash hair morning of surgery',
      'Wear comfortable, button-up shirt',
      'Arrange transportation home',
      'Eat a good breakfast'
    ],
    aftercare: [
      'Sleep with head elevated for 5-7 days',
      'Avoid touching or scratching transplanted area',
      'Gentle hair washing after 48 hours as instructed',
      'No exercise for 2 weeks',
      'Avoid sun exposure for 2 weeks',
      'Take prescribed medications as directed',
      'Expect shedding at 2-4 weeks (normal)',
      'New growth begins at 3-4 months'
    ],
    risks: [
      'Temporary swelling of forehead',
      'Numbness in donor/recipient areas',
      'Infection (rare with proper care)',
      'Scarring (minimal with FUE)',
      'Shock loss (temporary shedding)',
      'Unnatural appearance if done poorly'
    ],
    benefits: [
      'Permanent, natural-looking results',
      'Your own hair that grows naturally',
      'Minimal scarring compared to FUT',
      'Can style hair normally',
      'One-time procedure for lasting results',
      'Boosts confidence significantly'
    ],
    idealCandidates: [
      'Those with stable hair loss pattern',
      'Adequate donor hair density',
      'Age 25+ with established hair loss',
      'Good overall health',
      'Realistic expectations'
    ],
    notRecommendedFor: [
      'Those with active scalp conditions',
      'Insufficient donor hair',
      'Very young patients with unstable loss',
      'Those with unrealistic expectations',
      'Certain autoimmune conditions'
    ],
    resultsTimeline: 'New hair growth at 3-4 months, significant improvement at 6 months, final results at 12-18 months',
    maintenanceRequired: 'May need PRP treatments to maintain; rarely need second procedure',
    anesthesia: 'Local anesthesia',
    hospitalStay: 'None - outpatient procedure'
  },
  'rhinoplasty': {
    id: 'rhinoplasty',
    name: 'Rhinoplasty',
    category: 'face',
    description: 'Surgical nose reshaping for aesthetic and functional improvement',
    overview: 'Rhinoplasty is a surgical procedure that reshapes the nose for cosmetic or functional purposes. It can address size, shape, proportion, and breathing issues.',
    duration: '2-3 hours',
    recovery: '2-3 weeks visible recovery, 1 year final results',
    priceRange: { from: 4000, to: 15000 },
    howItWorks: [
      'General anesthesia or IV sedation administered',
      'Incisions made inside nostrils (closed) or across columella (open)',
      'Nasal skin lifted to access underlying structure',
      'Bone and cartilage reshaped, reduced, or augmented',
      'Skin re-draped and incisions closed',
      'Splint placed on nose for protection'
    ],
    preparation: [
      'Complete all pre-operative tests',
      'Stop smoking 4-6 weeks before',
      'Avoid aspirin and NSAIDs for 2 weeks',
      'Arrange 1-2 weeks off work',
      'Prepare recovery area at home',
      'Have someone drive you home',
      'Fast from midnight before surgery'
    ],
    aftercare: [
      'Keep head elevated for 2 weeks',
      'Apply cold compresses to reduce swelling',
      'Take prescribed pain medication',
      'Avoid blowing nose for 2 weeks',
      'No glasses on nose for 4-6 weeks',
      'Sleep on back only',
      'Avoid strenuous activity for 4-6 weeks',
      'Splint removed after 1 week'
    ],
    risks: [
      'Swelling and bruising (expected)',
      'Difficulty breathing temporarily',
      'Infection (rare)',
      'Asymmetry or unsatisfactory results',
      'Numbness (usually temporary)',
      'Septal perforation (rare)',
      'Need for revision surgery (5-10%)'
    ],
    benefits: [
      'Improved facial harmony',
      'Enhanced self-confidence',
      'Better breathing (if functional issue)',
      'Permanent results',
      'Corrects birth defects or injuries',
      'Natural-looking when done well'
    ],
    idealCandidates: [
      'Facial growth complete (age 15+ for girls, 17+ for boys)',
      'Good physical health',
      'Non-smokers',
      'Realistic expectations',
      'Stable mental health'
    ],
    notRecommendedFor: [
      'Those with unrealistic expectations',
      'Active smokers unwilling to quit',
      'Those with body dysmorphia',
      'Patients with bleeding disorders',
      'Those seeking perfection'
    ],
    resultsTimeline: 'Splint off at 1 week, most swelling gone at 3 months, subtle refinement continues for 1 year',
    maintenanceRequired: 'None - results are permanent',
    anesthesia: 'General anesthesia or IV sedation',
    hospitalStay: 'Usually outpatient, occasionally 1 night'
  },
  'breast-augmentation': {
    id: 'breast-augmentation',
    name: 'Breast Augmentation',
    category: 'breast',
    description: 'Breast enlargement with implants for enhanced size and shape',
    overview: 'Breast augmentation uses silicone or saline implants to increase breast size, improve shape, and enhance body proportions.',
    duration: '1-2 hours',
    recovery: '4-6 weeks for full recovery',
    priceRange: { from: 4000, to: 10000 },
    howItWorks: [
      'General anesthesia administered',
      'Incision made (under breast, around areola, or armpit)',
      'Pocket created under breast tissue or chest muscle',
      'Implant inserted and positioned',
      'Incisions closed with sutures',
      'Surgical bra placed for support'
    ],
    preparation: [
      'Get baseline mammogram if recommended',
      'Stop smoking 4-6 weeks before',
      'Avoid aspirin and blood thinners',
      'Arrange 1-2 weeks off work',
      'Buy front-opening clothing',
      'Prepare meals in advance',
      'Have someone stay with you for 24-48 hours'
    ],
    aftercare: [
      'Wear surgical bra 24/7 for 4-6 weeks',
      'Sleep on back for 4-6 weeks',
      'No lifting arms above head for 2 weeks',
      'No lifting heavy objects for 4-6 weeks',
      'Take prescribed medications',
      'Attend all follow-up appointments',
      'Massage breasts as instructed',
      'No underwire bras for 3 months'
    ],
    risks: [
      'Capsular contracture (scar tissue hardening)',
      'Implant rupture or leak',
      'Changes in nipple sensation',
      'Asymmetry',
      'Infection',
      'Need for revision surgery',
      'Implant displacement'
    ],
    benefits: [
      'Enhanced breast size and shape',
      'Improved body proportion',
      'Correction of asymmetry',
      'Restored volume after weight loss or pregnancy',
      'Increased clothing options',
      'Boosted self-confidence'
    ],
    idealCandidates: [
      'Adults over 18 (saline) or 22 (silicone)',
      'Good physical health',
      'Realistic expectations',
      'Non-smokers',
      'Stable weight'
    ],
    notRecommendedFor: [
      'Those currently pregnant or breastfeeding',
      'Those with active breast cancer',
      'Those with untreated infections',
      'People with unrealistic expectations',
      'Those unwilling to follow aftercare'
    ],
    resultsTimeline: 'Immediate results, final shape at 3-6 months as swelling subsides and implants settle',
    maintenanceRequired: 'Implants may need replacement after 10-20 years',
    anesthesia: 'General anesthesia',
    hospitalStay: 'Usually outpatient or 1 night'
  },
  'liposuction': {
    id: 'liposuction',
    name: 'Liposuction',
    category: 'body',
    description: 'Fat removal and body sculpting for improved contours',
    overview: 'Liposuction is a surgical procedure that removes stubborn fat deposits to improve body contours. It\'s not a weight loss solution but a body sculpting technique.',
    duration: '1-4 hours depending on areas',
    recovery: '2-4 weeks, final results at 3-6 months',
    priceRange: { from: 2000, to: 10000 },
    howItWorks: [
      'General or local anesthesia with sedation',
      'Small incisions made in treatment areas',
      'Tumescent fluid injected to minimize bleeding',
      'Cannula inserted to break up fat cells',
      'Fat suctioned out through cannula',
      'Incisions closed and compression garments applied'
    ],
    preparation: [
      'Reach stable weight before surgery',
      'Stop smoking 4 weeks before',
      'Avoid blood thinners',
      'Stay hydrated',
      'Buy compression garments',
      'Arrange transportation and help at home'
    ],
    aftercare: [
      'Wear compression garments 24/7 for 4-6 weeks',
      'Walk gently to prevent blood clots',
      'Drain fluids as instructed',
      'Take prescribed antibiotics',
      'Avoid strenuous exercise for 4-6 weeks',
      'Maintain healthy diet and exercise',
      'Massage treated areas as directed'
    ],
    risks: [
      'Swelling and bruising (expected)',
      'Contour irregularities',
      'Fluid accumulation (seroma)',
      'Numbness (usually temporary)',
      'Infection',
      'Fat embolism (rare)',
      'Skin laxity'
    ],
    benefits: [
      'Removes stubborn fat resistant to diet',
      'Improved body contours',
      'Permanent fat cell removal',
      'Can treat multiple areas',
      'Enhanced self-confidence',
      'Better-fitting clothes'
    ],
    idealCandidates: [
      'Within 30% of ideal body weight',
      'Good skin elasticity',
      'Non-smokers',
      'Localized fat deposits',
      'Healthy lifestyle commitment'
    ],
    notRecommendedFor: [
      'Those seeking weight loss solution',
      'Those with poor skin elasticity',
      'People with bleeding disorders',
      'Those with unrealistic expectations',
      'Active smokers'
    ],
    resultsTimeline: 'Immediate improvement, 50% results at 1 month, final results at 3-6 months',
    maintenanceRequired: 'Maintain weight with diet and exercise to preserve results',
    anesthesia: 'General or local with sedation',
    hospitalStay: 'Usually outpatient'
  },
  'bbl': {
    id: 'bbl',
    name: 'Brazilian Butt Lift (BBL)',
    category: 'body',
    description: 'Fat transfer to buttocks for enhanced shape and volume',
    overview: 'The Brazilian Butt Lift combines liposuction with fat grafting to enhance buttock size and shape using your own body fat for natural-looking results.',
    duration: '3-4 hours',
    recovery: '4-6 weeks, no sitting directly for 2-3 weeks',
    priceRange: { from: 5000, to: 15000 },
    howItWorks: [
      'General anesthesia administered',
      'Liposuction performed on donor areas (abdomen, thighs, back)',
      'Harvested fat processed and purified',
      'Fat injected into buttocks at multiple levels',
      'Fat sculpted for desired shape',
      'Compression garments and BBL pillow provided'
    ],
    preparation: [
      'Gain 5-10 pounds if needed for fat harvest',
      'Stop smoking 4-6 weeks before',
      'Avoid blood thinners',
      'Buy BBL pillow for sitting',
      'Arrange help at home for 2 weeks',
      'Prepare meals in advance'
    ],
    aftercare: [
      'NO SITTING OR LYING ON BACK for 2-3 weeks',
      'Use BBL pillow when must sit',
      'Sleep on stomach or side only',
      'Wear compression garments 24/7',
      'Walk gently to promote circulation',
      'Lymphatic massage after 2 weeks',
      'No exercise for 6-8 weeks'
    ],
    risks: [
      'Fat embolism (serious, follow aftercare strictly)',
      'Fat necrosis',
      'Asymmetry',
      'Volume loss (30-40% normal)',
      'Infection',
      'Seroma',
      'Skin irregularities'
    ],
    benefits: [
      'Enhanced buttock size and shape',
      'Natural look and feel (your own fat)',
      'Improved body proportions',
      'Slimmer waist from liposuction',
      'No implants required',
      'Long-lasting results'
    ],
    idealCandidates: [
      'Enough fat for transfer',
      'Good overall health',
      'Non-smokers',
      'Can commit to aftercare restrictions',
      'Realistic expectations'
    ],
    notRecommendedFor: [
      'Very thin patients without adequate fat',
      'Those who cannot avoid sitting',
      'Active smokers',
      'Those with blood disorders',
      'Unrealistic expectations'
    ],
    resultsTimeline: '60-70% of transferred fat survives permanently, final results at 6-12 months',
    maintenanceRequired: 'Maintain stable weight; may need touch-up',
    anesthesia: 'General anesthesia',
    hospitalStay: 'Usually outpatient or 1 night'
  },
  'dental-veneers': {
    id: 'dental-veneers',
    name: 'Porcelain Veneers',
    category: 'dental',
    description: 'Custom porcelain shells for a perfect smile transformation',
    overview: 'Dental veneers are thin, custom-made shells that cover the front surface of teeth to improve appearance, color, shape, and alignment.',
    duration: '2-3 visits over 2-3 weeks',
    recovery: '1-2 days sensitivity',
    priceRange: { from: 500, to: 2000 },
    howItWorks: [
      'Consultation and smile design planning',
      'Teeth prepared by removing thin layer of enamel',
      'Impressions taken for custom veneers',
      'Temporary veneers placed',
      'Permanent veneers crafted in lab',
      'Veneers bonded to teeth with special cement',
      'Adjustments made for perfect fit'
    ],
    preparation: [
      'Dental health check and cleaning',
      'Treatment of any cavities or gum disease',
      'Discussion of desired shade and shape',
      'No special preparation needed'
    ],
    aftercare: [
      'Avoid hard foods for 24-48 hours',
      'No biting nails or hard objects',
      'Wear night guard if you grind teeth',
      'Regular brushing and flossing',
      'Avoid staining foods/drinks initially',
      'Regular dental checkups'
    ],
    risks: [
      'Tooth sensitivity',
      'Veneer chipping or cracking',
      'Color mismatch over time',
      'Irreversible enamel removal',
      'Gum inflammation',
      'Veneer falling off'
    ],
    benefits: [
      'Dramatic smile improvement',
      'Natural tooth appearance',
      'Stain resistant',
      'Long-lasting (10-15 years)',
      'Minimal tooth reduction',
      'Instant transformation'
    ],
    idealCandidates: [
      'Healthy teeth and gums',
      'Those with discolored teeth',
      'Chipped or worn teeth',
      'Minor alignment issues',
      'Good oral hygiene habits'
    ],
    notRecommendedFor: [
      'Severe teeth grinding without treatment',
      'Extensive tooth decay',
      'Insufficient enamel',
      'Those who don\'t maintain oral hygiene'
    ],
    resultsTimeline: 'Immediate results, veneers last 10-15 years with proper care',
    maintenanceRequired: 'Regular dental checkups, possible replacement after 10-15 years',
    anesthesia: 'Local anesthesia',
    hospitalStay: 'None - dental clinic procedure'
  }
};

// Map procedure names to database IDs
const getProcedureId = (name: string): string => {
  const nameMap: Record<string, string> = {
    'lip fillers': 'lip-fillers',
    'lip filler': 'lip-fillers',
    'botox': 'botox',
    'botox treatment': 'botox',
    'fue hair transplant': 'hair-transplant',
    'dhi hair transplant': 'hair-transplant',
    'hair transplant': 'hair-transplant',
    'rhinoplasty': 'rhinoplasty',
    'rhinoplasty (korean)': 'rhinoplasty',
    'breast augmentation': 'breast-augmentation',
    'liposuction': 'liposuction',
    'full body liposuction': 'liposuction',
    'brazilian butt lift': 'bbl',
    'brazilian butt lift (bbl)': 'bbl',
    'bbl': 'bbl',
    'porcelain veneers': 'dental-veneers',
    'dental veneers': 'dental-veneers',
    'veneers': 'dental-veneers'
  };
  return nameMap[name.toLowerCase()] || 'lip-fillers';
};

export default function ProcedureDetailPage() {
  const { id, clinicId } = useParams();
  const { convertPrice, selectedCurrency } = useCurrency();
  const { t } = useLanguage();
  const [expandedSection, setExpandedSection] = useState<string | null>('howItWorks');

  const procedureId = id ? getProcedureId(decodeURIComponent(id)) : 'lip-fillers';
  const procedure = procedureDatabase[procedureId] || procedureDatabase['lip-fillers'];

  const formatPrice = (amount: number) => {
    const converted = convertPrice(amount, 'GBP');
    return `${selectedCurrency.symbol}${Math.round(converted).toLocaleString()}`;
  };

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  const Section = ({ 
    id, 
    title, 
    items, 
    icon: Icon,
    variant = 'default'
  }: { 
    id: string; 
    title: string; 
    items: string[]; 
    icon: React.ElementType;
    variant?: 'default' | 'warning' | 'success';
  }) => {
    const isExpanded = expandedSection === id;
    const variantStyles = {
      default: 'bg-white',
      warning: 'bg-amber-50 border-amber-200',
      success: 'bg-green-50 border-green-200'
    };
    const iconStyles = {
      default: 'text-primary',
      warning: 'text-amber-600',
      success: 'text-green-600'
    };

    return (
      <div className={`rounded-xl border ${variantStyles[variant]} overflow-hidden mb-3`}>
        <button
          onClick={() => toggleSection(id)}
          className="w-full flex items-center justify-between p-4"
        >
          <div className="flex items-center gap-3">
            <Icon className={`w-5 h-5 ${iconStyles[variant]}`} />
            <span className="font-semibold text-gray-900">{title}</span>
          </div>
          {isExpanded ? (
            <ChevronUp className="w-5 h-5 text-gray-400" />
          ) : (
            <ChevronDown className="w-5 h-5 text-gray-400" />
          )}
        </button>
        {isExpanded && (
          <div className="px-4 pb-4">
            <ul className="space-y-2">
              {items.map((item, index) => (
                <li key={index} className="flex items-start gap-2 text-sm text-gray-700">
                  <CheckCircle className={`w-4 h-4 mt-0.5 flex-shrink-0 ${iconStyles[variant]}`} />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <div className="bg-gradient-to-br from-pink-500 via-purple-500 to-indigo-500 text-white px-4 pt-12 pb-8">
        <div className="flex items-center gap-3 mb-4">
          <Link 
            to={clinicId ? `/aesthetics/clinic/${clinicId}` : '/aesthetics'} 
            className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div className="flex-1">
            <h1 className="text-2xl font-bold">{procedure.name}</h1>
            <p className="text-white/80 text-sm capitalize">{procedure.category} {t('aesthetics.procedure') || 'Procedure'}</p>
          </div>
        </div>
      </div>

      <div className="px-4 -mt-4">
        {/* Overview Card */}
        <div className="bg-white rounded-2xl shadow-lg p-4 mb-4">
          <p className="text-gray-700 leading-relaxed">{procedure.overview}</p>
          
          {/* Quick Info Grid */}
          <div className="grid grid-cols-2 gap-3 mt-4">
            <div className="bg-gray-50 rounded-xl p-3">
              <div className="flex items-center gap-2 mb-1">
                <Clock className="w-4 h-4 text-primary" />
                <span className="text-xs text-gray-500">{t('aesthetics.duration') || 'Duration'}</span>
              </div>
              <p className="font-semibold text-gray-900">{procedure.duration}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-3">
              <div className="flex items-center gap-2 mb-1">
                <Shield className="w-4 h-4 text-primary" />
                <span className="text-xs text-gray-500">{t('aesthetics.recovery') || 'Recovery'}</span>
              </div>
              <p className="font-semibold text-gray-900">{procedure.recovery}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-3">
              <div className="flex items-center gap-2 mb-1">
                <Stethoscope className="w-4 h-4 text-primary" />
                <span className="text-xs text-gray-500">{t('aesthetics.anesthesia') || 'Anesthesia'}</span>
              </div>
              <p className="font-semibold text-gray-900 text-sm">{procedure.anesthesia}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-3">
              <div className="flex items-center gap-2 mb-1">
                <Calendar className="w-4 h-4 text-primary" />
                <span className="text-xs text-gray-500">{t('aesthetics.hospitalStay') || 'Hospital Stay'}</span>
              </div>
              <p className="font-semibold text-gray-900 text-sm">{procedure.hospitalStay}</p>
            </div>
          </div>

          {/* Price Range */}
          <div className="mt-4 p-3 bg-gradient-to-r from-primary/10 to-teal-500/10 rounded-xl">
            <p className="text-sm text-gray-600">{t('aesthetics.priceRange') || 'Price Range'}</p>
            <p className="text-xl font-bold text-primary">
              {formatPrice(procedure.priceRange.from)} - {formatPrice(procedure.priceRange.to)}
            </p>
            <p className="text-xs text-gray-500 mt-1">{t('aesthetics.priceNote') || 'Prices vary by clinic and location'}</p>
          </div>
        </div>

        {/* Results Timeline */}
        <div className="bg-gradient-to-r from-purple-500 to-indigo-500 rounded-2xl p-4 mb-4 text-white">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-5 h-5" />
            <h3 className="font-semibold">{t('aesthetics.resultsTimeline') || 'Results Timeline'}</h3>
          </div>
          <p className="text-white/90 text-sm">{procedure.resultsTimeline}</p>
        </div>

        {/* Collapsible Sections */}
        <Section 
          id="howItWorks" 
          title={t('aesthetics.howItWorks') || 'How It Works'} 
          items={procedure.howItWorks}
          icon={Stethoscope}
        />

        <Section 
          id="benefits" 
          title={t('aesthetics.benefits') || 'Benefits'} 
          items={procedure.benefits}
          icon={Star}
          variant="success"
        />

        <Section 
          id="preparation" 
          title={t('aesthetics.preparation') || 'Preparation'} 
          items={procedure.preparation}
          icon={Calendar}
        />

        <Section 
          id="aftercare" 
          title={t('aesthetics.aftercare') || 'Aftercare Instructions'} 
          items={procedure.aftercare}
          icon={Heart}
        />

        <Section 
          id="risks" 
          title={t('aesthetics.risks') || 'Risks & Side Effects'} 
          items={procedure.risks}
          icon={AlertTriangle}
          variant="warning"
        />

        <Section 
          id="idealCandidates" 
          title={t('aesthetics.idealCandidates') || 'Ideal Candidates'} 
          items={procedure.idealCandidates}
          icon={CheckCircle}
          variant="success"
        />

        <Section 
          id="notRecommended" 
          title={t('aesthetics.notRecommended') || 'Not Recommended For'} 
          items={procedure.notRecommendedFor}
          icon={AlertTriangle}
          variant="warning"
        />

        {/* Maintenance */}
        <div className="bg-white rounded-xl border p-4 mb-4">
          <h3 className="font-semibold text-gray-900 mb-2">{t('aesthetics.maintenance') || 'Maintenance Required'}</h3>
          <p className="text-sm text-gray-700">{procedure.maintenanceRequired}</p>
        </div>

        {/* Book Consultation CTA */}
        <div className="bg-white rounded-xl shadow-lg p-4 sticky bottom-20">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-sm text-gray-600">{t('aesthetics.readyToStart') || 'Ready to Start?'}</p>
              <p className="text-lg font-bold text-gray-900">{t('aesthetics.bookConsultation') || 'Book a Consultation'}</p>
            </div>
            <div className="flex gap-2">
              <a href="tel:+44123456789" className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <Phone className="w-5 h-5 text-green-600" />
              </a>
              <a href="mailto:info@clinic.com" className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <Mail className="w-5 h-5 text-blue-600" />
              </a>
            </div>
          </div>
          <Link 
            to="/aesthetics"
            className="w-full bg-gradient-to-r from-pink-500 to-purple-500 text-white font-semibold py-3 rounded-xl flex items-center justify-center"
          >
            {t('aesthetics.findClinic') || 'Find a Clinic'}
          </Link>
        </div>
      </div>
    </div>
  );
}
