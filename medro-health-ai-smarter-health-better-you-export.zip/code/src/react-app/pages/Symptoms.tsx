import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Search, ChevronRight, AlertCircle, Loader2, Sparkles, Home, Stethoscope, AlertTriangle } from 'lucide-react';
import { cn } from '@/react-app/lib/utils';
import BottomNav from '@/react-app/components/BottomNav';

const symptomCategories = [
  {
    id: 'general',
    name: 'General Health',
    symptoms: ['Fever', 'Fatigue', 'Weight Loss', 'Night Sweats', 'Weakness', 'Chills', 'Loss of Appetite']
  },
  {
    id: 'respiratory',
    name: 'Respiratory',
    symptoms: ['Cough', 'Shortness of Breath', 'Chest Pain', 'Wheezing', 'Sore Throat', 'Runny Nose', 'Congestion']
  },
  {
    id: 'digestive',
    name: 'Digestive',
    symptoms: ['Nausea', 'Vomiting', 'Diarrhea', 'Constipation', 'Abdominal Pain', 'Bloating', 'Heartburn', 'Loss of Appetite']
  },
  {
    id: 'head',
    name: 'Head & Neurological',
    symptoms: ['Headache', 'Dizziness', 'Migraine', 'Vision Problems', 'Confusion', 'Memory Issues', 'Numbness']
  },
  {
    id: 'skin',
    name: 'Skin & Allergy',
    symptoms: ['Rash', 'Itching', 'Hives', 'Acne', 'Hair Loss', 'Swelling', 'Dry Skin', 'Bruising']
  },
  {
    id: 'musculoskeletal',
    name: 'Muscles & Joints',
    symptoms: ['Back Pain', 'Joint Pain', 'Muscle Aches', 'Stiffness', 'Cramps', 'Neck Pain', 'Swelling']
  },
  {
    id: 'mental',
    name: 'Mental Health',
    symptoms: ['Anxiety', 'Depression', 'Stress', 'Insomnia', 'Mood Changes', 'Irritability', 'Panic Attacks']
  },
  {
    id: 'cardiovascular',
    name: 'Heart & Circulation',
    symptoms: ['Chest Pain', 'Palpitations', 'Rapid Heartbeat', 'Swollen Legs', 'Cold Hands/Feet', 'Shortness of Breath']
  },
];

interface SymptomAnalysis {
  severity: 'low' | 'moderate' | 'high';
  possibleConditions: string[];
  explanation: string;
  recommendations: string[];
  warningSign: string[];
  seeDoctor: boolean;
  urgency: string;
  homeRemedies: string[];
}

export default function SymptomsPage() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<SymptomAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [expandedCategory, setExpandedCategory] = useState<string | null>('general');

  const toggleSymptom = (symptom: string) => {
    setSelectedSymptoms(prev =>
      prev.includes(symptom)
        ? prev.filter(s => s !== symptom)
        : [...prev, symptom]
    );
    setAnalysis(null);
    setError(null);
  };

  const analyzeSymptoms = async () => {
    if (selectedSymptoms.length === 0) return;

    setIsAnalyzing(true);
    setError(null);

    try {
      const response = await fetch('/api/symptom-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symptoms: selectedSymptoms }),
      });

      if (!response.ok) {
        throw new Error('Failed to analyze symptoms');
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }
      setAnalysis(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const filteredCategories = searchQuery
    ? symptomCategories.map(cat => ({
        ...cat,
        symptoms: cat.symptoms.filter(s => 
          s.toLowerCase().includes(searchQuery.toLowerCase())
        )
      })).filter(cat => cat.symptoms.length > 0)
    : symptomCategories;

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="sticky top-0 bg-gradient-to-r from-purple-500 to-purple-600 px-4 py-4 z-40">
        <div className="flex items-center gap-3 max-w-lg mx-auto">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 rounded-full hover:bg-white/20 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div>
            <h1 className="text-lg font-bold text-white">Check Symptoms</h1>
            <div className="flex items-center gap-1.5 text-sm text-white/80">
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI-powered analysis</span>
            </div>
          </div>
        </div>
      </header>

      <main className="px-4 py-6 max-w-lg mx-auto space-y-6">
        {/* Disclaimer */}
        <div className="bg-amber-50 rounded-2xl p-4 border border-amber-100 flex gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm text-amber-800 font-medium">For Information Only</p>
            <p className="text-xs text-amber-700 mt-1">
              This AI-powered tool provides general information, not medical diagnosis. Always consult a healthcare professional for proper evaluation.
            </p>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search symptoms..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-xl text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>

        {/* Selected Symptoms */}
        {selectedSymptoms.length > 0 && (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <p className="text-sm font-medium text-gray-700 mb-3">
              Selected Symptoms ({selectedSymptoms.length})
            </p>
            <div className="flex flex-wrap gap-2">
              {selectedSymptoms.map(symptom => (
                <button
                  key={symptom}
                  onClick={() => toggleSymptom(symptom)}
                  className="px-3 py-1.5 bg-purple-100 text-purple-700 rounded-full text-sm font-medium flex items-center gap-1"
                >
                  {symptom}
                  <span className="ml-1 text-purple-500">×</span>
                </button>
              ))}
            </div>
            <button
              onClick={analyzeSymptoms}
              disabled={isAnalyzing}
              className="w-full mt-4 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  AI Analyzing...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  Analyze with AI
                </>
              )}
            </button>
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="bg-red-50 rounded-2xl border border-red-200 p-4">
            <p className="text-sm text-red-700">{error}</p>
            <button
              onClick={analyzeSymptoms}
              className="mt-2 text-sm text-red-600 font-medium underline"
            >
              Try again
            </button>
          </div>
        )}

        {/* Analysis Results */}
        {analysis && (
          <div className={cn(
            'rounded-2xl border shadow-sm p-5',
            analysis.severity === 'high' ? 'bg-red-50 border-red-200' :
            analysis.severity === 'moderate' ? 'bg-amber-50 border-amber-200' :
            'bg-green-50 border-green-200'
          )}>
            {/* Severity Badge */}
            <div className="flex items-center gap-2 mb-4">
              <div className={cn(
                'px-3 py-1 rounded-full text-sm font-semibold flex items-center gap-1.5',
                analysis.severity === 'high' ? 'bg-red-200 text-red-800' :
                analysis.severity === 'moderate' ? 'bg-amber-200 text-amber-800' :
                'bg-green-200 text-green-800'
              )}>
                <Sparkles className="w-3.5 h-3.5" />
                AI Analysis: {analysis.severity === 'high' ? 'High Priority' :
                 analysis.severity === 'moderate' ? 'Moderate' : 'Low Priority'}
              </div>
            </div>

            {/* Explanation */}
            <p className="text-sm text-gray-700 mb-4">{analysis.explanation}</p>

            {/* Possible Conditions */}
            <h3 className="font-semibold text-gray-900 mb-2">Possible Conditions</h3>
            <ul className="mb-4 space-y-1">
              {analysis.possibleConditions.map(condition => (
                <li key={condition} className="text-sm text-gray-700">• {condition}</li>
              ))}
            </ul>

            {/* Recommendations */}
            <h3 className="font-semibold text-gray-900 mb-2">Recommendations</h3>
            <ul className="mb-4 space-y-1">
              {analysis.recommendations.map((rec, idx) => (
                <li key={idx} className="text-sm text-gray-700">• {rec}</li>
              ))}
            </ul>

            {/* Home Remedies */}
            {analysis.homeRemedies && analysis.homeRemedies.length > 0 && (
              <>
                <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                  <Home className="w-4 h-4" />
                  Home Care
                </h3>
                <ul className="mb-4 space-y-1">
                  {analysis.homeRemedies.map((remedy, idx) => (
                    <li key={idx} className="text-sm text-gray-700">• {remedy}</li>
                  ))}
                </ul>
              </>
            )}

            {/* Warning Signs */}
            {analysis.warningSign && analysis.warningSign.length > 0 && (
              <div className="bg-white/50 rounded-xl p-3 mb-4">
                <h3 className="font-semibold text-red-700 mb-2 flex items-center gap-2 text-sm">
                  <AlertTriangle className="w-4 h-4" />
                  Seek Immediate Care If:
                </h3>
                <ul className="space-y-1">
                  {analysis.warningSign.map((sign, idx) => (
                    <li key={idx} className="text-sm text-red-700">• {sign}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Urgency */}
            {analysis.urgency && (
              <p className="text-sm text-gray-600 mb-4 italic">{analysis.urgency}</p>
            )}

            {/* Doctor Button */}
            {analysis.seeDoctor && (
              <button
                onClick={() => navigate('/doctors')}
                className="w-full py-3 bg-red-600 text-white rounded-xl font-semibold hover:bg-red-700 transition-colors flex items-center justify-center gap-2"
              >
                <Stethoscope className="w-5 h-5" />
                Find a Doctor in Medro
              </button>
            )}
          </div>
        )}

        {/* Symptom Categories */}
        <div className="space-y-3">
          {filteredCategories.map(category => (
            <div key={category.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              <button
                onClick={() => setExpandedCategory(expandedCategory === category.id ? null : category.id)}
                className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors"
              >
                <span className="font-semibold text-gray-900">{category.name}</span>
                <ChevronRight className={cn(
                  'w-5 h-5 text-gray-400 transition-transform',
                  expandedCategory === category.id && 'rotate-90'
                )} />
              </button>
              
              {expandedCategory === category.id && (
                <div className="px-4 pb-4">
                  <div className="flex flex-wrap gap-2">
                    {category.symptoms.map(symptom => (
                      <button
                        key={symptom}
                        onClick={() => toggleSymptom(symptom)}
                        className={cn(
                          'px-3 py-2 rounded-xl text-sm font-medium transition-colors',
                          selectedSymptoms.includes(symptom)
                            ? 'bg-purple-600 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        )}
                      >
                        {symptom}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
