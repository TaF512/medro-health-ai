// VAT rates by country
export const vatRates: Record<string, number> = {
  BD: 0.15, // 15% VAT Bangladesh
  GB: 0.20, // 20% VAT UK
  US: 0.08, // ~8% sales tax average US
  IN: 0.18, // 18% GST India
  AE: 0.05, // 5% VAT UAE
  CA: 0.13, // 13% HST Canada
  AU: 0.10, // 10% GST Australia
  DE: 0.19, // 19% VAT Germany
  FR: 0.20, // 20% VAT France
  SA: 0.15, // 15% VAT Saudi Arabia
};

export const SERVICE_FEE_RATE = 0.05; // 5% Medro service fee

export interface PriceBreakdown {
  basePrice: number;
  serviceFee: number;
  vat: number;
  totalPrice: number;
  currency: string;
  vatRate: number;
}

/**
 * Calculate the full patient-facing price including service fee and VAT.
 * The provider (doctor/lab) receives the basePrice.
 * Patient pays: basePrice + serviceFee + VAT
 */
export function calculatePatientPrice(
  basePrice: number,
  country: string,
  currency: string
): PriceBreakdown {
  const vatRate = vatRates[country] || 0.20;
  
  // 5% service fee on base price
  const serviceFee = Math.round(basePrice * SERVICE_FEE_RATE);
  
  // VAT is calculated on (basePrice + serviceFee)
  const vatBase = basePrice + serviceFee;
  const vat = Math.round(vatBase * vatRate);
  
  // Total patient pays
  const totalPrice = basePrice + serviceFee + vat;
  
  return {
    basePrice,
    serviceFee,
    vat,
    totalPrice,
    currency,
    vatRate,
  };
}

/**
 * Format price with currency symbol
 */
export function formatPrice(amount: number, currencyOrSymbol: string): string {
  const symbols: Record<string, string> = {
    'BDT': '৳',
    'GBP': '£',
    'USD': '$',
    'INR': '₹',
    'AED': 'د.إ',
    'EUR': '€',
    'CAD': 'C$',
    'AUD': 'A$',
    'SAR': 'SAR ',
  };
  
  const symbol = symbols[currencyOrSymbol] || currencyOrSymbol;
  return `${symbol}${amount.toLocaleString()}`;
}

/**
 * Get VAT label for country
 */
export function getVatLabel(country: string): string {
  const labels: Record<string, string> = {
    GB: 'VAT',
    US: 'Sales Tax',
    IN: 'GST',
    AU: 'GST',
    CA: 'HST',
    AE: 'VAT',
    BD: 'VAT',
    DE: 'MwSt',
    FR: 'TVA',
    SA: 'VAT',
  };
  return labels[country] || 'VAT';
}
