import { useState } from 'react';
import { Globe, ChevronDown, Check, X } from 'lucide-react';
import { useCurrency, currencies, Currency } from '@/react-app/contexts/CurrencyContext';
import { useLanguage, languages, Language } from '@/react-app/contexts/LanguageContext';

export default function LocaleSelector() {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'currency' | 'language'>('currency');
  const { selectedCurrency, setSelectedCurrency } = useCurrency();
  const { selectedLanguage, setSelectedLanguage, t } = useLanguage();

  const handleCurrencySelect = (currency: Currency) => {
    setSelectedCurrency(currency);
  };

  const handleLanguageSelect = (language: Language) => {
    setSelectedLanguage(language);
  };

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-24 right-4 z-40 flex items-center gap-1.5 bg-white border border-gray-200 rounded-full px-3 py-2 shadow-lg hover:shadow-xl transition-all"
      >
        <span className="text-lg">{selectedCurrency.flag}</span>
        <span className="text-xs font-medium text-gray-700">
          {selectedCurrency.code} ({selectedCurrency.symbol})
        </span>
        <span className="text-xs text-gray-400">|</span>
        <span className="text-xs font-medium text-gray-700">{selectedLanguage.nativeName}</span>
        <ChevronDown className="w-3 h-3 text-gray-400" />
      </button>

      {/* Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
          <div 
            className="absolute inset-0 bg-black/50"
            onClick={() => setIsOpen(false)}
          />
          
          <div className="relative bg-white w-full max-w-md rounded-t-2xl sm:rounded-2xl max-h-[80vh] flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b">
              <div className="flex items-center gap-2">
                <Globe className="w-5 h-5 text-primary" />
                <h3 className="font-semibold text-gray-900">{t('settings.language')} & {t('settings.currency')}</h3>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="p-1 hover:bg-gray-100 rounded-full"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            {/* Tabs */}
            <div className="flex border-b">
              <button
                onClick={() => setActiveTab('currency')}
                className={`flex-1 py-3 text-sm font-medium transition-colors ${
                  activeTab === 'currency'
                    ? 'text-primary border-b-2 border-primary'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {t('settings.currency')}
              </button>
              <button
                onClick={() => setActiveTab('language')}
                className={`flex-1 py-3 text-sm font-medium transition-colors ${
                  activeTab === 'language'
                    ? 'text-primary border-b-2 border-primary'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {t('settings.language')}
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-2">
              {activeTab === 'currency' ? (
                <div className="grid grid-cols-2 gap-2">
                  {currencies.map((currency) => (
                    <button
                      key={currency.code}
                      onClick={() => handleCurrencySelect(currency)}
                      className={`flex items-center gap-3 p-3 rounded-xl transition-all ${
                        selectedCurrency.code === currency.code
                          ? 'bg-primary/10 border-2 border-primary'
                          : 'bg-gray-50 border-2 border-transparent hover:bg-gray-100'
                      }`}
                    >
                      <span className="text-2xl">{currency.flag}</span>
                      <div className="flex-1 text-left">
                        <p className="font-medium text-gray-900 text-sm">{currency.code}</p>
                        <p className="text-xs text-gray-500">{currency.symbol}</p>
                      </div>
                      {selectedCurrency.code === currency.code && (
                        <Check className="w-4 h-4 text-primary" />
                      )}
                    </button>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2">
                  {languages.map((language) => (
                    <button
                      key={language.code}
                      onClick={() => handleLanguageSelect(language)}
                      className={`flex items-center gap-3 p-3 rounded-xl transition-all ${
                        selectedLanguage.code === language.code
                          ? 'bg-primary/10 border-2 border-primary'
                          : 'bg-gray-50 border-2 border-transparent hover:bg-gray-100'
                      }`}
                    >
                      <span className="text-2xl">{language.flag}</span>
                      <div className="flex-1 text-left">
                        <p className="font-medium text-gray-900 text-sm">{language.nativeName}</p>
                        <p className="text-xs text-gray-500">{language.name}</p>
                      </div>
                      {selectedLanguage.code === language.code && (
                        <Check className="w-4 h-4 text-primary" />
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-4 border-t bg-gray-50 rounded-b-2xl">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500">Selected:</span>
                <span className="font-medium text-gray-900">
                  {selectedCurrency.flag} {selectedCurrency.code} ({selectedCurrency.symbol}) • {selectedLanguage.nativeName}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
