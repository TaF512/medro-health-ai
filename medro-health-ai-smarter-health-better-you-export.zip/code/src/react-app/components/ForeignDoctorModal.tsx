import { X, AlertTriangle, CheckCircle, XCircle, Info } from 'lucide-react';
import { Doctor } from '@/react-app/data/doctors';
import { useNavigate } from 'react-router';

interface ForeignDoctorModalProps {
  doctor: Doctor;
  patientCountry: string;
  onClose: () => void;
}

export default function ForeignDoctorModal({ doctor, patientCountry, onClose }: ForeignDoctorModalProps) {
  const navigate = useNavigate();
  
  const getCountryName = (code: string) => {
    const countries: Record<string, string> = {
      'GB': 'United Kingdom',
      'US': 'United States',
      'BD': 'Bangladesh',
      'IN': 'India',
      'AE': 'UAE',
      'CA': 'Canada',
      'AU': 'Australia',
      'ES': 'Spain',
      'PK': 'Pakistan',
      'DE': 'Germany',
      'FR': 'France',
    };
    return countries[code] || code;
  };

  const handleProceed = () => {
    onClose();
    navigate(`/book/${doctor.id}?guidance_only=true`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
      <div className="bg-white rounded-2xl max-w-md w-full max-h-[90vh] overflow-y-auto shadow-xl">
        {/* Header */}
        <div className="p-4 border-b border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-2 text-amber-600">
            <AlertTriangle className="w-5 h-5" />
            <h2 className="font-semibold">Foreign Doctor Notice</h2>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          {/* Doctor Info */}
          <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
            <img 
              src={doctor.image} 
              alt={doctor.name}
              className="w-14 h-14 rounded-xl object-cover"
            />
            <div>
              <h3 className="font-semibold text-gray-900">{doctor.name}</h3>
              <p className="text-sm text-primary">{doctor.specialty}</p>
              <p className="text-xs text-gray-500 flex items-center gap-1">
                {doctor.countryFlag} Licensed in: {doctor.licensedCountries.map(c => getCountryName(c)).join(', ') || 'Guidance only'}
              </p>
            </div>
          </div>

          {/* Notice Box */}
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl">
            <div className="flex items-start gap-2">
              <Info className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm text-amber-800 font-medium">
                  This doctor is not licensed to practice in {getCountryName(patientCountry)}.
                </p>
                <p className="text-sm text-amber-700 mt-1">
                  Due to medical regulations, they can only provide limited services to patients in your country.
                </p>
              </div>
            </div>
          </div>

          {/* What they CAN do */}
          <div className="space-y-2">
            <h4 className="font-medium text-gray-900 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-500" />
              What they CAN do for you:
            </h4>
            <ul className="space-y-1.5 ml-6">
              <li className="text-sm text-gray-600 flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                Provide second opinions on existing diagnoses
              </li>
              <li className="text-sm text-gray-600 flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                Offer general health guidance and advice
              </li>
              <li className="text-sm text-gray-600 flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                Answer health-related questions
              </li>
              <li className="text-sm text-gray-600 flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                Review your medical records and test results
              </li>
              <li className="text-sm text-gray-600 flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                Suggest lifestyle and wellness improvements
              </li>
            </ul>
          </div>

          {/* What they CANNOT do */}
          <div className="space-y-2">
            <h4 className="font-medium text-gray-900 flex items-center gap-2">
              <XCircle className="w-4 h-4 text-red-500" />
              What they CANNOT do:
            </h4>
            <ul className="space-y-1.5 ml-6">
              <li className="text-sm text-gray-600 flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                Issue prescriptions valid in {getCountryName(patientCountry)}
              </li>
              <li className="text-sm text-gray-600 flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                Provide official medical diagnosis
              </li>
              <li className="text-sm text-gray-600 flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                Issue sick notes or medical certificates
              </li>
              <li className="text-sm text-gray-600 flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                Refer you to local specialists
              </li>
            </ul>
          </div>

          {/* Disclaimer */}
          <p className="text-xs text-gray-500 italic">
            For prescriptions, official diagnoses, or medical certificates, please consult a doctor licensed in your country.
          </p>
        </div>

        {/* Actions */}
        <div className="p-4 border-t border-gray-100 flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 px-4 border border-gray-200 text-gray-700 rounded-xl font-medium hover:bg-gray-50 transition-colors"
          >
            Find Licensed Doctor
          </button>
          <button
            onClick={handleProceed}
            className="flex-1 py-2.5 px-4 bg-amber-500 text-white rounded-xl font-medium hover:bg-amber-600 transition-colors"
          >
            Proceed Anyway
          </button>
        </div>
      </div>
    </div>
  );
}
