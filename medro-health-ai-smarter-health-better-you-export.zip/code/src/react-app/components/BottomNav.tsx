import { NavLink, useLocation } from 'react-router';
import { Home, MessageCircle, Stethoscope, FlaskConical, LayoutGrid } from 'lucide-react';
import { cn } from '@/react-app/lib/utils';

const navItems = [
  { path: '/', icon: Home, label: 'Home' },
  { path: '/chat', icon: MessageCircle, label: 'AI Chat' },
  { path: '/tests', icon: FlaskConical, label: 'Tests' },
  { path: '/doctors', icon: Stethoscope, label: 'Doctors' },
  { path: '/more', icon: LayoutGrid, label: 'More' },
];

// Paths that should highlight their respective tabs
const morePaths = ['/more', '/medications', '/blood-donors', '/records', '/symptoms', '/tracker', '/food'];
const testsPaths = ['/tests', '/labs'];

export default function BottomNav() {
  const location = useLocation();
  
  const isMoreActive = morePaths.some(path => location.pathname.startsWith(path));
  const isTestsActive = testsPaths.some(path => location.pathname.startsWith(path));

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-2 py-2 z-50">
      <div className="flex justify-around items-center max-w-lg mx-auto">
        {navItems.map((item) => {
          const isActive = item.path === '/more' 
            ? isMoreActive 
            : item.path === '/tests'
            ? isTestsActive
            : location.pathname === item.path;
          
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={cn(
                'flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-all duration-200',
                isActive
                  ? 'text-primary bg-primary/10'
                  : 'text-gray-500 hover:text-gray-700'
              )}
            >
              <item.icon
                className={cn(
                  'w-5 h-5 transition-transform',
                  isActive && 'scale-110'
                )}
                strokeWidth={isActive ? 2.5 : 2}
              />
              <span className={cn(
                'text-[10px] font-medium',
                isActive && 'font-semibold'
              )}>
                {item.label}
              </span>
            </NavLink>
          );
        })}
      </div>
    </nav>
  );
}
