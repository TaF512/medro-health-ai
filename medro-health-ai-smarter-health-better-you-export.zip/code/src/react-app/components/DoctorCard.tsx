import { useState } from 'react';
import { Star, Video, Shield, Clock, Globe, AlertCircle, Info, MessageCircle, Phone, Languages, CheckCircle, ChevronDown } from 'lucide-react';
import { useNavigate } from 'react-router';
import { Doctor } from '@/react-app/data/doctors';
import { cn } from '@/react-app/lib/utils';
import { calculatePatientPrice, getVatLabel } from '@/react-app/lib/pricing';
import { useCurrency } from '@/react-app/contexts/CurrencyContext';

type ConsultType = 'video' | 'voice' | 'chat';

// Generate mock availability slots for each day
const generateTimeSlots = (day: string) => {
  const baseSlots = ['9:00 AM', '10:00 AM', '11:00 AM', '2:00 PM', '3:00 PM', '4:00 PM', '5:00 PM'];
  // Vary availability by day
  const dayIndex = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].indexOf(day);
  return baseSlots.filter((_, i) => (i + dayIndex) % 3 !== 0);
};

interface DoctorCardProps {
  doctor: Doctor;
  compact?: boolean;
  patientCountry?: string;
  onForeignDoctorClick?: (doctor: Doctor) => void;
}

export default function DoctorCard({ doctor, compact = false, patientCountry, onForeignDoctorClick }: DoctorCardProps) {
  const navigate = useNavigate();
  const [showPriceBreakdown, setShowPriceBreakdown] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [selectedConsultType, setSelectedConsultType] = useState<ConsultType | null>(null);
  const [selectedDay, setSelectedDay] = useState<string>('Tue');
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  
  const { selectedCurrency, convertPrice } = useCurrency();
  const isLicensedForPatient = patientCountry && doctor.licensedCountries.includes(patientCountry);
  const isForeignDoctor = patientCountry && !isLicensedForPatient;
  
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const timeSlots = generateTimeSlots(selectedDay);

  // Calculate patient-facing price with fees (in original currency)
  const priceBreakdown = calculatePatientPrice(doctor.price, doctor.country, doctor.currency);
  
  // Convert to user's selected currency
  const convertedTotal = convertPrice(priceBreakdown.totalPrice, doctor.currency);
  const convertedBase = convertPrice(priceBreakdown.basePrice, doctor.currency);
  const convertedService = convertPrice(priceBreakdown.serviceFee, doctor.currency);
  const convertedVat = convertPrice(priceBreakdown.vat, doctor.currency);
  const convertedOriginal = doctor.originalPrice ? convertPrice(doctor.originalPrice, doctor.currency) : null;

  const handleConsultTypeClick = (e: React.MouseEvent, type: ConsultType) => {
    e.preventDefault();
    e.stopPropagation();
    setSelectedConsultType(type);
    if (!expanded) setExpanded(true);
  };

  const handleBookConsultation = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    // Check if foreign doctor - show modal instead
    if (isForeignDoctor && onForeignDoctorClick) {
      onForeignDoctorClick(doctor);
      return;
    }
    
    // Navigate to booking with pre-selected options
    const params = new URLSearchParams();
    if (selectedConsultType) params.set('type', selectedConsultType);
    if (selectedDay) params.set('day', selectedDay);
    if (selectedTime) params.set('time', selectedTime);
    navigate(`/book/${doctor.id}?${params.toString()}`);
  };

  return (
    <div
      className={cn(
        'bg-white rounded-2xl border shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden',
        compact ? 'p-3' : 'p-4',
        isForeignDoctor ? 'border-amber-200 bg-amber-50/30' : 'border-gray-100 hover:border-gray-200'
      )}
    >
      <div className="flex gap-3">
        <div className="relative flex-shrink-0">
          <img
            src={doctor.image}
            alt={doctor.name}
            className={cn(
              'rounded-xl object-cover',
              compact ? 'w-16 h-16' : 'w-20 h-20'
            )}
          />
          {doctor.isOnline && (
            <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full" />
          )}
          {/* Country Flag Badge */}
          <span className="absolute -top-1 -left-1 text-lg bg-white rounded-full w-6 h-6 flex items-center justify-center shadow-sm border border-gray-100">
            {doctor.countryFlag}
          </span>
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <h3 className={cn(
                  'font-semibold text-gray-900 truncate',
                  compact ? 'text-sm' : 'text-base'
                )}>
                  {doctor.name}
                </h3>
                {doctor.isVerified && (
                  <Shield className="w-4 h-4 text-blue-500 flex-shrink-0" />
                )}
              </div>
              <p className="text-sm text-primary font-medium truncate">
                {doctor.specialty}
              </p>
              {/* Country Info & Multi-Country Licensing */}
              <div className="flex items-center gap-1 mt-0.5 flex-wrap">
                <Globe className="w-3 h-3 text-gray-400" />
                <span className="text-xs text-gray-500">
                  {doctor.countryFlag} Based in {doctor.country === 'GB' ? 'UK' : doctor.country}
                </span>
                {doctor.licensedCountries.length > 1 && (
                  <span className="ml-1 px-1.5 py-0.5 text-xs bg-blue-100 text-blue-700 rounded-full font-medium">
                    +{doctor.licensedCountries.length - 1} more
                  </span>
                )}
              </div>
              {/* Show all licensed countries if more than 1 */}
              {doctor.licensedCountries.length > 1 && (
                <div className="flex items-center gap-1 mt-1">
                  <span className="text-xs text-gray-400">Licensed in:</span>
                  <div className="flex gap-0.5">
                    {doctor.licensedCountries.map((code) => {
                      const flags: Record<string, string> = { BD: '🇧🇩', GB: '🇬🇧', US: '🇺🇸', IN: '🇮🇳', AE: '🇦🇪', CA: '🇨🇦', AU: '🇦🇺', NZ: '🇳🇿', IE: '🇮🇪', SA: '🇸🇦' };
                      return <span key={code} className="text-sm" title={code}>{flags[code] || code}</span>;
                    })}
                  </div>
                </div>
              )}
              {/* Languages */}
              <div className="flex items-center gap-1 mt-1">
                <Languages className="w-3 h-3 text-gray-400" />
                <span className="text-xs text-gray-500">
                  {doctor.languages.slice(0, 3).join(', ')}
                  {doctor.languages.length > 3 && ` +${doctor.languages.length - 3}`}
                </span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2 mt-1.5 flex-wrap">
            <div className="flex items-center gap-1">
              <Star className="w-3.5 h-3.5 text-yellow-500 fill-yellow-500" />
              <span className="text-sm font-medium text-gray-700">{doctor.rating}</span>
            </div>
            <span className="text-gray-300">•</span>
            <span className="text-sm text-gray-500">{doctor.reviews} reviews</span>
            
            {/* Scope Badge */}
            {doctor.scope === 'guidance_only' ? (
              <span className="px-1.5 py-0.5 text-xs font-medium bg-purple-100 text-purple-700 rounded">
                Guidance Only
              </span>
            ) : isLicensedForPatient ? (
              <span className="px-1.5 py-0.5 text-xs font-medium bg-green-100 text-green-700 rounded">
                Licensed
              </span>
            ) : isForeignDoctor ? (
              <span className="px-1.5 py-0.5 text-xs font-medium bg-amber-100 text-amber-700 rounded flex items-center gap-0.5">
                <AlertCircle className="w-3 h-3" />
                Foreign
              </span>
            ) : null}
          </div>

          <div className="flex items-center justify-between mt-2">
            <div className="relative">
              <div 
                className="flex items-center gap-1 cursor-help"
                onMouseEnter={() => setShowPriceBreakdown(true)}
                onMouseLeave={() => setShowPriceBreakdown(false)}
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setShowPriceBreakdown(!showPriceBreakdown);
                }}
              >
                {/* Only show strikethrough when there's an actual discount */}
                {convertedOriginal && (
                  <span className="text-xs text-gray-400 line-through">
                    {selectedCurrency.symbol}{convertedOriginal.toLocaleString()}
                  </span>
                )}
                <span className="text-base font-bold text-gray-900">
                  {selectedCurrency.symbol}{convertedTotal.toLocaleString()}
                </span>
                <Info className="w-3.5 h-3.5 text-gray-400" />
              </div>
              
              {/* Price Breakdown Tooltip */}
              {showPriceBreakdown && (
                <div 
                  className="absolute bottom-full left-0 mb-2 bg-gray-900 text-white text-xs rounded-lg p-3 z-50 min-w-[200px] shadow-lg"
                  onClick={(e) => e.preventDefault()}
                >
                  <p className="font-medium mb-2 text-gray-300">Price Breakdown ({selectedCurrency.code})</p>
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Doctor's fee</span>
                      <span>{selectedCurrency.symbol}{convertedBase.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Service fee (5%)</span>
                      <span>{selectedCurrency.symbol}{convertedService.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">{getVatLabel(doctor.country)} ({Math.round(priceBreakdown.vatRate * 100)}%)</span>
                      <span>{selectedCurrency.symbol}{convertedVat.toLocaleString()}</span>
                    </div>
                    <div className="border-t border-gray-700 pt-1 mt-1 flex justify-between font-medium">
                      <span>You pay</span>
                      <span className="text-green-400">{selectedCurrency.symbol}{convertedTotal.toLocaleString()}</span>
                    </div>
                  </div>
                  <div className="absolute bottom-0 left-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900" />
                </div>
              )}
            </div>
            
            {/* Consultation Type Icons - Selectable */}
            <div className="flex items-center gap-1">
              {doctor.consultationType.includes('video') && (
                <button 
                  onClick={(e) => handleConsultTypeClick(e, 'video')}
                  className={cn(
                    'w-7 h-7 rounded-lg flex items-center justify-center transition-all',
                    selectedConsultType === 'video' 
                      ? 'bg-green-500' 
                      : 'bg-gray-100 hover:bg-gray-200'
                  )} 
                  title="Video Call"
                >
                  <Video className={cn('w-3.5 h-3.5', selectedConsultType === 'video' ? 'text-white' : 'text-gray-500')} />
                </button>
              )}
              {doctor.consultationType.includes('voice') && (
                <button 
                  onClick={(e) => handleConsultTypeClick(e, 'voice')}
                  className={cn(
                    'w-7 h-7 rounded-lg flex items-center justify-center transition-all',
                    selectedConsultType === 'voice' 
                      ? 'bg-green-500' 
                      : 'bg-gray-100 hover:bg-gray-200'
                  )} 
                  title="Voice Call"
                >
                  <Phone className={cn('w-3.5 h-3.5', selectedConsultType === 'voice' ? 'text-white' : 'text-gray-500')} />
                </button>
              )}
              {doctor.consultationType.includes('chat') && (
                <button 
                  onClick={(e) => handleConsultTypeClick(e, 'chat')}
                  className={cn(
                    'w-7 h-7 rounded-lg flex items-center justify-center transition-all',
                    selectedConsultType === 'chat' 
                      ? 'bg-green-500' 
                      : 'bg-gray-100 hover:bg-gray-200'
                  )} 
                  title="Chat"
                >
                  <MessageCircle className={cn('w-3.5 h-3.5', selectedConsultType === 'chat' ? 'text-white' : 'text-gray-500')} />
                </button>
              )}
              <button
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setExpanded(!expanded);
                }}
                className="w-7 h-7 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-all"
              >
                <ChevronDown className={cn('w-3.5 h-3.5 text-gray-500 transition-transform', expanded && 'rotate-180')} />
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {!compact && !expanded && (
        <div className="flex items-center gap-1.5 mt-3 text-sm text-gray-500">
          <Clock className="w-4 h-4" />
          <span>Next available: {doctor.nextAvailable}</span>
        </div>
      )}
      
      {/* Expanded Availability Section */}
      {expanded && !compact && (
        <div className="mt-4 pt-4 border-t border-gray-100 space-y-4">
          {/* Availability Days */}
          <div>
            <p className="text-sm font-medium text-gray-700 mb-2">Availability</p>
            <div className="flex gap-1.5 flex-wrap">
              {days.map((day) => (
                <button
                  key={day}
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setSelectedDay(day);
                    setSelectedTime(null);
                  }}
                  className={cn(
                    'px-3 py-1.5 rounded-lg text-xs font-medium transition-all border',
                    selectedDay === day
                      ? 'bg-gray-900 text-white border-gray-900'
                      : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300'
                  )}
                >
                  {day}
                </button>
              ))}
            </div>
          </div>
          
          {/* Time Slots */}
          <div>
            <p className="text-sm font-medium text-gray-700 mb-2">Available Times</p>
            <div className="flex gap-2 flex-wrap">
              {timeSlots.map((time) => (
                <button
                  key={time}
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setSelectedTime(time);
                  }}
                  className={cn(
                    'px-3 py-1.5 rounded-lg text-xs font-medium transition-all border',
                    selectedTime === time
                      ? 'bg-green-500 text-white border-green-500'
                      : 'bg-white text-gray-600 border-gray-200 hover:border-green-300 hover:text-green-600'
                  )}
                >
                  {time}
                </button>
              ))}
            </div>
          </div>
          
          {/* Consultation Options */}
          <div>
            <p className="text-sm font-medium text-gray-700 mb-2">Consultation Options</p>
            <div className="flex gap-2">
              {doctor.consultationType.includes('video') && (
                <button
                  onClick={(e) => handleConsultTypeClick(e, 'video')}
                  className={cn(
                    'flex-1 flex flex-col items-center gap-1.5 p-3 rounded-xl border transition-all',
                    selectedConsultType === 'video'
                      ? 'border-green-500 bg-green-50'
                      : 'border-gray-200 hover:border-gray-300'
                  )}
                >
                  <Video className={cn('w-5 h-5', selectedConsultType === 'video' ? 'text-green-600' : 'text-gray-400')} />
                  <span className={cn('text-xs font-medium', selectedConsultType === 'video' ? 'text-green-700' : 'text-gray-600')}>
                    Video Call
                  </span>
                </button>
              )}
              {doctor.consultationType.includes('voice') && (
                <button
                  onClick={(e) => handleConsultTypeClick(e, 'voice')}
                  className={cn(
                    'flex-1 flex flex-col items-center gap-1.5 p-3 rounded-xl border transition-all',
                    selectedConsultType === 'voice'
                      ? 'border-green-500 bg-green-50'
                      : 'border-gray-200 hover:border-gray-300'
                  )}
                >
                  <Phone className={cn('w-5 h-5', selectedConsultType === 'voice' ? 'text-green-600' : 'text-gray-400')} />
                  <span className={cn('text-xs font-medium', selectedConsultType === 'voice' ? 'text-green-700' : 'text-gray-600')}>
                    Voice Call
                  </span>
                </button>
              )}
              {doctor.consultationType.includes('chat') && (
                <button
                  onClick={(e) => handleConsultTypeClick(e, 'chat')}
                  className={cn(
                    'flex-1 flex flex-col items-center gap-1.5 p-3 rounded-xl border transition-all',
                    selectedConsultType === 'chat'
                      ? 'border-green-500 bg-green-50'
                      : 'border-gray-200 hover:border-gray-300'
                  )}
                >
                  <MessageCircle className={cn('w-5 h-5', selectedConsultType === 'chat' ? 'text-green-600' : 'text-gray-400')} />
                  <span className={cn('text-xs font-medium', selectedConsultType === 'chat' ? 'text-green-700' : 'text-gray-600')}>
                    Chat
                  </span>
                </button>
              )}
            </div>
          </div>
          
          {/* Consultation Fee & Book Button */}
          <div className="flex items-center justify-between pt-2">
            <div>
              <p className="text-xs text-gray-500">Consultation Fee</p>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-gray-900">
                  {selectedCurrency.symbol}{convertedTotal.toLocaleString()}
                </span>
                {selectedTime && (
                  <span className="flex items-center gap-1 text-xs text-green-600">
                    <CheckCircle className="w-3.5 h-3.5" />
                    Available
                  </span>
                )}
              </div>
            </div>
            <button
              onClick={handleBookConsultation}
              disabled={!selectedConsultType || !selectedTime}
              className={cn(
                'px-5 py-2.5 rounded-xl font-medium text-sm transition-all',
                selectedConsultType && selectedTime
                  ? 'bg-gradient-to-r from-primary to-purple-500 text-white hover:shadow-lg'
                  : 'bg-gray-100 text-gray-400 cursor-not-allowed'
              )}
            >
              Book Consultation
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
