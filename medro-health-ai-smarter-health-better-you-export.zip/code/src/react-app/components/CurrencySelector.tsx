import { useState, useRef, useEffect } from 'react';
import { Check, X } from 'lucide-react';
import { useCurrency, currencies } from '@/react-app/contexts/CurrencyContext';
import { cn } from '@/react-app/lib/utils';

interface CurrencySelectorProps {
  floating?: boolean;
}

export default function CurrencySelector({ floating = false }: CurrencySelectorProps) {
  const { selectedCurrency, setSelectedCurrency } = useCurrency();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  if (floating) {
    return (
      <>
        {/* Floating Button */}
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-24 right-4 z-40 w-12 h-12 bg-white rounded-full shadow-lg border border-gray-200 flex items-center justify-center text-2xl hover:shadow-xl transition-shadow active:scale-95"
          aria-label="Change currency"
        >
          {selectedCurrency.flag}
        </button>

        {/* Modal Overlay */}
        {isOpen && (
          <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
            <div 
              className="absolute inset-0 bg-black/50 backdrop-blur-sm"
              onClick={() => setIsOpen(false)}
            />
            <div 
              ref={dropdownRef}
              className="relative bg-white rounded-t-3xl sm:rounded-2xl w-full max-w-sm mx-4 mb-0 sm:mb-4 overflow-hidden animate-in slide-in-from-bottom duration-200"
            >
              <div className="p-4 border-b border-gray-100 flex items-center justify-between">
                <h3 className="font-semibold text-gray-900">Select Currency</h3>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>
              <div className="max-h-[60vh] overflow-y-auto p-2">
                {currencies.map((currency) => (
                  <button
                    key={currency.code}
                    onClick={() => {
                      setSelectedCurrency(currency);
                      setIsOpen(false);
                    }}
                    className={cn(
                      'w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors',
                      selectedCurrency.code === currency.code 
                        ? 'bg-primary/10 border border-primary/30' 
                        : 'hover:bg-gray-50'
                    )}
                  >
                    <span className="text-3xl">{currency.flag}</span>
                    <div className="flex-1 text-left">
                      <p className="font-medium text-gray-900">{currency.name}</p>
                      <p className="text-sm text-gray-500">{currency.code} · {currency.symbol}</p>
                    </div>
                    {selectedCurrency.code === currency.code && (
                      <Check className="w-5 h-5 text-primary" />
                    )}
                  </button>
                ))}
              </div>
              <div className="p-4 border-t border-gray-100 bg-gray-50">
                <p className="text-xs text-gray-500 text-center">
                  Prices converted using approximate exchange rates
                </p>
              </div>
            </div>
          </div>
        )}
      </>
    );
  }

  // Non-floating inline version
  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 bg-gray-100 rounded-full hover:bg-gray-200 transition-colors"
      >
        <span className="text-xl">{selectedCurrency.flag}</span>
        <span className="font-medium text-gray-700 text-sm">{selectedCurrency.code}</span>
      </button>

      {isOpen && (
        <div className="absolute top-full right-0 mt-2 bg-white rounded-xl shadow-lg border border-gray-100 z-50 overflow-hidden min-w-[240px]">
          <div className="p-2 border-b border-gray-100 bg-gray-50">
            <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Select Currency</p>
          </div>
          <div className="max-h-[280px] overflow-y-auto">
            {currencies.map((currency) => (
              <button
                key={currency.code}
                onClick={() => {
                  setSelectedCurrency(currency);
                  setIsOpen(false);
                }}
                className={cn(
                  'w-full flex items-center gap-3 px-3 py-2 hover:bg-gray-50 transition-colors',
                  selectedCurrency.code === currency.code ? 'bg-primary/5' : ''
                )}
              >
                <span className="text-xl">{currency.flag}</span>
                <div className="flex-1 text-left">
                  <p className="font-medium text-gray-900 text-sm">{currency.name}</p>
                  <p className="text-xs text-gray-500">{currency.symbol}</p>
                </div>
                {selectedCurrency.code === currency.code && (
                  <Check className="w-4 h-4 text-primary" />
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
