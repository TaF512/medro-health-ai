import { LucideIcon } from 'lucide-react';
import { Link } from 'react-router';
import { cn } from '@/react-app/lib/utils';

interface QuickActionCardProps {
  title: string;
  subtitle?: string;
  icon: LucideIcon;
  to: string;
  color?: string;
  iconBgColor?: string;
}

export default function QuickActionCard({
  title,
  subtitle,
  icon: Icon,
  to,
  color = 'text-primary',
  iconBgColor = 'bg-primary/10'
}: QuickActionCardProps) {
  return (
    <Link
      to={to}
      className="flex items-center gap-3 p-4 bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md hover:border-gray-200 transition-all duration-200 active:scale-[0.98]"
    >
      <div className={cn('p-3 rounded-xl', iconBgColor)}>
        <Icon className={cn('w-6 h-6', color)} />
      </div>
      <div className="flex-1 min-w-0">
        <h3 className="font-semibold text-gray-900 truncate">{title}</h3>
        {subtitle && (
          <p className="text-sm text-gray-500 truncate">{subtitle}</p>
        )}
      </div>
    </Link>
  );
}
