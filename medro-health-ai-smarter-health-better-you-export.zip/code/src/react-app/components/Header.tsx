import { Bell, User, ShoppingCart } from 'lucide-react';
import { Link } from 'react-router';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { useCart } from '@/react-app/context/CartContext';

interface HeaderProps {
  title?: string;
  showGreeting?: boolean;
}

export default function Header({ title, showGreeting = false }: HeaderProps) {
  const { user, isGuest, guestRole } = useAuth();
  const { itemCount } = useCart();
  
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  const firstName = isGuest 
    ? (guestRole === 'doctor' ? 'Dr. Guest' : 'Guest') 
    : (user?.name?.split(' ')[0] || 'there');

  return (
    <header className="sticky top-0 bg-white/95 backdrop-blur-sm border-b border-gray-100 px-4 py-3 z-40">
      <div className="flex items-center justify-between max-w-lg mx-auto">
        <div className="flex items-center gap-3">
          <img 
            src="https://019c7544-ff60-755c-b21b-4cf637d4527f.mochausercontent.com/medro-logo.png" 
            alt="Medro Health AI" 
            className="h-8 object-contain"
          />
          {showGreeting ? (
            <div>
              <p className="text-sm text-gray-500">{getGreeting()}</p>
              <h1 className="text-lg font-bold text-gray-900">{firstName} 👋</h1>
            </div>
          ) : title ? (
            <h1 className="text-xl font-bold text-gray-900">{title}</h1>
          ) : null}
        </div>
        <div className="flex items-center gap-2">
          <Link
            to="/cart"
            className="relative p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
          >
            <ShoppingCart className="w-5 h-5 text-gray-700" />
            {itemCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-primary text-white text-xs font-bold rounded-full flex items-center justify-center">
                {itemCount > 9 ? '9+' : itemCount}
              </span>
            )}
          </Link>
          <Link
            to="/notifications"
            className="relative p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
          >
            <Bell className="w-5 h-5 text-gray-700" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
          </Link>
          <Link
            to="/profile"
            className="rounded-full overflow-hidden hover:ring-2 hover:ring-primary/30 transition-all"
          >
            {isGuest ? (
              <div className="w-9 h-9 bg-gray-200 flex items-center justify-center">
                <User className="w-5 h-5 text-gray-500" />
              </div>
            ) : user?.avatar ? (
              <img src={user.avatar} alt="" className="w-9 h-9 rounded-full" />
            ) : (
              <div className="w-9 h-9 bg-primary/10 flex items-center justify-center text-primary font-medium">
                {firstName.charAt(0).toUpperCase()}
              </div>
            )}
          </Link>
        </div>
      </div>
    </header>
  );
}
