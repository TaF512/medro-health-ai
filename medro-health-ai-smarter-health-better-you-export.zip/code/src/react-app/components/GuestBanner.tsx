import { useNavigate } from 'react-router';
import { LogIn, X } from 'lucide-react';
import { useState } from 'react';

interface GuestBannerProps {
  message?: string;
}

export default function GuestBanner({ message = "Sign up to save your data and unlock all features" }: GuestBannerProps) {
  const navigate = useNavigate();
  const [isDismissed, setIsDismissed] = useState(false);

  if (isDismissed) return null;

  return (
    <div className="bg-gradient-to-r from-primary to-teal-600 px-4 py-3 flex items-center justify-between gap-3">
      <div className="flex items-center gap-3 flex-1 min-w-0">
        <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0">
          <LogIn className="w-4 h-4 text-white" />
        </div>
        <p className="text-sm text-white font-medium truncate">{message}</p>
      </div>
      <div className="flex items-center gap-2 flex-shrink-0">
        <button
          onClick={() => navigate('/login')}
          className="px-3 py-1.5 bg-white text-primary text-sm font-semibold rounded-full hover:bg-white/90 transition-colors"
        >
          Sign Up
        </button>
        <button
          onClick={() => setIsDismissed(true)}
          className="p-1 hover:bg-white/20 rounded-full transition-colors"
        >
          <X className="w-4 h-4 text-white" />
        </button>
      </div>
    </div>
  );
}
