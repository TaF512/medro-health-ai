import { useState } from 'react';
import { Clock, Star, ChevronRight, Info } from 'lucide-react';
import { Link } from 'react-router';
import { LabTest, labCountries } from '@/react-app/data/tests';
import { calculatePatientPrice, getVatLabel } from '@/react-app/lib/pricing';
import { useCurrency } from '@/react-app/contexts/CurrencyContext';

interface TestCardProps {
  test: LabTest;
}

export default function TestCard({ test }: TestCardProps) {
  const [showPriceBreakdown, setShowPriceBreakdown] = useState(false);
  const { selectedCurrency, convertPrice } = useCurrency();
  const countryData = labCountries.find(c => c.code === test.country);
  
  // Calculate patient-facing price with fees (in original currency)
  const priceBreakdown = calculatePatientPrice(test.price, test.country, test.currency);
  
  // Convert to user's selected currency
  const convertedTotal = convertPrice(priceBreakdown.totalPrice, test.currency);
  const convertedBase = convertPrice(priceBreakdown.basePrice, test.currency);
  const convertedService = convertPrice(priceBreakdown.serviceFee, test.currency);
  const convertedVat = convertPrice(priceBreakdown.vat, test.currency);
  const convertedOriginal = test.originalPrice ? convertPrice(test.originalPrice, test.currency) : null;

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
      <div className="p-4">
        <div className="flex gap-3">
          <div className="w-20 h-20 rounded-xl bg-gradient-to-br from-teal-50 to-cyan-100 flex items-center justify-center flex-shrink-0 relative">
            <span className="text-3xl">🩸</span>
            {countryData && (
              <span className="absolute -bottom-1 -right-1 text-lg">{countryData.flag}</span>
            )}
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-start gap-2">
              <h3 className="font-semibold text-gray-900 leading-tight flex-1">{test.name}</h3>
            </div>
            <p className="text-sm text-primary mt-0.5">
              Includes {test.testsIncluded} Test{test.testsIncluded > 1 ? 's' : ''}
            </p>
            {/* Show what's included for packages with 2+ components */}
            {test.components && test.components.length >= 2 && (
              <div className="flex flex-wrap gap-1 mt-1">
                {test.components.slice(0, 3).map((comp, i) => (
                  <span key={i} className="text-xs px-1.5 py-0.5 bg-gray-100 text-gray-600 rounded">
                    {comp.name.length > 15 ? comp.name.substring(0, 15) + '...' : comp.name}
                  </span>
                ))}
                {test.components.length > 3 && (
                  <span className="text-xs px-1.5 py-0.5 bg-primary/10 text-primary rounded font-medium">
                    +{test.components.length - 3} more
                  </span>
                )}
              </div>
            )}
            
            <div className="flex items-center gap-1.5 mt-2">
              {test.labs.slice(0, 3).map((lab, i) => (
                <span key={i} className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center text-xs">
                  {lab.charAt(0)}
                </span>
              ))}
              {test.labs.length > 3 && (
                <span className="text-xs text-gray-500">+{test.labs.length - 3}</span>
              )}
            </div>
            
            <div className="flex items-center gap-2 mt-2 relative">
              <div 
                className="flex items-center gap-1 cursor-help"
                onMouseEnter={() => setShowPriceBreakdown(true)}
                onMouseLeave={() => setShowPriceBreakdown(false)}
                onClick={(e) => {
                  e.stopPropagation();
                  setShowPriceBreakdown(!showPriceBreakdown);
                }}
              >
                {/* Only show strikethrough when there's an actual discount */}
                {test.discount && convertedOriginal && (
                  <span className="text-sm text-gray-400 line-through">
                    {selectedCurrency.symbol}{convertedOriginal.toLocaleString()}
                  </span>
                )}
                <span className="text-lg font-bold text-gray-900">
                  {selectedCurrency.symbol}{convertedTotal.toLocaleString()}
                </span>
                <Info className="w-3.5 h-3.5 text-gray-400" />
              </div>
              {test.discount && (
                <span className="px-1.5 py-0.5 bg-red-100 text-red-600 text-xs font-medium rounded">
                  {test.discount}% OFF
                </span>
              )}
              
              {/* Price Breakdown Tooltip */}
              {showPriceBreakdown && (
                <div 
                  className="absolute bottom-full left-0 mb-2 bg-gray-900 text-white text-xs rounded-lg p-3 z-50 min-w-[200px] shadow-lg"
                  onClick={(e) => e.stopPropagation()}
                >
                  <p className="font-medium mb-2 text-gray-300">Price Breakdown ({selectedCurrency.code})</p>
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Test price</span>
                      <span>{selectedCurrency.symbol}{convertedBase.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Service fee (5%)</span>
                      <span>{selectedCurrency.symbol}{convertedService.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">{getVatLabel(test.country)} ({Math.round(priceBreakdown.vatRate * 100)}%)</span>
                      <span>{selectedCurrency.symbol}{convertedVat.toLocaleString()}</span>
                    </div>
                    <div className="border-t border-gray-700 pt-1 mt-1 flex justify-between font-medium">
                      <span>You pay</span>
                      <span className="text-green-400">{selectedCurrency.symbol}{convertedTotal.toLocaleString()}</span>
                    </div>
                  </div>
                  <div className="absolute bottom-0 left-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900" />
                </div>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-100">
          <div className="flex items-center gap-3 text-sm text-gray-500">
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              <span>Report in {test.reportTime}</span>
            </div>
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
              <span>{test.bookings.toLocaleString()}+ booked</span>
            </div>
          </div>
          
          <Link
            to={`/tests/${test.id}`}
            className="flex items-center gap-1 px-4 py-2 bg-primary text-white font-medium rounded-lg hover:bg-primary/90 transition-colors"
          >
            <span>Book Test</span>
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}
