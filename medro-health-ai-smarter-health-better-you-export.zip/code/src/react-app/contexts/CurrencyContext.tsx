import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface Currency {
  code: string;
  symbol: string;
  name: string;
  flag: string;
}

export const currencies: Currency[] = [
  { code: 'GBP', symbol: '£', name: 'British Pound', flag: '🇬🇧' },
  { code: 'USD', symbol: '$', name: 'US Dollar', flag: '🇺🇸' },
  { code: 'EUR', symbol: '€', name: 'Euro', flag: '🇪🇺' },
  { code: 'BDT', symbol: '৳', name: 'Bangladeshi Taka', flag: '🇧🇩' },
  { code: 'INR', symbol: '₹', name: 'Indian Rupee', flag: '🇮🇳' },
  { code: 'AED', symbol: 'د.إ', name: 'UAE Dirham', flag: '🇦🇪' },
  { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar', flag: '🇨🇦' },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar', flag: '🇦🇺' },
  { code: 'SAR', symbol: '﷼', name: 'Saudi Riyal', flag: '🇸🇦' },
];

// Exchange rates relative to GBP (1 GBP = X currency)
// Based on approximate real rates (June 2024)
const exchangeRatesToGBP: Record<string, number> = {
  GBP: 1,
  USD: 1.27,
  EUR: 1.17,
  BDT: 149.5,
  INR: 105.8,
  AED: 4.67,
  CAD: 1.73,
  AUD: 1.93,
  SAR: 4.77,
};

interface CurrencyContextType {
  selectedCurrency: Currency;
  setSelectedCurrency: (currency: Currency) => void;
  convertPrice: (amount: number, fromCurrency: string) => number;
  formatPrice: (amount: number, fromCurrency: string) => string;
  getCurrencySymbol: (code: string) => string;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const [selectedCurrency, setSelectedCurrencyState] = useState<Currency>(() => {
    const saved = localStorage.getItem('carely_currency');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return currencies[0]; // Default to GBP
      }
    }
    return currencies[0];
  });

  useEffect(() => {
    localStorage.setItem('carely_currency', JSON.stringify(selectedCurrency));
  }, [selectedCurrency]);

  const setSelectedCurrency = (currency: Currency) => {
    setSelectedCurrencyState(currency);
  };

  const convertPrice = (amount: number, fromCurrency: string): number => {
    if (fromCurrency === selectedCurrency.code) {
      return Math.round(amount);
    }
    
    // Convert from source currency to GBP, then to target currency
    const fromRate = exchangeRatesToGBP[fromCurrency] || 1;
    const toRate = exchangeRatesToGBP[selectedCurrency.code] || 1;
    
    const amountInGBP = amount / fromRate;
    const convertedAmount = amountInGBP * toRate;
    
    // Round appropriately based on currency
    if (['BDT', 'INR', 'SAR'].includes(selectedCurrency.code)) {
      return Math.round(convertedAmount);
    }
    return Math.round(convertedAmount * 100) / 100;
  };

  const formatPrice = (amount: number, fromCurrency: string): string => {
    const converted = convertPrice(amount, fromCurrency);
    const symbol = selectedCurrency.symbol;
    
    // Format with proper decimals
    if (['BDT', 'INR', 'SAR'].includes(selectedCurrency.code)) {
      return `${symbol}${converted.toLocaleString()}`;
    }
    return `${symbol}${converted.toFixed(2)}`;
  };

  const getCurrencySymbol = (code: string): string => {
    const currency = currencies.find(c => c.code === code);
    return currency?.symbol || code;
  };

  return (
    <CurrencyContext.Provider value={{
      selectedCurrency,
      setSelectedCurrency,
      convertPrice,
      formatPrice,
      getCurrencySymbol,
    }}>
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const context = useContext(CurrencyContext);
  if (!context) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
}
