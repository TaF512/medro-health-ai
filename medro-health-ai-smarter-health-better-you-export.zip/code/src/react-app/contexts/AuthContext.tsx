import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface User {
  id: string;
  email: string;
  name: string | null;
  avatar: string | null;
  role: 'patient' | 'doctor' | null;
  country: string | null;
}

interface AuthContextValue {
  user: User | null;
  isGuest: boolean;
  guestRole: 'patient' | 'doctor' | null;
  isPending: boolean;
  isFetching: boolean;
  fetchUser: () => Promise<void>;
  redirectToLogin: () => Promise<void>;
  exchangeCodeForSessionToken: () => Promise<void>;
  logout: () => Promise<void>;
  setRole: (role: 'patient' | 'doctor', country?: string) => Promise<void>;
  enterGuestMode: (role: 'patient' | 'doctor') => void;
  exitGuestMode: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const GUEST_MODE_KEY = 'carely_guest_mode';
const GUEST_ROLE_KEY = 'carely_guest_role';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isGuest, setIsGuest] = useState(() => {
    return localStorage.getItem(GUEST_MODE_KEY) === 'true';
  });
  const [guestRole, setGuestRole] = useState<'patient' | 'doctor' | null>(() => {
    const role = localStorage.getItem(GUEST_ROLE_KEY);
    return role === 'patient' || role === 'doctor' ? role : null;
  });
  const [isPending, setIsPending] = useState(true);
  const [isFetching, setIsFetching] = useState(false);

  const fetchUser = async () => {
    setIsFetching(true);
    try {
      const res = await fetch('/api/users/me');
      const data = await res.json();
      setUser(data.user);
    } catch (error) {
      setUser(null);
    } finally {
      setIsFetching(false);
      setIsPending(false);
    }
  };

  const redirectToLogin = async () => {
    const res = await fetch('/api/oauth/google/redirect_url');
    const data = await res.json();
    window.location.href = data.redirectUrl;
  };

  const exchangeCodeForSessionToken = async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    
    if (!code) {
      throw new Error('No authorization code found');
    }

    const res = await fetch('/api/sessions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }),
    });

    if (!res.ok) {
      throw new Error('Failed to exchange code');
    }

    await fetchUser();
  };

  const logout = async () => {
    await fetch('/api/logout');
    setUser(null);
    localStorage.removeItem(GUEST_MODE_KEY);
    setIsGuest(false);
  };

  const enterGuestMode = (role: 'patient' | 'doctor') => {
    localStorage.setItem(GUEST_MODE_KEY, 'true');
    localStorage.setItem(GUEST_ROLE_KEY, role);
    setIsGuest(true);
    setGuestRole(role);
    setIsPending(false);
  };

  const exitGuestMode = () => {
    localStorage.removeItem(GUEST_MODE_KEY);
    localStorage.removeItem(GUEST_ROLE_KEY);
    setIsGuest(false);
    setGuestRole(null);
  };

  const setRole = async (role: 'patient' | 'doctor', country?: string) => {
    const res = await fetch('/api/users/role', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role, country }),
    });

    if (!res.ok) {
      throw new Error('Failed to set role');
    }

    setUser(prev => prev ? { ...prev, role } : null);
  };

  useEffect(() => {
    fetchUser();
  }, []);

  return (
    <AuthContext.Provider value={{
      user,
      isGuest,
      guestRole,
      isPending,
      isFetching,
      fetchUser,
      redirectToLogin,
      exchangeCodeForSessionToken,
      logout,
      setRole,
      enterGuestMode,
      exitGuestMode,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
