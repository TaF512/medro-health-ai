import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router";
import { AuthProvider, useAuth } from "@/react-app/contexts/AuthContext";
import { CartProvider } from "@/react-app/context/CartContext";
import { CurrencyProvider } from "@/react-app/contexts/CurrencyContext";
import { LanguageProvider } from "@/react-app/contexts/LanguageContext";
import { Loader2 } from "lucide-react";

// Pages
import HomePage from "@/react-app/pages/Home";
import DoctorsPage from "@/react-app/pages/Doctors";
import TestsPage from "@/react-app/pages/Tests";
import TestDetailPage from "@/react-app/pages/TestDetail";
import ChatPage from "@/react-app/pages/Chat";
import TrackerPage from "@/react-app/pages/Tracker";
import ProfilePage from "@/react-app/pages/Profile";
import HealthProfilePage from "@/react-app/pages/HealthProfile";
import BloodDonorsPage from "@/react-app/pages/BloodDonors";
import LoginPage from "@/react-app/pages/Login";
import RoleSelectPage from "@/react-app/pages/RoleSelect";
import AuthCallbackPage from "@/react-app/pages/AuthCallback";
import DoctorDashboardPage from "@/react-app/pages/DoctorDashboard";
import MorePage from "@/react-app/pages/More";
import SymptomsPage from "@/react-app/pages/Symptoms";
import MedicationsPage from "@/react-app/pages/Medications";
import RecordsPage from "@/react-app/pages/Records";

import RemedySearchPage from "@/react-app/pages/RemedySearch";
import MedicationEncyclopediaPage from "@/react-app/pages/MedicationEncyclopedia";
import BookDoctorPage from "@/react-app/pages/BookDoctor";
import AppointmentsPage from "@/react-app/pages/Appointments";
import FollowUpsPage from "@/react-app/pages/FollowUps";
import UpcomingPage from "@/react-app/pages/Upcoming";
import RewardsPage from "@/react-app/pages/Rewards";
import PharmacyPage from "@/react-app/pages/Pharmacy";
import CartPage from "@/react-app/pages/Cart";
import DoctorSchedulePage from "@/react-app/pages/DoctorSchedule";
import DoctorPatientsPage from "@/react-app/pages/DoctorPatients";
import DoctorMessagesPage from "@/react-app/pages/DoctorMessages";
import DoctorAnalyticsPage from "@/react-app/pages/DoctorAnalytics";
import DoctorProfilePage from "@/react-app/pages/DoctorProfile";
import FoodPage from "@/react-app/pages/Food";
import FoodPhotoScanPage from "@/react-app/pages/FoodPhotoScan";
import FoodManualLogPage from "@/react-app/pages/FoodManualLog";
import FoodBarcodePage from "@/react-app/pages/FoodBarcode";
import FoodHistoryPage from "@/react-app/pages/FoodHistory";
import FoodFavoritesPage from "@/react-app/pages/FoodFavorites";
import FoodSettingsPage from "@/react-app/pages/FoodSettings";
import DoctorOnboardingPage from "@/react-app/pages/DoctorOnboarding";
import ForgotPasswordPage from "@/react-app/pages/ForgotPassword";
import NHSAppointmentsPage from "@/react-app/pages/NHSAppointments";
import LabDetailPage from "@/react-app/pages/LabDetail";
import AestheticsPage from "@/react-app/pages/Aesthetics";
import ProcedureDetailPage from "@/react-app/pages/ProcedureDetail";
import ClinicDoctorsPage from "@/react-app/pages/ClinicDoctors";
import BookAestheticsConsultationPage from "@/react-app/pages/BookAestheticsConsultation";

// Loading component
function LoadingScreen() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <Loader2 className="w-8 h-8 text-primary animate-spin" />
    </div>
  );
}



// Route guard for patients or guests
function RequirePatient({ children }: { children: React.ReactNode }) {
  const { user, isGuest, guestRole, isPending } = useAuth();

  if (isPending) {
    return <LoadingScreen />;
  }

  // Allow patient guests to access patient routes
  if (isGuest && guestRole === 'patient') {
    return <>{children}</>;
  }

  // Redirect doctor guests to doctor dashboard
  if (isGuest && guestRole === 'doctor') {
    return <Navigate to="/doctor/dashboard" replace />;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (!user.role) {
    return <Navigate to="/role-select" replace />;
  }

  if (user.role !== 'patient') {
    return <Navigate to="/doctor/dashboard" replace />;
  }

  return <>{children}</>;
}

// Route guard for doctors only
function RequireDoctor({ children }: { children: React.ReactNode }) {
  const { user, isGuest, guestRole, isPending } = useAuth();

  if (isPending) {
    return <LoadingScreen />;
  }

  // Allow doctor guests to access doctor routes
  if (isGuest && guestRole === 'doctor') {
    return <>{children}</>;
  }

  // Redirect patient guests to home
  if (isGuest && guestRole === 'patient') {
    return <Navigate to="/" replace />;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (!user.role) {
    return <Navigate to="/role-select" replace />;
  }

  if (user.role !== 'doctor') {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}

// Redirect logged in users away from login
function PublicRoute({ children }: { children: React.ReactNode }) {
  const { user, isGuest, isPending } = useAuth();

  if (isPending) {
    return <LoadingScreen />;
  }

  // Guests can still access login to sign up
  if (isGuest) {
    return <>{children}</>;
  }

  if (user) {
    if (!user.role) {
      return <Navigate to="/role-select" replace />;
    }
    return <Navigate to={user.role === 'patient' ? '/' : '/doctor/dashboard'} replace />;
  }

  return <>{children}</>;
}

function AppRoutes() {
  return (
    <Routes>
      {/* Public routes */}
      <Route path="/login" element={<PublicRoute><LoginPage /></PublicRoute>} />
      <Route path="/forgot-password" element={<PublicRoute><ForgotPasswordPage /></PublicRoute>} />
      <Route path="/auth/callback" element={<AuthCallbackPage />} />
      
      {/* Role selection (authenticated but no role) */}
      <Route path="/role-select" element={<RoleSelectPage />} />

      {/* Patient routes */}
      <Route path="/" element={<RequirePatient><HomePage /></RequirePatient>} />
      <Route path="/doctors" element={<RequirePatient><DoctorsPage /></RequirePatient>} />
      <Route path="/tests" element={<RequirePatient><TestsPage /></RequirePatient>} />
      <Route path="/tests/:id" element={<RequirePatient><TestDetailPage /></RequirePatient>} />
      <Route path="/labs/:id" element={<RequirePatient><LabDetailPage /></RequirePatient>} />
      <Route path="/chat" element={<RequirePatient><ChatPage /></RequirePatient>} />
      <Route path="/tracker" element={<RequirePatient><TrackerPage /></RequirePatient>} />
      <Route path="/food" element={<RequirePatient><FoodPage /></RequirePatient>} />
      <Route path="/food/scan" element={<RequirePatient><FoodPhotoScanPage /></RequirePatient>} />
      <Route path="/food/manual" element={<RequirePatient><FoodManualLogPage /></RequirePatient>} />
      <Route path="/food/barcode" element={<RequirePatient><FoodBarcodePage /></RequirePatient>} />
      <Route path="/food/history" element={<RequirePatient><FoodHistoryPage /></RequirePatient>} />
      <Route path="/food/favorites" element={<RequirePatient><FoodFavoritesPage /></RequirePatient>} />
      <Route path="/food/settings" element={<RequirePatient><FoodSettingsPage /></RequirePatient>} />
      <Route path="/profile" element={<RequirePatient><ProfilePage /></RequirePatient>} />
      <Route path="/profile/health" element={<RequirePatient><HealthProfilePage /></RequirePatient>} />
      <Route path="/blood-donors" element={<RequirePatient><BloodDonorsPage /></RequirePatient>} />
      <Route path="/more" element={<RequirePatient><MorePage /></RequirePatient>} />
      <Route path="/symptoms" element={<RequirePatient><SymptomsPage /></RequirePatient>} />
      <Route path="/medications" element={<RequirePatient><MedicationsPage /></RequirePatient>} />
      <Route path="/records" element={<RequirePatient><RecordsPage /></RequirePatient>} />
      
      <Route path="/remedies" element={<RequirePatient><RemedySearchPage /></RequirePatient>} />
      <Route path="/medications-info" element={<RequirePatient><MedicationEncyclopediaPage /></RequirePatient>} />
      <Route path="/book/:id" element={<RequirePatient><BookDoctorPage /></RequirePatient>} />
      <Route path="/appointments" element={<RequirePatient><AppointmentsPage /></RequirePatient>} />
      <Route path="/upcoming" element={<RequirePatient><UpcomingPage /></RequirePatient>} />
      <Route path="/follow-ups" element={<RequirePatient><FollowUpsPage /></RequirePatient>} />
      <Route path="/rewards" element={<RequirePatient><RewardsPage /></RequirePatient>} />
      <Route path="/pharmacy" element={<RequirePatient><PharmacyPage /></RequirePatient>} />
      <Route path="/cart" element={<RequirePatient><CartPage /></RequirePatient>} />
      <Route path="/nhs-appointments" element={<RequirePatient><NHSAppointmentsPage /></RequirePatient>} />
      <Route path="/aesthetics" element={<RequirePatient><AestheticsPage /></RequirePatient>} />
      <Route path="/aesthetics/procedure/:id" element={<RequirePatient><ProcedureDetailPage /></RequirePatient>} />
      <Route path="/aesthetics/procedure/:id/:clinicId" element={<RequirePatient><ProcedureDetailPage /></RequirePatient>} />
      <Route path="/aesthetics/clinic/:clinicId/doctors" element={<RequirePatient><ClinicDoctorsPage /></RequirePatient>} />
      <Route path="/book-aesthetics/:clinicId/:doctorId" element={<RequirePatient><BookAestheticsConsultationPage /></RequirePatient>} />

      {/* Doctor routes */}
      <Route path="/doctor/onboarding" element={<RequireDoctor><DoctorOnboardingPage /></RequireDoctor>} />
      <Route path="/doctor/dashboard" element={<RequireDoctor><DoctorDashboardPage /></RequireDoctor>} />
      <Route path="/doctor/schedule" element={<RequireDoctor><DoctorSchedulePage /></RequireDoctor>} />
      <Route path="/doctor/patients" element={<RequireDoctor><DoctorPatientsPage /></RequireDoctor>} />
      <Route path="/doctor/messages" element={<RequireDoctor><DoctorMessagesPage /></RequireDoctor>} />
      <Route path="/doctor/analytics" element={<RequireDoctor><DoctorAnalyticsPage /></RequireDoctor>} />
      <Route path="/doctor/profile" element={<RequireDoctor><DoctorProfilePage /></RequireDoctor>} />

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <LanguageProvider>
          <CurrencyProvider>
            <CartProvider>
              <AppRoutes />
            </CartProvider>
          </CurrencyProvider>
        </LanguageProvider>
      </AuthProvider>
    </Router>
  );
}
