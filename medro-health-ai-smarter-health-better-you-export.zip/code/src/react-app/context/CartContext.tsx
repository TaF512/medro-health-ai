import { createContext, useContext, useState, ReactNode } from 'react';

export interface CartItem {
  id: string;
  type: 'test' | 'doctor';
  name: string;
  description: string;
  price: number;
  currency: string;
  quantity: number;
  labId?: string;
  labName?: string;
  doctorId?: string;
  consultationType?: string;
  homeCollection?: boolean;
  country: string;
  image?: string;
}

interface CostBreakdown {
  subtotal: number;
  serviceCharge: number; // 5% Medro service charge
  vat: number; // VAT varies by country
  carelyCommission: number; // Already included in service charge
  providerAmount: number; // What lab/doctor receives
  discount: number;
  total: number;
  currency: string;
}

interface CartContextType {
  items: CartItem[];
  couponCode: string;
  couponDiscount: number;
  addItem: (item: Omit<CartItem, 'quantity'>) => void;
  removeItem: (id: string, type: 'test' | 'doctor') => void;
  updateQuantity: (id: string, type: 'test' | 'doctor', quantity: number) => void;
  clearCart: () => void;
  applyCoupon: (code: string) => boolean;
  removeCoupon: () => void;
  getBreakdown: () => CostBreakdown;
  itemCount: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

// VAT rates by country
const vatRates: Record<string, number> = {
  BD: 0.15, // 15% VAT Bangladesh
  GB: 0.20, // 20% VAT UK
  US: 0.08, // ~8% sales tax average US
  IN: 0.18, // 18% GST India
  AE: 0.05, // 5% VAT UAE
  CA: 0.13, // 13% HST Canada
  AU: 0.10, // 10% GST Australia
  DE: 0.19, // 19% VAT Germany
  FR: 0.20, // 20% VAT France
  SA: 0.15, // 15% VAT Saudi Arabia
};

// Valid coupon codes
const validCoupons: Record<string, number> = {
  'CARELY10': 0.10, // 10% off
  'HEALTH20': 0.20, // 20% off
  'FIRSTORDER': 0.15, // 15% off
  'WELLNESS25': 0.25, // 25% off
};

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [couponCode, setCouponCode] = useState('');
  const [couponDiscount, setCouponDiscount] = useState(0);

  const addItem = (item: Omit<CartItem, 'quantity'>) => {
    setItems(prev => {
      const existingIndex = prev.findIndex(
        i => i.id === item.id && i.type === item.type && i.labId === item.labId
      );
      
      if (existingIndex >= 0) {
        const updated = [...prev];
        updated[existingIndex].quantity += 1;
        return updated;
      }
      
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const removeItem = (id: string, type: 'test' | 'doctor') => {
    setItems(prev => prev.filter(i => !(i.id === id && i.type === type)));
  };

  const updateQuantity = (id: string, type: 'test' | 'doctor', quantity: number) => {
    if (quantity <= 0) {
      removeItem(id, type);
      return;
    }
    setItems(prev => prev.map(i => 
      i.id === id && i.type === type ? { ...i, quantity } : i
    ));
  };

  const clearCart = () => {
    setItems([]);
    setCouponCode('');
    setCouponDiscount(0);
  };

  const applyCoupon = (code: string): boolean => {
    const upperCode = code.toUpperCase().trim();
    if (validCoupons[upperCode]) {
      setCouponCode(upperCode);
      setCouponDiscount(validCoupons[upperCode]);
      return true;
    }
    return false;
  };

  const removeCoupon = () => {
    setCouponCode('');
    setCouponDiscount(0);
  };

  const getBreakdown = (): CostBreakdown => {
    if (items.length === 0) {
      return {
        subtotal: 0,
        serviceCharge: 0,
        vat: 0,
        carelyCommission: 0,
        providerAmount: 0,
        discount: 0,
        total: 0,
        currency: 'GBP',
      };
    }

    // Use the first item's currency (assuming all items are same currency for simplicity)
    const currency = items[0]?.currency || 'GBP';
    const country = items[0]?.country || 'GB';
    const vatRate = vatRates[country] || 0.20;

    // Calculate subtotal
    const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    // 5% service charge (this is Medro's commission)
    const serviceCharge = Math.round(subtotal * 0.05);
    const carelyCommission = serviceCharge; // Same as service charge

    // What the provider (lab/doctor) receives
    const providerAmount = subtotal;

    // Calculate base for VAT (subtotal + service charge)
    const vatBase = subtotal + serviceCharge;
    const vat = Math.round(vatBase * vatRate);

    // Apply coupon discount to subtotal
    const discount = Math.round(subtotal * couponDiscount);

    // Total = subtotal + service charge + VAT - discount
    const total = subtotal + serviceCharge + vat - discount;

    return {
      subtotal,
      serviceCharge,
      vat,
      carelyCommission,
      providerAmount,
      discount,
      total: Math.max(0, total),
      currency,
    };
  };

  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <CartContext.Provider value={{
      items,
      couponCode,
      couponDiscount,
      addItem,
      removeItem,
      updateQuantity,
      clearCart,
      applyCoupon,
      removeCoupon,
      getBreakdown,
      itemCount,
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within CartProvider');
  }
  return context;
}
