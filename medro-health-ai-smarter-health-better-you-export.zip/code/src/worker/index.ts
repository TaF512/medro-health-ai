import { Hono } from "hono";
import { getCookie, setCookie } from "hono/cookie";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  getCurrentUser,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import { GoogleGenAI } from "@google/genai";

interface Env {
  MOCHA_USERS_SERVICE_API_URL: string;
  MOCHA_USERS_SERVICE_API_KEY: string;
  GEMINI_API_KEY?: string;
  DB: D1Database;
}

const app = new Hono<{ Bindings: Env }>();

// Barcode lookup using Open Food Facts API
app.get("/api/barcode/:code", async (c) => {
  const barcode = c.req.param("code");
  
  try {
    const response = await fetch(`https://world.openfoodfacts.org/api/v2/product/${barcode}.json`);
    const data = await response.json() as {
      status: number;
      product?: {
        product_name?: string;
        brands?: string;
        serving_size?: string;
        nutriments?: {
          'energy-kcal_100g'?: number;
          'energy-kcal_serving'?: number;
          proteins_100g?: number;
          proteins_serving?: number;
          carbohydrates_100g?: number;
          carbohydrates_serving?: number;
          fat_100g?: number;
          fat_serving?: number;
          sugars_100g?: number;
          fiber_100g?: number;
          sodium_100g?: number;
          salt_100g?: number;
        };
        image_url?: string;
        nutrition_grades?: string;
        categories_tags?: string[];
      };
    };
    
    if (data.status !== 1 || !data.product) {
      return c.json({ error: "Product not found", found: false }, 404);
    }
    
    const product = data.product;
    const nutriments = product.nutriments || {};
    
    // Prefer per-serving values, fallback to per-100g
    const calories = Math.round(nutriments['energy-kcal_serving'] || nutriments['energy-kcal_100g'] || 0);
    const protein = Math.round(nutriments.proteins_serving || nutriments.proteins_100g || 0);
    const carbs = Math.round(nutriments.carbohydrates_serving || nutriments.carbohydrates_100g || 0);
    const fat = Math.round(nutriments.fat_serving || nutriments.fat_100g || 0);
    
    // Generate health warnings based on nutrition data
    const warnings: string[] = [];
    const suggestions: string[] = [];
    
    if (nutriments.sugars_100g && nutriments.sugars_100g > 15) {
      warnings.push("High in sugar");
    }
    if (nutriments.sodium_100g && nutriments.sodium_100g > 0.6) {
      warnings.push("High in sodium");
    }
    if (nutriments.fat_100g && nutriments.fat_100g > 17.5) {
      warnings.push("High in fat");
    }
    if (nutriments.fiber_100g && nutriments.fiber_100g >= 3) {
      suggestions.push("Good source of fiber");
    }
    if (nutriments.proteins_100g && nutriments.proteins_100g >= 10) {
      suggestions.push("High in protein");
    }
    
    // Nutrition grade suggestion
    if (product.nutrition_grades) {
      const grade = product.nutrition_grades.toUpperCase();
      if (grade === 'A' || grade === 'B') {
        suggestions.push(`Nutri-Score: ${grade} (Good choice)`);
      } else if (grade === 'D' || grade === 'E') {
        warnings.push(`Nutri-Score: ${grade} (Consume in moderation)`);
      }
    }
    
    return c.json({
      found: true,
      name: product.product_name || "Unknown Product",
      brand: product.brands || "",
      servingSize: product.serving_size || "per 100g",
      calories,
      protein,
      carbs,
      fat,
      image: product.image_url || null,
      nutritionGrade: product.nutrition_grades || null,
      warnings,
      suggestions,
      details: {
        sugars: Math.round(nutriments.sugars_100g || 0),
        fiber: Math.round(nutriments.fiber_100g || 0),
        sodium: Math.round((nutriments.sodium_100g || 0) * 1000), // Convert to mg
      }
    });
  } catch (error) {
    console.error("Barcode lookup error:", error);
    return c.json({ error: "Failed to lookup barcode", found: false }, 500);
  }
});

// Get Google OAuth redirect URL
app.get("/api/oauth/google/redirect_url", async (c) => {
  const redirectUrl = await getOAuthRedirectUrl("google", {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });
  return c.json({ redirectUrl }, 200);
});

// Exchange code for session token
app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60,
  });

  return c.json({ success: true }, 200);
});

// Get current user with role from database
app.get("/api/users/me", async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);
  
  if (!sessionToken) {
    return c.json({ user: null }, 200);
  }

  try {
    const mochaUser = await getCurrentUser(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });

    if (!mochaUser) {
      return c.json({ user: null }, 200);
    }

    // Check if user exists in our database
    const { results } = await c.env.DB.prepare(
      "SELECT * FROM users WHERE mocha_user_id = ?"
    ).bind(mochaUser.id).all();

    if (results.length === 0) {
      // Create user without role - they'll select it
      await c.env.DB.prepare(
        "INSERT INTO users (mocha_user_id, email, name, avatar_url) VALUES (?, ?, ?, ?)"
      ).bind(
        mochaUser.id,
        mochaUser.email,
        mochaUser.google_user_data.name || null,
        mochaUser.google_user_data.picture || null
      ).run();

      return c.json({
        user: {
          id: mochaUser.id,
          email: mochaUser.email,
          name: mochaUser.google_user_data.name,
          avatar: mochaUser.google_user_data.picture,
          role: null,
          country: null,
        }
      }, 200);
    }

    const dbUser = results[0] as any;
    return c.json({
      user: {
        id: mochaUser.id,
        email: mochaUser.email,
        name: dbUser.name || mochaUser.google_user_data.name,
        avatar: dbUser.avatar_url || mochaUser.google_user_data.picture,
        role: dbUser.role,
        country: dbUser.country || null,
      }
    }, 200);
  } catch (error) {
    return c.json({ user: null }, 200);
  }
});

// Set user role with country
app.post("/api/users/role", authMiddleware, async (c) => {
  const user = c.get("user");
  const body = await c.req.json();
  const { role, country } = body;

  if (!role || !["patient", "doctor"].includes(role)) {
    return c.json({ error: "Invalid role" }, 400);
  }

  // Update user role and country
  await c.env.DB.prepare(
    "UPDATE users SET role = ?, country = ?, updated_at = CURRENT_TIMESTAMP WHERE mocha_user_id = ?"
  ).bind(role, country || null, user!.id).run();

  // Get user's database ID
  const { results: userResults } = await c.env.DB.prepare(
    "SELECT id FROM users WHERE mocha_user_id = ?"
  ).bind(user!.id).all();

  if (userResults.length > 0) {
    const userId = (userResults[0] as any).id;
    
    if (role === 'patient' && country) {
      // Create patient profile with country if it doesn't exist
      const { results: existing } = await c.env.DB.prepare(
        "SELECT id FROM patient_profiles WHERE user_id = ?"
      ).bind(userId).all();

      if (existing.length === 0) {
        await c.env.DB.prepare(
          "INSERT INTO patient_profiles (user_id, country) VALUES (?, ?)"
        ).bind(userId, country).run();
      } else {
        await c.env.DB.prepare(
          "UPDATE patient_profiles SET country = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?"
        ).bind(country, userId).run();
      }
    } else if (role === 'doctor' && country) {
      // Create doctor profile with country if it doesn't exist
      const { results: existing } = await c.env.DB.prepare(
        "SELECT id FROM doctor_profiles WHERE user_id = ?"
      ).bind(userId).all();

      if (existing.length === 0) {
        await c.env.DB.prepare(
          "INSERT INTO doctor_profiles (user_id, country_of_residence) VALUES (?, ?)"
        ).bind(userId, country).run();
      }
    }
  }

  return c.json({ success: true, role }, 200);
});

// Get patient profile
app.get("/api/patient/profile", authMiddleware, async (c) => {
  const user = c.get("user");
  
  // Get user record
  const { results: userResults } = await c.env.DB.prepare(
    "SELECT id FROM users WHERE mocha_user_id = ?"
  ).bind(user!.id).all();

  if (userResults.length === 0) {
    return c.json({ error: "User not found" }, 404);
  }

  const userId = (userResults[0] as any).id;

  // Get patient profile
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM patient_profiles WHERE user_id = ?"
  ).bind(userId).all();

  if (results.length === 0) {
    return c.json({ profile: null }, 200);
  }

  const profile = results[0] as any;
  return c.json({
    profile: {
      fullName: profile.full_name,
      dateOfBirth: profile.date_of_birth,
      sex: profile.sex,
      heightCm: profile.height_cm,
      weightKg: profile.weight_kg,
      bloodGroup: profile.blood_group,
      conditions: profile.conditions ? JSON.parse(profile.conditions) : [],
      allergies: profile.allergies,
      currentMedications: profile.current_medications ? JSON.parse(profile.current_medications) : [],
      emergencyContactName: profile.emergency_contact_name,
      emergencyContactPhone: profile.emergency_contact_phone,
      isBloodDonor: Boolean(profile.is_blood_donor),
      isBloodGroupPublic: Boolean(profile.is_blood_group_public),
    }
  }, 200);
});

// Save patient profile
app.post("/api/patient/profile", authMiddleware, async (c) => {
  const user = c.get("user");
  const body = await c.req.json();

  // Get user record
  const { results: userResults } = await c.env.DB.prepare(
    "SELECT id FROM users WHERE mocha_user_id = ?"
  ).bind(user!.id).all();

  if (userResults.length === 0) {
    return c.json({ error: "User not found" }, 404);
  }

  const userId = (userResults[0] as any).id;

  // Check if profile exists
  const { results: existing } = await c.env.DB.prepare(
    "SELECT id FROM patient_profiles WHERE user_id = ?"
  ).bind(userId).all();

  const conditions = body.conditions ? JSON.stringify(body.conditions) : null;
  const medications = body.currentMedications ? JSON.stringify(body.currentMedications) : null;

  if (existing.length === 0) {
    // Insert new profile
    await c.env.DB.prepare(`
      INSERT INTO patient_profiles (
        user_id, full_name, date_of_birth, sex, height_cm, weight_kg,
        blood_group, conditions, allergies, current_medications,
        emergency_contact_name, emergency_contact_phone,
        is_blood_donor, is_blood_group_public
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      userId,
      body.fullName || null,
      body.dateOfBirth || null,
      body.sex || null,
      body.heightCm || null,
      body.weightKg || null,
      body.bloodGroup || null,
      conditions,
      body.allergies || null,
      medications,
      body.emergencyContactName || null,
      body.emergencyContactPhone || null,
      body.isBloodDonor ? 1 : 0,
      body.isBloodGroupPublic ? 1 : 0
    ).run();
  } else {
    // Update existing profile
    await c.env.DB.prepare(`
      UPDATE patient_profiles SET
        full_name = ?, date_of_birth = ?, sex = ?, height_cm = ?, weight_kg = ?,
        blood_group = ?, conditions = ?, allergies = ?, current_medications = ?,
        emergency_contact_name = ?, emergency_contact_phone = ?,
        is_blood_donor = ?, is_blood_group_public = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE user_id = ?
    `).bind(
      body.fullName || null,
      body.dateOfBirth || null,
      body.sex || null,
      body.heightCm || null,
      body.weightKg || null,
      body.bloodGroup || null,
      conditions,
      body.allergies || null,
      medications,
      body.emergencyContactName || null,
      body.emergencyContactPhone || null,
      body.isBloodDonor ? 1 : 0,
      body.isBloodGroupPublic ? 1 : 0,
      userId
    ).run();
  }

  return c.json({ success: true }, 200);
});

// Blood compatibility map - who can donate TO this blood type
const BLOOD_COMPATIBILITY: Record<string, string[]> = {
  'A+': ['A+', 'A-', 'O+', 'O-'],
  'A-': ['A-', 'O-'],
  'B+': ['B+', 'B-', 'O+', 'O-'],
  'B-': ['B-', 'O-'],
  'AB+': ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'], // Universal recipient
  'AB-': ['A-', 'B-', 'AB-', 'O-'],
  'O+': ['O+', 'O-'],
  'O-': ['O-'], // Can only receive from O-
};

// Search for blood donors
app.get("/api/blood-donors", authMiddleware, async (c) => {
  const bloodGroup = c.req.query("bloodGroup");
  
  if (!bloodGroup) {
    return c.json({ error: "Blood group is required" }, 400);
  }

  // Get compatible donor blood types
  const compatibleTypes = BLOOD_COMPATIBILITY[bloodGroup] || [];
  
  if (compatibleTypes.length === 0) {
    return c.json({ donors: [] }, 200);
  }

  // Build query for compatible donors who are public and willing to donate
  const placeholders = compatibleTypes.map(() => '?').join(',');
  const query = `
    SELECT pp.full_name, pp.blood_group, u.avatar_url
    FROM patient_profiles pp
    JOIN users u ON pp.user_id = u.id
    WHERE pp.blood_group IN (${placeholders})
    AND pp.is_blood_donor = 1
    AND pp.is_blood_group_public = 1
  `;

  const { results } = await c.env.DB.prepare(query).bind(...compatibleTypes).all();

  const donors = (results as any[]).map(d => ({
    name: d.full_name || 'Anonymous',
    bloodGroup: d.blood_group,
    avatar: d.avatar_url,
    location: 'Dhaka, Bangladesh',
    phone: '07505847747',
    email: 'gggtestt@gmail.com',
  }));

  return c.json({ donors }, 200);
});

// Save doctor profile (onboarding)
app.post("/api/doctor/profile", authMiddleware, async (c) => {
  const user = c.get("user");
  const body = await c.req.json();

  // Get user's database ID
  const { results: userResults } = await c.env.DB.prepare(
    "SELECT id FROM users WHERE mocha_user_id = ?"
  ).bind(user!.id).all();

  if (userResults.length === 0) {
    return c.json({ error: "User not found" }, 404);
  }

  const userId = (userResults[0] as any).id;

  // Check if profile exists
  const { results: existing } = await c.env.DB.prepare(
    "SELECT id FROM doctor_profiles WHERE user_id = ?"
  ).bind(userId).all();

  const languages = body.languages ? JSON.stringify(body.languages) : null;
  const licensedCountries = body.licensedCountries ? JSON.stringify(body.licensedCountries) : null;
  const verificationStatus = body.scope === 'licensed_clinical' ? 'pending' : 'not_required';

  if (existing.length === 0) {
    await c.env.DB.prepare(`
      INSERT INTO doctor_profiles (
        user_id, full_name, specialty, languages, bio, 
        price_amount, price_currency, scope, licensed_countries, verification_status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      userId,
      body.fullName || null,
      body.specialty || null,
      languages,
      body.bio || null,
      body.priceAmount || 50,
      body.priceCurrency || 'GBP',
      body.scope || 'guidance_only',
      licensedCountries,
      verificationStatus
    ).run();
  } else {
    await c.env.DB.prepare(`
      UPDATE doctor_profiles SET
        full_name = ?, specialty = ?, languages = ?, bio = ?,
        price_amount = ?, price_currency = ?, scope = ?, 
        licensed_countries = ?, verification_status = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE user_id = ?
    `).bind(
      body.fullName || null,
      body.specialty || null,
      languages,
      body.bio || null,
      body.priceAmount || 50,
      body.priceCurrency || 'GBP',
      body.scope || 'guidance_only',
      licensedCountries,
      verificationStatus,
      userId
    ).run();
  }

  return c.json({ success: true }, 200);
});

// Get doctor profile
app.get("/api/doctor/profile", authMiddleware, async (c) => {
  const user = c.get("user");

  const { results: userResults } = await c.env.DB.prepare(
    "SELECT id FROM users WHERE mocha_user_id = ?"
  ).bind(user!.id).all();

  if (userResults.length === 0) {
    return c.json({ error: "User not found" }, 404);
  }

  const userId = (userResults[0] as any).id;

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM doctor_profiles WHERE user_id = ?"
  ).bind(userId).all();

  if (results.length === 0) {
    return c.json({ profile: null }, 200);
  }

  const profile = results[0] as any;
  return c.json({
    profile: {
      fullName: profile.full_name,
      photoUrl: profile.photo_url,
      specialty: profile.specialty,
      languages: profile.languages ? JSON.parse(profile.languages) : [],
      countryOfResidence: profile.country_of_residence,
      bio: profile.bio,
      priceAmount: profile.price_amount,
      priceCurrency: profile.price_currency,
      scope: profile.scope,
      licensedCountries: profile.licensed_countries ? JSON.parse(profile.licensed_countries) : [],
      verificationStatus: profile.verification_status,
      rating: profile.rating,
      totalConsultations: profile.total_consultations,
    }
  }, 200);
});

// Get all doctors (for patient browsing)
app.get("/api/doctors", async (c) => {
  const patientCountry = c.req.query("patientCountry");
  const specialty = c.req.query("specialty");
  const licensedOnly = c.req.query("licensedOnly") === 'true';

  let query = `
    SELECT dp.*, u.name as user_name, u.avatar_url, u.country as user_country
    FROM doctor_profiles dp
    JOIN users u ON dp.user_id = u.id
    WHERE u.role = 'doctor'
  `;
  const params: any[] = [];

  if (specialty) {
    query += " AND dp.specialty = ?";
    params.push(specialty);
  }

  const { results } = await c.env.DB.prepare(query).bind(...params).all();

  let doctors = (results as any[]).map(d => {
    const licensedCountries = d.licensed_countries ? JSON.parse(d.licensed_countries) : [];
    const isLicensedForPatient = patientCountry && licensedCountries.includes(patientCountry);
    
    return {
      id: d.id,
      name: d.full_name || d.user_name || 'Dr. Unknown',
      photoUrl: d.photo_url || d.avatar_url,
      specialty: d.specialty || 'General Practice',
      countryOfResidence: d.country_of_residence || d.user_country,
      bio: d.bio,
      priceAmount: d.price_amount || 50,
      priceCurrency: d.price_currency || 'GBP',
      scope: d.scope || 'guidance_only',
      licensedCountries,
      verificationStatus: d.verification_status || 'pending',
      rating: d.rating || 4.5,
      totalConsultations: d.total_consultations || 0,
      isLicensedForPatient,
    };
  });

  // Filter by licensed only if requested
  if (licensedOnly && patientCountry) {
    doctors = doctors.filter(d => d.isLicensedForPatient);
  }

  return c.json({ doctors }, 200);
});

// AI Health Chat endpoint
app.post("/api/chat", async (c) => {
  const body = await c.req.json();
  const { message, images } = body;

  if (!message && (!images || images.length === 0)) {
    return c.json({ error: "Message or images required" }, 400);
  }

  if (!c.env.GEMINI_API_KEY) {
    return c.json({ 
      response: "I apologize, but the AI service is not configured yet. Please ask the administrator to set up the GEMINI_API_KEY." 
    }, 200);
  }

  try {
    const ai = new GoogleGenAI({ apiKey: c.env.GEMINI_API_KEY });

    const systemInstruction = `You are a helpful AI health assistant for Medro Health AI, a healthcare app. Be genuinely helpful while maintaining safety.

HOW TO RESPOND TO SYMPTOMS:
When someone describes symptoms, provide helpful step-by-step guidance:
1. Acknowledge their concern with empathy
2. Explain what the symptoms COULD indicate (use phrases like "this may be", "common causes include")
3. Provide practical home care steps they can try NOW (rest, hydration, OTC remedies, diet changes, etc.)
4. List warning signs that would require immediate medical attention
5. Recommend when to see a doctor

ALWAYS END symptom discussions with: "⚠️ This information is for guidance only, not diagnosis. For proper evaluation, you can find qualified doctors in your country within the Medro Health AI app - just tap the Doctors tab to browse specialists near you."

YOUR CAPABILITIES:
- ANALYZE MEDICAL IMAGES: When users attach images of prescriptions, lab reports, X-rays, skin conditions, medication bottles, or food/nutrition labels, carefully analyze what you see and provide helpful explanations
- Explain what symptoms commonly indicate and what might help
- Provide step-by-step home remedies and self-care instructions
- Suggest diet changes, exercises, and lifestyle modifications
- Explain medical terms, test results, and reports in simple language
- Give medication information (uses, side effects, interactions)
- Offer mental health support and stress management tips

FOR IMAGE ANALYSIS:
- Describe what you observe clearly and objectively
- Explain medical terms or values shown in reports
- For prescriptions: list medications, dosages, and explain what each is typically used for
- For lab results: explain what each value means and whether it's within normal range
- For skin conditions or physical symptoms: describe what you see and common conditions that may look similar
- For food/nutrition labels: analyze nutritional content and provide dietary advice
- Always clarify that visual analysis is not a diagnosis and recommend professional consultation

SAFETY RULES:
- Never claim to diagnose - use "may indicate", "could be", "common causes"
- For emergencies (chest pain, difficulty breathing, severe bleeding, stroke signs, suicidal thoughts), tell them to call emergency services IMMEDIATELY
- Remind users that in-app doctors can provide proper consultations
- Be warm, supportive, and thorough - people come here because they need real help

IMPORTANT: Medro Health AI has licensed doctors available in multiple countries. When recommending professional help, always mention: "You can book a consultation with a doctor in your country right here in the Medro Health AI app - go to the Doctors tab to find specialists filtered by your location."`;

    // Build content parts (text + images if provided)
    const contentParts: any[] = [];
    
    // Add text message first
    const textContent = message || "Please analyze this medical image/document and provide helpful information about what you see.";
    contentParts.push({ text: textContent });
    
    // Add images if present
    if (images && images.length > 0) {
      for (const img of images) {
        contentParts.push({
          inlineData: {
            mimeType: img.mimeType,
            data: img.data,
          }
        });
      }
    }

    // Use generateContent directly for better reliability with images
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: contentParts,
      config: {
        systemInstruction,
        thinkingConfig: { thinkingBudget: 0 }
      }
    });
    
    return c.json({ response: response.text }, 200);
  } catch (error) {
    console.error("Gemini API error:", error);
    return c.json({ 
      response: "I'm having trouble connecting right now. Please try again in a moment." 
    }, 200);
  }
});

// AI Remedy Search endpoint
app.post("/api/remedy-search", async (c) => {
  const body = await c.req.json();
  const { condition } = body;

  if (!condition) {
    return c.json({ error: "Condition is required" }, 400);
  }

  if (!c.env.GEMINI_API_KEY) {
    return c.json({ error: "AI service not configured" }, 500);
  }

  try {
    const ai = new GoogleGenAI({ apiKey: c.env.GEMINI_API_KEY });

    const prompt = `You are a natural health advisor. The user is looking for natural food remedies for: "${condition}"

Provide a structured response in JSON format with this exact structure:
{
  "conditionName": "Proper name of the condition",
  "description": "Brief description of the condition (1-2 sentences)",
  "remedies": [
    {
      "food": "Name of food/remedy",
      "icon": "Single emoji representing this food",
      "benefits": "How this helps with the condition",
      "howToUse": "Practical instructions on how to consume or use"
    }
  ],
  "disclaimer": "Specific warning relevant to this condition"
}

Provide 5-8 evidence-based natural food remedies. Focus on common, accessible foods and herbs. Include practical, actionable advice.

IMPORTANT: Return ONLY valid JSON, no markdown formatting or code blocks.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: { thinkingConfig: { thinkingBudget: 0 } }
    });

    const text = response.text || "";
    // Try to extract JSON from the response
    let jsonStr = text;
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      jsonStr = jsonMatch[0];
    }
    
    const data = JSON.parse(jsonStr);
    return c.json(data, 200);
  } catch (error) {
    console.error("Remedy search error:", error);
    return c.json({ error: "Failed to search remedies" }, 500);
  }
});

// AI Food Analysis endpoint - Accurate calorie and nutrition counting
app.post("/api/analyze-food", async (c) => {
  const body = await c.req.json();
  const { image, mimeType } = body;

  if (!image) {
    return c.json({ error: "Image is required" }, 400);
  }

  if (!c.env.GEMINI_API_KEY) {
    return c.json({ error: "AI service not configured" }, 500);
  }

  try {
    const ai = new GoogleGenAI({ apiKey: c.env.GEMINI_API_KEY });

    const prompt = `You are an expert nutritionist and food recognition AI. Analyze this food image with maximum accuracy.

YOUR TASK:
1. Identify EVERY food item visible in the image - be thorough and specific
2. Estimate the portion size of each item (cups, grams, pieces, tablespoons, etc.)
3. Calculate accurate calories and macronutrients for each item
4. Sum up the total nutritional values

Respond in this exact JSON format:
{
  "items": [
    {
      "name": "Specific food name (e.g., 'White Rice' not just 'Rice')",
      "portion": "Estimated portion (e.g., '1 cup', '150g', '2 pieces')",
      "calories": 200,
      "protein": 4,
      "carbs": 45,
      "fat": 0.5
    }
  ],
  "totals": {
    "calories": 500,
    "protein": 20,
    "carbs": 60,
    "fat": 15
  },
  "mealName": "A descriptive name for the overall meal",
  "healthScore": 7,
  "warnings": ["List any health concerns like high sodium, saturated fat, etc."],
  "suggestions": ["Healthy tips related to this meal"],
  "details": "Brief nutritional analysis summary"
}

ACCURACY GUIDELINES:
- Use standard nutritional databases values (USDA, etc.)
- Account for cooking methods (fried adds oil/fat, grilled is leaner)
- Estimate portions based on plate/container size if visible
- If multiple servings are visible, calculate for what appears to be one person's portion
- Be specific: "Grilled Chicken Breast (150g)" not just "Chicken"
- Include ALL visible items including sauces, garnishes, drinks
- healthScore: 1-10 where 10 is very healthy, consider balance, processing, nutrients

IMPORTANT: Return ONLY valid JSON, no markdown formatting or code blocks.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        { text: prompt },
        {
          inlineData: {
            mimeType: mimeType || "image/jpeg",
            data: image
          }
        }
      ],
      config: {
        thinkingConfig: { thinkingBudget: 0 }
      }
    });

    const text = response.text || "";
    let jsonStr = text;
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      jsonStr = jsonMatch[0];
    }
    
    const data = JSON.parse(jsonStr);
    return c.json(data, 200);
  } catch (error) {
    console.error("Food analysis error:", error);
    return c.json({ error: "Failed to analyze food image" }, 500);
  }
});

// AI Symptom Analysis endpoint
app.post("/api/symptom-analysis", async (c) => {
  const body = await c.req.json();
  const { symptoms } = body;

  if (!symptoms || !Array.isArray(symptoms) || symptoms.length === 0) {
    return c.json({ error: "Symptoms array is required" }, 400);
  }

  if (!c.env.GEMINI_API_KEY) {
    return c.json({ error: "AI service not configured" }, 500);
  }

  try {
    const ai = new GoogleGenAI({ apiKey: c.env.GEMINI_API_KEY });

    const prompt = `You are a medical information assistant (NOT a doctor). The user reports these symptoms: ${symptoms.join(", ")}

Analyze these symptoms and provide a structured response in JSON format:
{
  "severity": "low" | "moderate" | "high",
  "possibleConditions": ["Condition 1", "Condition 2", "Condition 3"],
  "explanation": "Brief explanation of why these conditions might be related to the symptoms",
  "recommendations": [
    "Specific actionable recommendation 1",
    "Specific actionable recommendation 2",
    "Specific actionable recommendation 3",
    "Specific actionable recommendation 4"
  ],
  "warningSign": ["Signs that require immediate medical attention"],
  "seeDoctor": true/false,
  "urgency": "Description of when to see a doctor",
  "homeRemedies": ["Practical home care steps"]
}

RULES:
- Use "may indicate", "could suggest", "commonly associated with" - never diagnose
- severity should be "high" if any symptoms could indicate emergency (chest pain, difficulty breathing, severe bleeding, etc.)
- seeDoctor should be true if symptoms persist more than a few days or are severe
- Provide practical, actionable home care advice
- List specific warning signs that need immediate attention

IMPORTANT: Return ONLY valid JSON, no markdown formatting or code blocks.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: { thinkingConfig: { thinkingBudget: 0 } }
    });

    const text = response.text || "";
    let jsonStr = text;
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      jsonStr = jsonMatch[0];
    }
    
    const data = JSON.parse(jsonStr);
    return c.json(data, 200);
  } catch (error) {
    console.error("Symptom analysis error:", error);
    return c.json({ error: "Failed to analyze symptoms" }, 500);
  }
});

// AI Medication Information endpoint
app.post("/api/medication-info", async (c) => {
  const body = await c.req.json();
  const { medication } = body;

  if (!medication) {
    return c.json({ error: "Medication name is required" }, 400);
  }

  if (!c.env.GEMINI_API_KEY) {
    return c.json({ error: "AI service not configured" }, 500);
  }

  try {
    const ai = new GoogleGenAI({ apiKey: c.env.GEMINI_API_KEY });

    const prompt = `You are a pharmacist providing medication information. The user is asking about: "${medication}"

Provide comprehensive information in JSON format:
{
  "name": "Generic name of the medication",
  "brandNames": ["Common brand names"],
  "drugClass": "Classification of the drug",
  "description": "Brief description of what this medication is",
  "uses": [
    "Primary use 1",
    "Primary use 2"
  ],
  "benefits": [
    "Key benefit 1",
    "Key benefit 2",
    "Key benefit 3"
  ],
  "sideEffects": {
    "common": ["Common side effect 1", "Common side effect 2"],
    "serious": ["Serious side effect requiring medical attention"]
  },
  "longTermEffects": [
    "Effect of long-term use 1",
    "Effect of long-term use 2",
    "Potential risks with extended use"
  ],
  "dosageInfo": "General dosage information",
  "interactions": ["Drug/food interactions to be aware of"],
  "precautions": ["Who should avoid or use with caution"],
  "naturalAlternatives": ["Natural alternatives that may help with similar conditions"],
  "disclaimer": "Important safety disclaimer"
}

Provide accurate, balanced information including both benefits and risks. Be especially detailed about long-term consumption effects.

IMPORTANT: Return ONLY valid JSON, no markdown formatting or code blocks.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: { thinkingConfig: { thinkingBudget: 0 } }
    });

    const text = response.text || "";
    let jsonStr = text;
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      jsonStr = jsonMatch[0];
    }
    
    const data = JSON.parse(jsonStr);
    return c.json(data, 200);
  } catch (error) {
    console.error("Medication info error:", error);
    return c.json({ error: "Failed to get medication info" }, 500);
  }
});

// AI Health Recommendations endpoint
app.post("/api/health-recommendations", async (c) => {
  const body = await c.req.json();
  const { stats } = body;

  if (!c.env.GEMINI_API_KEY) {
    return c.json({ error: "AI service not configured" }, 500);
  }

  try {
    const ai = new GoogleGenAI({ apiKey: c.env.GEMINI_API_KEY });

    const prompt = `You are a health coach AI. Based on the user's daily health stats, provide personalized recommendations.

User's stats:
- Water intake: ${stats?.waterIntake || 0}ml (goal: 2500ml)
- Steps: ${stats?.steps || 0} (goal: 10000)
- Sleep: ${stats?.sleepHours || 0} hours (goal: 8)
- Calories consumed: ${stats?.caloriesConsumed || 0}
- Supplements taken today: ${stats?.supplements?.join(', ') || 'None'}

Provide 5-6 personalized, actionable recommendations in JSON format:
{
  "recommendations": [
    {
      "id": "unique_id",
      "type": "water|food|exercise|sleep|supplement",
      "title": "Short action title",
      "description": "Specific, personalized advice based on their stats",
      "priority": "high|medium|low"
    }
  ]
}

Make recommendations specific to their current stats. For example:
- If water intake is low, recommend drinking water
- If steps are below goal, suggest a specific walk duration
- If they haven't taken certain supplements, remind them
- Give meal suggestions based on time of day and calorie intake

IMPORTANT: Return ONLY valid JSON, no markdown formatting or code blocks.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: { thinkingConfig: { thinkingBudget: 0 } }
    });

    const text = response.text || "";
    let jsonStr = text;
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      jsonStr = jsonMatch[0];
    }
    
    const data = JSON.parse(jsonStr);
    return c.json(data, 200);
  } catch (error) {
    console.error("Health recommendations error:", error);
    return c.json({ error: "Failed to get recommendations" }, 500);
  }
});

// AI Lab Result Analysis endpoint
app.post("/api/analyze-lab-result", async (c) => {
  const body = await c.req.json();
  const { testName, results } = body;

  if (!testName || !results) {
    return c.json({ error: "Test name and results are required" }, 400);
  }

  if (!c.env.GEMINI_API_KEY) {
    return c.json({ error: "AI service not configured" }, 500);
  }

  try {
    const ai = new GoogleGenAI({ apiKey: c.env.GEMINI_API_KEY });

    const prompt = `You are a medical lab result interpreter. Analyze the following lab test results and provide a patient-friendly explanation.

Test: ${testName}
Results: ${JSON.stringify(results)}

Provide analysis in JSON format:
{
  "summary": "Brief overall summary of results",
  "findings": [
    {
      "parameter": "Name of the measured parameter",
      "value": "The value",
      "status": "normal|low|high|critical",
      "explanation": "What this means in simple terms",
      "recommendation": "What the patient should do or know"
    }
  ],
  "overallStatus": "normal|attention|concern",
  "lifestyleAdvice": ["Specific lifestyle recommendations based on results"],
  "followUp": "Recommendation for follow-up if needed",
  "disclaimer": "This is for informational purposes only. Always consult your doctor for medical advice."
}

Be encouraging but honest. Explain medical terms simply. If any values are concerning, recommend consulting a doctor.

IMPORTANT: Return ONLY valid JSON, no markdown formatting or code blocks.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: { thinkingConfig: { thinkingBudget: 0 } }
    });

    const text = response.text || "";
    let jsonStr = text;
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      jsonStr = jsonMatch[0];
    }
    
    const data = JSON.parse(jsonStr);
    return c.json(data, 200);
  } catch (error) {
    console.error("Lab result analysis error:", error);
    return c.json({ error: "Failed to analyze results" }, 500);
  }
});

// Logout
app.get("/api/logout", async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === "string") {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, "", {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

export default app;
